from pathlib import Path
import os, subprocess, json, signal, sys
out=Path(__file__).parent;tool=Path('/var/tmp/sparkling-matrix-recovery/toolchains')
env=os.environ.copy();env['PATH']=':'.join(str(next((tool/t).glob('*/bin'))) for t in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
for name,line in [('fixed-position-final',41)]:
 cmd=['gnatprove','-P',str(out/'proof.gpr'),'-u','mj-data-pipeline.adb','--limit-subp=mj-data-pipeline.adb:'+str(line),'--level=0','--proof=per_check','--timeout=3','--prover=cvc5,altergo','-j2','--checks-as-errors=on','--report=all','--counterexamples=off']
 (out/(name+'.command.json')).write_text(json.dumps(cmd,indent=2))
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:r=p.wait(timeout=180)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);r=p.wait();f.write('\nWall-time cap180s reached\n')
 (out/(name+'.exit')).write_text(str(r))
 print(name,r,flush=True);print((out/(name+'.log')).read_text()[-20000:],flush=True)
 g=out/'proof-obj/gnatprove/mj-data-pipeline.spark'
 if g.exists(): (out/(name+'.spark.json')).write_bytes(g.read_bytes())
