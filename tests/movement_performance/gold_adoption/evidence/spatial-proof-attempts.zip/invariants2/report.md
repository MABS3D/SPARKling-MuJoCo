# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-x11knezx/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prepare` | `mj-data-spatial.adb:8` | [unproved_checks](logs/mj-data-spatial__prepare__adb_8.log) | 135 | 117 | 0 | 71.3 |

## Diagnostics

### mj-data-spatial__prepare__adb_8

- `mj-data-spatial.adb:22` (medium): range check might fail, cannot prove lower bound for D.Nb [reason for check: default component value must fit in the type] [provers reached step limit before completing the proof]
- `mj-data-spatial.adb:24` (medium): length check might fail [reason for check: array must be of the appropriate length] [provers reached step limit before completing the proof]
- `mj-data-spatial.adb:29` (medium): loop invariant might fail in first iteration, cannot prove Stable_Ready (D) [provers reached step limit before completing the proof]
- `mj-data-spatial.adb:29` (medium): in inlined expression function body at mj-data.ads:637
- `mj-data-spatial.adb:29` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Stable_Ready (D) [provers reached step limit before completing the proof]
- `mj-data-spatial.adb:32` (medium): loop invariant might fail in first iteration, cannot prove V (0) in -Limit .. Limit [provers reached step limit before completing the proof]
- `mj-data-spatial.adb:32` (medium): in inlined expression function body at mj-smooth_math.ads:19
- `mj-data-spatial.adb:32` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove V (0) in -Limit .. Limit [provers reached step limit before completing the proof]
- 109 more diagnostics in the individual log.

