# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-py9h8cbg/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Reset` | `mj-data.adb:1121` | [unproved_checks](logs/mj-data__reset__adb_1121.log) | 43 | 2 | 0 | 83.9 |

## Diagnostics

### mj-data__reset__adb_1121

- `mj-data.adb:1161` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data.ads:123` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached time and memory limit before completing the proof]

