# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-l1tdhx4g/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Allocated_Not_Empty` | `mj-data.adb:1092` | [completed_no_unproved](logs/mj-data__prove_allocated_not_empty__adb_1092.log) | 1 | 0 | 0 | 20.8 |
| `Reset` | `mj-data.adb:1100` | [unproved_checks](logs/mj-data__reset__adb_1100.log) | 39 | 1 | 0 | 59.6 |

## Diagnostics

### mj-data__reset__adb_1100

- `mj-data.ads:119` (medium): postcondition might fail, cannot prove Time (D) = 0.0 [provers reached time and memory limit before completing the proof]

