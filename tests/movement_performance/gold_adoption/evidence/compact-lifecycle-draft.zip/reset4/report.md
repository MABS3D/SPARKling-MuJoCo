# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-n5fbozhf/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Establish_Reset_State` | `mj-data.adb:1108` | [unproved_checks](logs/mj-data__establish_reset_state__adb_1108.log) | 8 | 7 | 0 | 45.9 |
| `Reset` | `mj-data.adb:1122` | [unproved_checks](logs/mj-data__reset__adb_1122.log) | 41 | 1 | 0 | 66.4 |

## Diagnostics

### mj-data__establish_reset_state__adb_1108

- `mj-data.adb:1111` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1111` (medium): array index check might fail [reason for check: value must be a valid index into the array] [provers reached time limit before completing the proof]
- `mj-data.adb:1111` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1111` (medium): array index check might fail [reason for check: value must be a valid index into the array] [provers reached time limit before completing the proof]
- `mj-data.adb:1112` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1113` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1114` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]

### mj-data__reset__adb_1122

- `mj-data.ads:123` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached time and memory limit before completing the proof]

