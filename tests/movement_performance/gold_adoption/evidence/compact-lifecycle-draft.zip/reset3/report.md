# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4icqm3x9/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Allocated_Not_Empty` | `mj-data.adb:1092` | [completed_no_unproved](logs/mj-data__prove_allocated_not_empty__adb_1092.log) | 1 | 0 | 0 | 18.6 |
| `Prove_Zero_Time` | `mj-data.adb:1100` | [completed_no_unproved](logs/mj-data__prove_zero_time__adb_1100.log) | 1 | 0 | 0 | 6.8 |
| `Reset` | `mj-data.adb:1108` | [unproved_checks](logs/mj-data__reset__adb_1108.log) | 40 | 2 | 0 | 57.1 |

## Diagnostics

### mj-data__reset__adb_1108

- `mj-data.ads:121` (medium): postcondition might fail, cannot prove D.State.Qpos (J) = D.Joint_Config (J).Reference [provers reached time and memory limit before completing the proof]
- `mj-data.ads:121` (medium): in inlined expression function body at mj-data.ads:738

