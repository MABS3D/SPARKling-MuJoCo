# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-6pli8iip/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Establish_Reset_State` | `mj-data.adb:1108` | [completed_no_unproved](logs/mj-data__establish_reset_state__adb_1108.log) | 8 | 0 | 0 | 23.0 |
| `Reset` | `mj-data.adb:1121` | [unproved_checks](logs/mj-data__reset__adb_1121.log) | 41 | 1 | 0 | 70.8 |

## Diagnostics

### mj-data__reset__adb_1121

- `mj-data.ads:123` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached time and memory limit before completing the proof]

