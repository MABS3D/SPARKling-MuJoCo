# Compact lifecycle proof preparation — NOT adopted

Active mass remains dense. Isolated source starts from the existing compact
verification candidate, with current accepted pose source and static proof cuts.
Reset's latest complete invocation emits43 proof checks with one remaining
Configuration preservation obligation. The selected spec-line retry emitted
zero proof checks and is NOT a pass. Small null-body lemmas for nonempty/time
and Establish_Reset_State close; they do not close Reset.

Build_Topology was refactored to read-only dimension/configuration arguments and
mutable Topology/Ancestors only: its previous whole-Simulation contract omitted
frame facts needed by Initialize's buffer allocations. The narrowed interface is
still a DRAFT: whole Build_Topology and Initialize attempts timed out with zero
checks. No runtime or lifecycle change from this tree is active. No timeout is
a mathematical limitation permitting a Silver completion claim.

Each report manifest freezes its exact sources and command. Source snapshots
for successful/failed attempts are included under snapshots/<run>. The final
source tree differs from earlier attempt snapshots; do not combine them as one
whole-unit proof. Current final diff against compact verification is in
lifecycle-draft.patch.
