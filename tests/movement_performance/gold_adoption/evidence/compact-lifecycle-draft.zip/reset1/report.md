# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-a57fyi02/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Reset` | `mj-data.adb:1092` | [unproved_checks](logs/mj-data__reset__adb_1092.log) | 37 | 9 | 0 | 77.4 |

## Diagnostics

### mj-data__reset__adb_1092

- `mj-data.adb:1117` (medium): assertion might fail, cannot prove Stable_Ready (D) [provers reached time limit before completing the proof]
- `mj-data.adb:1117` (medium): in inlined expression function body at mj-data.ads:638
- `mj-data.adb:1118` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1120` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1121` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1122` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1123` (medium): assertion might fail, cannot prove D.State.Qpos (J) = D.Joint_Config (J).Reference [provers reached time limit before completing the proof]
- `mj-data.adb:1123` (medium): in inlined expression function body at mj-data.ads:738
- 1 more diagnostics in the individual log.

