# Configuration_Image — closed exact ghost-model refactoring

Only mj-data.ads/adb are in this patch. No active repository file was modified. All added model functions and the equivalence lemma are Ghost Static; the executable configuration/state storage and runtime procedures are unchanged.

Configuration now delegates its snapshot construction to a ghost Configuration_Image taking only scalar configuration values and readonly body/joint/actuator parameter arrays. The constructor is an expression function opaque by default through documented Hide_Info. Its definition is opened only in the equivalence lemma. Legacy_Configuration retains the exact original total expression, including its empty-snapshot fallback; legacy-formula-continuity.json verifies the unchanged expression bytes.

No precondition was added to public Configuration. The constructor's private length preconditions prevent Natural conversion overflow for arbitrary standalone arrays; both calls in total Configuration are proved to meet them. Prove_Configuration_Equivalence has no precondition, so it proves equality to the former expression for every well-typed Simulation, including incomplete/empty states. No Assume, suppressed check, changed equality operator or trusted body was added.

Closed scoped proof results:

| Target | Proof checks | Open/errors |
|---|---:|---:|
| Configuration_Image |9|0/0|
| Legacy_Configuration |12|0/0|
| Configuration |13|0/0|
| Prove_Configuration_Equality |28|0/0|
| Prove_Configuration_Equivalence |2|0/0|

64 distinct checks. These establish the ghost-model refactoring only. They do not close caller frame proofs, the original CRB producer, or the complete dynamics. The separate Try_CRB_Publication wrapper trial remains open: 5 proof checks, 4 proved and 1 timeout reported on Configuration(D)=Configuration(D)'Old (proof-crb-publication-image, 75.0 seconds). Splitting its equivalent Static postconditions did not close it (73.3 seconds). Full wrapper diagnostics and source linkage are archived in /var/tmp/sparkling-mass-publication-integration/handoff-split-publication; no caller benefit or global adoption is claimed. No performance gain is attributed to a ghost-model change.

proofs.zip contains exact commands, raw logs, structured results and manifests for the successful model/equivalence runs and rejected initial type-check attempts. proof-source-objects.zip preserves their complete immutable inputs by SHA256. Source snapshots include an isolated runtime-publication candidate; that candidate is not part of configuration-image.patch. Apply only the two-file patch when testing the model independently in another clone, preserving that clone's other changes.

Reproduce with prove_fragments.py, the recorded toolchain root, level0, cvc5,z3, timeout3, steps0, jobs1. Run the model functions first, then Prove_Configuration_Equality and Prove_Configuration_Equivalence. Each archived manifest includes the exact command arguments and source mapping.
