# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-mstv0n_s/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 129` | `mj-data-forces_phase.adb:129` | [unproved_checks](logs/mj-data-forces_phase__adb_line_129.log) | 2 | 2 | 0 | 46.5 |

## Diagnostics

### mj-data-forces_phase__adb_line_129

- `mj-data-forces_phase.adb:150` (medium): "Bias" might not be initialized
- `mj-data-forces_phase.adb:149` (medium): "Gravity" might not be initialized

