package MJ.Data.Force_Boundary_Checks is
   procedure Check (D : in out Simulation);
end MJ.Data.Force_Boundary_Checks;
