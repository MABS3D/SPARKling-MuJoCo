# Proven redundant damping rejection, 2026-09-26

Follow-up to the isolated minimal damping kernel. No active repository changes by this agent.

## Result

1. Keep the original checked body and strengthen only its postcondition with `Accepted`. The complete scalar subprogram proves **15/15** on the unchanged input domain: factor entries in Work_Real (+/-1e60), step and damping in Nonneg_Tier0 (0..1e10). Evidence: damping-always-accepted/.
2. Replace the numeric rejection with the same multiply-then-add, a direct store, and `Accepted := True`. Retain all original exact/value/frame/acceptance postconditions plus the proved acceptance guarantee. The **complete Solver_Kernels unit proves116/116**, zero open/errors, cvc5+altergo3s,steps0,level0,jobs2,22.6s. Evidence: damping-no-rejection-complete/.

No assumptions, suppressions, extra trusted bodies or stronger preconditions were introduced. These are proofs of the floating-point operations, not a real-arithmetic substitution. Nonnegative product is at most1e20; even at the upper factor bound the rounded sum remains within Work_Real. This fact is now proved by GNATprove rather than taken as an assertion/assumption.

The helper's Inline_Always and constant True result allow the existing caller rejection branch to be removed by compilation. The existing public validation, layout checks, error policy and other solver checks are unchanged. Numerical/build/performance validation remains root's next step; this agent has not measured the candidate.

## Files

- bounded-source/: complete isolated candidate source.
- no-rejection-over-minimal.patch: incremental2-file change on top of minimal-damping-kernel.patch.
- damping-without-rejection.patch: complete3-file change from the original source state (Solver_Kernels spec/body plus the original loader scalar expression replaced by the helper call).
- damping-range-evidence.zip: both new proof attempts, exact source objects, final changed source files, these patches and this note.
- range-archive-manifest.json: archive hash and continuity checks.

The unchanged new helper precondition was already proved at the loader callsite in minimal-damping-callsite/ (1/1). That callsite proof remains a modular result under the loader contract and loop invariants. This does not close the entire loader, Solve_Acceleration, Solve_Euler, or the remaining Phase_Ready scan removal. Their pending proof work remains documented in README.md and the first handoff archive.
