# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-mop3tv2g/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 289` | `mj-data-spatial.adb:289` | [unproved_checks](logs/mj-data-spatial__adb_line_289.log) | 2 | 1 | 0 | 36.7 |
| `line 257` | `mj-data-spatial.adb:257` | [completed_no_proof_checks](logs/mj-data-spatial__adb_line_257.log) | 0 | 0 | 0 | 19.8 |
| `line 282` | `mj-data-spatial.adb:282` | [proof_timeout](logs/mj-data-spatial__adb_line_282.log) | 0 | 0 | 0 | 45.1 |
| `line 283` | `mj-data-spatial.adb:283` | [completed_no_unproved](logs/mj-data-spatial__adb_line_283.log) | 4 | 0 | 0 | 20.4 |
| `line 285` | `mj-data-spatial.adb:285` | [completed_no_unproved](logs/mj-data-spatial__adb_line_285.log) | 2 | 0 | 0 | 18.1 |

## Diagnostics

### mj-data-spatial__adb_line_289

- `mj-data-spatial.adb:289` (medium): precondition might fail, cannot prove Target (I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]

