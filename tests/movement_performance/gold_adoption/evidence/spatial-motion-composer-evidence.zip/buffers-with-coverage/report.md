# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-08a7cwjp/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Buffers` | `mj-data-spatial.adb:228` | [unproved_checks](logs/mj-data-spatial__build_buffers__adb_228.log) | 68 | 1 | 0 | 67.1 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_228

- `mj-data-spatial.adb:294` (medium): precondition might fail, cannot prove Target (I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]

