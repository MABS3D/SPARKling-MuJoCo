# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-h0mmjntg/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Expose_Motion_Direction` | `mj-data-spatial.adb:110` | [completed_no_unproved](logs/mj-data-spatial__expose_motion_direction__adb_110.log) | 4 | 0 | 0 | 16.6 |
| `Build_Buffers` | `mj-data-spatial.adb:120` | [unproved_checks](logs/mj-data-spatial__build_buffers__adb_120.log) | 88 | 3 | 0 | 67.1 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_120

- `mj-data-spatial.adb:149` (medium): postcondition might fail, cannot prove X in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:159` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:176` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]

