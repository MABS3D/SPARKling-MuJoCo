with MJ.Spatial_Kernels;
with MJ.Spatial_Storage;
with MJ.Smooth_Topology;

package body MJ.Data.Spatial with SPARK_Mode is
   package SK renames MJ.Spatial_Kernels;
   package SS renames MJ.Spatial_Storage;
   package T renames MJ.Smooth_Topology;
   type Vector_Array is array (Natural range <>) of Vector;

   procedure Add_Moment (Target : in out Vector; Source : Vector; Ok : out Boolean)
     with Global => null,
     Pre => Bounded (Target, 1.0e24) and then Bounded (Source, 1.0e24),
     Post => Bounded (Target, 1.0e24)
       and then Ok = Bounded (Target'Old + Source, 1.0e24)
       and then Target = (if Ok then Target'Old + Source else Target'Old)
   is
      Sum : constant Vector := Target + Source;
   begin
      Ok := Bounded (Sum, 1.0e24);
      if Ok then Target := Sum; end if;
   end Add_Moment;
   pragma Inline_Always (Add_Moment);

   procedure Root_Center
     (Mass : Real; Moment, Body_Center : Vector; Value : out Vector; Ok : out Boolean)
     with Global => null,
     Pre => Mass in 0.0 .. 1.0e14 and then Bounded (Moment, 1.0e24)
       and then Bounded (Body_Center, Max_Val),
     Post => Bounded (Value, 1.0e40)
       and then Ok = Bounded (Value, Max_Val)
       and then Value = (if Mass < Min_Val then Body_Center else (1.0 / Mass) * Moment)
   is
   begin
      Value := (if Mass < Min_Val then Body_Center else (1.0 / Mass) * Moment);
      Ok := Bounded (Value, Max_Val);
   end Root_Center;
   pragma Inline_Always (Root_Center);

   procedure Set_Moment
     (Target : in out Vector_Array; Index : Natural; Mass : Nonneg_Tier0; Position : Vector)
     with Global => null,
     Pre => Index in Target'Range
       and then (for all K in Target'Range => Bounded (Target (K), 1.0e24))
       and then Bounded (Position, Max_Val),
     Post => (for all K in Target'Range => Bounded (Target (K), 1.0e24))
       and then Target (Index) = SK.Mass_Moment (Mass, Position)
       and then (for all K in Target'Range =>
         (if K /= Index then Target (K) = Target'Old (K)))
   is
   begin
      Target (Index) := SK.Mass_Moment (Mass, Position);
   end Set_Moment;
   pragma Inline_Always (Set_Moment);

   procedure Build_Centers
     (Config : Body_Parameter_Array; Poses : Body_State_Array;
      Topology : T.Cache; Center : out Vector_Array; Ok : out Boolean)
     with Global => null,
     Pre => Config'First = 0 and then Config'Length in 1 .. Max_Bodies
       and then Poses'First = 0 and then Poses'Last = Config'Last
       and then Center'First = 0 and then Center'Last = Config'Last
       and then Int64 (T.Body_Count (Topology)) = Int64 (Config'Length)
       and then (for all B in 1 .. Config'Last => Config (B).Parent < B),
     Post => (for all K in Center'Range => Bounded (Center (K), Max_Val))
       and then Center (0) = Zero
       and then (if Ok then (for all B in 1 .. Config'Last => Bounded (Poses (B).Center, Max_Val)))
   is
      Moment : Vector_Array (Config'Range) := [others => Zero];
   begin
      Ok := False;
      Center := [others => Zero];
      for B in 1 .. Config'Last loop
         if not Bounded (Poses (B).Center, Max_Val) then return; end if;
         Set_Moment (Moment, B, Config (B).Mass, Poses (B).Center);
         pragma Loop_Invariant (for all K in Moment'Range => Bounded (Moment (K), 1.0e24));
         pragma Loop_Invariant (for all K in 1 .. B => Bounded (Poses (K).Center, Max_Val));
      end loop;
      for B in reverse 1 .. Config'Last loop
         pragma Loop_Invariant (for all K in Moment'Range => Bounded (Moment (K), 1.0e24));
         declare
            P : constant Natural := Config (B).Parent;
            Accepted : Boolean;
            Child : constant Vector := Moment (B);
         begin
            if P > 0 then
               Add_Moment (Moment (P), Child, Accepted);
               if not Accepted then return; end if;
            end if;
         end;
      end loop;
      for B in 1 .. Config'Last loop
         pragma Loop_Invariant (for all K in Center'Range => Bounded (Center (K), Max_Val));
         if T.Root (Topology, B) = B then
            declare
               Mass : constant Real := T.Subtree_Mass (Topology, B);
               Value : Vector;
               Accepted : Boolean;
            begin
               Root_Center (Mass, Moment (B), Poses (B).Center, Value, Accepted);
               if not Accepted then return; end if;
               Center (B) := Value;
            end;
         end if;
      end loop;
      Ok := True;
   end Build_Centers;
   pragma Inline_Always (Build_Centers);

   procedure Expose_Motion_Direction (Poses : Joint_State_Array; Index : Natural)
     with Ghost => Static, Global => null,
     Pre => Index in Poses'Range
       and then (for all P of Poses => Bounded (P.Direction, 2.0)),
     Post => Bounded (Poses (Index).Direction, 2.0)
   is
   begin
      null;
   end Expose_Motion_Direction;

   procedure Build_Buffers
     (Config : Body_Parameter_Array; Joints : Joint_Parameter_Array;
      Poses : Body_State_Array; Joint_Poses : Joint_State_Array;
      Topology : T.Cache; Center : Vector_Array;
      Inertias, Motions : in out Real_Array; Ok : out Boolean)
     with Global => null,
     Pre => Config'First = 0 and then Config'Length in 1 .. Max_Bodies
       and then Joints'First = 0 and then Joints'Length <= Max_Dofs
       and then Poses'First = 0 and then Poses'Last = Config'Last
       and then Joint_Poses'First = 0 and then Joint_Poses'Last = Joints'Last
       and then Center'First = 0 and then Center'Last = Config'Last
       and then Int64 (T.Body_Count (Topology)) = Int64 (Config'Length)
       and then Inertias'First = 0 and then Inertias'Last = 10 * Config'Length - 1
       and then Motions'First = 0 and then Motions'Last = 6 * Joints'Length - 1
       and then (for all B in Center'Range => Bounded (Center (B), Max_Val))
       and then (for all B in 1 .. Config'Last =>
         Bounded (Poses (B).Center, Max_Val)
         and then Bounded (Poses (B).Inertial_Rotation, 16.0)
         and then Bounded (Config (B).Inertia, Max_Val)
         and then Config (B).Joint_Count <= Joints'Length
         and then (if Config (B).Joint_Count > 0 then Config (B).First_Joint >= 0
           and then Config (B).First_Joint <= Joints'Length - Config (B).Joint_Count))
       and then (for all P of Joint_Poses => Bounded (P.Direction, 2.0))
       and then (for all J in Joints'Range => Joints (J).Body_Id in 1 .. Config'Last
         and then Config (Joints (J).Body_Id).Joint_Count > 0
         and then J in Config (Joints (J).Body_Id).First_Joint ..
           Config (Joints (J).Body_Id).First_Joint + Config (Joints (J).Body_Id).Joint_Count - 1),
     Post => (if Ok then
       (for all X of Inertias => X in -1.0e36 .. 1.0e36)
       and then (for all X of Motions => X in -1.0e12 .. 1.0e12))
   is
   begin
      Ok := False;
      SS.Store_Inertia (Inertias, 0, [others => 0.0]);
      for B in 1 .. Config'Last loop
         pragma Loop_Invariant (Static => (for all I in 0 .. 10 * B - 1 =>
           Inertias (I) in -1.0e36 .. 1.0e36));
         pragma Loop_Invariant (Static => (for all I in Motions'Range =>
           (if Joints (I / 6).Body_Id < B then
             Motions (I) in -1.0e12 .. 1.0e12)));
         declare
            C : constant Body_Parameters := Config (B);
            Origin : constant Vector := Center (T.Root (Topology, B));
            Offset : constant Vector := SK.Frame_Offset (Poses (B).Center, Origin);
         begin
            SS.Store_Inertia (Inertias, 10 * B, SK.Make_Inertia
              (Poses (B).Inertial_Rotation, C.Inertia, C.Mass, Offset));
            pragma Assert (Static => (for all I in 0 .. 10 * (B + 1) - 1 =>
              Inertias (I) in -1.0e36 .. 1.0e36));
            for K in 0 .. C.Joint_Count - 1 loop
               pragma Loop_Invariant (Static => Bounded (Origin, Max_Val));
               pragma Loop_Invariant (Static => (for all I in 0 .. 10 * (B + 1) - 1 =>
                 Inertias (I) in -1.0e36 .. 1.0e36));
               pragma Loop_Invariant (Static => (for all I in Motions'Range =>
                 (if Motions'Loop_Entry (I) in -1.0e12 .. 1.0e12 then
                   Motions (I) in -1.0e12 .. 1.0e12)));
               pragma Loop_Invariant (Static => (for all I in
                 6 * C.First_Joint .. 6 * (C.First_Joint + K) - 1 =>
                   Motions (I) in -1.0e12 .. 1.0e12));
               declare
                  J : constant Natural := C.First_Joint + K;
                  Joint : constant Joint_Parameters := Joints (J);
                  Pose : constant Joint_State := Joint_Poses (J);
               begin
                  if not Bounded (Pose.Anchor, Max_Val) then return; end if;
                  pragma Assert (Static => Bounded (Origin, Max_Val));
                  Expose_Motion_Direction (Joint_Poses, J);
                  pragma Assert (Static => Bounded (Pose.Direction, 2.0));
                  SS.Store_Motion (Motions, 6 * J, SK.Joint_Motion
                    (Pose.Direction, SK.Frame_Offset (Origin, Pose.Anchor), Joint.Kind = Hinge_Joint));
               end;
            end loop;
            pragma Assert (Static => (for all I in Motions'Range =>
              (if Joints (I / 6).Body_Id <= B then
                Motions (I) in -1.0e12 .. 1.0e12)));
         end;
      end loop;
      Ok := True;
   end Build_Buffers;
   pragma Inline_Always (Build_Buffers);

   procedure Expose_Stable_Ready (D : Simulation) with Ghost => Static,
     Global => null, Pre => Stable_Ready (D),
     Post => Storage_Ready (D) and then Configuration_Bounded (D)
       and then Configuration_Valid (D.Body_Config.all, D.Joint_Config.all,
         D.Actuator_Config.all, D.Nb, D.Nj, D.Na)
   is
   begin
      null;
   end Expose_Stable_Ready;

   procedure Establish_Stable_Ready (D : Simulation) with Ghost => Static,
     Global => null,
     Pre => Storage_Ready (D) and then Configuration_Bounded (D)
       and then Configuration_Valid (D.Body_Config.all, D.Joint_Config.all,
         D.Actuator_Config.all, D.Nb, D.Nj, D.Na),
     Post => Stable_Ready (D)
   is
   begin
      null;
   end Establish_Stable_Ready;

   procedure Expose_Spatial_Layout (D : Simulation)
     with Ghost => Static, Global => null, Pre => Storage_Ready (D),
     Post => D.Kinematic.Spatial_Inertias /= null
       and then D.Kinematic.Spatial_Inertias'First = 0
       and then D.Kinematic.Spatial_Inertias'Last = 10 * D.Nb - 1
       and then D.Kinematic.Spatial_Motions /= null
       and then D.Kinematic.Spatial_Motions'First = 0
       and then D.Kinematic.Spatial_Motions'Last = 6 * D.Nj - 1
   is
   begin
      null;
   end Expose_Spatial_Layout;

   procedure Prepare (D : in out Simulation; Ok : out Boolean) is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Unit_Quaternion);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Unit_Vector);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Stable_Ready);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Has_Real_Layout);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Array_Bounded);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Input_Image);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Image);
      Initial_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;
      Initial_State : constant Real_Array := State_Values (D) with Ghost => Static;
      Initial_Inputs : constant Real_Array := Input_Values (D) with Ghost => Static;
      Initial_Pos : constant Real_Array := Position_Values (D) with Ghost => Static;
      Initial_Vel : constant Real_Array := Velocity_Values (D) with Ghost => Static;
      Initial_Time : constant Real := D.Clock with Ghost => Static;
      Nb : constant Natural := D.Nb;
      Center : Vector_Array (0 .. Nb - 1) with Relaxed_Initialization;
   begin
      Expose_Stable_Ready (D);
      Expose_Spatial_Layout (D);
      if D.Cache.Spatial_Valid then
         Ok := True;
      else
         Build_Centers (D.Body_Config.all, D.Kinematic.Bodies.all,
                        D.Topology, Center, Ok);
         if Ok then
            Build_Buffers (D.Body_Config.all, D.Joint_Config.all,
                           D.Kinematic.Bodies.all, D.Kinematic.Joints.all,
                           D.Topology, Center, D.Kinematic.Spatial_Inertias.all,
                           D.Kinematic.Spatial_Motions.all, Ok);
            D.Cache.Spatial_Valid := Ok;
         end if;
      end if;
      pragma Assert (Static => Has_Real_Layout (D.Kinematic.Spatial_Inertias, 10 * D.Nb));
      pragma Assert (Static => Has_Real_Layout (D.Kinematic.Spatial_Motions, 6 * D.Nj));
      pragma Assert (Static => Storage_Ready (D));
      pragma Assert (Static => Configuration_Bounded (D));
      Establish_Stable_Ready (D);
      pragma Assert (Static => Stable_Ready (D));
      pragma Assert (Static => Position_Values (D) = Initial_Pos);
      pragma Assert (Static => Velocity_Values (D) = Initial_Vel);
      pragma Assert (Static => D.Clock = Initial_Time);
      pragma Assert (Static => State_Values (D) = Initial_State);
      pragma Assert (Static => Input_Values (D) = Initial_Inputs);
      pragma Assert (Static => Inputs_Bounded (D));
      pragma Assert (Static => Caches_Bounded (D));
      pragma Assert (Static => Is_Ready (D));
      Prove_Configuration_Equality (Configuration (D), Initial_Config);
   end Prepare;
end MJ.Data.Spatial;
