# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-eirwava8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 273` | `mj-data-spatial.adb:273` | [completed_no_unproved](logs/mj-data-spatial__adb_line_273.log) | 1 | 0 | 0 | 30.0 |
| `line 292` | `mj-data-spatial.adb:292` | [completed_no_unproved](logs/mj-data-spatial__adb_line_292.log) | 1 | 0 | 0 | 16.8 |
| `line 309` | `mj-data-spatial.adb:309` | [unproved_checks](logs/mj-data-spatial__adb_line_309.log) | 1 | 1 | 0 | 20.0 |

## Diagnostics

### mj-data-spatial__adb_line_309

- `mj-data-spatial.adb:309` (medium): assertion might fail, cannot prove X in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]

