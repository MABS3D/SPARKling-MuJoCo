# Spatial motion composer checkpoint and handoff — 2026-09-27

This isolated candidate closes the previously open Build_Buffers safety/bounds proof by extracting per-joint and per-body buffer routines with exact local output/frame contracts. It does not remove a runtime scan and is not adopted into the active repository. No active source was edited by this agent. No integrated performance result is claimed.

## Exact result and boundary

| Selected component | Proof checks closed | Scope |
|---|---:|---|
| Write_Joint_Motion | 20/20 | Exact accepted value, rejection unchanged, outside-record frame, preserved bounds |
| Build_Body_Motions | 70/70 | Exact accepted values and interval/frame properties |
| Build_One_Body | 62/62 | Exact inertia, accepted motion values, outside-slab frame |
| Prove_Motion_Coverage / Prove_Complete_Motions | 20/20 and 6/6 | Ghost interval coverage |
| Prove_Empty_Joint_Case | 1/1 | Ghost world-only case |
| Build_Buffers | 66/66 | Emitted safety/call checks and success bounds on both slabs; also 4 flow checks closed |
| Add_Moment / Root_Center / Set_Moment | 9/9, 12/12, 12/12 | Prior exact arithmetic leaves, unchanged |
| Build_Centers | 42/42 | Prior safety/bounds, world-center initialization, validated input centers; unchanged |
| Expose_Motion_Direction | 4/4 | Prior direction bridge, unchanged |
| Spatial_Storage unit | 104/104 | Previously closed/adopted exact storage/frame contracts, unchanged |
| Expose_Spatial_Poses / Establish_Spatial_Layout | 5/5 and 5/5 | New Static ghost bridges in final source |
| Prepare | INCOMPLETE | Final narrowed attempt timed out at 100.2 seconds, zero emitted proof checks |

These are separate selected scopes, not an aggregate whole-unit proof. Build_Buffers and Build_Centers do not yet export a complete ordered functional model. Exact component formulas are established in the leaves; propagating them into a complete composer specification remains unfinished proof/specification engineering. This is not a documented mathematical Silver exception. Prepare's original public contract remains unchanged and unclosed; it includes readiness, caches, configuration, state and input preservation. No full Spatial unit or dynamics claim follows.

The final Prepare attempt yielded no individual diagnostic. Open integration points remain caller preconditions for Build_Centers/Build_Buffers and reconstruction/preservation of Stable_Ready, Caches_Bounded, Is_Ready and the original frames. This is a list of pending proof scope, not a list of counterexamples. Earlier failures and timeouts are kept in the archive. The directory named buffers-closed is a historical failed candidate (70 checks, 1 open), not the successful composer result; composer-one-body is the 66/66 receipt.

## Runtime and reference

The factorization keeps the original arithmetic expressions, FP evaluation order, guard order, packed stores and error behavior. It uses readonly input arrays/records and mutable output slabs. The world inertia is written first; each body's inertia precedes its motions; the first invalid joint anchor still returns failure. No guard, warning policy or deallocation was removed. Ghost snapshots/coverage lemmas are Static. Inline_Always may affect code generation, so performance requires a separate integrated timing result.

The corresponding C structure is mj_comPos in MuJoCo 3.14.0 engine_core_smooth.c: accumulate mass moments, accumulate children in reverse traversal, form root centers, then write body inertia and DOF motion values. This candidate preserves the already supported hinge/slide subset; it does not claim ball/free/sleeping/constraints support or universal C equivalence. The independent review in handoff-review confirms expression/order continuity and documents specification limitations.

## Numerical validation

Final source: numerics-final624/results.json reports Compatible policy, MuJoCo 3.14.0, 624 scenarios, 168192 compared values, zero failures, atol=rtol=2e-10, seed 20260923, 24 samples per model. Seven normalization edge cases also passed. The runner separately executes fourteen policy/rejection cases in Strict mode; this is not 624 scenarios in both policies. Rejection cases retain the expected Numeric_Limit/Singular_Inertia/Ill_Conditioned_Inertia outcomes and unchanged state where applicable.

The earlier numerics-with-probe report is historical: 360 scenarios on the version before the final per-body runtime extraction. The first numerics directory records a build failure because the isolated copy lacked the unchanged smooth_probe.adb main. That was supplied from active before both passing runs. Only the final624 run validates the current final runtime composition. Neither test is a benchmark.

## Sources, continuity, and use

- source/: final candidate, including the two proved Prepare ghost bridges and its still-incomplete caller.
- checkpoint-composer/source/: earlier exact composer66 snapshot before those ghost bridge additions; not a complete replacement for active because unused active-only Fused_RNE files were absent at checkpoint time.
- final-spatial-over-active.patch: single-file candidate against active Spatial baseline.
- checkpoint-composer/spatial-over-active.patch: exact reviewed composer checkpoint.
- prepare-ghost-followup.patch: only checkpoint-to-final Prepare ghost additions/calls/Hide_Info changes; no new runtime arithmetic.
- active-spatial-base.adb: exact active file used for both diffs.
- final-source-hashes.json: current/checkpoint/base and storage hashes.
- final-proof-linkage.json and handoff-review/proof-linkage.json: exact local definitions linked to their successful snapshots. All twelve reviewed definitions remain text-identical in final source.
- snapshot-index.json: source mappings for all successful and failed reports. Archive sources/sha256 objects were verified against every manifest.
- report-index.json: separate selected outcomes, including failed and zero-check/time-limited runs.

All shared non-Spatial Ada inputs match the active base used for this task; no extracted solver candidate was included. The final source also includes the unchanged unused active Fused_RNE files. Older Add_Moment/Root_Center receipts predate the stronger Static storage spec; neither calls Spatial_Storage. Other helper receipts share the same non-Spatial inputs as the composer checkpoint. Mathematical kernel contracts remain dependencies; they were not all reproved by this subtask. Storage104 receipt and source hashes are included independently.

Typical proof command (exact original arguments are in each results.json):

    python3 experimental/smooth/tools/prove_fragments.py --repo . --report-dir <fresh-directory> --toolchain-root /var/tmp/sparkling-matrix-recovery/toolchains --unit mj-data-spatial --name Build_Buffers --wall-seconds 95 --total-seconds 105 --prover-seconds 3 --steps 0 --provers cvc5,altergo --level 0 --jobs 2 --cap-mb 2500

Final numerical command:

    /var/tmp/sparkling-movement-env/bin/python experimental/smooth/tools/compare_numerics.py --repo . --report-dir <fresh-directory> --toolchain-root /var/tmp/sparkling-matrix-recovery/toolchains --samples 24 --extra-fixtures '/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tests/tree_invariants/fixtures'

Toolchain GNAT/GNATprove 16.1 and GPRbuild 26; generated proof projects and exact commands/logs are archived. Final checked probe SHA256: 7cfcda2f0a94765135876345e41f4c766c62ee1a0d05cae86a246d0a6fdc3bad.

Next proof task: preserve this closed composer, split the Prepare publication/frame boundary further and discharge selected caller preconditions before retrying the whole routine. Strengthen the global ordered functional model separately. Do not suppress checks, assume readiness, or claim scan removal based only on the closed helper checks.
