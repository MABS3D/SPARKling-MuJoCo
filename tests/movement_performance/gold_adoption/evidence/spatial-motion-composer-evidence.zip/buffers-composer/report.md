# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-5daqr78q/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Buffers` | `mj-data-spatial.adb:192` | [unproved_checks](logs/mj-data-spatial__build_buffers__adb_192.log) | 64 | 2 | 0 | 59.0 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_192

- `mj-data-spatial.adb:221` (medium): postcondition might fail, cannot prove X in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:252` (medium): assertion might fail, cannot prove Motions (I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]

