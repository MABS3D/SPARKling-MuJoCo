from pathlib import Path
import hashlib,json,datetime
root=Path('/var/tmp/sparkling-spatial-motion-helper-20260927')
old=Path('/var/tmp/sparkling-spatial-split-20260926')
active=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
checkpoint=root/'checkpoint-composer/source'
out=root/'handoff-review'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def sub(s,name):
 start=s.index('   procedure '+name)
 end=s.index('   end '+name+';',start)+len('   end '+name+';')
 return s[start:end]
current=(checkpoint/'experimental/smooth/src/mj-data-spatial.adb').read_text()
pairs=[(old,'leaves-and-centers','Add_Moment'),(old,'leaves-and-centers','Root_Center'),(old,'moment-leaf','Set_Moment'),(old,'moment-leaf','Build_Centers'),(old,'motion-direction-prefix','Expose_Motion_Direction'),(root,'write-joint-components','Write_Joint_Motion'),(root,'body-motions','Build_Body_Motions'),(root,'motion-coverage','Prove_Motion_Coverage'),(root,'motion-coverage','Prove_Complete_Motions'),(root,'empty-case','Prove_Empty_Joint_Case'),(root,'one-body','Build_One_Body'),(root,'composer-one-body','Build_Buffers')]
links=[]
for ws,report,name in pairs:
 file=ws/report/'results.json'; data=json.loads(file.read_text())
 snapshot=Path(data['snapshot'])
 source=(snapshot/'experimental/smooth/src/mj-data-spatial.adb').read_text()
 a,b=sub(current,name),sub(source,name)
 assert a==b,(name,'source mismatch')
 results=[r for r in data['results'] if r['target']['name']==name]
 assert results and all(r['status']=='completed_no_unproved' and r['unproved']==0 and r['errors']==0 for r in results)
 diffs={n:{'proved_sha256':h,'checkpoint_sha256':sha(checkpoint/n)} for n,h in data['source_sha256'].items() if (checkpoint/n).exists() and sha(checkpoint/n)!=h}
 links.append({'name':name,'report':str(file),'report_sha256':sha(file),'subprogram_sha256':hashlib.sha256(a.encode()).hexdigest(),'source_text_identical':True,'proof_checks':[r['proof_checks'] for r in results],'source_differences':diffs})
(out/'proof-linkage.json').write_text(json.dumps(links,indent=2)+'\n')
files={}
for base in ('src','experimental/smooth/src'):
 for p in sorted((checkpoint/base).rglob('*')):
  if p.suffix not in ('.ads','.adb'): continue
  rel=p.relative_to(checkpoint);q=active/rel
  files[str(rel)]={'checkpoint':sha(p),'active':sha(q) if q.exists() else None}
manifest=json.loads((root/'composer-one-body/manifest.json').read_text())
full=all((checkpoint/n).exists() and sha(checkpoint/n)==h for n,h in manifest['source_sha256'].items())
assert full
active_only=[]
for base in ('src','experimental/smooth/src'):
 for p in sorted((active/base).rglob('*')):
  if p.suffix in ('.ads','.adb') and not (checkpoint/p.relative_to(active)).exists(): active_only.append(str(p.relative_to(active)))
source_record={'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkpoint':str(checkpoint),'active':str(active),'composer_complete_manifest_matches':full,'files':files,'active_only_sources':active_only}
(out/'source-hashes.json').write_text(json.dumps(source_record,indent=2)+'\n')
(out/'artifact-sha256.json').write_text(json.dumps({p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='artifact-sha256.json'},indent=2)+'\n')
print(out)
print('All twelve subprogram definitions match closed receipts; full composer source matches.')
print('Common Ada differences:',[n for n,h in files.items() if h['checkpoint']!=h['active']])
print('Active-only sources:',active_only)
