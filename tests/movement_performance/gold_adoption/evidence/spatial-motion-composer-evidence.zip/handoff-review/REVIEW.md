# Independent source review of the spatial composer checkpoint

Reviewed by scan_force_proofs on 2026-09-27. This was a read-only source/proof-artifact review; no proof job, build, benchmark or source modification was performed. The review scope is the immutable checkpoint-composer/source tree, not the other agent's subsequent working Prepare variants.

Outcome: no concrete runtime semantic regression or weakened existing public contract found in the inspected extraction. The composer proof is correctly reported as 66/66 for its stated bounds contract. Two proof-scope limitations must remain explicit before wider Gold/integration claims.

## Scope limitations

1. Build_Buffers at mj-data-spatial.adb:313-315 states only conditional bounds for the two arrays. Its 66/66 result proves those bounds and the emitted safety/call checks; it does not expose a complete per-body/per-joint result equation or characterize the exact accepted/failing prefix. Build_Centers at lines66-68 likewise guarantees bounds, world center zero and bounded input centers on success, not an ordered whole-tree accumulation model. Exact arithmetic and partial frames are proved in Add_Moment, Root_Center, Set_Moment, Write_Joint_Motion, Build_Body_Motions and Build_One_Body. Calling the entire composer or the full center computation functionally complete Gold would overstate this evidence; this is unfinished specification/proof composition, not a mathematical Silver exception.
2. Prepare's declaration is byte-identical to active, including full readiness/configuration/state/input frames, but the checkpoint body is still a separate integration obligation. Its helper calls and final assertions are not covered by the composer66 selection. The local Prepare attempts remain incomplete; no scan removal or full dynamics closure follows from this review.

These limitations do not identify a false contract or a counterexample. They identify what the supplied proof actually establishes and what is still required for the broader claim.

## Runtime expression and order comparison

- Body traversal order remains increasing for initial mass moments, decreasing for parent accumulation, increasing for root centers, then increasing for packed body inertias and each body's joint block.
- Set_Moment calls the unchanged Mass_Moment with the same mass and center. Add_Moment evaluates Target + Source in the original parent-plus-child order, checks the same 1.0e24 limit, and writes the parent only when accepted. The extra Child local is a value copy; it introduces no floating-point arithmetic.
- Root_Center preserves exactly the branch Mass < Min_Val and the expression (1.0 / Mass) * Moment, including reciprocal followed by multiplication. The Max_Val check still precedes assigning the center.
- Build_One_Body calls the unchanged Make_Inertia with the same rotation, diagonal, mass and Frame_Offset(Pose.Center, Origin). It stores the body's ten inertia cells before visiting that body's joints, as active does.
- Write_Joint_Motion tests the same anchor bound before computing Frame_Offset(Origin, Anchor) and Joint_Motion. The offset sign, hinge test, cross-product order and six-cell store order are unchanged. The leaf kernel/spec and Spatial_Storage bodies match active byte for byte.
- Empty joint blocks remain empty. The world body still receives ten zeros before the nonworld-body loop. The only-body/world-only case is now made explicit in ghost coverage lemmas and does not add runtime writes.
- Inline_Always can affect generated code and must be measured separately. This source review does not assert binary identity, integrated speedup or cross-language universal equivalence.

## Failure behavior and frame

Before the first packed store, a rejected center, parent sum or root center still leaves D's packed buffers untouched and Ok false. On the first rejected joint anchor, the current body's inertia and all earlier accepted motion stores remain written, and later joints/bodies are untouched. The same order follows from the extracted runtime body; Write_Joint_Motion additionally proves its own rejection leaves its target unchanged, while the body-level helper proves the frame outside the selected joint interval. The whole failing-prefix relation is not exported by Build_Buffers's current postcondition.

On entry with Spatial_Valid true, Prepare still returns Ok true without mutating the caches. On the construction path, a successful Build_Buffers publishes Spatial_Valid true; a failure assigns false to a flag that was already false. Failed Build_Centers leaves that flag false. Other mutable Simulation fields have no runtime writes in these extracted procedures. The helpers use readonly values/arrays for configuration and poses, and mutable parameters only for their designated output slabs.

The former eagerly initialized local arrays move into the helper/cache-miss path. This does not alter returned state or arithmetic on accepted calls; allocation/stack-exhaustion observability is outside the stated project contract. Debug assertion cost/control flow is not a performance-equivalence claim. No runtime domain guard was removed in this extraction.

## Contracts and source/proof linkage

- mj-data-spatial.ads is byte-identical to active: no public precondition strengthening or postcondition weakening.
- Among common Ada files in checkpoint and active, mj-data-spatial.adb is the only source difference. The checkpoint is not a full replacement for the active repository: active-only Fused_RNE files are not part of the checkpoint.
- The complete source manifest of composer-one-body matches checkpoint-composer/source, including its Build_Buffers definition. Its result is 66 proof checks, zero unproved, zero errors.
- The exact text of every selected local helper below matches its closed proof snapshot. proof-linkage.json records report paths, per-subprogram hashes, counts and dependency differences. Earlier Add_Moment/Root_Center receipts predate only the stronger Spatial_Storage Static spec; neither helper calls Spatial_Storage. The remaining local helper snapshots have identical non-Spatial-body inputs to this checkpoint.
- The strengthened active Spatial_Storage closure records 104 proof checks, zero open; its source hashes match the checkpoint. Existing mathematical kernels remain contractual dependencies. Their byte identity was checked; this review did not rerun their complete proof history.
- No Assume, check suppression, Skip_Proof, or new SPARK_Mode Off appears in the changed Spatial body.

| Local component | Closed proof checks |
|---|---:|
| Add_Moment | 9 |
| Root_Center | 12 |
| Set_Moment | 12 |
| Build_Centers | 42 |
| Expose_Motion_Direction | 4 |
| Write_Joint_Motion | 20 |
| Build_Body_Motions | 70 |
| Prove_Motion_Coverage | 20 |
| Prove_Complete_Motions | 6 |
| Prove_Empty_Joint_Case | 1 |
| Build_One_Body | 62 |
| Build_Buffers | 66 |

Source hashes and the comparison timestamp are in source-hashes.json. No new numerical/performance experiment was run by the reviewer. The other agent's later Prepare experiments and any eventual adoption need their own exact source linkage and validation.
