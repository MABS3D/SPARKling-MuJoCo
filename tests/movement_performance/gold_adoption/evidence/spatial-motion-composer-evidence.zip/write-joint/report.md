# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-28t1etod/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Write_Joint_Motion` | `mj-data-spatial.adb:121` | [unproved_checks](logs/mj-data-spatial__write_joint_motion__adb_121.log) | 19 | 1 | 0 | 23.9 |

## Diagnostics

### mj-data-spatial__write_joint_motion__adb_121

- `mj-data-spatial.adb:131` (medium): postcondition might fail, cannot prove SS.Load_Motion (Target, Base) = SK.Joint_Motion (Pose.Direction, SK.Frame_Offset (Origin, Pose.Anchor), Hinge) [provers reached time limit before completing the proof]

