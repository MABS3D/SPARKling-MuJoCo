# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-1t18s4uv/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 305` | `mj-data-spatial.adb:305` | [unproved_checks](logs/mj-data-spatial__adb_line_305.log) | 1 | 1 | 0 | 32.8 |

## Diagnostics

### mj-data-spatial__adb_line_305

- `mj-data-spatial.adb:305` (medium): assertion might fail, cannot prove X in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]

