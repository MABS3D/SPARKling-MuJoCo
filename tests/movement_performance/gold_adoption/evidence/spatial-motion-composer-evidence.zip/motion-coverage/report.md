# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-jyowt85o/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Motion_Coverage` | `mj-data-spatial.adb:192` | [completed_no_unproved](logs/mj-data-spatial__prove_motion_coverage__adb_192.log) | 20 | 0 | 0 | 17.4 |
| `Prove_Complete_Motions` | `mj-data-spatial.adb:214` | [completed_no_unproved](logs/mj-data-spatial__prove_complete_motions__adb_214.log) | 6 | 0 | 0 | 3.1 |

## Diagnostics

