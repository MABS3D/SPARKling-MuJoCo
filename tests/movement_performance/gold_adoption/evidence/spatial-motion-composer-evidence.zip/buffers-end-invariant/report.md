# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-imiommzz/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Buffers` | `mj-data-spatial.adb:228` | [analysis_error](logs/mj-data-spatial__build_buffers__adb_228.log) | 0 | 0 | 4 | 16.0 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_228

- `mj-data-spatial.adb:264` (error): non-scalar object or object with address clause declared before loop-invariant is not yet supported
- `mj-data-spatial.adb:265` (error): non-scalar object or object with address clause declared before loop-invariant is not yet supported
- `mj-data-spatial.adb:266` (error): non-scalar object or object with address clause declared before loop-invariant is not yet supported
- `mj-data-spatial.adb:267` (error): non-scalar object or object with address clause declared before loop-invariant is not yet supported

