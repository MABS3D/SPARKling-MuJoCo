# Mass publication helper — closed local proof,2026-09-27

No active repository source was modified. No runtime scan was removed, and no benchmark was run by this agent. The source/ directory and mass-publication.patch contain a standalone private child package, not yet called by the simulator.

## Current accepted proof scope

| Scope | Checks | Unproved/errors | Evidence |
|---|---:|---:|---|
| Whole MJ.Data.Mass_Publication unit |64|0/0|proof-publication-closed|
| Matrix_Offset supporting kernel |6|0/0|proof-publication-leaf-closure|
| Prove_Configuration_Equality supporting lemma |28|0/0|proof-publication-leaf-closure|

The whole-unit run completed in67.8s with CVC5+Z3,3s/check,steps0,jobs1. The supporting leaf proofs completed in3.5s and29.8s. Smaller preliminary passes overlap the64unit checks and must not be added to them. These results establish local floating-point/data-frame behavior under the stated contracts; they do not establish the physical CRB algorithm or the whole dynamics pipeline.

Publish exactly copies an already bounded symmetric dense candidate into D.Dynamics.Mass, marks mass current, invalidates force/acceleration results, and preserves readiness, shape, state/input values, positions, passive/actuation validity, configuration, position/velocity values, time and step size. Its producer must prove the existing input contract. Debug builds can evaluate normal contracts; the release body adds no new numeric calculation or scanning loop.

## Repair without weakening contracts

The public .ads file is byte-identical to the previous59checks/1unproved version; the three non-ghost assignments in Publish are unchanged. contract-runtime-continuity.json records this comparison.

The missing step was instantiating two equivalent matrix-symmetry predicates. The repair proves one matrix entry, then a complete row explicitly. A separate ghost wrapper exposes this already proved row result through Automatic_Instantiation. Inline_For_Proof supplies the row expression as a direct definition, allowing the final nested-quantifier bridge to close. The unit proof includes all new lemma bodies; no Assume, Skip_Proof, suppression, trusted body, or strengthened public precondition was added.

These are documented GNATprove annotations: https://docs.adacore.com/spark2014-docs/html/ug/en/appendix/additional_annotate_pragmas.html . Automatic instantiation derives an axiom from the ghost lemma contract, whose body is separately proved in this same unit; it is not a replacement for proving that body. GNAT rejects combining Inline_For_Proof and Hide_Info for the same expression function, so that rejected intermediate attempt is preserved among the diagnostics.

## Remaining integration work

See INTEGRATION.md for the narrow next callsite. This helper alone does not remove the Forces_Phase.Compute Phase_Ready scan. Assemble still needs successful readiness preservation over its CRB producer and dense fallback, including Spatial.Prepare. Compute itself still needs preservation for eliminating the following actuation scan. Earlier monolithic timeouts and the GNAT internal crashes remain in HISTORY.md and the evidence archive; they are not counted as proof successes.

## Reproduction and evidence

Reconstruct the immutable inputs using proof-source-objects.zip/runs.json entry proof-publication-closed. Then run:

```sh
ulimit -s 65536
python3 experimental/smooth/tools/prove_fragments.py \
  --repo /var/tmp/sparkling-force-scan-gold \
  --toolchain-root /var/tmp/sparkling-matrix-recovery/toolchains \
  --whole-unit mj-data-mass_publication \
  --report-dir /var/tmp/force-publication-new-run \
  --prepare-seconds 150 --wall-seconds 150 --total-seconds 170 \
  --prover-seconds 3 --steps 0 --provers cvc5,z3 --cap-mb 3000 --jobs 1
```

For the two supporting leaves, replace --whole-unit with --unit mj-smooth_kernels --unit mj-data --name Matrix_Offset --name Prove_Configuration_Equality and use a fresh report directory. Full commands and exact source manifests are recorded in each archived result.

proofs.zip contains every successful/failed diagnostic run, structured .spark records and manifests. proof-source-objects.zip preserves their deduplicated input files by SHA256. The packager verifies every source object and ZIP CRC; artifact-sha256.json records final artifact hashes. Raw misleading statuses for compiler crashes are corrected through an explicit effective_status in proof-index.json while preserving original reports.
