# Narrow next integration, not applied

The active dense Assemble branch in experimental/smooth/src/mj-data-inertia_phase.adb currently calls Try_Assemble_CRB into a local Candidate and then copies Candidate into D.Dynamics.Mass. Its next common successful block marks Mass_Valid true and returns Success.

The narrow change is adding with MJ.Data.Mass_Publication and replacing only:

```ada
if Used_CRB then D.Dynamics.Mass.all := Candidate; end if;
```

with:

```ada
if Used_CRB then MJ.Data.Mass_Publication.Publish (D, Candidate); end if;
```

Keep the existing outer success branch initially. The helper sets Mass_Valid slightly earlier, but no observable operation intervenes before the outer block; Force_Valid was already cleared by Assemble. The three writes are the same mass copy and validity writes. Avoid changing the dense fallback or scan removal in this small integration.

At that callsite prove: Is_Ready(D),Pose_Valid, Candidate square layout with current D.Nv, bounded Candidate and symmetry. Spatial.Prepare promises readiness/pose/dimensions; Try_Assemble_CRB promises bounded symmetric candidate. A passing callsite check would remain conditional on those producer contracts: their open bodies still prevent claiming the complete chain.

After integration, establish source continuity, compile with checked contracts, run numerical Compatible/Strict regression checks, and measure integrated release performance if code generation changes. The new child-package call may affect inlining; no runtime gain is claimed from this standalone helper.

Then complete producer and fallback preservation before removing the Forces entry scan. The helper does not repair Try_Assemble_CRB or Spatial.Prepare by itself.
