# Forces scan / mass publication proof handoff — 2026-09-26

No active repository source was modified. No runtime scan was removed. No benchmark was run by this agent.

## Final status

The final isolated private `MJ.Data.Mass_Publication` unit emits **59 proof checks, one unproved** (64.6s, CVC5+Z3, 3s/check, unlimited prover steps). Its one unresolved obligation is the postcondition of `Prove_Dense_Symmetry` at body line54: converting the proved quantified row predicate into the equivalent expanded two-index predicate. It is unfinished proof engineering, not a mathematical limitation. The helper is **not ready for adoption under a complete Gold claim**. In particular, Publish relies on that unproved lemma contract even though its own local obligations pass.

The same final unit contains proved entry/row symmetry facts, proof of outer induction over a named row predicate, and exact publication/state-frame obligations. Earlier separate entry and row proofs close13 and17checks respectively. Those counts must not be added to the final59 because they overlap.

`Publish` copies an already bounded symmetric dense candidate into `D.Dynamics.Mass`, marks mass current, invalidates acceleration/force results, and preserves readiness, shape, state/input values, positions, passive/actuation validity, configuration, position/velocity values, time and step size. It does not establish the physical CRB computation; its producer must supply the stated input contract.

The draft patch is `mass-publication.patch`; isolated files are under `source/experimental/smooth/src`. No call site uses this new helper yet. Applying this patch alone provides no performance improvement.

## Why the Forces phase scan cannot yet be removed

The public Forces.Compute boundary already checks Is_Ready. The internal pipeline calls Forces_Phase.Compute after successful Inertia_Phase.Assemble. Replacing the internal Phase_Ready scan with a Static assertion is mechanically possible after strengthening the private precondition, but a sound proof chain needs Assemble's body to establish its readiness postcondition, including its Spatial.Prepare and dense fallback dependencies. These bodies remain pending. Current Forces_Phase.Compute itself also needs a readiness/frame proof before the following actuation scan can be removed.

Fresh unchanged Compute diagnostic timed out at60s without emitting checks. Assemble attempts with expression hiding and then explicit readiness/mass/frame loop invariants timed out at90s without emitting checks. These are not passes. Their exact source variants remain in the source-object archive.

## Tooling failures

Embedding Publish_Mass as a local subprogram of Inertia_Phase triggered GNAT `Storage_Error stack overflow or erroneous memory access` at an unrelated Solve_Euler assignment. Raising the shell stack from8MB to64MB did not fix it. Moving the helper into a private child package avoided the crash. One raw driver record labels the crashed run unproved_checks because it printed a failed diagnostic before crashing; the proof-index adds effective_status=compiler_internal_error. No result from either crashed run is accepted.

An early draft also failed because Configuration is Static ghost data and was placed in a normal Post aspect; the final code uses a Static postcondition. One mistaken line selector targeted an annotation rather than a proof obligation and timed out; retained only as diagnostic history.

## Reproduce the final result

Use the source snapshot reconstructed from `proof-source-objects.zip` / runs.json entry `proof-publication-final`; current active sources may have changed after this investigation.

```sh
ulimit -s 65536
python3 experimental/smooth/tools/prove_fragments.py \
  --repo /var/tmp/sparkling-force-scan-gold \
  --toolchain-root /var/tmp/sparkling-matrix-recovery/toolchains \
  --whole-unit mj-data-mass_publication \
  --report-dir /var/tmp/force-publication-new-run \
  --prepare-seconds 150 --wall-seconds 150 --total-seconds 170 \
  --prover-seconds 3 --steps 0 --provers cvc5,z3 --cap-mb 3000 --jobs 1
```

Reports, logs, complete structured proof records and source manifests are in `proofs.zip`. `proof-source-objects.zip` stores every run's immutable input files by SHA256 with a run-to-path mapping. Each source blob was checked against its manifest SHA; both zip CRC checks passed. Archive hashes are in artifact-sha256.json.

Next smallest target: the final Prove_Dense_Symmetry postcondition, including visibility/instantiation of Direct_Row_Symmetric; then rerun the complete publication unit. Only after that integrate the helper into Assemble and prove its caller preconditions and remaining branches. Do not remove runtime guards based solely on these modular helper checks.
