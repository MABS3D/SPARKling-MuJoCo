#!/usr/bin/env python3
"""Read-only source comparison. This is not an SMT or binary equivalence proof."""
from pathlib import Path
import argparse, hashlib, json, re

EVIDENCE = Path(__file__).resolve().parent
ROOT = EVIDENCE / 'review-baseline'
CANDIDATE = EVIDENCE / 'review-candidate'

def body(source, name):
    starts = [source.find('   procedure ' + name + suffix) for suffix in (' (', '\n')]
    start = min(x for x in starts if x >= 0)
    source = source[start:]
    source = source[:source.index('   end ' + name + ';') + len('   end ' + name + ';')]
    return source[source.index('\n   is\n'):]

def normalize(source):
    source = re.sub(r'--[^\n]*', '', source)
    source = re.sub(r'\bpragma\b.*?;', '', source, flags=re.S | re.I)
    return re.sub(r'\s+', '', source).lower()

def run(baseline, candidate):
    old, new = baseline.read_text(), candidate.read_text()
    left, right = body(old, 'Solve_Compatible'), body(new, 'Solve_Compatible_Buffers')
    for before, after in [
        ('D.Scratch.Ancestor_Factor.all', 'Factor'), ('D.Scratch.Ancestor_Factor', 'Factor'),
        ('D.Scratch.Solution.all', 'Solution'), ('D.Scratch.Solution', 'Solution'),
        ('D.Dynamics.Total.all', 'Total'), ('D.First_Clamped', 'First_Clamped'),
        ('D.Ancestors', 'Rows'), ('D.Nv', 'AR.Size (Rows)')]:
        left = left.replace(before, after)
    right = right.replace('Solve_Compatible_Buffers', 'Solve_Compatible')
    right = re.sub(r'Add_Prefix_Row\s*\(Solution,', 'SK.Add_Row (Solution (0 .. I - 1),', right)
    right = right.replace('Store_Work_Entry (Solution, J, Value);', 'Solution (J) := Value;')
    left, right = normalize(left), normalize(right)
    dependencies = ['mj-solver_kernels.ads', 'mj-solver_kernels.adb',
                    'mj-solver_reductions.ads', 'mj-solver_reductions.adb',
                    'mj-ancestor_rows.ads', 'mj-ancestor_rows.adb']
    return {
        'baseline': str(baseline), 'candidate': str(candidate),
        'baseline_sha256': hashlib.sha256(baseline.read_bytes()).hexdigest(),
        'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
        'normalized_runtime_tokens_equal': left == right,
        'normalized_baseline_sha256': hashlib.sha256(left.encode()).hexdigest(),
        'normalized_candidate_sha256': hashlib.sha256(right.encode()).hexdigest(),
        'unchanged_dependencies': {n: (baseline.parent / n).read_bytes() == (candidate.parent / n).read_bytes() for n in dependencies},
        'normalization': 'Erase comments and all pragma instrumentation; rename D fields to corresponding formal buffers; expand two exact row/store wrappers. The prefix expansion applies in Diag = I branch, where Source length is I.',
        'reviewed': ['Clamp before pivot write; same reciprocal; same K/A/I directions.',
                     'Same arithmetic operands, grouping, leaf kernels and failure-return positions.',
                     'Same partial scratch writes on rejected rows and zero-size behavior.',
                     'New wrapper retains old postconditions and adds explicit static frame guarantees.'],
        'limitations': ['Source review and normalized token equality are not compiler/binary/FP equivalence proof or performance equivalence.',
                        'Erased assertion/precondition instrumentation may differ in checked builds; comparison concerns algorithm for valid entry contracts.',
                        'Buffers proof establishes safety, accepted-result bounds and preservation of existing nonnegative clamp diagnostic, not full factorization/solution refinement.',
                        'Numeric_Limit does not guarantee scratch buffers satisfy Work_Array, consistent with original behavior.',
                        'No build, test or proof executed by this script. Reported624-scenario/failure tests were performed separately by parent.']}

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--baseline', type=Path, default=ROOT/'mj-data-inertia_phase.adb'); ap.add_argument('--candidate', type=Path, default=CANDIDATE/'mj-data-inertia_phase.adb'); ap.add_argument('--output', type=Path)
    args = ap.parse_args(); result = run(args.baseline, args.candidate); output = json.dumps(result, indent=2) + '\n'
    if args.output: args.output.write_text(output)
    else: print(output, end='')
    raise SystemExit(0 if result['normalized_runtime_tokens_equal'] and all(result['unchanged_dependencies'].values()) else 1)
