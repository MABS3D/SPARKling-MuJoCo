# CRB publication branch and exact ghost-model follow-up

This is an isolated, unadopted draft. No active repository source was edited. No Phase_Ready scan was removed. No runtime or performance claim is made.

The original CRB producer is unchanged. The prepared success branch was extracted into Try_Ready_CRB: construct Candidate, call the readonly producer wrapper, and publish only when Used_CRB is true. This branch closes its complete declared safety/frame/success contract: 6/6 proof checks. The driver selected both declaration and body; they are duplicate validations of the same six checks, not twelve distinct obligations.

Try_CRB_Publication still calls Spatial.Prepare first, preserves its failed-preparation exit, and then calls the proved prepared branch. Its complete wrapper contract remains open. The latest plain model and Configuration_Image trials each produce 5 proof records: four proved preconditions and one open postcondition reported at Configuration(D) = Configuration(D)'Old. All failure paths and original existing Assemble contracts are preserved.

## Exact proof status

| Target | Proof checks | Open | Evidence |
|---|---:|---:|---|
| Try_Ready_CRB | 6 | 0 | proof-crb-ready-branch, original ghost model |
| Equal_Configurations | 22 | 0 | proof-configuration-transitivity, original ghost model |
| Try_CRB_Publication, split branch | 5 | 1 | proof-crb-publication-visible-config |
| Try_CRB_Publication, Configuration_Image | 5 | 1 | proof-crb-publication-image |
| Same wrapper, separate equivalent Static posts | 5 | 1 | proof-crb-publication-separated-post-valid |
| Original producer, line 34 Load_Inertia | 0 final records | unknown | proof_timeout after 70.2 seconds; not a pass |

Previous reusable leaf evidence remains separate:

- /var/tmp/sparkling-force-scan-gold/handoff: Mass_Publication whole unit 64/64, Matrix_Offset 6/6, Prove_Configuration_Equality 28/28 under original model.
- /var/tmp/sparkling-mass-publication-integration/handoff-readonly-candidate: Try_CRB_Candidate readonly producer contract composition 4/4. This does not prove Try_Assemble_CRB's body.
- /var/tmp/sparkling-configuration-image-gold/handoff-configuration-image: isolated two-file Ghost Static model refactor, 64/64 distinct checks including exact total equivalence to the original expression. Do not apply that patch globally without demonstrated caller benefit.

## Remaining frame boundary

Spatial.Prepare already states exact Configuration(D)=Configuration(D)'Old in mj-data-spatial.ads. Try_Ready_CRB states the same exact frame. The split wrapper saves Initial_Config and Prepared_Config, then calls the existing Equal_Configurations lemma. All those call preconditions prove, including the transitivity lemma's Configuration(current)=Prepared_Config and Prepared_Config=Initial_Config. The remaining reported goal is the wrapper's Configuration/current-to-Old postcondition. An explicit final assertion merely moves the same timeout to that assertion; it was not accepted as a proof.

Configuration_Image receives only scalar configuration values and readonly body/joint/actuator arrays and is opaque by default. Its exact original-expression equivalence is independently proved without a precondition, including incomplete and empty states. However, the wrapper passes the complete mutable Simulation through two subprograms; configuration preservation is communicated through snapshot record equalities. Constructor opacity alone has not made that composed frame close. No counterexample was produced; the recorded reason is solver time limit, not evidence of a false property.

Separating the five Static conjuncts into equivalent individual Postcondition pragmas did not split the final reported GNATprove obligation and left the same 4/5 result. This variant is saved only under model-trial-source, not selected for the main patch. No more monolithic or unchanged retries were launched.

## Files and source linkage

crb-publication-split.patch contains the runtime candidate and standalone helper against the recorded historical active baseline; source contains those exact four files. It does not contain Configuration_Image. model-trial-source contains the four differing files from the later model/split-post trial for diagnosis only. The standalone model patch is archived at the separate path above.

proofs.zip preserves all scoped split follow-up runs, including unsuccessful assertions, timeouts, and a cancelled preparation launch after a local edit assertion failed. proof-source-objects.zip stores immutable full inputs keyed by SHA256; runs.json maps each run to its source hashes. Commands, toolchain configuration, logs, and structured records are in each report. source-continuity.json verifies original producer and fallback preservation and the selected prepared branch's exact proof-source linkage. artifact-sha256.json covers all handoff files.

Numerical and performance validation are not run for this unclosed runtime candidate. Gold integration remains blocked on the outer wrapper and the unchanged original producer/Spatial.Prepare dependencies. The proved branch is a reusable modular component, not closure of Assemble or the dynamics.
