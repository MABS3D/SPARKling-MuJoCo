# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-jrj0_mop/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 446` | `mj-data-inertia_phase.adb:446` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_446.log) | 4 | 0 | 0 | 72.8 |
| `line 447` | `mj-data-inertia_phase.adb:447` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_447.log) | 2 | 0 | 0 | 51.0 |
| `line 449` | `mj-data-inertia_phase.adb:449` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_449.log) | 1 | 0 | 0 | 51.9 |

## Diagnostics

