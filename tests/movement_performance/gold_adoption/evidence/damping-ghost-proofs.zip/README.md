# Ghost-only damping-bound candidate, 2026-09-26

Isolated copy of the active repository after its accepted pose changes. Active source remains untouched by this agent.

## Change

`MJ.Solver_Kernels.Prove_Damping_Bound` is Ghost=>Static, takes Previous:Work_Real and Step,Damping:Nonneg_Tier0, has a null body and proves `Previous + Step * Damping in Work_Real`. Its input bounds already hold at the existing damping diagonal update. No new assumption, suppression, trusted body or stronger runtime domain was added.

`Load_Ancestor_Factor` keeps its original Value declaration, multiply-then-add expression and direct store. The only removed runtime operation is the `Within_Work(Value)` rejection branch. A Static lemma invocation before the expression and a Static assertion after it supply its formal justification. There is no new runtime helper, Accepted variable or copy.

The C comparison was rechecked in the pinned MuJoCo3.14.0 source: engine_forward.c:1555-1564, mj_EulerSkip, directly adds timestep*damp_deriv into the compact factor diagonal, then performs factorization/pivot warning. Our candidate preserves the existing supported constant-damping domain and downstream pivot/error policy; it makes no broader claim about C's polynomial/actuator damping support.

## Proof scope

- lemma/: complete null-body subprogram,3/3 checks.
- kernels-complete/: complete final Solver_Kernels unit,104/104 checks (including the3 lemma checks; do not add these twice).
- callers/: changed caller argument checks at inertia_phase.adb:446/447 prove4+2 checks; removed-guard Static assertion449 proves1 check. Total7 selected checks, zero open/errors. These are not a full Load_Ancestor_Factor proof.

All runs use cvc5+altergo,3seconds,steps0,level0,jobs2. The wrapper's remaining state/frame obligations and the broader Solve/Euler chain remain open elsewhere; these selected proofs do not close full dynamics or remove Phase_Ready scans.

## Handoff

- ghost-damping-bound.patch:3-file candidate patch.
- baseline-sha256.json: hashes of the3 files copied from the active source before edits.
- source/: complete candidate tree; its accepted pose changes are preserved.
- evidence.zip: exact source objects and all proof reports/commands.
- archive-manifest.json: archive checksum/source-continuity validation.

No build, numerical differential tests, machine-code inspection or integrated benchmark was performed by this agent. Root performs those before adopting this source candidate.
