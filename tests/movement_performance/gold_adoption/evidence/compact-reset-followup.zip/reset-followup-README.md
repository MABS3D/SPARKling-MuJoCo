# Compact Reset follow-up — not adopted

The original best completed Reset proof remains 43 proof checks with one open
Configuration preservation obligation (reset7 in compact-lifecycle-draft.zip).
This follow-up tried making Configuration opaque in Reset and exposing its
exact snapshot through a separately proved Ghost Static lemma at entry/exit.
The lemma closes 13 proof checks + 1 flow check; the complete Reset invocation
then reached the 110-second cap with zero completed proof checks. This is not
a pass and does not improve Reset closure. No contract has been weakened.

Exact source/manifests/logs of both invocations are preserved. The source tree
is restored to the previous best Reset body, while retaining the pre-existing
narrow Build_Topology draft. No source here is active in the simulator.
Build_Topology and Initialize are still unproved; mass remains dense in active
code. The original archive and this follow-up must not be combined into a
claim of whole lifecycle Gold.

Hide_Info scope reference (AdaCore official user guide):
https://docs.adacore.com/spark2014-docs/html/ug/en/appendix/additional_annotate_pragmas.html#pruning-the-proof-context-on-a-case-by-case-basis
