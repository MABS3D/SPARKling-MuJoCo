# Euler readiness / solver proof work, 2026-09-26

All experiments are isolated from the active repository. No scans have been removed in the proposed minimal patch.

## Minimal candidate requested by root

`minimal-damping-kernel.patch` changes only MJ.Solver_Kernels.ads/.adb and the existing diagonal update in Load_Ancestor_Factor. Apply it to the source state originally copied from the repository. The complete candidate tree is `minimal-source/`.

The new Add_Damping_Diagonal kernel preserves the exact multiply-then-add expression, computes the same +/-Work_Limit acceptance predicate, stores only on acceptance, and guarantees that rejected updates leave the whole factor unchanged and accepted updates leave all other entries unchanged. It is Inline_Always. The loader keeps its original loop, checks, failure return, policy, First_Clamped behavior, and frame invariants.

`Data.Within_Work` is private to Data and cannot be used by Solver_Kernels without a dependency cycle; the helper therefore spells the identical range check as `Value in Work_Real`, whose range is exactly +/-MJ.Smooth_Math.Work_Limit.

Evidence:
- `minimal-damping-leaf/`: 15 checks, zero open (helper in final package; only subsequent spec comment positioning changed).
- `minimal-kernels-complete/`: first final Solver_Kernels attempt: 116 checks, 3 open at a 5-second cvc5 budget, all in unchanged Add_Row/Add_Row_Disjoint loops. Retained as failed-attempt evidence.
- `minimal-kernels-complete-multiprover/`: final complete Solver_Kernels proof: **116 checks, zero open/errors**, cvc5+altergo,3s per prover, steps0,level0,jobs2;22.8s. This is the accepted final unit proof. The 15 new-leaf checks are a subset, not additional checks to add to116.
- `minimal-damping-callsite/`: selected new call at inertia_phase.adb:445, 1/1 precondition check proved under the existing loader contract and loop invariants.

No integrated timings, build, numerical tests, or machine-code identity checks were performed by this agent. Root handles those before adoption.

## Broader unintegrated draft

`source/` additionally contains Apply_Damping and Prove_Damping_Row_Separation as local helpers, which remove the loop's writable Simulation parameter from the proof boundary. Do not integrate this draft yet:
- exact scalar Add_Damping_Diagonal: 15/15;
- ghost row-separation lemma: 21/21;
- Apply_Damping: 90 checks / 6 open, including quantified exact floating results, off-diagonal frame and output-bound closure;
- narrowed Load_Ancestor_Factor: 12/12 under Apply_Damping's currently unproved contract (one unused initial Result assignment warning).

The narrow wrapper's result confirms that Simulation-wide loop framing was a proof bottleneck, but cannot be claimed as end-to-end closure while Apply_Damping remains open. All exact sources, commands, source hashes and logs are in damping-functional-v2/ and its recorded snapshot.

## Conditional Euler guard experiment

`entry-source/` only strengthens Solve_Euler precondition to Is_Ready and replaces its Phase_Ready rejection branch with a Static assertion. The removed branch condition proves (entry-selected/, two checks) and its actual Euler.Step call precondition proves (entry-callsite/, one check). A separate incidental check of the state equality helper at Euler line92 remained unproved and is retained in entry-selected/.

Do not use these selected lines to claim the remaining solver chain proved: baseline Solve_Euler still has 3 open checks / 15 (exit readiness and combined frame postcondition). Its private Solve helper currently promises only Stable_Ready and Shape; it does not preserve the inputs, cached outputs, force-valid flag, configuration, etc. in its contract. Both Compatible and Strict paths require proper solver frame contracts or narrower mutable scratch parameters before closing whole Solve_Euler and Solve_Acceleration.

## Resource pause

The load-narrow loader run was terminated at root's request to avoid contamination of the integrated benchmark; its tool_error status is an interruption, not proof failure or success. benchmark-pause.txt records this explicitly.

## Final handoff / reproduction

The minimal patch remains unadopted in the active repository on root's instruction. Final full-unit proof command:

```sh
python3 minimal-source/experimental/smooth/tools/prove_fragments.py --repo minimal-source --report-dir minimal-kernels-complete-multiprover --toolchain-root /var/tmp/sparkling-matrix-recovery/toolchains --whole-unit mj-solver_kernels --wall-seconds 120 --total-seconds 130 --prover-seconds 3 --steps 0 --provers cvc5,altergo --level 0 --jobs 2 --cap-mb 2500
```

Run from this handoff directory, or use its absolute paths as recorded in results.json. The selected callsite proof remains 1/1 under the loader's existing assumptions; the complete loader and remaining Solve chain remain pending. No scan removal is included or justified by this patch alone.

`handoff-evidence.zip` contains all successful, failed and interrupted attempts, proof-index.json, exact source objects addressed by SHA-256 for every run, full candidate source, the proof runner/watchdog, patch and this README. Each results.json maps repository paths to source-object hashes. `archive-manifest.json` records the final archive checksum and source continuity checks.
