# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-793ouslu/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Apply_Damping` | `mj-data-inertia_phase.adb:436` | [unproved_checks](logs/mj-data-inertia_phase__apply_damping__adb_436.log) | 10 | 1 | 0 | 26.0 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:467` | [tool_error](logs/mj-data-inertia_phase__load_ancestor_factor__adb_467.log) | 0 | 0 | 0 | 28.3 |

## Diagnostics

### mj-data-inertia_phase__apply_damping__adb_436

- `mj-data-inertia_phase.adb:441` (medium): range check might fail, cannot prove upper bound for Joints'Length [provers gave up before completing the proof]

