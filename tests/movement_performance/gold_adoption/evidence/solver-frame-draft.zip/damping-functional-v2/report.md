# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-eak71tgr/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Damping_Row_Separation` | `mj-data-inertia_phase.adb:436` | [completed_no_unproved](logs/mj-data-inertia_phase__prove_damping_row_separation__adb_436.log) | 21 | 0 | 0 | 22.9 |
| `Apply_Damping` | `mj-data-inertia_phase.adb:460` | [unproved_checks](logs/mj-data-inertia_phase__apply_damping__adb_460.log) | 90 | 6 | 0 | 36.3 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:516` | [completed_with_warnings](logs/mj-data-inertia_phase__load_ancestor_factor__adb_516.log) | 12 | 0 | 0 | 36.7 |

## Diagnostics

### mj-data-inertia_phase__apply_damping__adb_460

- `mj-data-inertia_phase.adb:468` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:468` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:499` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Factor (AR.Start (Rows, K) + AR.Length (Rows, K) - 1) = Initial (AR.Start (Rows, K) + AR.Length (Rows, K) - 1) + Damping_Step * Joints (K).Damping [possible fix: precondition of subprogram at line 460 should mention Damping_Step and Joints] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:499` (medium): loop invariant might fail in first iteration, cannot prove Factor (AR.Start (Rows, K) + AR.Length (Rows, K) - 1) = Initial (AR.Start (Rows, K) + AR.Length (Rows, K) - 1) + Damping_Step * Joints (K).Damping [possible fix: precondition of subprogram at line 460 should mention Damping_Step and Joints] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:501` (medium): float overflow check might fail [reason for check: result of floating-point addition must be bounded] [possible fix: precondition of subprogram at line 460 should mention Damping_Step and Joints] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:507` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Factor (AR.Start (Rows, K) + A) = Initial (AR.Start (Rows, K) + A) [provers gave up before completing the proof]

### mj-data-inertia_phase__load_ancestor_factor__adb_516

- `mj-data-inertia_phase.adb:539` (warning): unused assignment

