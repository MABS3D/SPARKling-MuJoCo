# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-ijhoy7zy/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Damping_Row_Separation` | `mj-data-inertia_phase.adb:436` | [analysis_error](logs/mj-data-inertia_phase__prove_damping_row_separation__adb_436.log) | 0 | 0 | 3 | 1.8 |
| `Apply_Damping` | `mj-data-inertia_phase.adb:460` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:516` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-data-inertia_phase__prove_damping_row_separation__adb_436

- `mj-data-inertia_phase.adb:498` (error): quantified expression must be parenthesized
- `mj-data-inertia_phase.adb:502` (error): quantified expression must be parenthesized
- `mj-data-inertia_phase.adb:505` (error): quantified expression must be parenthesized

