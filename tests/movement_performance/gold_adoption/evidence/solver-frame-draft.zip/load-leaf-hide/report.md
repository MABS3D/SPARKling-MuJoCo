# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-qbfju8wn/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:438` | [unproved_checks](logs/mj-data-inertia_phase__load_ancestor_factor__adb_438.log) | 31 | 20 | 0 | 99.0 |

## Diagnostics

### mj-data-inertia_phase__load_ancestor_factor__adb_438

- `mj-data-inertia_phase.adb:443` (medium): postcondition might fail, cannot prove Configuration_Valid (D.Body_Config.all, D.Joint_Config.all, D.Actuator_Config.all, D.Nb, D.Nj, D.Na) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:443` (medium): in inlined expression function body at mj-data.ads:634
- `mj-data-inertia_phase.adb:464` (medium): precondition might fail, cannot prove Dense'Last = Size (P) * Size (P) - 1 [provers gave up before completing the proof]
- `mj-data-inertia_phase.adb:468` (medium): precondition might fail [provers gave up before completing the proof]
- `mj-data-inertia_phase.adb:468` (medium): precondition might fail [provers gave up before completing the proof]
- `mj-data-inertia_phase.adb:470` (medium): precondition might fail, cannot prove X in Work_Real [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:470` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:473` (medium): assertion might fail, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- 12 more diagnostics in the individual log.

