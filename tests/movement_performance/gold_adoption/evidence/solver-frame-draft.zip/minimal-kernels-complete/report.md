# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-b235wl1n/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-solver_kernels.adb:1` | [unproved_checks](logs/mj-solver_kernels__whole_unit.log) | 116 | 3 | 0 | 49.2 |

## Diagnostics

### mj-solver_kernels__whole_unit

- `mj-solver_kernels.adb:39` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Target (J) = (if J <= I then Add_Product (Target'Loop_Entry (J), Source (Source'First + (J - Target'First)), Multiplier) else Target'Loop_Entry (J)) [provers reached time limit before completing the proof]
- `mj-solver_kernels.adb:80` (medium): loop invariant might not be preserved by an arbitrary iteration [provers reached time limit before completing the proof]
- `mj-solver_kernels.adb:84` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Buffer (J) = (if J in Target_First .. I then Add_Product (Buffer'Loop_Entry (J), Buffer'Loop_Entry (Source_First + (J - Target_First)), Multiplier) else Buffer'Loop_Entry (J)) [provers reached time limit before completing the proof]

