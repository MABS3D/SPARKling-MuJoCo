# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-ohmksrni/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Solve_Euler` | `mj-data-inertia_phase.adb:625` | [unproved_checks](logs/mj-data-inertia_phase__solve_euler__adb_625.log) | 15 | 3 | 0 | 47.8 |

## Diagnostics

### mj-data-inertia_phase__solve_euler__adb_625

- `mj-data-inertia_phase.adb:637` (medium): assertion might fail, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:637` (medium): in inlined expression function body at mj-data.ads:633
- `mj-data-inertia_phase.ads:35` (medium): postcondition might fail [provers reached time limit before completing the proof]

