# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-c9_h1pbb/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 627` | `mj-data-inertia_phase.adb:627` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_627.log) | 2 | 0 | 0 | 80.8 |
| `line 92` | `mj-data-euler.adb:92` | [unproved_checks](logs/mj-data-euler__adb_line_92.log) | 1 | 1 | 0 | 12.9 |

## Diagnostics

### mj-data-euler__adb_line_92

- `mj-data-euler.adb:92` (medium): precondition might fail, cannot prove A = B [provers reached time limit before completing the proof]

