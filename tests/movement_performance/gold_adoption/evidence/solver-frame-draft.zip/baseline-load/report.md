# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-gwz5k8e3/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:417` | [unproved_checks](logs/mj-data-inertia_phase__load_ancestor_factor__adb_417.log) | 32 | 24 | 0 | 117.2 |

## Diagnostics

### mj-data-inertia_phase__load_ancestor_factor__adb_417

- `mj-data-inertia_phase.adb:422` (medium): postcondition might fail, cannot prove Inputs_Bounded (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:422` (medium): in inlined expression function body at mj-data.ads:637
- `mj-data-inertia_phase.adb:439` (medium): precondition might fail, cannot prove Dense'Last = Size (P) * Size (P) - 1 [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:443` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:443` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:445` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:445` (medium): array index check might fail [reason for check: value must be a valid index into the array] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:445` (medium): float overflow check might fail [reason for check: result of floating-point addition must be bounded] [provers reached time limit before completing the proof]
- 16 more diagnostics in the individual log.

