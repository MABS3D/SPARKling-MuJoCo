# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-eywwzhe1/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Buffers` | `mj-data-spatial.adb:93` | [unproved_checks](logs/mj-data-spatial__build_buffers__adb_93.log) | 77 | 7 | 0 | 68.5 |
| `Prepare` | `mj-data-spatial.adb:184` | [unproved_checks](logs/mj-data-spatial__prepare__adb_184.log) | 25 | 10 | 0 | 48.2 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_93

- `mj-data-spatial.adb:121` (medium): postcondition might fail, cannot prove X in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:129` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Inertias (I) in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:132` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:142` (medium): loop invariant might fail in first iteration, cannot prove Inertias (I) in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:146` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:153` (medium): precondition might fail, cannot prove V (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:153` (medium): in inlined expression function body at mj-smooth_math.ads:19

### mj-data-spatial__prepare__adb_184

- `mj-data-spatial.adb:206` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:213` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:215` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:216` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:218` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:219` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:220` (medium): assertion might fail, cannot prove Inputs_Bounded (D) [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:220` (medium): in inlined expression function body at mj-data.ads:637
- 2 more diagnostics in the individual log.

