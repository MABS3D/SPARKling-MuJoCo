# Proved Static spatial storage contracts

Apply storage-static-bounds.patch only. The original exact storage and unaffected-cell frame contracts remain unchanged; new Static postconditions expose bounds of written cells and preservation of previously bounded cells. No input precondition is strengthened. The runtime .adb is unchanged.

The complete MJ.Spatial_Storage unit passes104/104, zero unproved/errors, cvc5+altergo3s, steps0, level0, jobs2. See storage-prefix/results.json and logs for exact commands and tool reports. This is the complete storage-unit result under its dependency contracts; it does not close callers or justify scan removal by itself.

storage-baseline-sha256.json records baseline/proved spec and unchanged body hashes. sources/sha256 contains all98 exact source objects verified against the proof manifest. final-source contains the spec, unchanged body, proof runner and guarded process wrapper. No active source edits, runtime tests or benchmarks were performed by this agent. Parent subsequently integrated this spec and owns further caller validation.
