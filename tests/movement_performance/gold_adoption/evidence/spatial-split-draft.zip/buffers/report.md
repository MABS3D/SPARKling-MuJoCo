# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-jeqgpr3l/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Buffers` | `mj-data-spatial.adb:64` | [unproved_checks](logs/mj-data-spatial__build_buffers__adb_64.log) | 77 | 7 | 0 | 65.5 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_64

- `mj-data-spatial.adb:92` (medium): postcondition might fail, cannot prove X in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:100` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Inertias (I) in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:103` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:113` (medium): loop invariant might fail in first iteration, cannot prove Inertias (I) in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:117` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:124` (medium): precondition might fail, cannot prove V (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:124` (medium): in inlined expression function body at mj-smooth_math.ads:19

