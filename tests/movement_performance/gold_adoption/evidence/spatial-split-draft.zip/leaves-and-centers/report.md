# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-eepg2bjn/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Add_Moment` | `mj-data-spatial.adb:11` | [completed_no_unproved](logs/mj-data-spatial__add_moment__adb_11.log) | 9 | 0 | 0 | 20.0 |
| `Root_Center` | `mj-data-spatial.adb:25` | [completed_no_unproved](logs/mj-data-spatial__root_center__adb_25.log) | 12 | 0 | 0 | 14.2 |
| `Build_Centers` | `mj-data-spatial.adb:40` | [unproved_checks](logs/mj-data-spatial__build_centers__adb_40.log) | 43 | 1 | 0 | 67.5 |

## Diagnostics

### mj-data-spatial__build_centers__adb_40

- `mj-data-spatial.adb:70` (medium): formal parameters "Target" and "Source" might be aliased (SPARK RM 6.4.2)

