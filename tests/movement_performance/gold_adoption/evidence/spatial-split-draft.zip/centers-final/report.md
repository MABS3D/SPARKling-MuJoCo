# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4adu7ftw/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Centers` | `mj-data-spatial.adb:40` | [unproved_checks](logs/mj-data-spatial__build_centers__adb_40.log) | 43 | 2 | 0 | 79.3 |

## Diagnostics

### mj-data-spatial__build_centers__adb_40

- `mj-data-spatial.adb:60` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove V (1) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:60` (medium): in inlined expression function body at mj-smooth_math.ads:19

