# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-eodn1y_8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Buffers` | `mj-data-spatial.adb:94` | [unproved_checks](logs/mj-data-spatial__build_buffers__adb_94.log) | 85 | 6 | 0 | 73.7 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_94

- `mj-data-spatial.adb:122` (medium): postcondition might fail, cannot prove X in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:133` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:142` (medium): assertion might fail, cannot prove Inertias (I) in -1.0e36 .. 1.0e36 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:149` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:157` (medium): assertion might fail, cannot prove V (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:157` (medium): in inlined expression function body at mj-smooth_math.ads:19

