# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-pz0n9a26/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Set_Moment` | `mj-data-spatial.adb:40` | [completed_no_unproved](logs/mj-data-spatial__set_moment__adb_40.log) | 12 | 0 | 0 | 24.2 |
| `Build_Centers` | `mj-data-spatial.adb:56` | [completed_no_unproved](logs/mj-data-spatial__build_centers__adb_56.log) | 42 | 0 | 0 | 60.2 |

## Diagnostics

