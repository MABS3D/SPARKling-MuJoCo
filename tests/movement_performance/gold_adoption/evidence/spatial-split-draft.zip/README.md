# Spatial preparation proof split — bounded experiment, 2026-09-26/27

No active repository source was edited by this agent. All work is in this isolated tree. All owned proof/build processes are finished. No runtime numerical tests, machine-code comparison, or benchmark was performed by this agent.

## Independently adoptable change

`storage-static-bounds.patch` changes only `mj-spatial_storage.ads`: existing exact stored values and preservation of every unaffected cell are retained. Static postconditions additionally expose bounds for written cells and preservation of any previously bounded cell. The runtime storage body is byte-identical to the baseline.

The final complete `MJ.Spatial_Storage` unit passes **104/104 checks, zero unproved/errors**, using cvc5+altergo, 3 seconds per prover, steps0, level0, jobs2 (`storage-prefix/`). The earlier 98-check result is an earlier version, not an additional independent total. This change carries no new domain restriction or assumption, and adds no runtime check.

Baseline spec SHA256: `523a98262b271efffb26f2681c78a5ae35543331261350b9f1b067f4412a38b5`

Proved spec SHA256: `08ffda6963208c8164662ab8c431f8d039de24b4a6fa5af6e30855d0ae9f26ba`

Unchanged body SHA256: `502d06c6f7698f1db52fefd80c0508ff89a84fa4fb4406fc8555d60bd47ceb2c`

Exact source snapshot: `/tmp/sparkling-smooth-fragments-yb4fi4jf/source`. The same spec is in `source/experimental/smooth/src/`.

## Broader draft — not ready for integration or scan removal

`spatial-split-draft.patch` and `source/experimental/smooth/src/mj-data-spatial.adb` split the previous Prepare body into narrow readonly inputs, mutable spatial arrays, exact arithmetic leaves, and a small publication wrapper. The public Prepare API and postconditions are unchanged. Original arithmetic order, numeric failure branches, world-zero inertia, root-center fallback, and Spatial_Valid publication are retained. The reverse accumulation copies the child vector before borrowing the parent element, avoiding aliasing without changing arithmetic.

Scoped closure achieved:

| Scope | Checks | Exact evidence |
| --- | ---: | --- |
| Add_Moment | 9/9 | leaves-and-centers/; exact accepted sum, exact rejected unchanged target, Ok equals bound decision |
| Root_Center | 12/12 | leaves-and-centers/; exact mass-threshold branch and multiply-after-reciprocal expression, Ok equals output bound decision |
| Set_Moment | 12/12 | moment-leaf/; exact Mass_Moment result, unchanged other vectors, preserves all moment bounds |
| Build_Centers | 42/42 | moment-leaf/; array safety, numeric-domain bounds, world center zero, success implies validated pose centers |
| Expose_Stable_Ready | 5/5 | wrapper/ |
| Establish_Stable_Ready | 5/5 | wrapper/ |
| Expose_Spatial_Layout | 5/5 | narrow-prefix/ |

Build_Centers is a useful proof prerequisite, not a completed Gold specification of ordered subtree COM accumulation. Its exact arithmetic leaves are proved, but a complete ordered accumulation ghost model and composed physical/accuracy properties are still pending. No Silver exception is claimed. These scoped results do not establish the complete Spatial unit or dynamics.

Final source snapshot for Set_Moment and Build_Centers is `/tmp/sparkling-smooth-fragments-pz0n9a26/source`, matching the final candidate body. Add_Moment and Root_Center definitions are unchanged from their closed snapshot.

Remaining obligations:

* `Build_Buffers`: `narrow-prefix/` emits88 checks and5 unproved diagnostic lines (4 distinct obligations), no errors. In its immutable snapshot `/tmp/sparkling-smooth-fragments-v2zc10ed/source`, lines125/135/152 are final motion-bound postcondition and outer/inner motion-prefix preservation; line160 (plus smooth_math.ads continuation) is deriving the selected joint direction bound. The stronger storage posts closed the earlier inertia-prefix obligations. The current source has these same buffer statements shifted14 lines by Set_Moment: lines139/149/166/174.
* `Prepare`: last attempt in `narrow-prefix/` timed out85.1s before emitting obligations, so zero emitted diagnostics is not success. The prior `buffers-wrapper-v2/` snapshot emitted25 checks and10 diagnostic lines covering Build_Buffers input facts, Stable_Ready reestablishment, position/velocity/state/input frames, Inputs_Bounded, and configuration equality. See the exact stored logs; a timeout alone does not demonstrate a runtime defect.
* The complete Spatial unit and caller/dependency closure remain pending. No Phase_Ready scan was removed. No partial wrapper proof is substituted for full closure.

The next focused route is to isolate per-body joint-motion writes and explicit ownership/index equalities, then expose pose/layout facts once through proved ghost helpers while keeping unrelated simulation state opaque. Do not weaken original postconditions or introduce assumptions/suppression. Caches_Bounded constrains these spatial arrays only when Spatial_Valid is true; the normal false-cache branch cannot assume all stale cells are bounded, so the draft retains written-prefix proofs.

## C structure checked

The local normal MuJoCo3.14.0 reference (`mjVERSION_HEADER3014000`) at `/var/tmp/sparkling-movement-c/source/src/engine/engine_core_smooth.c`, `mj_comPos`, lines250–353 initializes body moments, accumulates backward to parents, normalizes by subtree mass, stores world/body inertias, then maps motion DOFs. This draft retains the existing supported hinge/slide implementation and arithmetic; it does not claim support for C's sleeping, free, or ball branches. Its normalization of only used root centers is an existing supported-subset choice, not a newly introduced optimization.

## Evidence and reproducibility

Each report directory retains results.json, manifest.json, report.md, command lines, tool versions, stdout/stderr logs and structured proof output. Every attempt is retained, including syntax/alias diagnostics and timeouts:

centers/, centers-v2/, buffers/, wrapper/, storage-complete/, leaves-and-centers/, buffers-wrapper-v2/, centers-final/, buffers-final/, storage-prefix/, narrow-prefix/, moment-leaf/.

`proof-index.json` indexes every result without merging overlapping counts. `evidence.zip` contains these reports, patches, final changed files, the original Spatial body, source objects by SHA256, runner/watchdog, and relevant repository policy. Source hashes recorded by every invocation are checked against its immutable snapshot before packaging. `archive-manifest.json` records archive checksum and CRC/source-continuity validation. Parent performs integration checks and timing before any runtime draft adoption.
