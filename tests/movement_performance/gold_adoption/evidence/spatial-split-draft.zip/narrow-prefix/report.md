# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-v2zc10ed/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Centers` | `mj-data-spatial.adb:40` | [proof_timeout](logs/mj-data-spatial__build_centers__adb_40.log) | 0 | 0 | 0 | 85.1 |
| `Build_Buffers` | `mj-data-spatial.adb:96` | [unproved_checks](logs/mj-data-spatial__build_buffers__adb_96.log) | 88 | 5 | 0 | 72.5 |
| `Expose_Spatial_Layout` | `mj-data-spatial.adb:192` | [completed_no_unproved](logs/mj-data-spatial__expose_spatial_layout__adb_192.log) | 5 | 0 | 0 | 7.3 |
| `Prepare` | `mj-data-spatial.adb:205` | [proof_timeout](logs/mj-data-spatial__prepare__adb_205.log) | 0 | 0 | 0 | 85.1 |

## Diagnostics

### mj-data-spatial__build_buffers__adb_96

- `mj-data-spatial.adb:125` (medium): postcondition might fail, cannot prove X in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:135` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:152` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Motions (6 * J + I) in -1.0e12 .. 1.0e12 [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:160` (medium): assertion might fail, cannot prove V (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-spatial.adb:160` (medium): in inlined expression function body at mj-smooth_math.ads:19

