# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-txft4kne/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_Centers` | `mj-data-spatial.adb:11` | [analysis_error](logs/mj-data-spatial__build_centers__adb_11.log) | 0 | 0 | 1 | 2.0 |

## Diagnostics

### mj-data-spatial__build_centers__adb_11

- `mj-data-spatial.adb:32` (error): pragma "LOOP_INVARIANT" must appear next to pragma at line 29

