# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-i88k31p2/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Expose_Stable_Ready` | `mj-data-spatial.adb:134` | [completed_no_unproved](logs/mj-data-spatial__expose_stable_ready__adb_134.log) | 5 | 0 | 0 | 25.9 |
| `Establish_Stable_Ready` | `mj-data-spatial.adb:144` | [completed_no_unproved](logs/mj-data-spatial__establish_stable_ready__adb_144.log) | 5 | 0 | 0 | 6.3 |
| `Prepare` | `mj-data-spatial.adb:155` | [analysis_error](logs/mj-data-spatial__prepare__adb_155.log) | 0 | 0 | 4 | 2.5 |

## Diagnostics

### mj-data-spatial__prepare__adb_155

- `mj-data-spatial.adb:167` (error): subtype constraint cannot depend on variable input "D" [E0007]
- `mj-data-spatial.adb:167` (error): use instead a constant initialized to the expression with variable input
- `mj-data-spatial.adb:167` (error): launch "gnatprove --explain=E0007" for more information
- `mj-data-spatial.adb:167` (error): subtype constraint cannot depend on variable input "D"

