from pathlib import Path
import os,subprocess,json,signal,hashlib
out=Path(__file__).parent;tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains')
env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
source={str(p.relative_to(out/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'source').rglob('*') if p.is_file()}
(out/'source-manifest.json').write_text(json.dumps(source,indent=2))
for name,unit,line in [('world','mj-fused_rne.adb',4),('gyro-model','mj-fused_rne.ads',22),('body-model','mj-fused_rne.ads',30),('try-body','mj-fused_rne.adb',9)]:
 cmd=['gnatprove','-P',str(out/'proof.gpr'),'-u',unit,'--limit-subp='+unit+':'+str(line),'--level=0','--proof=per_check','--timeout=3','--prover=cvc5,altergo','-j2','--checks-as-errors=on','--report=all','--counterexamples=off']
 (out/(name+'.command.json')).write_text(json.dumps(cmd,indent=2))
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:r=p.wait(timeout=120)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);r=p.wait();f.write('\nWall-time cap120s reached\n')
 (out/(name+'.exit')).write_text(str(r));print(name,r,flush=True);print((out/(name+'.log')).read_text()[-14000:],flush=True)
 g=out/'obj/gnatprove/mj-fused_rne.spark'
 if g.exists():(out/(name+'.spark.json')).write_bytes(g.read_bytes())
 if r:break
