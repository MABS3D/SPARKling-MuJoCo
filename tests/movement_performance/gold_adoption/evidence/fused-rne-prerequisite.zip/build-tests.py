from pathlib import Path
import subprocess,os,json
out=Path(__file__).parent;tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
for kind,flags in [('checked','"-O0", "-g", "-gnata", "-gnato", "-gnatVa"'),('release','"-O3", "-gnatp", "-march=native", "-flto"')]:
 name='Test_'+kind.title();gpr='project '+name+' is\n for Source_Dirs use ("source");\n for Main use ("fused_rne_test.adb");\n for Object_Dir use "test-'+kind+'-obj";\n for Exec_Dir use "bin-'+kind+'";\n for Create_Missing_Dirs use "True";\n package Compiler is\n for Default_Switches ("Ada") use ("-gnat2022", '+flags+', "-ffp-contract=off");\n end Compiler;\nend '+name+';\n';p=out/('test_'+kind+'.gpr');p.write_text(gpr)
 cmd=['gprbuild','-P',str(p),'-j2'];r=subprocess.run(cmd,cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/('build-'+kind+'.log')).write_text(r.stdout);print(kind,'build',r.returncode);print(r.stdout[-3000:]);
 if r.returncode:raise SystemExit(r.returncode)
 r=subprocess.run([str(out/('bin-'+kind)/'fused_rne_test')],cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/('test-'+kind+'.log')).write_text(r.stdout);print(kind,'test',r.returncode,r.stdout);r.check_returncode()
