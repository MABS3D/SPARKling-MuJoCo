# CRB candidate/publication follow-up — isolated, 2026-09-27

No active repository file was modified. No scan was removed, no runtime candidate adopted, and no benchmark or broad Assemble proof was run. This archive is separate from the earlier handoff/ candidate and the independently closed Mass_Publication helper.

## Best final candidate

- Try_CRB_Candidate: 4/4 proof checks closed, zero errors, 25.2 s.
- Try_CRB_Publication: 7 proof records, 6 proved and 1 open postcondition record, zero errors, 99.9 s. The driver reports two unproved diagnostics because it also records the expression-function expansion location; there are not two distinct failed proof records.
- The only remaining diagnostic is Symmetric_Mass in the success portion of the wrapper's postcondition. The original Work_Array callsite failure is gone; the published precondition and candidate producer precondition now pass. State_Values is no longer reported as a blocker, but the combined wrapper postcondition remains unproved, so no complete frame/Gold claim is made.

The final code adds a small readonly producer wrapper, then removes the unnecessary Relaxed_Initialization annotation from the local Candidate. Try_Assemble_CRB itself is unchanged. Its out parameter is fully initialized on return; removing the annotation changes verification representation, not runtime assignments. The new wrapper exposes only elementwise membership in the existing Work_Real subtype and the existing symmetry predicate. Its proof composes the old producer contract; it does not close the producer body.

The intermediate explicit-bounds variant with Relaxed_Initialization still emitted 9 checks and 2 failed proof records (symmetry precondition and state frame), in 76.0 s. It is archived as diagnostic evidence. Removing that annotation leaves 7 checks with the publication precondition proved and the residual failure moved to the final symmetry postcondition. This is evidence of a proof-representation obstacle, not proof of a general solver bug.

## Exact residual boundary and bounded opaque-predicate attempt

Final experimental/smooth/src/mj-data-inertia_phase.adb line124 calls:

```ada
MJ.Data.Mass_Publication.Publish (D, Candidate);
```

That call's precondition is now proved. The already closed Publish contract in mj-data-mass_publication.ads lines12–22 promises Is_Ready(D), Mass_Current(D), Symmetric_Mass(D), all listed frame properties and exact mass contents. No statement mutates D after this call before the wrapper returns.

The remaining wrapper goal is mj-data-inertia_phase.ads line13:

```ada
and then (if Used_CRB then Mass_Current (D) and then Symmetric_Mass (D));
```

GNATprove diagnoses the expansion in mj-data.ads line742:

```ada
D.Dynamics.Mass (I * D.Nv + J) = D.Dynamics.Mass (J * D.Nv + I)
```

Symmetric_Mass is an expression function at mj-data.ads lines739–742, combining Is_Ready with a nested row/column quantifier. The final wrapper hides Smooth_Dynamics.Symmetric, but does not hide Data.Symmetric_Mass. A final authorized attempt kept Symmetric_Mass opaque in Try_CRB_Publication, reusing the already proved Publish postcondition directly. It reached the watchdog at 90.2 s with no completed proof records (peak group RSS 529 MB). This is not a pass or evidence that the predicate approach cannot work. Its exact changed source and timeout are archived in proof-crb-publication-opaque-symmetry. The source/ final candidate has been restored to the preceding completed 6/7 result. No further proof was launched.

This is not a claim that the remaining goal is false or that a new assumption is needed. The structured record has prover timeouts. Do not remove any runtime guard on this evidence.

## Source and proof continuity

Existing Assemble and later contracts, original CRB producer, successful outer branch, dense fallback and later bodies are unchanged. The Mass_Publication helper matches its previous closed 64-check source. source-continuity.json records these checks and the exact readonly wrapper text matches its closed 4-check proof snapshot. Full producer, Spatial.Prepare and Assemble dependency closure still remain open.

The source snapshot includes the unused Fused_RNE unit and accepted pose change, but predates the later strengthened Static Spatial_Storage specification. The patch does not touch that file. Keep newer active changes when reviewing it. No claim of full current-source equivalence is made.

proofs.zip contains the four follow-up runs and exact commands/structured records. proof-source-objects.zip preserves all their immutable source inputs by SHA256. proof-check-summary.json distinguishes failed proof records from duplicate diagnostics. source/ contains the final 6/7 candidate; all hashes and ZIP CRCs were checked.

Reproduce the two bounded targets separately, smallest first:

```sh
ulimit -s 65536
python3 experimental/smooth/tools/prove_fragments.py \
  --repo /var/tmp/sparkling-mass-publication-integration \
  --toolchain-root /var/tmp/sparkling-matrix-recovery/toolchains \
  --unit mj-data-inertia_phase --name Try_CRB_Candidate \
  --report-dir /var/tmp/crb-readonly-new-run \
  --prepare-seconds 110 --wall-seconds 110 --total-seconds 120 \
  --prover-seconds 3 --steps 0 --provers cvc5,z3 --cap-mb 3000 --jobs 1
```

Then substitute Try_CRB_Publication and a fresh report directory. These proofs are modular and are not substitutes for the open producer body or runtime validation.
