with MJ.Types; use MJ.Types;
with MJ.Spatial_Kernels;
package MJ.Composite_Bounds with SPARK_Mode, Ghost => Static is
   Max_Bodies : constant := 4_096;
   Quantum : constant Real := 2.0 ** 120;
   subtype Weight is Positive range 1 .. Max_Bodies;
   procedure Bound_Sum (A, B : Real; NA, NB : Weight)
     with Global => null,
     Pre => NA <= Max_Bodies - NB
       and then A in -Real (NA)*Quantum .. Real (NA)*Quantum
       and then B in -Real (NB)*Quantum .. Real (NB)*Quantum,
     Post => A + B in -Real (NA + NB)*Quantum .. Real (NA + NB)*Quantum;
end MJ.Composite_Bounds;
