# CRB composite bound: proved numerical prerequisite, pending integration

Target: remove only the post-add `SK.Bounded (Sum, 1.0e40)` rejection in the
reverse CRB body accumulation. Keep arithmetic exactly `SK.Add(Parent, Child)`.
The C 3.14.0 mj_crb accumulation likewise adds each child inertia to its parent.

Existing facts: Load_Inertia provides each body's ten components bounded by
1e36; the active model admits at most 4096 bodies (not 256, the DOF limit).
Each composite represents the rounded sum of disjoint original body inertias.

Candidate tight bound: count * 2**120. Its maximum at 4096 is about 5.445e39,
below 1e40. The leaf bound exceeds 1e36, and endpoints should be exactly
representable for integer counts in 1..4096. GNATprove did not automatically
close the generic rounded-add bound under the tested budgets.

Candidate with rounding margin: (3*count-1) * 2**119. Its leaf bound remains
2**120 and maximum is about 8.166e39. A merge leaves a 2**119 margin between the
sum of child budgets and the parent budget. The scalar rounded-add theorem is now PROVED: 15 checks, with altergo
closing the last bound direction in 11.45 s under a 30 s/check budget. The
leaf/global Budget_Bounds lemma passes 2 checks, and the inertia-vector wrapper
passes 19 checks after ten explicit ghost calls to the scalar lemma. Complete helper unit passes 39 checks. Initial
short-budget failures are retained as diagnostics. No guard was removed or
active source modified.

Once the scalar theorem closes, use ghost positive weights and the invariant
that the sum of weights in the active prefix 0..B is at most Nb. On merging
B into P<B, increment Weight(P) by Weight(B), then drop B from the active prefix.
Processed entries may retain their weights and composite values, needed later
for per-DOF products; exclude them from the active-prefix accounting rather
than zeroing or modifying their runtime inertia. Root children with P=0 are
removed from active accounting without accumulating into the unused world.
A separate integer prefix-sum transfer lemma establishes both merged count
<= Nb and conservation/decrease of the active-prefix total. All weights and
lemmas are Ghost=>Static and must leave generated arithmetic unchanged.

Integration remains unimplemented. The numerical prerequisite is proved, but
the runtime CRB guard is still present until the caller supplies the integer
weight conservation invariant. Do not label the whole CRB path complete or
substitute an Assume/unchecked conversion.
