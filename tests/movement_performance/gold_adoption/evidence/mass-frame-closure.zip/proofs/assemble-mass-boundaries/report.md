# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-ol5xo4ga/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble` | `mj-data-inertia_phase.adb:654` | [unproved_checks](logs/mj-data-inertia_phase__assemble__adb_654.log) | 33 | 12 | 0 | 85.9 |

## Diagnostics

### mj-data-inertia_phase__assemble__adb_654

- `mj-data-inertia_phase.adb:687` (medium): precondition might fail, cannot prove Target'Last = Nv * Nv - 1 [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:693` (medium): assertion might fail, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:693` (medium): in inlined expression function body at mj-data.ads:633
- `mj-data-inertia_phase.adb:695` (medium): precondition might fail, cannot prove Mass'Last = Nv * Nv - 1 [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:696` (medium): precondition might fail, cannot prove Stable_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:696` (medium): in inlined expression function body at mj-data.ads:637
- `mj-data-inertia_phase.adb:701` (medium): precondition might fail, cannot prove Linear'Last = 3 * Bodies'Length * Nv - 1 [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:705` (medium): assertion might fail, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- 4 more diagnostics in the individual log.

