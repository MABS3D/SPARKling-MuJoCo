# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-klucbp69/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `State_Representation` | `mj-data-inertia_phase.adb:686` | [completed_no_unproved](logs/mj-data-inertia_phase__state_representation__adb_686.log) | 5 | 0 | 0 | 20.4 |
| `Equal_State_Images` | `mj-data-inertia_phase.adb:699` | [unproved_checks](logs/mj-data-inertia_phase__equal_state_images__adb_699.log) | 7 | 1 | 0 | 5.9 |

## Diagnostics

### mj-data-inertia_phase__equal_state_images__adb_699

- `mj-data-inertia_phase.adb:705` (medium): postcondition might fail [provers reached time limit before completing the proof]

