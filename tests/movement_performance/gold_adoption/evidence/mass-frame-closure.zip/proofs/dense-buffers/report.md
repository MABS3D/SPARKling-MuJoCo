# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-dfgewvq7/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble_Dense_Mass` | `mj-data-inertia_phase.adb:547` | [unproved_checks](logs/mj-data-inertia_phase__assemble_dense_mass__adb_547.log) | 61 | 3 | 0 | 60.6 |

## Diagnostics

### mj-data-inertia_phase__assemble_dense_mass__adb_547

- `mj-data-inertia_phase.adb:554` (medium): range check might fail, cannot prove upper bound for Joints'Length [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:610` (medium): overflow check might fail, cannot prove upper bound for V * Nv + V [reason for check: result of addition must fit in a 32-bits machine integer] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:611` (medium): array index check might fail [reason for check: value must be a valid index into the array] [provers reached time limit before completing the proof]

