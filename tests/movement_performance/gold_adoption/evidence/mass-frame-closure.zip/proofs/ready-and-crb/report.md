# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-at4pok47/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Ready_Properties` | `mj-data-inertia_phase.adb:700` | [completed_no_unproved](logs/mj-data-inertia_phase__ready_properties__adb_700.log) | 1 | 0 | 0 | 18.8 |
| `Assemble_CRB_Path` | `mj-data-inertia_phase.adb:708` | [unproved_checks](logs/mj-data-inertia_phase__assemble_crb_path__adb_708.log) | 25 | 2 | 0 | 43.1 |

## Diagnostics

### mj-data-inertia_phase__assemble_crb_path__adb_708

- `mj-data-inertia_phase.adb:714` (medium): postcondition might fail, cannot prove D.Allocated [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:714` (medium): in inlined expression function body at mj-data.ads:426

