# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4ipo8_ed/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Expose_Assembly_Layout` | `mj-data-inertia_phase.adb:640` | [completed_no_unproved](logs/mj-data-inertia_phase__expose_assembly_layout__adb_640.log) | 15 | 0 | 0 | 24.0 |
| `Assemble_Dense_Path` | `mj-data-inertia_phase.adb:961` | [unproved_checks](logs/mj-data-inertia_phase__assemble_dense_path__adb_961.log) | 30 | 1 | 0 | 33.9 |

## Diagnostics

### mj-data-inertia_phase__assemble_dense_path__adb_961

- `mj-data-inertia_phase.adb:965` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]

