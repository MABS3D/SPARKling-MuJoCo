# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-l53d52c_/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble_Dense_Path` | `mj-data-inertia_phase.adb:944` | [unproved_checks](logs/mj-data-inertia_phase__assemble_dense_path__adb_944.log) | 19 | 2 | 0 | 52.3 |

## Diagnostics

### mj-data-inertia_phase__assemble_dense_path__adb_944

- `mj-data-inertia_phase.adb:1017` (medium): precondition might fail, cannot prove A (MJ.Smooth_Kernels.Matrix_Offset (N, I, J)) = A (MJ.Smooth_Kernels.Matrix_Offset (N, J, I)) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:1017` (medium): in inlined expression function body at mj-smooth_dynamics.ads:116

