# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-gmqworp4/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble` | `mj-data-inertia_phase.adb:623` | [unproved_checks](logs/mj-data-inertia_phase__assemble__adb_623.log) | 44 | 12 | 0 | 88.1 |

## Diagnostics

### mj-data-inertia_phase__assemble__adb_623

- `mj-data-inertia_phase.adb:648` (warning): unused assignment
- `mj-data-inertia_phase.adb:656` (medium): length check might fail [reason for check: array must be of the appropriate length] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:662` (medium): assertion might fail, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:662` (medium): in inlined expression function body at mj-data.ads:633
- `mj-data-inertia_phase.adb:665` (medium): precondition might fail, cannot prove Stable_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:665` (medium): in inlined expression function body at mj-data.ads:637
- `mj-data-inertia_phase.adb:668` (warning): unused assignment
- `mj-data-inertia_phase.adb:669` (medium): precondition might fail, cannot prove R (0, 0) in -Limit .. Limit [provers reached time limit before completing the proof]
- 6 more diagnostics in the individual log.

