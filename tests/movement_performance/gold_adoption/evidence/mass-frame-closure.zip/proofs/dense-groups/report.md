# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-o90zw5zh/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Fill_Dense_Ready` | `mj-data-inertia_phase.adb:845` | [completed_no_unproved](logs/mj-data-inertia_phase__fill_dense_ready__adb_845.log) | 27 | 0 | 0 | 105.4 |
| `Fill_And_Mark_Mass` | `mj-data-inertia_phase.adb:894` | [completed_no_unproved](logs/mj-data-inertia_phase__fill_and_mark_mass__adb_894.log) | 17 | 0 | 0 | 42.1 |

## Diagnostics

