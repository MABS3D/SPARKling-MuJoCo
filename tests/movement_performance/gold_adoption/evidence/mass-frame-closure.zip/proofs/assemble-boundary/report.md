# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-49el_3uu/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble_Ready` | `mj-data-inertia_phase.adb:1040` | [unproved_checks](logs/mj-data-inertia_phase__assemble_ready__adb_1040.log) | 34 | 2 | 0 | 77.6 |
| `Assemble` | `mj-data-inertia_phase.adb:1140` | [completed_no_unproved](logs/mj-data-inertia_phase__assemble__adb_1140.log) | 2 | 0 | 0 | 9.4 |

## Diagnostics

### mj-data-inertia_phase__assemble_ready__adb_1040

- `mj-data-inertia_phase.adb:1042` (medium): postcondition might fail, cannot prove Configuration_Valid (D.Body_Config.all, D.Joint_Config.all, D.Actuator_Config.all, D.Nb, D.Nj, D.Na) [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:1042` (medium): in inlined expression function body at mj-data.ads:634

