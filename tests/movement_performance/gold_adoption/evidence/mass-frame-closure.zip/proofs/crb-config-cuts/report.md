# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-2s_xy38t/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_And_Publish_CRB` | `mj-data-inertia_phase.adb:719` | [unproved_checks](logs/mj-data-inertia_phase__build_and_publish_crb__adb_719.log) | 15 | 2 | 0 | 83.3 |
| `Assemble_CRB_Path` | `mj-data-inertia_phase.adb:778` | [completed_no_unproved](logs/mj-data-inertia_phase__assemble_crb_path__adb_778.log) | 19 | 0 | 0 | 71.9 |

## Diagnostics

### mj-data-inertia_phase__build_and_publish_crb__adb_719

- `mj-data-inertia_phase.adb:730` (medium): postcondition might fail, cannot prove D.Dynamics.Mass (I * D.Nv + J) = D.Dynamics.Mass (J * D.Nv + I) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:730` (medium): in inlined expression function body at mj-data.ads:742

