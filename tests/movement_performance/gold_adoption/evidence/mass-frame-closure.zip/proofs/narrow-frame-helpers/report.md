# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-yrh4jzke/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Refresh_Jacobian_Cache` | `mj-data-pipeline.adb:691` | [unproved_checks](logs/mj-data-pipeline__refresh_jacobian_cache__adb_691.log) | 16 | 1 | 0 | 49.3 |
| `Ensure_Jacobians` | `mj-data-pipeline.adb:737` | [completed_no_unproved](logs/mj-data-pipeline__ensure_jacobians__adb_737.log) | 4 | 0 | 0 | 13.6 |
| `Expose_Assembly_Layout` | `mj-data-inertia_phase.adb:654` | [completed_no_unproved](logs/mj-data-inertia_phase__expose_assembly_layout__adb_654.log) | 15 | 0 | 0 | 10.8 |

## Diagnostics

### mj-data-pipeline__refresh_jacobian_cache__adb_691

- `mj-data-pipeline.adb:693` (medium): postcondition might fail [provers reached time limit before completing the proof]

