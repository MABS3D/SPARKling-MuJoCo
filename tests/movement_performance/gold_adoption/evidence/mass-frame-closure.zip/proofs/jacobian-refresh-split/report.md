# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-jknf2iuh/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Refresh_Jacobian_Cache` | `mj-data-pipeline.adb:691` | [unproved_checks](logs/mj-data-pipeline__refresh_jacobian_cache__adb_691.log) | 16 | 1 | 0 | 63.0 |
| `Refresh_Jacobian_Cache` | `mj-data-pipeline.adb:708` | [unproved_checks](logs/mj-data-pipeline__refresh_jacobian_cache__adb_708.log) | 16 | 1 | 0 | 5.6 |

## Diagnostics

### mj-data-pipeline__refresh_jacobian_cache__adb_691

- `mj-data-pipeline.adb:695` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]

### mj-data-pipeline__refresh_jacobian_cache__adb_708

- `mj-data-pipeline.adb:695` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]

