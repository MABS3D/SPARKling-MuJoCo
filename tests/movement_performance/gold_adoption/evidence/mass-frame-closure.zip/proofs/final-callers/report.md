# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-vpi51v5e/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble` | `mj-data-inertia.adb:4` | [completed_no_unproved](logs/mj-data-inertia__assemble__adb_4.log) | 2 | 0 | 0 | 28.0 |
| `Assemble` | `mj-data-inertia_phase.adb:1141` | [completed_no_unproved](logs/mj-data-inertia_phase__assemble__adb_1141.log) | 2 | 0 | 0 | 9.5 |
| `Ensure_Jacobians` | `mj-data-pipeline.adb:719` | [completed_no_unproved](logs/mj-data-pipeline__ensure_jacobians__adb_719.log) | 18 | 0 | 0 | 42.2 |
| `Evaluate_Ready` | `mj-data-pipeline.adb:884` | [completed_no_unproved](logs/mj-data-pipeline__evaluate_ready__adb_884.log) | 26 | 0 | 0 | 28.9 |

## Diagnostics

