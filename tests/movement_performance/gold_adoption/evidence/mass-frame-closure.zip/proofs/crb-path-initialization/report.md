# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-kg4r9a8_/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble_CRB_Path` | `mj-data-inertia_phase.adb:700` | [unproved_checks](logs/mj-data-inertia_phase__assemble_crb_path__adb_700.log) | 23 | 2 | 0 | 53.7 |

## Diagnostics

### mj-data-inertia_phase__assemble_crb_path__adb_700

- `mj-data-inertia_phase.adb:702` (medium): postcondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:777` (medium): assertion might fail [provers reached time limit before completing the proof]

