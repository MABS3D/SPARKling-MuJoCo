# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-8odtg5hk/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_And_Publish_CRB` | `mj-data-inertia_phase.adb:719` | [analysis_error](logs/mj-data-inertia_phase__build_and_publish_crb__adb_719.log) | 0 | 0 | 4 | 15.2 |
| `Assemble_CRB_Path` | `mj-data-inertia_phase.adb:755` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-data-inertia_phase__build_and_publish_crb__adb_719

- `mj-data-inertia_phase.adb:747` (error): subtype constraint cannot depend on variable input "D" [E0007]
- `mj-data-inertia_phase.adb:747` (error): use instead a constant initialized to the expression with variable input
- `mj-data-inertia_phase.adb:747` (error): launch "gnatprove --explain=E0007" for more information
- `mj-data-inertia_phase.adb:747` (error): subtype constraint cannot depend on variable input "D"

