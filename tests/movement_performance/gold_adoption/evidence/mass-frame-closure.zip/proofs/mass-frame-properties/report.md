# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-dw1xccok/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Equal_Mass_Properties` | `mj-data-inertia_phase.adb:947` | [completed_no_unproved](logs/mj-data-inertia_phase__equal_mass_properties__adb_947.log) | 3 | 0 | 0 | 15.8 |
| `Build_And_Publish_CRB` | `mj-data-inertia_phase.adb:693` | [completed_no_unproved](logs/mj-data-inertia_phase__build_and_publish_crb__adb_693.log) | 15 | 0 | 0 | 67.7 |

## Diagnostics

