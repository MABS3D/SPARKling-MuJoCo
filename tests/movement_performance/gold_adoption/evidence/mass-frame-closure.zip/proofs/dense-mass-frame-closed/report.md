# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-iq43kv9q/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble_Dense_Path` | `mj-data-inertia_phase.adb:961` | [unproved_checks](logs/mj-data-inertia_phase__assemble_dense_path__adb_961.log) | 27 | 3 | 0 | 50.3 |

## Diagnostics

### mj-data-inertia_phase__assemble_dense_path__adb_961

- `mj-data-inertia_phase.adb:965` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:1023` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:1028` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]

