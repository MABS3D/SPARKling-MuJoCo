# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-lmdho0ic/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble_Dense_Path` | `mj-data-inertia_phase.adb:972` | [unproved_checks](logs/mj-data-inertia_phase__assemble_dense_path__adb_972.log) | 19 | 1 | 0 | 47.4 |

## Diagnostics

### mj-data-inertia_phase__assemble_dense_path__adb_972

- `mj-data-inertia_phase.adb:1047` (medium): precondition might fail, cannot prove MJ.Smooth_Dynamics.Work_Array (D.Dynamics.Mass.all) [provers reached time limit before completing the proof]

