# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-63rrb28f/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Evaluate_Inertia_Forces` | `mj-data-pipeline.adb:719` | [completed_with_warnings](logs/mj-data-pipeline__evaluate_inertia_forces__adb_719.log) | 18 | 0 | 0 | 36.3 |
| `Evaluate_Actuation_Acceleration` | `mj-data-pipeline.adb:795` | [completed_no_unproved](logs/mj-data-pipeline__evaluate_actuation_acceleration__adb_795.log) | 18 | 0 | 0 | 25.6 |

## Diagnostics

### mj-data-pipeline__evaluate_inertia_forces__adb_719

- `mj-data-pipeline.adb:789` (warning): statement has no effect

