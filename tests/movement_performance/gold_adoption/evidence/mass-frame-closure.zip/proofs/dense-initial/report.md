# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-ralqjmk_/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble_Dense_Mass` | `mj-data-inertia_phase.adb:547` | [analysis_error](logs/mj-data-inertia_phase__assemble_dense_mass__adb_547.log) | 0 | 0 | 1 | 2.1 |

## Diagnostics

### mj-data-inertia_phase__assemble_dense_mass__adb_547

- `mj-data-inertia_phase.adb:589` (error): prefix of dereference must be an access type

