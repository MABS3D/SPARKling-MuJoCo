# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-8cc568yn/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Copy_Bounded_Mass` | `mj-data-inertia_phase.adb:623` | [completed_no_unproved](logs/mj-data-inertia_phase__copy_bounded_mass__adb_623.log) | 5 | 0 | 0 | 15.4 |
| `Prove_Dense_Inputs` | `mj-data-inertia_phase.adb:638` | [completed_no_unproved](logs/mj-data-inertia_phase__prove_dense_inputs__adb_638.log) | 12 | 0 | 0 | 16.8 |

## Diagnostics

