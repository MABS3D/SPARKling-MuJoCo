# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-o21lxb2o/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Fill_Dense_Ready` | `mj-data-inertia_phase.adb:793` | [proof_timeout](logs/mj-data-inertia_phase__fill_dense_ready__adb_793.log) | 0 | 0 | 0 | 130.2 |
| `Fill_And_Mark_Mass` | `mj-data-inertia_phase.adb:857` | [unproved_checks](logs/mj-data-inertia_phase__fill_and_mark_mass__adb_857.log) | 6 | 1 | 0 | 29.9 |

## Diagnostics

### mj-data-inertia_phase__fill_and_mark_mass__adb_857

- `mj-data-inertia_phase.adb:864` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]

