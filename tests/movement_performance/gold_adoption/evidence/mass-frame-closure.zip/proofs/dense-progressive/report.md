# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-cv9slfya/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Fill_And_Mark_Mass` | `mj-data-inertia_phase.adb:782` | [unproved_checks](logs/mj-data-inertia_phase__fill_and_mark_mass__adb_782.log) | 37 | 1 | 0 | 123.5 |

## Diagnostics

### mj-data-inertia_phase__fill_and_mark_mass__adb_782

- `mj-data-inertia_phase.adb:789` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]

