# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-pvb95squ/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Fill_And_Mark_Mass` | `mj-data-inertia_phase.adb:817` | [unproved_checks](logs/mj-data-inertia_phase__fill_and_mark_mass__adb_817.log) | 47 | 2 | 0 | 151.1 |

## Diagnostics

### mj-data-inertia_phase__fill_and_mark_mass__adb_817

- `mj-data-inertia_phase.adb:824` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:874` (medium): assertion might fail [provers reached time and memory limit before completing the proof]

