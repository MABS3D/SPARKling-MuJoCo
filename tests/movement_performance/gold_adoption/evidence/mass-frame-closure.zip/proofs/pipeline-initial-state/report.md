# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-h6w2cs5k/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Evaluate_Ready` | `mj-data-pipeline.adb:713` | [analysis_error](logs/mj-data-pipeline__evaluate_ready__adb_713.log) | 0 | 0 | 1 | 4.1 |

## Diagnostics

### mj-data-pipeline__evaluate_ready__adb_713

- `mj-data-inertia_phase.adb:589` (error): prefix of dereference must be an access type

