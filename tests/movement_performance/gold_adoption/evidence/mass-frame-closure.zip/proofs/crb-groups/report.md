# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-g66vyy74/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Build_And_Publish_CRB` | `mj-data-inertia_phase.adb:719` | [unproved_checks](logs/mj-data-inertia_phase__build_and_publish_crb__adb_719.log) | 12 | 1 | 0 | 50.5 |
| `Assemble_CRB_Path` | `mj-data-inertia_phase.adb:775` | [unproved_checks](logs/mj-data-inertia_phase__assemble_crb_path__adb_775.log) | 14 | 1 | 0 | 37.1 |

## Diagnostics

### mj-data-inertia_phase__build_and_publish_crb__adb_719

- `mj-data-inertia_phase.adb:726` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached time limit before completing the proof]

### mj-data-inertia_phase__assemble_crb_path__adb_775

- `mj-data-inertia_phase.adb:782` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached time limit before completing the proof]

