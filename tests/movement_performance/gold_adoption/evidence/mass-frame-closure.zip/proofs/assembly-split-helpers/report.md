# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-0u8f4330/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Reset_Mass` | `mj-data-inertia_phase.adb:669` | [completed_no_unproved](logs/mj-data-inertia_phase__reset_mass__adb_669.log) | 8 | 0 | 0 | 53.8 |
| `Assemble_CRB_Path` | `mj-data-inertia_phase.adb:700` | [unproved_checks](logs/mj-data-inertia_phase__assemble_crb_path__adb_700.log) | 9 | 3 | 0 | 32.8 |
| `Assemble_Dense_Path` | `mj-data-inertia_phase.adb:735` | [unproved_checks](logs/mj-data-inertia_phase__assemble_dense_path__adb_735.log) | 18 | 3 | 0 | 54.0 |
| `Mark_Ready` | `mj-data-mass_publication.adb:85` | [completed_no_unproved](logs/mj-data-mass_publication__mark_ready__adb_85.log) | 10 | 0 | 0 | 25.9 |

## Diagnostics

### mj-data-inertia_phase__assemble_crb_path__adb_700

- `mj-data-inertia_phase.adb:704` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:729` (medium): precondition might fail, cannot prove A'Last = N * N - 1 [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:729` (medium): in inlined expression function body at mj-smooth_dynamics.ads:99

### mj-data-inertia_phase__assemble_dense_path__adb_735

- `mj-data-inertia_phase.adb:737` (medium): postcondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:770` (medium): precondition might fail, cannot prove Stable_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:770` (medium): in inlined expression function body at mj-data.ads:637

