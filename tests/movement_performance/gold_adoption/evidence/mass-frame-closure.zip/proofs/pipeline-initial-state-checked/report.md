# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-arhrt9i9/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Evaluate_Ready` | `mj-data-pipeline.adb:713` | [unproved_checks](logs/mj-data-pipeline__evaluate_ready__adb_713.log) | 42 | 1 | 0 | 63.7 |

## Diagnostics

### mj-data-pipeline__evaluate_ready__adb_713

- `mj-data-pipeline.ads:57` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time and memory limit before completing the proof]

