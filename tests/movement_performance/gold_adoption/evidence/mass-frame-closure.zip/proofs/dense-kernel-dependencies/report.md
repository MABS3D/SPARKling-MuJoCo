# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-giu4scp8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prepared_Mass_Contribution` | `mj-smooth_dynamics.adb:118` | [completed_no_unproved](logs/mj-smooth_dynamics__prepared_mass_contribution__adb_118.log) | 18 | 0 | 0 | 6.6 |
| `Prepare_Mass_Columns` | `mj-smooth_dynamics.adb:224` | [completed_no_unproved](logs/mj-smooth_dynamics__prepare_mass_columns__adb_224.log) | 28 | 0 | 0 | 23.1 |
| `Store_Symmetric` | `mj-smooth_dynamics.adb:208` | [completed_no_unproved](logs/mj-smooth_dynamics__store_symmetric__adb_208.log) | 16 | 0 | 0 | 4.4 |

## Diagnostics

