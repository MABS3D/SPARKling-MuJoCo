from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text();a=s.index('   procedure Fill_And_Mark_Mass');b=s.index('   end Fill_And_Mark_Mass;',a)+len('   end Fill_And_Mark_Mass;\n   pragma Inline_Always (Fill_And_Mark_Mass);');t=s[a:b]
head=t[:t.index('   is\n')]
fill=t[:t.index('      if Result /= Success then return; end if;')]
fill=fill.replace('Fill_And_Mark_Mass','Fill_Dense_Ready').replace('(if Result = Success then Mass_Current (D) and then Symmetric_Mass (D)))', 'MJ.Smooth_Dynamics.Work_Array (D.Dynamics.Mass.all)\n         and then MJ.Smooth_Dynamics.Symmetric (D.Dynamics.Mass.all, D.Nv))')
fill+='   end Fill_Dense_Ready;\n   pragma Inline_Always (Fill_Dense_Ready);\n\n'
hides=''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['Ancestor_Pattern_Ready','Topology_Layout_Ready','Unit_Quaternion','Unit_Vector','Body_Bounded','Joint_Bounded','State_Image','Input_Image','State_Values','Input_Values','Configuration','Position_Values','Velocity_Values','MJ.Smooth_Kernels.All_Tier0','MJ.Smooth_Dynamics.Symmetric'])
outer=head+'   is\n'+hides+'''   begin
      Fill_Dense_Ready (D, Result);
      if Result /= Success then return; end if;
      Mass_Publication.Mark_Ready (D);
   end Fill_And_Mark_Mass;
   pragma Inline_Always (Fill_And_Mark_Mass);'''
p.write_text(s[:a]+fill+outer+s[b:])
