from pathlib import Path
r=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src')
p=r/'mj-data-pipeline.ads';s=p.read_text();s='with MJ.Smooth_Dynamics;\n'+s
needle="   pragma Postcondition (Static => D.Dynamics.Mass.all = D.Dynamics.Mass.all'Old);"
assert s.count(needle)==1
s=s.replace(needle,needle+'''
   pragma Postcondition (Static =>
     (if MJ.Smooth_Dynamics.Work_Array (D.Dynamics.Mass.all)'Old
      then MJ.Smooth_Dynamics.Work_Array (D.Dynamics.Mass.all))
     and then (if MJ.Smooth_Dynamics.Symmetric (D.Dynamics.Mass.all, D.Nv)'Old
      then MJ.Smooth_Dynamics.Symmetric (D.Dynamics.Mass.all, D.Nv)));''')
p.write_text(s)
p=r/'mj-data-inertia_phase.adb';s=p.read_text();a=s.index('   procedure Assemble_Dense_Path');b=s.index('   end Assemble_Dense_Path;',a);t=s[a:b]
x=t.index('         Ready_Properties (D);');y=t.index('         end;',x)+len('         end;')
t=t[:x]+'         Pipeline.Ensure_Jacobians (D, Result);'+t[y:]
t=t.replace('         Equal_Configurations (Configuration (D), Before_Config, Initial_Config);','         Equal_Configurations (Configuration (D), Before_Config, Initial_Config);\n         pragma Assert (Static => State_Values (D) = Initial_State);\n         pragma Assert (Static => Input_Values (D) = Initial_Inputs);')
s=s[:a]+t+s[b:]
p.write_text(s)
