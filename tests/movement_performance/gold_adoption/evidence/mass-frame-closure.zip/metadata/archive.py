from pathlib import Path
import hashlib,io,json,re,runpy,zipfile
R=Path(__file__).parent
REPO=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
E=REPO/'tests/movement_performance/gold_adoption/evidence'
ns=runpy.run_path(str(R/'review_source.py'));sha=ns['sha'];norm=ns['norm'];sub=ns['sub']
review=json.loads((R/'source-review.json').read_text())
final=json.loads((R/'final-callers/results.json').read_text())
assert all(x['status']=='completed_no_unproved' for x in final['results'])
assert all(sha(R/'source'/n)==h for n,h in final['source_sha256'].items())
nums=[]
m=json.loads((R/'numerics-compatible/manifest.json').read_text())
assert all(sha(R/'source'/n)==h for n,h in m['hashes'].items())
assert all(m['hashes'][n]==h for n,h in final['source_sha256'].items())
for policy in ['compatible','strict']:
 j=json.loads((R/f'numerics-{policy}/results.json').read_text())
 assert j['status']=='passed' and j['scenarios']==624 and j['comparisons']==168192
 assert sha(Path(j['probe']))==j['probe_sha256']
 nums.append({k:j[k] for k in ['policy','status','scenarios','comparisons','probe_sha256','atol','rtol']})
# Independently preserve the prior matrix-index/configuration lemmas and their exact inputs.
old=E/'mass-publication-closed.zip'
with zipfile.ZipFile(old) as z:
 with zipfile.ZipFile(io.BytesIO(z.read('proof-source-objects.zip'))) as q:
  runs=json.loads(q.read('runs.json'));leaf=runs['proof-publication-leaf-closure']
  for n in ['experimental/smooth/src/mj-data.ads','experimental/smooth/src/mj-data.adb','experimental/smooth/src/mj-smooth_kernels.ads','experimental/smooth/src/mj-smooth_kernels.adb','experimental/smooth/src/mj-smooth_dynamics.ads']:
   assert sha(R/'source'/n)==leaf[n]
  inherited={'archive':old.name,'archive_sha256':sha(old),'proof_index':json.loads(z.read('proof-index.json')),'matching_leaf_inputs':leaf}
(R/'inherited-leaf-receipts.json').write_text(json.dumps(inherited,indent=2)+'\n')
summary={'date':'2026-09-27','status':'assembly_and_pipeline_frame_contracts_closed_isolated',
 'scope':'All current Assemble contracts and the composition of Evaluate_Ready, with separately proved mass/CRB/dense/Jacobian frame helpers. These are modular proofs under the called contracts, not the full ordered mass model, physical accuracy, or complete dynamics.',
 'complete_scopes':review['complete_scopes'],
 'integration':{'report':'final-callers','all_four_targets_closed':True,'source_identical_to_numerical_build':True},
 'totals_excluding_repeated_integration_and_prior_crb_spatial':{'proof':sum(x['proof'] for x in review['complete_scopes']),'flow':sum(x['flow'] for x in review['complete_scopes']),'open':0},
 'inherited':[
  {'scope':'Accumulate_Composite','proof':99,'flow':3,'receipt':'crb-accumulation-closure.zip/json','unchanged':True},
  {'scope':'CRB producer/load/fill/zero','proof':78,'flow':8,'receipt':'crb-callers-closure.zip/json','unchanged':True},
  {'scope':'MJ.Data.Spatial whole unit','proof':391,'flow':55,'receipt':'spatial-prepare-closure.zip/json','unchanged':True},
  {'scope':'Matrix_Offset and Prove_Configuration_Equality','proof':34,'receipt':'mass-publication-closed.zip','inputs_verified':True}],
 'no_new_assume_suppression_or_trusted_body':True,'public_preconditions_unchanged':True,
 'source_review':review,'numerics':nums,'runtime_adopted':False,'active_source_files_unchanged':100,'new_scans_removed':0,
 'integrated_timings':'Not run; two quiet integrated sessions remain required before runtime adoption. No speedup is claimed.',
 'remaining':'Full ordered mass construction model and proofs of the force, actuation, solve and integration bodies as needed for the complete dynamics chain. Active CRB guard and three internal Phase_Ready scans remain.',
 'upstream':{'version':'3.14.0','commit':'9ecbb9d7b5ee623f54745638d36799ff90e6f7cd','reviewed':'mj_crb reverse composite accumulation and forward DOF/ancestor traversal','source_sha256':sha(Path('/var/tmp/sparkling-movement-c/source/src/engine/engine_core_smooth.c'))}}
(R/'closure.json').write_text(json.dumps(summary,indent=2)+'\n')
# Deduplicate immutable source snapshots by content: do not multiply sixty copies of the library.
objects={};index=[];reports=[]
for d in sorted(R.iterdir()):
 if not d.is_dir() or not (d/'results.json').exists():continue
 j=json.loads((d/'results.json').read_text())
 if 'snapshot' not in j:continue
 snap=Path(j['snapshot']);manifest={}
 for p in sorted(snap.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
   h=sha(p);objects.setdefault(h,p);manifest[str(p.relative_to(snap))]=h
 assert all(manifest[n]==h for n,h in j['source_sha256'].items())
 reports.append(d)
 index.append({'report':d.name,'original_snapshot':str(snap),'source_files':manifest,'status':[{'name':x['target']['name'],'status':x['status']} for x in j['results']]})
(R/'snapshot-index.json').write_text(json.dumps(index,indent=2)+'\n')
(R/'REPRODUCE.md').write_text('''# Assembly/state frame closure — 2026-09-27

`candidate-source/` is the complete isolated candidate. It is not the active runtime.
`metadata/closure.json` records the accepted scopes and open work. Raw failed,
timed-out, analysis-error and superseded trials remain separate in `proofs/`.
No failed row is counted as a passed proof.

Every frozen proof input is reconstructible from `metadata/snapshot-index.json`:
for the selected report, write each `source_files` entry using the bytes of
`source-objects/sha256/<hash>`. Verify its hash before writing. All source objects,
reports, final numerical inputs/outputs and the checked probe are archived.
`tools/prove_fragments.py` and each report's arguments reproduce the target scopes
with the recorded GNAT toolchain. `tools/compare_numerics.py` uses MuJoCo 3.14.0.
The prior Matrix_Offset/configuration lemma evidence is indexed separately.

The source review checks unchanged CRB accumulation/producer bodies, unchanged
spatial preparation, all existing public preconditions, phase call order and
ordered fallback arithmetic after parameter substitution and the proved storage
and index helper contracts. This is not a binary equivalence or timing proof.
Helper boundaries, cache flag rewrites and candidate lifetime changed.

The proof scope is memory safety, bounds, symmetry, publication flags and state/
configuration/input preservation under called contracts. The complete ordered
mass model and the other dynamics bodies remain separate work. No runtime scan
was removed from the active checkout. Performance adoption requires two quiet
integrated measurements; numerical tests do not establish performance parity.

Expression-body context annotations follow the AdaCore documentation:
https://docs.adacore.com/spark2014-docs/html/ug/en/appendix/additional_annotate_pragmas.html
They limit definitions exposed to a caller; they do not replace a body proof.
''')
archive=E/'mass-frame-closure.zip';entries={}
def add(z,p,name):
 assert name not in entries;entries[name]=sha(p);z.write(p,name)
def tree(z,path,prefix):
 for p in sorted(path.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':add(z,p,prefix+'/'+str(p.relative_to(path)))
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 tree(z,R/'source','candidate-source')
 for d in reports:tree(z,d,'proofs/'+d.name)
 for h,p in sorted(objects.items()):add(z,p,'source-objects/sha256/'+h)
 for policy in ['compatible','strict']:tree(z,R/f'numerics-{policy}','validation/'+policy)
 probe=Path(json.loads((R/'numerics-compatible/results.json').read_text())['probe']);add(z,probe,'validation/bin/smooth_probe')
 build=Path(m['snapshot']).parent;add(z,build/'smooth_probe.gpr','validation/smooth_probe.gpr')
 for p in sorted(R.iterdir()):
  if p.is_file() and not p.name.startswith('archive-output'):add(z,p,'metadata/'+p.name)
 for name in ['crb-accumulation-closure.json','crb-callers-closure.json','spatial-prepare-closure.json']:add(z,E/name,'prior-receipts/'+name)
 for name in ['prove_fragments.py','compare_numerics.py']:add(z,REPO/'experimental/smooth/tools'/name,'tools/'+name)
 add(z,REPO/'tools/guarded.py','tools/guarded.py')
 z.writestr('SHA256SUMS',''.join(h+'  '+n+'\n' for n,h in sorted(entries.items())))
with zipfile.ZipFile(archive) as z:
 for n,h in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 assert z.testzip() is None
summary['archive']=archive.name;summary['archive_sha256']=sha(archive);summary['archive_bytes']=archive.stat().st_size
(E/'mass-frame-closure.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(entries),'reports':len(reports),'unique_source_objects':len(objects),'totals':summary['totals_excluding_repeated_integration_and_prior_crb_spatial']},indent=2))
