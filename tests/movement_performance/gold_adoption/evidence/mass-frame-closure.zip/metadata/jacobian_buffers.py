from pathlib import Path
r=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src')
p=r/'mj-data-pipeline.adb';s=p.read_text();a=s.index('   procedure Refresh_Jacobian_Cache');b=s.index('   procedure Evaluate_Inertia_Forces',a)
build=(r/'mj-data-jacobians.ads').read_text().split('   procedure Build\n',1)[1].split('end MJ.Data.Jacobians;',1)[0]
build=build.replace('Linear, Angular : out Real_Array; Ok : out Boolean)', 'Linear, Angular : in out Real_Array; Valid : in out Boolean; Result : out Status)')
build=build.split('     Post =>',1)[0].replace("       and then Angular'Last = Linear'Last,", "       and then Angular'Last = Linear'Last\n       and then (if Valid then (for all X of Linear => Within_Work (X))\n         and then (for all X of Angular => Within_Work (X))),")
helper='   procedure Refresh_Jacobian_Buffers\n'+build+'''     Post => (for all X of Linear => Within_Work (X))
       and then (for all X of Angular => Within_Work (X))
       and then Valid = (Result = Success)
   is
   begin
      if Valid then Result := Success; return; end if;
      Jacobians.Build (Bodies, Joints, Body_Poses, Joint_Poses, Linear, Angular, Valid);
      Result := (if Valid then Success else Numeric_Limit);
   end Refresh_Jacobian_Buffers;
   pragma Inline_Always (Refresh_Jacobian_Buffers);

'''
helper=helper.replace('and then Topology (Bodies, Joints)', 'and then Jacobians.Topology (Bodies, Joints)')
outer='''   procedure Ensure_Jacobians (D : in out Simulation; Result : out Status) is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Image);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Input_Image);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", MJ.Smooth_Kernels.All_Tier0);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Unit_Quaternion);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Unit_Vector);
      Initial_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;
      Initial_State : constant Real_Array := State_Values (D) with Ghost => Static;
   begin
      Refresh_Jacobian_Buffers
        (D.Body_Config.all, D.Joint_Config.all,
         D.Kinematic.Bodies.all, D.Kinematic.Joints.all,
         D.Kinematic.Linear_Jacobian.all, D.Kinematic.Angular_Jacobian.all,
         D.Cache.Jacobian_Valid, Result);
      Prove_Configuration_Equality (Configuration (D), Initial_Config);
      pragma Assert (Static => State_Values (D) = Initial_State);
   end Ensure_Jacobians;

'''
p.write_text(s[:a]+helper+outer+s[b:])
