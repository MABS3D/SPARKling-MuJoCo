from pathlib import Path
import hashlib,json,re,difflib
R=Path(__file__).parent
REPO=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
PREVIOUS=Path('/var/tmp/sparkling-crb-callers-20260927/source')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sub(s,n):
 a=re.search(r'^   (?:procedure|function) '+re.escape(n)+r'\b',s,re.M).start()
 b=re.search(r'^   end '+re.escape(n)+r';',s[a:],re.M)
 return s[a:a+b.end()]
def norm(s):return re.sub(r'\s+','',s)
def flow_summary(path):
 s=path.read_text();m=re.search(r'^Total\s+\d+\s+(\d+)\s*\(',s,re.M)
 return int(m.group(1)) if m else 0
SCOPES=[
 ('pipeline-first-pair-final','Evaluate_Inertia_Forces'),
 ('pipeline-two-phase-helpers','Evaluate_Actuation_Acceleration'),
 ('pipeline-composed','Evaluate_Ready'),
 ('jacobian-narrow-buffers','Refresh_Jacobian_Buffers'),
 ('jacobians-mass-properties','Ensure_Jacobians'),
 ('dense-final','Assemble_Dense_Mass'),
 ('mass-boundaries','Prove_Dense_Inputs'),
 ('layout-and-dense-frame','Expose_Assembly_Layout'),
 ('assembly-split-helpers','Reset_Mass'),
 ('crb-position-frame','Ready_Properties'),
 ('mass-frame-properties','Build_And_Publish_CRB'),
 ('crb-config-cuts','Assemble_CRB_Path'),
 ('dense-groups','Fill_Dense_Ready'),
 ('dense-groups','Fill_And_Mark_Mass'),
 ('dense-path-final','Assemble_Dense_Path'),
 ('assemble-ready-closed','Assemble_Ready'),
 ('assemble-boundary','Assemble'),
 ('dense-kernel-dependencies','Prepared_Mass_Contribution'),
 ('dense-kernel-dependencies','Prepare_Mass_Columns'),
 ('dense-kernel-dependencies','Store_Symmetric')]
scopes=[]
for label,name in SCOPES:
 j=json.loads((R/label/'results.json').read_text());row=next(x for x in j['results'] if x['target']['name']==name)
 assert row['status']=='completed_no_unproved',(label,name,row['status'])
 file='experimental/smooth/src/'+row['target']['file']
 assert norm(sub((R/'source'/file).read_text(),name))==norm(sub((Path(j['snapshot'])/file).read_text(),name)),(label,name,'source changed')
 raw=json.loads((R/label/row['log']).with_suffix('.spark.json').read_text())
 for unit in raw.values():
  assert not unit.get('pragma_assume')
  assert all(x.get('severity')=='info' for k in ['proof','flow'] for x in unit.get(k,[])),(label,name,'diagnostics')
 summary=(R/label/row['log']).with_suffix('.summary.txt')
 scopes.append(dict(name=name,unit=Path(file).stem,report=label,proof=row['proof_checks'],flow=flow_summary(summary),runner_flow=row['flow_checks'],open=0,source_body_and_contract_equal_ignoring_whitespace=True))
# The complete publication unit, not the sum of overlapping helper runs.
j=json.loads((R/'publication-whole-unit/results.json').read_text());row=j['results'][0]
assert row['status']=='completed_no_unproved'
for ext in ['ads','adb']:
 f='experimental/smooth/src/mj-data-mass_publication.'+ext
 assert sha(R/'source'/f)==sha(Path(j['snapshot'])/f)
scopes.append(dict(name='whole unit',unit='mj-data-mass_publication',report='publication-whole-unit',proof=row['proof_checks'],flow=flow_summary((R/'publication-whole-unit'/row['log']).with_suffix('.summary.txt')),open=0,whole_source_identical=True))
# The already proved CRB producer and accumulation are unchanged.
n='experimental/smooth/src/mj-data-inertia_phase.adb';old=(PREVIOUS/n).read_text();new=(R/'source'/n).read_text()
for name in ['Accumulate_Composite','Load_Composite','Zero_CRB_Mass','Fill_CRB_Mass','Try_Assemble_CRB']:
 assert sub(old,name)==sub(new,name),name
assert old[old.index('   --  A positive divisor'):]==new[new.index('   --  A positive divisor'):]
for n in ['experimental/smooth/src/mj-data-spatial.adb','experimental/smooth/src/mj-data-spatial.ads','experimental/smooth/src/mj-data-inertia_phase.ads']:
 assert sha(R/'source'/n)==sha(PREVIOUS/n)
# Only one existing private specification changed; all public preconditions stay intact.
changed_specs=[]
for p in (PREVIOUS/'experimental/smooth/src').glob('*.ads'):
 n=p.relative_to(PREVIOUS)
 if sha(p)!=sha(R/'source'/n):changed_specs.append(str(n))
assert changed_specs==['experimental/smooth/src/mj-data-pipeline.ads'],changed_specs
po=(PREVIOUS/'experimental/smooth/src/mj-data-pipeline.ads').read_text();pn=(R/'source/experimental/smooth/src/mj-data-pipeline.ads').read_text()
for name in ['Update_Poses','Ensure_Cartesian_Motion','Evaluate_Ready']:
 pattern=r'   procedure '+name+r'\b[\s\S]*?(?=\n   procedure |\nend MJ.Data.Pipeline;)'
 assert re.search(pattern,po)[0]==re.search(pattern,pn)[0],name
for text in [po,pn]:
 e=text.split('   procedure Ensure_Jacobians',1)[1].split('   procedure Evaluate_Ready',1)[0]
 assert 'Pre => Is_Ready (D) and then Positions_Current (D)' in e
 for clause in ["State_Values (D) = State_Values (D)'Old", "Input_Values (D) = Input_Values (D)'Old", "Mass_Current (D) = Mass_Current (D)'Old", "Configuration (D) = Configuration (D)'Old"]:assert clause in e
# Ordered fallback arithmetic after expanding only the proved storage/index helpers.
def executable(x):
 x=re.sub(r'--[^\n]*','',x)
 x=re.sub(r'pragma\s+[^;]*;','',x)
 return norm(x)
a=sub(old,'Assemble');a=a[a.index('      --  Kinetic energy:'):a.index('      D.Cache.Mass_Valid := True;',a.index('      --  Kinetic energy:'))]
b=sub(new,'Assemble_Dense_Mass');b=b[b.index('      --  Kinetic energy:'):b.rindex('      Result := Success;')]
for x,y in [('D.Kinematic.Angular_Jacobian.all','Angular'),('D.Kinematic.Angular_Jacobian','Angular'),('D.Kinematic.Linear_Jacobian.all','Linear'),('D.Kinematic.Bodies','Poses'),('D.Body_Config','Bodies'),('D.Joint_Config','Joints'),('D.Dynamics.Mass','Mass'),('D.Nb',"Bodies'Length"),('D.Nj',"Joints'Length"),('D.Nv','Nv')]:a=a.replace(x,y)
b=b.replace('MJ.Smooth_Kernels.Matrix_Offset (Nv, V, V)','V * Nv + V')
b=b.replace('MJ.Smooth_Dynamics.Store_Symmetric (Mass, Nv, I, J, Value);','Mass (I * Nv + J) := Value; Mass (J * Nv + I) := Value;')
b=b.replace('MJ.Smooth_Dynamics.Store_Symmetric (Mass, Nv, V, V, Value);','Mass (I) := Value;')
assert executable(a)==executable(b),'fallback ordered arithmetic changed'
# The public five-phase sequence is unchanged after flattening the two inline groups.
def phase_calls(x):
 return re.findall(r'(?:Update_Poses|Inertia_Phase\.Assemble|Forces_Phase\.Compute|Actuation_Phase\.Compute|Inertia_Phase\.Solve_Acceleration) \(D, Result\);',x)
po_body=(PREVIOUS/'experimental/smooth/src/mj-data-pipeline.adb').read_text();pn_body=(R/'source/experimental/smooth/src/mj-data-pipeline.adb').read_text()
pbody=sub(pn_body,'Evaluate_Ready')
for helper in ['Evaluate_Inertia_Forces','Evaluate_Actuation_Acceleration']:
 pbody=pbody.replace(helper+' (D, Result);',sub(pn_body,helper))
assert phase_calls(sub(po_body,'Evaluate_Ready'))==phase_calls(pbody)
active=json.loads((REPO/'tests/movement_performance/gold_adoption/evidence/active-source-match.json').read_text())['source_sha256']
assert all(sha(REPO/n)==h for n,h in active.items())
result={'complete_scopes':scopes,'producer_accumulation_unchanged':True,'spatial_whole_unit_source_unchanged':True,'solver_tail_unchanged':True,'active_sources_unchanged':len(active),'existing_changed_specs':changed_specs,'public_preconditions_unchanged':True,'jacobian_spec_change':'Equivalent split of previous conjunction, plus Static exact raw mass preservation and conditional preservation of mass bounds and symmetry. These added clauses are proved in jacobians-mass-properties.','flow_counts':'Confirmed against the saved GNATprove summary tables; raw runner counters are retained.','ordered_fallback_arithmetic_checked':True,'phase_sequence_checked':True,'runtime_review_limits':'Source ordering audit after argument substitution and the proved Matrix_Offset/Store_Symmetric contracts; the diagonal double store is normalized to the same final write. Helper boundaries, cache flag rewrites and candidate allocation lifetime changed. No binary or timing equivalence is claimed.','functional_scope':'Bounds, symmetry, status/cache publication and preservation of public state under the called contracts. The full ordered mass model and the complete dynamics proof are still separate open work.'}
(R/'source-review.json').write_text(json.dumps(result,indent=2)+'\n')
patch=''
for n in ['experimental/smooth/src/mj-data-inertia_phase.adb','experimental/smooth/src/mj-data-pipeline.adb','experimental/smooth/src/mj-data-pipeline.ads','experimental/smooth/src/mj-data-mass_publication.ads','experimental/smooth/src/mj-data-mass_publication.adb']:
 before=(PREVIOUS/n).read_text() if (PREVIOUS/n).exists() else ''
 patch+=''.join(difflib.unified_diff(before.splitlines(True),(R/'source'/n).read_text().splitlines(True),fromfile='a/'+n,tofile='b/'+n))
(R/'from-crb-callers.patch').write_text(patch)
print(json.dumps(result,indent=2))
