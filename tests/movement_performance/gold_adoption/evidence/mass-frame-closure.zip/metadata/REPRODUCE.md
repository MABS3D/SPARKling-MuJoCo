# Assembly/state frame closure — 2026-09-27

`candidate-source/` is the complete isolated candidate. It is not the active runtime.
`metadata/closure.json` records the accepted scopes and open work. Raw failed,
timed-out, analysis-error and superseded trials remain separate in `proofs/`.
No failed row is counted as a passed proof.

Every frozen proof input is reconstructible from `metadata/snapshot-index.json`:
for the selected report, write each `source_files` entry using the bytes of
`source-objects/sha256/<hash>`. Verify its hash before writing. All source objects,
reports, final numerical inputs/outputs and the checked probe are archived.
`tools/prove_fragments.py` and each report's arguments reproduce the target scopes
with the recorded GNAT toolchain. `tools/compare_numerics.py` uses MuJoCo 3.14.0.
The prior Matrix_Offset/configuration lemma evidence is indexed separately.

The source review checks unchanged CRB accumulation/producer bodies, unchanged
spatial preparation, all existing public preconditions, phase call order and
ordered fallback arithmetic after parameter substitution and the proved storage
and index helper contracts. This is not a binary equivalence or timing proof.
Helper boundaries, cache flag rewrites and candidate lifetime changed.

The proof scope is memory safety, bounds, symmetry, publication flags and state/
configuration/input preservation under called contracts. The complete ordered
mass model and the other dynamics bodies remain separate work. No runtime scan
was removed from the active checkout. Performance adoption requires two quiet
integrated measurements; numerical tests do not establish performance parity.

Expression-body context annotations follow the AdaCore documentation:
https://docs.adacore.com/spark2014-docs/html/ug/en/appendix/additional_annotate_pragmas.html
They limit definitions exposed to a caller; they do not replace a body proof.
