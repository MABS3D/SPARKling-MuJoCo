from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text();a=s.index('   procedure Fill_Dense_Ready');b=s.index('   end Fill_Dense_Ready;',a);t=s[a:b];head=t[:t.index('   is\n')]
hides=''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['Ancestor_Pattern_Ready','Topology_Layout_Ready','Unit_Quaternion','Unit_Vector','Body_Bounded','Joint_Bounded','State_Image','Input_Image','MJ.Smooth_Kernels.All_Tier0','MJ.Smooth_Dynamics.Symmetric'])
body=head+'   is\n'+hides+'''      Initial_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;
   begin
      Expose_Assembly_Layout (D);
      Prove_Jacobian_Readiness (D);
      Prove_Dense_Inputs (D);
      Assemble_Dense_Mass
        (D.Body_Config.all, D.Joint_Config.all, D.Kinematic.Bodies.all,
         D.Kinematic.Linear_Jacobian.all, D.Kinematic.Angular_Jacobian.all,
         D.Nv, D.Dynamics.Mass.all, Result);
      pragma Assert (Static => Has_Real_Layout (D.Dynamics.Mass, D.Nv * D.Nv));
      pragma Assert (Static => Ancestor_Storage_Ready (D));
      pragma Assert (Static => Topology_Storage_Ready (D));
      pragma Assert (Static => Storage_Ready (D));
      pragma Assert (Static => Configuration_Bounded (D));
      pragma Assert (Static => Stable_Ready (D));
      pragma Assert (Static => Inputs_Bounded (D));
      pragma Assert (Static => Caches_Bounded (D));
      pragma Assert (Static => Is_Ready (D));
      Prove_Configuration_Equality (Configuration (D), Initial_Config);
'''
p.write_text(s[:a]+body+s[b:])
