   procedure Assemble (D : in out Simulation; Result : out Status) is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Ancestor_Pattern_Ready);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Topology_Layout_Ready);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Unit_Quaternion);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Unit_Vector);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Body_Bounded);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Joint_Bounded);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Image);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Input_Image);
      Initial_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;
      Nv : constant Natural := D.Nv;
      Used_CRB, Spatial_Ok : Boolean;
   begin
      --  Both callers establish readiness: the public boundary checks it,
      --  and the pipeline's proved pose update preserves it.
      pragma Assert (Static => Phase_Ready (D));
      if not D.Cache.Pose_Valid then
         Result := Stale_Results;
         Prove_Configuration_Equality (Configuration (D), Initial_Config);
         pragma Assert (Stable_Ready (D)); return;
      end if;
      D.Cache.Mass_Valid := False;
      D.Cache.Force_Valid := False;
      Zero_CRB_Mass (D.Dynamics.Mass.all, D.Nv);
      Used_CRB := False;
      if D.Nv >= 3 then
         declare
            Candidate : Real_Array (0 .. Nv * Nv - 1) with Relaxed_Initialization;
         begin
            Spatial.Prepare (D, Spatial_Ok);
            pragma Assert (Static => D.Nv = Nv);
            Expose_Assembly_Layout (D);
            if Spatial_Ok then Try_Assemble_CRB (D, Candidate, Used_CRB); end if;
            if Used_CRB then
               Copy_Bounded_Mass (Candidate, Nv, D.Dynamics.Mass.all);
            end if;
            pragma Assert (Static => D.Dynamics.Mass'First = 0
              and then D.Dynamics.Mass'Last = D.Nv * D.Nv - 1);
         end;
      end if;
      if Used_CRB then
         D.Cache.Mass_Valid := True;
         Result := Success;
         Prove_Configuration_Equality (Configuration (D), Initial_Config);
         pragma Assert (Stable_Ready (D)); return;
      end if;
      Zero_CRB_Mass (D.Dynamics.Mass.all, D.Nv);
      Pipeline.Ensure_Jacobians (D, Result);
      pragma Assert (Static => D.Nv = Nv);
      if Result /= Success then
         Prove_Configuration_Equality (Configuration (D), Initial_Config);
         pragma Assert (Stable_Ready (D)); return;
      end if;
      Expose_Assembly_Layout (D);
      Prove_Jacobian_Readiness (D);
      Prove_Dense_Inputs (D);
      Assemble_Dense_Mass
        (D.Body_Config.all, D.Joint_Config.all, D.Kinematic.Bodies.all,
         D.Kinematic.Linear_Jacobian.all, D.Kinematic.Angular_Jacobian.all,
         D.Nv, D.Dynamics.Mass.all, Result);
      if Result /= Success then
         Prove_Configuration_Equality (Configuration (D), Initial_Config);
         pragma Assert (Stable_Ready (D)); return;
      end if;
      D.Cache.Mass_Valid := True;
      Result := Success;
      Prove_Configuration_Equality (Configuration (D), Initial_Config);
      pragma Assert (Stable_Ready (D));
   end Assemble;