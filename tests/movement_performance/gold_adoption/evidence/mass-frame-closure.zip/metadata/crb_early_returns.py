from pathlib import Path
import textwrap
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text();a=s.index('   procedure Assemble_CRB_Path');b=s.index('   end Assemble_CRB_Path;',a);t=s[a:b];t=t[:t.index('   begin\n')]
def framed(call):
 return '''declare
   Before_State : constant Real_Array := State_Values (D) with Ghost => Static;
   Before_Inputs : constant Real_Array := Input_Values (D) with Ghost => Static;
   Before_Pos : constant Real_Array := Position_Values (D) with Ghost => Static;
   Before_Vel : constant Real_Array := Velocity_Values (D) with Ghost => Static;
   Before_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;
begin
   '''+call+'''
   Ready_Properties (D);
   MJ.Smooth_Kernels.Equal_Transitive (State_Values (D), Before_State, Initial_State);
   MJ.Smooth_Kernels.Equal_Transitive (Input_Values (D), Before_Inputs, Initial_Inputs);
   MJ.Smooth_Kernels.Equal_Transitive (Position_Values (D), Before_Pos, Initial_Pos);
   MJ.Smooth_Kernels.Equal_Transitive (Velocity_Values (D), Before_Vel, Initial_Vel);
   Equal_Configurations (Configuration (D), Before_Config, Initial_Config);
end;
'''
t+='''   begin
      Ready_Properties (D);
      Used_CRB := False;
      if D.Nv < 3 then return; end if;
      declare
         Candidate : Real_Array (0 .. Nv * Nv - 1);
      begin
'''+textwrap.indent(framed('Spatial.Prepare (D, Spatial_Ok);'),'         ')+'''         pragma Assert (Static => D.Nv = Nv);
         if not Spatial_Ok then return; end if;
         Try_Assemble_CRB (D, Candidate, Used_CRB);
         if not Used_CRB then return; end if;
'''+textwrap.indent(framed('Mass_Publication.Publish (D, Candidate);'),'         ')+'''      end;
'''
p.write_text(s[:a]+t+s[b:])
