from pathlib import Path
r=Path(__file__).parent;p=r/'source/experimental/smooth/src/mj-data-pipeline.adb';s=(r/'pipeline-before-phase-split.adb').read_text()
a=s.index('   procedure Evaluate_Ready');end=s.index('   end Evaluate_Ready;',a)+len('   end Evaluate_Ready;');part=s[a:end]
head,code=part.split('   begin\n',1);code=code.rsplit('   end Evaluate_Ready;',1)[0];blocks=code.split('      declare\n         Before_Pos')[1:];assert len(blocks)==5
blocks=['      declare\n         Before_Pos'+x for x in blocks]
locals=head.split(' is\n',1)[1]
frame="""Is_Ready (D) and then Stable_Ready (D)
         and then Is_Empty (D) = Is_Empty (D)'Old and then Shape (D) = Shape (D)'Old
         and then State_Values (D) = State_Values (D)'Old
         and then Input_Values (D) = Input_Values (D)'Old
         and then Positions_Current (D) = Positions_Current (D)'Old
         and then Configuration (D) = Configuration (D)'Old
         and then Position_Values (D) = Position_Values (D)'Old
         and then Velocity_Values (D) = Velocity_Values (D)'Old
         and then Time (D) = Time (D)'Old and then Step_Size (D) = Step_Size (D)'Old"""
def helper(name,body,last):
 return '   procedure '+name+''' (D : in out Simulation; Result : out Status)
     with Global => null, Pre => Is_Ready (D) and then Stable_Ready (D),
       Post => (Static => '''+frame+('''
         and then (if Result = Success then Forces_Current (D))''' if last else '')+''')
   is
'''+locals+'''   begin
      pragma Assert (Static => State_Values (D) = Initial_State);
'''+body+'   end '+name+';\n   pragma Inline_Always ('+name+');\n\n'
helpers=helper('Evaluate_Inertia_Forces',blocks[1]+blocks[2],False)+helper('Evaluate_Actuation_Acceleration',blocks[3]+blocks[4],True)
b1=blocks[1].replace('Inertia_Phase.Assemble (D, Result);','Evaluate_Inertia_Forces (D, Result);')
b2=blocks[4].replace('Inertia_Phase.Solve_Acceleration (D, Result);','Evaluate_Actuation_Acceleration (D, Result);')
new=head+'   begin\n      pragma Assert (Static => State_Values (D) = Initial_State);\n'+blocks[0]+b1+b2+'   end Evaluate_Ready;'
s=s[:a]+helpers+new+s[end:]
a=s.index('   procedure Ensure_Jacobians');end=s.index('   end Ensure_Jacobians;',a);t=s[a:end]
t=t.replace('      Accepted : Boolean;','      Initial_State : constant Real_Array := State_Values (D) with Ghost => Static;\n      Accepted : Boolean;')
t=t.replace('         return;','         pragma Assert (Static => State_Values (D) = Initial_State);\n         return;',1)
t=t.replace('      Result := (if Accepted then Success else Numeric_Limit);','      Result := (if Accepted then Success else Numeric_Limit);\n      pragma Assert (Static => State_Values (D) = Initial_State);')
p.write_text(s[:a]+t+s[end:])
print('Two bounded two-phase helpers and explicit Jacobian state frame added.')
