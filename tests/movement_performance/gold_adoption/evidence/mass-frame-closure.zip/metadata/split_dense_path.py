from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb')
s=p.read_text();a=s.index('   procedure Assemble_Dense_Path');b=s.index('   end Assemble_Dense_Path;',a)+len('   end Assemble_Dense_Path;\n   pragma Inline_Always (Assemble_Dense_Path);')
t=s[a:b]
fill=t.replace('Assemble_Dense_Path','Fill_And_Mark_Mass').replace('Pre => Is_Ready (D) and then Positions_Current (D),','''Pre => Is_Ready (D) and then Positions_Current (D)
         and then D.Cache.Jacobian_Valid
         and then MJ.Smooth_Dynamics.Work_Array (D.Dynamics.Mass.all)
         and then MJ.Smooth_Dynamics.Symmetric (D.Dynamics.Mass.all, D.Nv),''')
fill=fill.replace('      Reset_Mass (D);\n      Pipeline.Ensure_Jacobians (D, Result);\n      if Result /= Success then return; end if;\n','')
start=t.index('   begin\n');end=t.index('   end Assemble_Dense_Path;')
outer=t[:start]+'''   begin
      Reset_Mass (D);
      Pipeline.Ensure_Jacobians (D, Result);
      if Result /= Success then return; end if;
      Fill_And_Mark_Mass (D, Result);
'''+t[end:]
outer=outer.replace('      Initial_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;', ''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['State_Values','Input_Values','Configuration','Position_Values','Velocity_Values','MJ.Smooth_Dynamics.Symmetric','MJ.Smooth_Dynamics.Work_Array']))
p.write_text(s[:a]+fill+'\n\n'+outer+s[b:])
