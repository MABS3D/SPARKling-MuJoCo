from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text();a=s.index('   procedure Assemble (D :');b=s.index('   end Assemble;',a)+len('   end Assemble;');t=s[a:b]
head='''   procedure Assemble_Ready (D : in out Simulation; Result : out Status)
     with Global => null, Pre => Is_Ready (D),
       Post => (Static => Is_Ready (D) and then Stable_Ready (D)
         and then Is_Empty (D) = Is_Empty (D)'Old and then Shape (D) = Shape (D)'Old
         and then State_Values (D) = State_Values (D)'Old
         and then Input_Values (D) = Input_Values (D)'Old
         and then Positions_Current (D) = Positions_Current (D)'Old
         and then Configuration (D) = Configuration (D)'Old
         and then Position_Values (D) = Position_Values (D)'Old
         and then Velocity_Values (D) = Velocity_Values (D)'Old
         and then Time (D) = Time (D)'Old and then Step_Size (D) = Step_Size (D)'Old
         and then (if Result = Success then Mass_Current (D) and then Symmetric_Mass (D)))
   is'''
t=t.replace('   procedure Assemble (D : in out Simulation; Result : out Status) is',head).replace('   end Assemble;', '   end Assemble_Ready;\n   pragma Inline_Always (Assemble_Ready);')
hides=''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['Is_Ready','Stable_Ready','Is_Empty','Shape','State_Values','Input_Values','Configuration','Position_Values','Velocity_Values','Positions_Current','Mass_Current','Symmetric_Mass','Time','Step_Size'])
wrapper='\n\n   procedure Assemble (D : in out Simulation; Result : out Status) is\n'+hides+'''   begin
      Assemble_Ready (D, Result);
   end Assemble;'''
p.write_text(s[:a]+t+wrapper+s[b:])
