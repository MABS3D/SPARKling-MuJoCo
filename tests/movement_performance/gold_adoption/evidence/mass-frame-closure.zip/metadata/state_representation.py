from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text();a=s.index('   procedure Ready_Properties')
helper='''   --  Link the public concatenated state query to the separately framed parts.
   procedure State_Representation (D : Simulation)
     with Ghost => Static, Global => null, Pre => Is_Ready (D),
       Post => Position_Values (D)'First = 0 and then Velocity_Values (D)'First = 0
         and then Int64 (Position_Values (D)'Length) <= Max_Dofs
         and then Int64 (Velocity_Values (D)'Length) <= Max_Dofs
         and then State_Values (D) = State_Image
           (Position_Values (D), Velocity_Values (D), Time (D))
   is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Image);
   begin
      null;
   end State_Representation;

   procedure Equal_State_Images (P1, P2, V1, V2 : Real_Array; T1, T2 : Nonneg_Tier0)
     with Ghost => Static, Global => null,
       Pre => P1'First = 0 and then P2'First = 0 and then V1'First = 0 and then V2'First = 0
         and then Int64 (P1'Length) <= Max_Dofs and then Int64 (P2'Length) <= Max_Dofs
         and then Int64 (V1'Length) <= Max_Dofs and then Int64 (V2'Length) <= Max_Dofs
         and then P1 = P2 and then V1 = V2 and then T1 = T2,
       Post => State_Image (P1, V1, T1) = State_Image (P2, V2, T2)
   is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Image);
   begin
      null;
   end Equal_State_Images;

'''
s=s[:a]+helper+s[a:]
for n in ['Assemble_CRB_Path','Fill_And_Mark_Mass']:
 a=s.index('   procedure '+n);b=s.index('   end '+n+';',a);t=s[a:b]
 t=t.replace('      Initial_State : constant','      Initial_Time : constant Nonneg_Tier0 := Time (D) with Ghost => Static;\n      Initial_State : constant')
 t=t.replace('   begin\n','''   begin
      State_Representation (D);
      pragma Assert (Static => Initial_State = State_Image (Initial_Pos, Initial_Vel, Initial_Time));
''',1)
 call='''State_Representation (D);
            Equal_State_Images (Position_Values (D), Initial_Pos,
              Velocity_Values (D), Initial_Vel, Time (D), Initial_Time);
'''
 if n=='Assemble_CRB_Path':
  t=t.replace('            pragma Assert (Static => State_Values (D) = Initial_State);','            '+call+'            pragma Assert (Static => State_Values (D) = Initial_State);')
 else:
  t=t.replace('      pragma Assert (Static => State_Values (D) = Initial_State);','      '+call+'      pragma Assert (Static => State_Values (D) = Initial_State);')
  t=t.replace('         Equal_Configurations (Configuration (D), Before_Config, Initial_Config);','         Equal_Configurations (Configuration (D), Before_Config, Initial_Config);\n         '+call)
 s=s[:a]+t+s[b:]
p.write_text(s)
