from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text();a=s.index('   procedure Assemble_CRB_Path');b=s.index('   end Assemble_CRB_Path;',a)+len('   end Assemble_CRB_Path;\n   pragma Inline_Always (Assemble_CRB_Path);');t=s[a:b]
head=t[:t.index('   is\n')]
hides=''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['Ancestor_Pattern_Ready','Topology_Layout_Ready','Unit_Quaternion','Unit_Vector','Body_Bounded','Joint_Bounded','State_Image','Input_Image','State_Values','Input_Values','Configuration','Position_Values','Velocity_Values','MJ.Smooth_Kernels.All_Tier0','MJ.Smooth_Dynamics.Symmetric'])
helper=head.replace('Assemble_CRB_Path','Build_And_Publish_CRB').replace('Pre => Is_Ready (D) and then Positions_Current (D),','Pre => Is_Ready (D) and then Positions_Current (D) and then D.Cache.Spatial_Valid,')+'   is\n'+hides+'''      Candidate : Real_Array (0 .. D.Nv * D.Nv - 1);
   begin
      Try_Assemble_CRB (D, Candidate, Used_CRB);
      if not Used_CRB then return; end if;
      Mass_Publication.Publish (D, Candidate);
   end Build_And_Publish_CRB;
   pragma Inline_Always (Build_And_Publish_CRB);

'''
outer=head+'   is\n'+hides+'''      Spatial_Ok : Boolean;
   begin
      Used_CRB := False;
      if D.Nv < 3 then return; end if;
      Spatial.Prepare (D, Spatial_Ok);
      if not Spatial_Ok then return; end if;
      Build_And_Publish_CRB (D, Used_CRB);
   end Assemble_CRB_Path;
   pragma Inline_Always (Assemble_CRB_Path);'''
p.write_text(s[:a]+helper+outer+s[b:])
