from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb')
s=p.read_text();a=s.index('   procedure Assemble_CRB_Path')
h='''   procedure Ready_Properties (D : Simulation)
     with Ghost => Static, Global => null, Pre => Is_Ready (D),
       Post => Stable_Ready (D) and then not Is_Empty (D) and then D.Nv <= Max_Dofs
   is
   begin
      null;
   end Ready_Properties;

'''
s=s[:a]+h+s[a:]
a=s.index('   procedure Assemble_CRB_Path');b=s.index('   end Assemble_CRB_Path;',a);t=s[a:b]
t=t.replace('      Nv : constant Natural := D.Nv;', ''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['Is_Ready','Stable_Ready','Is_Empty'])+'      Nv : constant Natural := D.Nv;')
t=t.replace('      pragma Assert (Static => not Is_Empty (D));','      Ready_Properties (D);')
t=t.replace('Spatial.Prepare (D, Spatial_Ok);','Spatial.Prepare (D, Spatial_Ok);\n      Ready_Properties (D);')
t=t.replace('Mass_Publication.Publish (D, Candidate);','Mass_Publication.Publish (D, Candidate);\n      Ready_Properties (D);')
s=s[:a]+t+s[b:]
a=s.index('   procedure Fill_And_Mark_Mass');b=s.index('   end Fill_And_Mark_Mass;',a);t=s[a:b]
t=t.replace('      Initial_Config : constant', '      Initial_State : constant Real_Array := State_Values (D) with Ghost => Static;\n      Initial_Config : constant')
t=t.replace('      if Result /= Success then return; end if;', '      pragma Assert (Static => State_Values (D) = Initial_State);\n      if Result /= Success then return; end if;')
t=t.replace('      Mass_Publication.Mark_Ready (D);','''      declare
         Before_State : constant Real_Array := State_Values (D) with Ghost => Static;
      begin
         Mass_Publication.Mark_Ready (D);
         MJ.Smooth_Kernels.Equal_Transitive (State_Values (D), Before_State, Initial_State);
      end;''')
s=s[:a]+t+s[b:]
p.write_text(s)
