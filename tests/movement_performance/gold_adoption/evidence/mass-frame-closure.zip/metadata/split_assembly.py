from pathlib import Path
import shutil
r=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src')
prev=Path('/var/tmp/sparkling-mass-publication-integration/handoff-split-publication/source/experimental/smooth/src')
for ext in ['ads','adb']:shutil.copyfile(prev/f'mj-data-mass_publication.{ext}',r/f'mj-data-mass_publication.{ext}')
# Publish can also mark an already-filled buffer without copying it.
p=r/'mj-data-mass_publication.ads';s=p.read_text();a=s.index('   procedure Publish (');b=s.index('end MJ.Data.Mass_Publication;')
t=s[a:b].replace('procedure Publish (D : in out Simulation; Mass : Real_Array)', 'procedure Mark_Ready (D : in out Simulation)').replace('Square_Layout (Mass, D.Nv)', 'Square_Layout (D.Dynamics.Mass.all, D.Nv)').replace('Work_Array (Mass)', 'Work_Array (D.Dynamics.Mass.all)').replace('Symmetric (Mass, D.Nv)', 'Symmetric (D.Dynamics.Mass.all, D.Nv)').replace('D.Dynamics.Mass.all = Mass', "D.Dynamics.Mass.all = D.Dynamics.Mass.all'Old")
p.write_text(s[:b]+t+s[b:])
p=r/'mj-data-mass_publication.adb';s=p.read_text();a=s.index('   procedure Publish (');b=s.index('\nend MJ.Data.Mass_Publication;')
t=s[a:b].replace('procedure Publish (D : in out Simulation; Mass : Real_Array)', 'procedure Mark_Ready (D : in out Simulation)').replace('Prove_Dense_Symmetry (Mass, D.Nv)', 'Prove_Dense_Symmetry (D.Dynamics.Mass.all, D.Nv)').replace('      D.Dynamics.Mass.all := Mass;\n','').replace('end Publish;', 'end Mark_Ready;')
p.write_text(s[:b]+t+s[b:])
p=r/'mj-data-inertia_phase.adb';s=p.read_text();s='with MJ.Data.Mass_Publication;\n'+s
a=s.index('   procedure Assemble (D :');b=s.index('   end Assemble;',a)+len('   end Assemble;')
Path('/var/tmp/sparkling-mass-frame-20260927/assemble-before-split.adb').write_text(s[a:b])
frame='''Is_Ready (D) and then Stable_Ready (D)
         and then Is_Empty (D) = Is_Empty (D)'Old and then Shape (D) = Shape (D)'Old
         and then State_Values (D) = State_Values (D)'Old
         and then Input_Values (D) = Input_Values (D)'Old
         and then Positions_Current (D) = Positions_Current (D)'Old
         and then Configuration (D) = Configuration (D)'Old
         and then Position_Values (D) = Position_Values (D)'Old
         and then Velocity_Values (D) = Velocity_Values (D)'Old
         and then Time (D) = Time (D)'Old and then Step_Size (D) = Step_Size (D)'Old'''
hides=''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['Ancestor_Pattern_Ready','Topology_Layout_Ready','Unit_Quaternion','Unit_Vector','State_Image','Input_Image'])
reset='''   procedure Reset_Mass (D : in out Simulation)
     with Global => null, Pre => Is_Ready (D),
       Post => (Static => '''+frame+'''
         and then not Mass_Current (D) and then not Forces_Current (D)
         and then MJ.Smooth_Dynamics.Work_Array (D.Dynamics.Mass.all)
         and then MJ.Smooth_Dynamics.Symmetric (D.Dynamics.Mass.all, D.Nv)
         and then (for all X of D.Dynamics.Mass.all => X = 0.0))
   is
'''+hides+'''      Initial_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;
   begin
      D.Cache.Mass_Valid := False;
      D.Cache.Force_Valid := False;
      Zero_CRB_Mass (D.Dynamics.Mass.all, D.Nv);
      Prove_Configuration_Equality (Configuration (D), Initial_Config);
   end Reset_Mass;
   pragma Inline_Always (Reset_Mass);

'''
crb='''   procedure Assemble_CRB_Path (D : in out Simulation; Used_CRB : out Boolean)
     with Global => null, Pre => Is_Ready (D) and then Positions_Current (D),
       Post => (Static => '''+frame+'''
         and then (if Used_CRB then Mass_Current (D) and then Symmetric_Mass (D)))
   is
'''+hides+'''      Nv : constant Natural := D.Nv;
      Spatial_Ok : Boolean;
   begin
      Used_CRB := False;
      if D.Nv >= 3 then
         declare
            Candidate : Real_Array (0 .. Nv * Nv - 1) with Relaxed_Initialization;
         begin
            Spatial.Prepare (D, Spatial_Ok);
            if Spatial_Ok then Try_Assemble_CRB (D, Candidate, Used_CRB); end if;
            if Used_CRB then Mass_Publication.Publish (D, Candidate); end if;
         end;
      end if;
   end Assemble_CRB_Path;
   pragma Inline_Always (Assemble_CRB_Path);

'''
dense='''   procedure Assemble_Dense_Path (D : in out Simulation; Result : out Status)
     with Global => null, Pre => Is_Ready (D) and then Positions_Current (D),
       Post => (Static => '''+frame+'''
         and then (if Result = Success then Mass_Current (D) and then Symmetric_Mass (D)))
   is
'''+hides+'''      Initial_Config : constant Configuration_Snapshot := Configuration (D) with Ghost => Static;
   begin
      Reset_Mass (D);
      Pipeline.Ensure_Jacobians (D, Result);
      if Result /= Success then return; end if;
      Expose_Assembly_Layout (D);
      Prove_Jacobian_Readiness (D);
      Prove_Dense_Inputs (D);
      Assemble_Dense_Mass
        (D.Body_Config.all, D.Joint_Config.all, D.Kinematic.Bodies.all,
         D.Kinematic.Linear_Jacobian.all, D.Kinematic.Angular_Jacobian.all,
         D.Nv, D.Dynamics.Mass.all, Result);
      pragma Assert (Static => D.Dynamics.Mass'First = 0
        and then D.Dynamics.Mass'Last = D.Nv * D.Nv - 1);
      Prove_Configuration_Equality (Configuration (D), Initial_Config);
      if Result /= Success then return; end if;
      Mass_Publication.Mark_Ready (D);
   end Assemble_Dense_Path;
   pragma Inline_Always (Assemble_Dense_Path);

'''
outer='''   procedure Assemble (D : in out Simulation; Result : out Status) is
'''+hides+''.join('      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", '+n+');\n' for n in ['Is_Ready','State_Values','Input_Values','Configuration','Position_Values','Velocity_Values','Symmetric_Mass'])+'''      Used_CRB : Boolean;
   begin
      pragma Assert (Static => Phase_Ready (D));
      if not D.Cache.Pose_Valid then Result := Stale_Results; return; end if;
      Reset_Mass (D);
      Assemble_CRB_Path (D, Used_CRB);
      if Used_CRB then Result := Success; return; end if;
      Assemble_Dense_Path (D, Result);
   end Assemble;'''
p.write_text(s[:a]+reset+crb+dense+outer+s[b:])
