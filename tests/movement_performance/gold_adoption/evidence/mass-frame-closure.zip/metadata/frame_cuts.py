from pathlib import Path
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb')
s=p.read_text()
def declarations(prefix):
 return ''.join(f'      {prefix}_{n} : constant {typ} := {q} (D) with Ghost => Static;\n' for n,q,typ in [('State','State_Values','Real_Array'),('Inputs','Input_Values','Real_Array'),('Pos','Position_Values','Real_Array'),('Vel','Velocity_Values','Real_Array'),('Config','Configuration','Configuration_Snapshot')])
def wrap(call):
 t='      declare\n'+declarations('Before')+'      begin\n      '+call+'\n'
 for n,q in [('State','State_Values'),('Inputs','Input_Values'),('Pos','Position_Values'),('Vel','Velocity_Values')]:
  t+=f'         MJ.Smooth_Kernels.Equal_Transitive ({q} (D), Before_{n}, Initial_{n});\n'
 t+='         Equal_Configurations (Configuration (D), Before_Config, Initial_Config);\n      end;'
 return t
for name,calls in [('Assemble_CRB_Path',['Spatial.Prepare (D, Spatial_Ok);','Mass_Publication.Publish (D, Candidate);']),('Assemble',['Reset_Mass (D);','Assemble_CRB_Path (D, Used_CRB);','Assemble_Dense_Path (D, Result);'])]:
 a=s.index('   procedure '+name+' (');b=s.index('   end '+name+';',a)
 t=s[a:b];loc=t.index('   begin\n')
 t=t[:loc]+declarations('Initial')+t[loc:]
 for call in calls:
  assert t.count(call)==1
  t=t.replace(call,wrap(call))
 if name=='Assemble_CRB_Path':
  t=t.replace('      Nv : constant Natural := D.Nv;', '      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", MJ.Smooth_Dynamics.Symmetric);\n      Nv : constant Natural := D.Nv;')
 s=s[:a]+t+s[b:]
p.write_text(s)
