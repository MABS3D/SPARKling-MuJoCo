from pathlib import Path
import textwrap
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text()
items=[('State','State_Values','Real_Array'),('Inputs','Input_Values','Real_Array'),('Pos','Position_Values','Real_Array'),('Vel','Velocity_Values','Real_Array'),('Config','Configuration','Configuration_Snapshot')]
def decls(prefix,spaces):return ''.join(' '*spaces+f'{prefix}_{n} : constant {typ} := {q} (D) with Ghost => Static;\n' for n,q,typ in items)
def frame(call):
 t='declare\n'+decls('Before',3)+'begin\n   '+call+'\n'
 for n,q,_ in items[:4]:t+=f'   MJ.Smooth_Kernels.Equal_Transitive ({q} (D), Before_{n}, Initial_{n});\n'
 t+='   Equal_Configurations (Configuration (D), Before_Config, Initial_Config);\nend;'
 return textwrap.indent(t,'      ')
for n,calls in [('Build_And_Publish_CRB',['Mass_Publication.Publish (D, Candidate);']),('Assemble_CRB_Path',['Spatial.Prepare (D, Spatial_Ok);','Build_And_Publish_CRB (D, Used_CRB);']),('Fill_And_Mark_Mass',['Fill_Dense_Ready (D, Result);','Mass_Publication.Mark_Ready (D);'])]:
 a=s.index('   procedure '+n);b=s.index('   end '+n+';',a);t=s[a:b];i=t.index('   begin\n');t=t[:i]+decls('Initial',6)+t[i:]
 t=t.replace('   begin\n','   begin\n      pragma Assert (Static => State_Values (D) = Initial_State);\n',1)
 for c in calls:t=t.replace('      '+c,frame(c))
 s=s[:a]+t+s[b:]
p.write_text(s)
