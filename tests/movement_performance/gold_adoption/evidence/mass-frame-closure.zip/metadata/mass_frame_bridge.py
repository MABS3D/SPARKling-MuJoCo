from pathlib import Path
import json,re
p=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src/mj-data-inertia_phase.adb');s=p.read_text()
snap=json.loads(Path('/var/tmp/sparkling-mass-frame-20260927/crb-config-cuts/results.json').read_text())['snapshot'];old=(Path(snap)/'experimental/smooth/src/mj-data-inertia_phase.adb').read_text()
for n in ['Build_And_Publish_CRB','Assemble_CRB_Path']:
 a=s.index('   procedure '+n);b=s.index('   end '+n+';',a)+len('   end '+n+';')
 x=old.index('   procedure '+n);y=old.index('   end '+n+';',x)+len('   end '+n+';');t=old[x:y]
 if n=='Build_And_Publish_CRB':t=t.replace('   is\n','   is\n      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Symmetric_Mass);\n')
 s=s[:a]+t+s[b:]
a=s.index('   procedure Assemble_Dense_Path')
helper='''   procedure Equal_Mass_Properties (Before, After : Real_Array; Nv : Natural)
     with Ghost => Static, Global => null,
       Pre => MJ.Smooth_Dynamics.Square_Layout (Before, Nv)
         and then MJ.Smooth_Dynamics.Square_Layout (After, Nv)
         and then Before = After
         and then MJ.Smooth_Dynamics.Work_Array (Before)
         and then MJ.Smooth_Dynamics.Symmetric (Before, Nv),
       Post => MJ.Smooth_Dynamics.Work_Array (After)
         and then MJ.Smooth_Dynamics.Symmetric (After, Nv)
   is
   begin
      null;
   end Equal_Mass_Properties;

'''
s=s[:a]+helper+s[a:]
a=s.index('   procedure Assemble_Dense_Path');b=s.index('   end Assemble_Dense_Path;',a);t=s[a:b]
# Keep exact snapshots local to the only call that can invalidate opaque mass facts.
needle='         Pipeline.Ensure_Jacobians (D, Result);'
assert needle in t
t=t.replace(needle,'''         Ready_Properties (D);
         Expose_Assembly_Layout (D);
         declare
            Before_Nv : constant Natural := D.Nv with Ghost => Static;
            Before_Mass : constant Real_Array := D.Dynamics.Mass.all with Ghost => Static;
         begin
            Pipeline.Ensure_Jacobians (D, Result);
            Expose_Assembly_Layout (D);
            pragma Assert (Static => D.Nv = Before_Nv);
            Equal_Mass_Properties (Before_Mass, D.Dynamics.Mass.all, D.Nv);
         end;''')
p.write_text(s[:a]+t+s[b:])
