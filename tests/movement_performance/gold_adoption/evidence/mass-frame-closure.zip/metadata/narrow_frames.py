from pathlib import Path
root=Path('/var/tmp/sparkling-mass-frame-20260927/source/experimental/smooth/src')
p=root/'mj-data-pipeline.adb'
s=p.read_text()
a=s.index('   procedure Ensure_Jacobians (')
b=s.index('   procedure Evaluate_Inertia_Forces',a)
body=s[a:b]
contract='''   procedure Refresh_Jacobian_Cache (D : in out Simulation; Result : out Status)
     with Global => null, Pre => Is_Ready (D) and then Positions_Current (D),
       Post => (Static => Is_Ready (D) and then Positions_Current (D)
         and then Is_Empty (D) = Is_Empty (D)'Old and then Shape (D) = Shape (D)'Old
         and then State_Values (D) = State_Values (D)'Old
         and then Input_Values (D) = Input_Values (D)'Old
         and then Mass_Current (D) = Mass_Current (D)'Old
         and then Passive_Current (D) = Passive_Current (D)'Old
         and then Actuation_Current (D) = Actuation_Current (D)'Old
         and then Forces_Current (D) = Forces_Current (D)'Old
         and then (if Result = Success then D.Cache.Jacobian_Valid)
         and then Stable_Ready (D)
         and then D.Dynamics.Mass.all = D.Dynamics.Mass.all'Old
         and then Configuration (D) = Configuration (D)'Old
         and then Position_Values (D) = Position_Values (D)'Old
         and then Velocity_Values (D) = Velocity_Values (D)'Old
         and then Time (D) = Time (D)'Old and then Step_Size (D) = Step_Size (D)'Old)
   is'''
body=body.replace('   procedure Ensure_Jacobians (D : in out Simulation; Result : out Status) is',contract).replace('   end Ensure_Jacobians;','   end Refresh_Jacobian_Cache;\n   pragma Inline_Always (Refresh_Jacobian_Cache);')
wrapper='''   procedure Ensure_Jacobians (D : in out Simulation; Result : out Status) is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Image);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Input_Image);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", State_Values);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Input_Values);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Configuration);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Position_Values);
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Velocity_Values);
   begin
      Refresh_Jacobian_Cache (D, Result);
   end Ensure_Jacobians;

'''
p.write_text(s[:a]+body+wrapper+s[b:])
p=root/'mj-data-pipeline.ads'
s=p.read_text().replace('   pragma Postcondition (Static => State_Values (D) = State_Values (D)\'Old);\n','')
p.write_text(s)
p=root/'mj-data-inertia_phase.adb'
s=p.read_text()
a=s.index('   procedure Assemble (D :')
helper='''   procedure Expose_Assembly_Layout (D : Simulation)
     with Ghost => Static, Global => null, Pre => Stable_Ready (D),
       Post => D.Dynamics.Mass'First = 0
         and then D.Dynamics.Mass'Last = D.Nv * D.Nv - 1
         and then D.Body_Config'First = 0 and then D.Body_Config'Length = D.Nb
         and then D.Kinematic.Linear_Jacobian'First = 0
         and then D.Kinematic.Linear_Jacobian'Last = 3 * D.Body_Config'Length * D.Nv - 1
         and then D.Kinematic.Angular_Jacobian'First = 0
         and then D.Kinematic.Angular_Jacobian'Last = D.Kinematic.Linear_Jacobian'Last
   is
   begin
      null;
   end Expose_Assembly_Layout;

'''
s=s[:a]+helper+s[a:]
a=s.index('   procedure Assemble (D :')
b=s.index('   end Assemble;',a)
body=s[a:b]
body=body.replace('            pragma Assert (Static => D.Nv = Nv);','            pragma Assert (Static => D.Nv = Nv);\n            Expose_Assembly_Layout (D);')
body=body.replace('      Prove_Jacobian_Readiness (D);','      Expose_Assembly_Layout (D);\n      Prove_Jacobian_Readiness (D);')
# Expose layout after a buffer write, before expanding readiness again.
body=body.replace('            if Used_CRB then Copy_Bounded_Mass (Candidate, Nv, D.Dynamics.Mass.all); end if;', '''            if Used_CRB then
               Copy_Bounded_Mass (Candidate, Nv, D.Dynamics.Mass.all);
            end if;
            pragma Assert (Static => D.Dynamics.Mass'First = 0
              and then D.Dynamics.Mass'Last = D.Nv * D.Nv - 1);''')
s=s[:a]+body+s[b:]
p.write_text(s)
