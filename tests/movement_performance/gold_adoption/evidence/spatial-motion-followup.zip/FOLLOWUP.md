# Motion prefix follow-up, 2026-09-27

A separate bounded follow-up to README.md/evidence.zip. The earlier archives are unchanged. No active repository files were edited by this agent; all proof/build processes are finished.

## Changes in the isolated draft

`motion-followup.patch` applies to the earlier candidate Spatial body saved as `pre-motion-refinement.adb`. It adds only a Ghost=>Static projection lemma, equivalent rearrangement of precondition quantifiers, and Static proof invariants/assertions. It preserves every runtime arithmetic expression, check, store, branch, and failure return. No helper affecting runtime was introduced.

`Expose_Motion_Direction` proves the bound of a selected joint direction from the existing all-directions bound. The direction quantifier is separated from ownership facts, so the projection need not instantiate a mixed record predicate. Prefix invariants now use the flat buffer index, matching the adopted storage contracts. The final experiment separates preservation of cells already bounded at inner-loop entry from bounds for the newly written contiguous prefix. This does not assume stale/unwritten buffers are bounded when Spatial_Valid is false.

## Results

| Scope | Result | Exact evidence |
| --- | --- | --- |
| Expose_Motion_Direction | 4/4, no unproved/errors | motion-direction-prefix/ |
| Build_Buffers with projection/flat indices | 88 checks, 3 open | motion-direction-prefix/ |
| Build_Buffers with separate preservation/prefix invariants | 94 checks, 3 open | motion-split-prefix/ |

The original direction-bound obligation and its lemma call are now proved. The final run emits no diagnostics for the invariant preserving cells that were bounded at loop entry; it is still part of a partially proved routine and is not reported as independent whole-routine closure.

Remaining distinct obligations in the final source and immutable snapshot `/tmp/sparkling-smooth-fragments-rcji7vta/source/experimental/smooth/src/mj-data-spatial.adb`:

* line149: success postcondition that all motion cells are within1e12.
* line178: preservation of the newly written prefix, indices `6 * First_Joint .. 6 * (First_Joint + K) - 1`.
* line194: body-completion assertion connecting written intervals and `Joints(I/6).Body_Id <= B`.

Each is a prover timeout under cvc5+altergo3s, steps0, level0, jobs2, not a demonstrated runtime fault. This follow-up ran no Prepare proof and removed no runtime scan. No complete Spatial-unit or dynamics closure is claimed. The previous closed Set_Moment, Build_Centers, Add_Moment and Root_Center code is unchanged.

A further focused step would isolate one body's joint-motion loop into a narrow buffer helper with exact written-value/frame contracts, then prove the simple interval extension separately from body ownership. That work is not implemented or claimed complete in this archive.

## Dependencies and evidence

The Spatial_Storage spec exactly matches the already adopted complete104/104 unit: SHA256 `08ffda6963208c8164662ab8c431f8d039de24b4a6fa5af6e30855d0ae9f26ba`; runtime body `502d06c6f7698f1db52fefd80c0508ff89a84fa4fb4406fc8555d60bd47ceb2c`. Its storage-prefix/ result is included as dependency evidence. The previous storage-evidence.zip is unchanged.

`motion-followup-evidence.zip` retains both new proof attempts, the complete storage dependency result, exact source objects by SHA256, source continuity checks, baseline/final body, patch, runner and guarded process wrapper. `motion-followup-manifest.json` records archive checksum, source counts and CRC validation. This agent performed no numerical tests, machine-code comparison or integrated timing.
