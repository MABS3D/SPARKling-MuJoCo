# CRB publication integration candidate — isolated, 2026-09-27

This candidate is separate from the closed standalone Mass_Publication helper. It has not been applied to the active repository, tested numerically, benchmarked, or accepted as Gold. No runtime scan has been removed.

The patch adds the unchanged, previously proved Mass_Publication package and a narrow Try_CRB_Publication wrapper. Assemble now calls the wrapper where it previously prepared the spatial data, assembled a local CRB Candidate, and copied that candidate into the public dense mass. Existing Assemble contracts, the CRB producer body, the successful outer block, dense fallback, and subsequent solver bodies are byte-identical. See source-continuity.json.

The wrapper calls Spatial.Prepare first, then allocates Candidate using a local constant Nv after successful preparation. Spatial's existing shape contract preserves dimensions. This avoids carrying an earlier dimension snapshot across the call. Numeric/failure outputs are preserved; Candidate is no longer allocated when Spatial preparation fails. Allocation-failure observability (Storage_Error) is outside the existing verification scope and is not claimed to be equivalent.

On successful CRB production, Publish performs its original three assignments: mass copy, Mass_Valid := True, and Force_Valid := False. The outer mass-valid assignment is retained, and force validity was already cleared before the branch. Existing fallback/failure paths are retained. Normal assertion-enabled builds may evaluate the new procedure contracts; no release performance claim is made.

The wrapper uses Hide_Info only to keep contracted predicates opaque during composition, without new runtime predicates. The rejected final proof-cut attempt also used Static ghost snapshots/assertions. No Assume, Skip_Proof, suppression, trusted body, or weaker existing contract has been introduced. Failed predicates remain open obligations, never assumed to be established outside modular contract reasoning.

## Final candidate status

The selected candidate is the simpler source from proof-crb-publication-final: 9 emitted checks, 2 open, zero errors, 66.9 seconds. Open obligations are Publish's Work_Array precondition (body line 110) and wrapper State_Values preservation (spec line 10). Dimension/layout checks, the symmetry requirement, readiness, configuration and other frame components did not produce failures in that run. This remains an incomplete proof and is not eligible for adoption.

A subsequent explicit-cut attempt (proof-crb-publication-cuts) emitted 14 checks with 3 open and zero errors in 81.6 seconds. It did not solve the producer boundedness transfer or final state frame and also left symmetry open. Its entire source and diagnostics are archived, but the source/ candidate has been restored to the simpler 9/2 version. No broader Assemble proof was attempted after this bounded integration failed; doing so would not close the missing dependency.

Next smallest proof-engineering step: isolate the producer-result handoff without D mutation, then prove array-value frame transitivity through both calls. Keep original guard behavior until the complete producer chain and Assemble preservation close.

## Proof interpretation

The independent Mass_Publication unit was already closed with 64 checks and supporting Matrix_Offset (6 checks) and Prove_Configuration_Equality (28 checks). Its exact files are unchanged here; hashes are in source-continuity.json. Full independent closure evidence is in /var/tmp/sparkling-force-scan-gold/handoff. Those checks are not a proof of CRB or the simulator.

The new wrapper is modular: Spatial.Prepare and Try_Assemble_CRB contracts remain dependencies whose open bodies must still be closed. A passing wrapper alone would not justify removing Forces_Phase.Compute's Phase_Ready scan. Assemble's dense fallback and producer chain still require proof, followed by checked numerical validation and performance validation before adoption.

proof-index.json gives every run, including rejected intermediate source and failures. proofs.zip retains logs, structured diagnostics, commands and manifests. proof-source-objects.zip preserves every immutable source input by SHA256, with runs.json mapping paths to objects. The source/ tree and patch contain the final candidate; they are not the earlier successful standalone helper artifact.

Reproduce the final wrapper run from the corresponding archived source snapshot:

```sh
ulimit -s 65536
python3 experimental/smooth/tools/prove_fragments.py \
  --repo /var/tmp/sparkling-mass-publication-integration \
  --toolchain-root /var/tmp/sparkling-matrix-recovery/toolchains \
  --unit mj-data-inertia_phase --name Try_CRB_Publication \
  --report-dir /var/tmp/crb-publication-new-run \
  --prepare-seconds 110 --wall-seconds 110 --total-seconds 120 \
  --prover-seconds 3 --steps 0 --provers cvc5,z3 --cap-mb 3000 --jobs 1
```

This source snapshot includes the newly integrated unused Fused_RNE package and accepted pose predicate change. The active repository subsequently strengthened mj-spatial_storage.ads; this isolated base predates that change. active-input-sha256.json and active-delta-at-handoff.json record the distinction. Applying this patch must preserve that newer active file. The patch does not touch it.
