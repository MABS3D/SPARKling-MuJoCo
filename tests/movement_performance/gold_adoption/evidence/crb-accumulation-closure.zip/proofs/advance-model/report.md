# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-dppm7ix3/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Reveal_Accumulation_Values` | `mj-data-inertia_phase.adb:268` | [completed_no_unproved](logs/mj-data-inertia_phase__reveal_accumulation_values__adb_268.log) | 22 | 0 | 0 | 29.6 |
| `Advance_Accumulation_Model` | `mj-data-inertia_phase.adb:285` | [completed_no_unproved](logs/mj-data-inertia_phase__advance_accumulation_model__adb_285.log) | 37 | 0 | 0 | 29.9 |

## Diagnostics

