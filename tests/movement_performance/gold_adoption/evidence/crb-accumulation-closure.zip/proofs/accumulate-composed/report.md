# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-91pllc62/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Accumulate_Composite` | `mj-data-inertia_phase.adb:308` | [unproved_checks](logs/mj-data-inertia_phase__accumulate_composite__adb_308.log) | 100 | 3 | 0 | 220.4 |

## Diagnostics

### mj-data-inertia_phase__accumulate_composite__adb_308

- `mj-data-inertia_phase.adb:330` (medium): loop invariant might not be preserved by an arbitrary iteration [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:332` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Weights (K) = 0 [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:358` (medium): precondition might fail, cannot prove After (K) (J) = (if P > 0 and then K = P then SK.Add (Before.Values (P), Before.Values (B)) (J) else Before.Values (K) (J)) [provers reached time limit before completing the proof]

