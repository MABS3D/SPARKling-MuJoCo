# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-v6zomvmv/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Transfer_Inertia_Bound` | `mj-data-inertia_phase.adb:208` | [completed_no_unproved](logs/mj-data-inertia_phase__transfer_inertia_bound__adb_208.log) | 3 | 0 | 0 | 16.0 |
| `Preserve_Weighted_Prefix` | `mj-data-inertia_phase.adb:217` | [completed_no_unproved](logs/mj-data-inertia_phase__preserve_weighted_prefix__adb_217.log) | 32 | 0 | 0 | 35.4 |

## Diagnostics

