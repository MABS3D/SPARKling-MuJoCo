# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-69c2owg8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Retire_Weight` | `mj-data-inertia_phase.adb:308` | [completed_no_unproved](logs/mj-data-inertia_phase__retire_weight__adb_308.log) | 19 | 0 | 0 | 17.9 |
| `Expose_Inertia_Equality` | `mj-data-inertia_phase.adb:325` | [completed_no_unproved](logs/mj-data-inertia_phase__expose_inertia_equality__adb_325.log) | 1 | 0 | 0 | 3.1 |
| `Describe_Model_Update` | `mj-data-inertia_phase.adb:334` | [completed_no_unproved](logs/mj-data-inertia_phase__describe_model_update__adb_334.log) | 28 | 0 | 0 | 26.1 |

## Diagnostics

