# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-6sfpnjyi/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_CRB` | `mj-data-inertia_phase.adb:462` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_crb__adb_462.log) | 49 | 4 | 0 | 110.2 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_crb__adb_462

- `mj-data-inertia_phase.adb:507` (medium): loop invariant might fail in first iteration, cannot prove T.Dof_Count (D.Topology) = D.Nv [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:509` (medium): loop invariant might fail in first iteration, cannot prove P /= null [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:509` (medium): in inlined expression function body at mj-data.ads:392
- `mj-data-inertia_phase.adb:514` (medium): precondition might fail, cannot prove Source (Base + K) in -1.0e12 .. 1.0e12 [provers reached time and memory limit before completing the proof]

