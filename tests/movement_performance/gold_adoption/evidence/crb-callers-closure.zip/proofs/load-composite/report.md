# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-3nqdg91w/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Composite` | `mj-data-inertia_phase.adb:431` | [unproved_checks](logs/mj-data-inertia_phase__load_composite__adb_431.log) | 21 | 5 | 0 | 20.3 |

## Diagnostics

### mj-data-inertia_phase__load_composite__adb_431

- `mj-data-inertia_phase.adb:431` (medium): "Composite" might not be initialized in "Load_Composite" [reason for check: OUT parameter should be fully initialized on return] [possible fix: initialize "Composite" on all paths, make "Composite" an IN OUT parameter or annotate it with aspect Relaxed_Initialization]
- `mj-data-inertia_phase.adb:436` (medium): "Composite" might not be initialized
- `mj-data-inertia_phase.adb:444` (medium): "Composite" might not be initialized
- `mj-data-inertia_phase.adb:446` (medium): "Composite" might not be initialized
- `mj-data-inertia_phase.adb:431` (medium): "Composite" might not be initialized in "Load_Composite"

