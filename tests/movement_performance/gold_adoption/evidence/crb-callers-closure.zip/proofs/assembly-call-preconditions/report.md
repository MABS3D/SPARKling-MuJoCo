# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-uudv6qfw/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 545` | `mj-data-inertia_phase.adb:545` | [proof_timeout](logs/mj-data-inertia_phase__adb_line_545.log) | 0 | 0 | 0 | 65.2 |
| `line 546` | `mj-data-inertia_phase.adb:546` | [proof_timeout](logs/mj-data-inertia_phase__adb_line_546.log) | 0 | 0 | 0 | 65.0 |

## Diagnostics

