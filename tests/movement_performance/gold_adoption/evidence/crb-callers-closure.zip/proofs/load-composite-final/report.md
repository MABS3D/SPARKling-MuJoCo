# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-d6cxj_lz/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Composite` | `mj-data-inertia_phase.adb:431` | [unproved_checks](logs/mj-data-inertia_phase__load_composite__adb_431.log) | 28 | 2 | 0 | 28.4 |

## Diagnostics

### mj-data-inertia_phase__load_composite__adb_431

- `mj-data-inertia_phase.adb:445` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove I (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:445` (medium): in inlined expression function body at mj-spatial_kernels.ads:25

