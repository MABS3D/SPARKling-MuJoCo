# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-dig3_0eg/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Zero_CRB_Mass` | `mj-data-inertia_phase.adb:450` | [unproved_checks](logs/mj-data-inertia_phase__zero_crb_mass__adb_450.log) | 3 | 1 | 0 | 15.7 |
| `Try_Assemble_CRB` | `mj-data-inertia_phase.adb:462` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_crb__adb_462.log) | 44 | 4 | 0 | 82.3 |

## Diagnostics

### mj-data-inertia_phase__zero_crb_mass__adb_450

- `mj-data-inertia_phase.adb:452` (high): "Mass" is not initialized

### mj-data-inertia_phase__try_assemble_crb__adb_462

- `mj-data-inertia_phase.adb:508` (medium): precondition might fail [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:509` (medium): precondition might fail, cannot prove Source'Length >= 6 [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:509` (medium): precondition might fail [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:512` (medium): precondition might fail [provers reached time and memory limit before completing the proof]

