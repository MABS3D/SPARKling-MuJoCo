# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-0a9mzq_i/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_CRB` | `mj-data-inertia_phase.adb:452` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_crb__adb_452.log) | 44 | 16 | 0 | 97.2 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_crb__adb_452

- `mj-data-inertia_phase.adb:457` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:457` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:474` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:474` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:477` (medium): precondition might fail, cannot prove A (MJ.Smooth_Kernels.Matrix_Offset (N, I, J)) = A (MJ.Smooth_Kernels.Matrix_Offset (N, J, I)) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:477` (medium): in inlined expression function body at mj-smooth_dynamics.ads:116
- `mj-data-inertia_phase.adb:491` (medium): loop invariant might fail in first iteration, cannot prove A (MJ.Smooth_Kernels.Matrix_Offset (N, I, J)) = A (MJ.Smooth_Kernels.Matrix_Offset (N, J, I)) [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:491` (medium): in inlined expression function body at mj-smooth_dynamics.ads:116
- 8 more diagnostics in the individual log.

