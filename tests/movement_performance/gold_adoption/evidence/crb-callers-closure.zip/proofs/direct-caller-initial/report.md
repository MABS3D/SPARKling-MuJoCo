# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-gr80twuh/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_CRB` | `mj-data-inertia_phase.adb:430` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_crb__adb_430.log) | 59 | 25 | 0 | 131.8 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_crb__adb_430

- `mj-data-inertia_phase.adb:435` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:435` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:449` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Composite (K)'Initialized [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:450` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove I (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:450` (medium): in inlined expression function body at mj-spatial_kernels.ads:25
- `mj-data-inertia_phase.adb:450` (medium): initialization check might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:451` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove I (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:451` (medium): in inlined expression function body at mj-spatial_kernels.ads:25
- 17 more diagnostics in the individual log.

