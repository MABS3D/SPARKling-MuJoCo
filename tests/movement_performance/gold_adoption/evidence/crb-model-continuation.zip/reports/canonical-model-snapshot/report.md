# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4yeitugv/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Accumulate_Composite` | `mj-data-inertia_phase.adb:160` | [unproved_checks](logs/mj-data-inertia_phase__accumulate_composite__adb_160.log) | 83 | 20 | 0 | 84.8 |

## Diagnostics

### mj-data-inertia_phase__accumulate_composite__adb_160

- `mj-data-inertia_phase.adb:164` (medium): postcondition might fail, cannot prove I (0) in -Limit .. Limit [provers reached step limit before completing the proof]
- `mj-data-inertia_phase.adb:164` (medium): in inlined expression function body at mj-spatial_kernels.ads:25
- `mj-data-inertia_phase.adb:175` (medium): assertion might fail, cannot prove I (0) in -Limit .. Limit [provers reached step limit before completing the proof]
- `mj-data-inertia_phase.adb:175` (medium): in inlined expression function body at mj-spatial_kernels.ads:25
- `mj-data-inertia_phase.adb:181` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove I (0) in -Limit .. Limit [provers reached step limit before completing the proof]
- `mj-data-inertia_phase.adb:181` (medium): in inlined expression function body at mj-spatial_kernels.ads:25
- `mj-data-inertia_phase.adb:182` (medium): loop invariant might not be preserved by an arbitrary iteration [provers reached step limit before completing the proof]
- `mj-data-inertia_phase.adb:184` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Weights (K) > 0 [provers reached step limit before completing the proof]
- 12 more diagnostics in the individual log.

