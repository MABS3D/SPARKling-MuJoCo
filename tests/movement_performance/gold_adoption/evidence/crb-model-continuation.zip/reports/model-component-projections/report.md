# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-v2_o35w2/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Model_Component_Equality` | `mj-data-inertia_phase.adb:182` | [unproved_checks](logs/mj-data-inertia_phase__prove_model_component_equality__adb_182.log) | 31 | 3 | 0 | 55.5 |

## Diagnostics

### mj-data-inertia_phase__prove_model_component_equality__adb_182

- `mj-data-inertia_phase.adb:190` (medium): postcondition might fail, cannot prove Model_Step (Left, B, P).Ok = Model_Step (Right, B, P).Ok [provers reached step limit before completing the proof]
- `mj-data-inertia_phase.adb:200` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove SK.Add (Left.Values (P), Left.Values (B)) (V) = SK.Add (Right.Values (P), Right.Values (B)) (V) [provers reached step limit before completing the proof]
- `mj-data-inertia_phase.adb:201` (medium): array index check might fail [reason for check: value must be a valid index into the array] [provers reached step limit before completing the proof]

