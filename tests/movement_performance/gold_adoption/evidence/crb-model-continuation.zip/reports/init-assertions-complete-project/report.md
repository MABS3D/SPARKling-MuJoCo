# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-gi8jekia/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 177` | `mj-data-inertia_phase.adb:177` | [proof_timeout](logs/mj-data-inertia_phase__adb_line_177.log) | 0 | 0 | 0 | 45.2 |
| `line 178` | `mj-data-inertia_phase.adb:178` | [proof_timeout](logs/mj-data-inertia_phase__adb_line_178.log) | 0 | 0 | 0 | 35.3 |
| `line 179` | `mj-data-inertia_phase.adb:179` | [proof_timeout](logs/mj-data-inertia_phase__adb_line_179.log) | 0 | 0 | 0 | 34.0 |

## Diagnostics

