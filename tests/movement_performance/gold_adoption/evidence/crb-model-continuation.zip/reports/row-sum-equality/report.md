# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-b545smox/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Composite_Row_Equal` | `mj-data-inertia_phase.adb:183` | [completed_no_unproved](logs/mj-data-inertia_phase__prove_composite_row_equal__adb_183.log) | 3 | 0 | 0 | 16.7 |
| `Prove_Inertia_Sums_Equal` | `mj-data-inertia_phase.adb:194` | [unproved_checks](logs/mj-data-inertia_phase__prove_inertia_sums_equal__adb_194.log) | 11 | 1 | 0 | 25.7 |

## Diagnostics

### mj-data-inertia_phase__prove_inertia_sums_equal__adb_194

- `mj-data-inertia_phase.adb:199` (medium): postcondition might fail, cannot prove SK.Add (A, B) = SK.Add (C, D) [provers reached step limit before completing the proof]

