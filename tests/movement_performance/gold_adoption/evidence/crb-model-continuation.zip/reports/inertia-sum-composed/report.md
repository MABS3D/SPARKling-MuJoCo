# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-uehg2ap5/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Inertia_Sums_Equal` | `mj-data-inertia_phase.adb:219` | [proof_timeout](logs/mj-data-inertia_phase__prove_inertia_sums_equal__adb_219.log) | 0 | 0 | 0 | 80.1 |

## Diagnostics

