# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-pm4oq0oo/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prove_Composite_Entry_Equal` | `mj-data-inertia_phase.adb:170` | [completed_no_unproved](logs/mj-data-inertia_phase__prove_composite_entry_equal__adb_170.log) | 5 | 0 | 0 | 16.1 |

## Diagnostics

