# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-84zvia6q/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Add_Prefix_Row` | `mj-data-inertia_phase.adb:293` | [unproved_checks](logs/mj-data-inertia_phase__add_prefix_row__adb_293.log) | 12 | 1 | 0 | 20.1 |

## Diagnostics

### mj-data-inertia_phase__add_prefix_row__adb_293

- `mj-data-inertia_phase.adb:309` (medium): range check might fail, cannot prove upper bound for Source'Length [provers reached time limit before completing the proof]

