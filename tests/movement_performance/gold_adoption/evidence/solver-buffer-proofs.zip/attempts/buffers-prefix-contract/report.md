# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-qy7cn0fm/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Solve_Compatible_Buffers` | `mj-data-inertia_phase.adb:314` | [unproved_checks](logs/mj-data-inertia_phase__solve_compatible_buffers__adb_314.log) | 81 | 2 | 0 | 66.5 |

## Diagnostics

### mj-data-inertia_phase__solve_compatible_buffers__adb_314

- `mj-data-inertia_phase.adb:387` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:387` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94

