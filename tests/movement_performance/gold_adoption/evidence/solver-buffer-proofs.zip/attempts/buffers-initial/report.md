# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-igz19c81/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Solve_Compatible_Buffers` | `mj-data-inertia_phase.adb:292` | [unproved_checks](logs/mj-data-inertia_phase__solve_compatible_buffers__adb_292.log) | 79 | 6 | 0 | 62.6 |

## Diagnostics

### mj-data-inertia_phase__solve_compatible_buffers__adb_292

- `mj-data-inertia_phase.adb:305` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:305` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:364` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:364` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:384` (medium): range check might fail [reason for check: input value must fit in parameter type] [possible fix: loop invariant at line 379 should mention Solution] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:385` (medium): range check might fail [reason for check: input value must fit in parameter type] [possible fix: loop invariant at line 379 should mention Solution] [provers reached time limit before completing the proof]

