# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-k59dt9hd/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Body_Inertia_Model` | `mj-data-spatial.adb:239` | [completed_no_unproved](logs/mj-data-spatial__body_inertia_model__adb_239.log) | 6 | 0 | 0 | 18.1 |
| `Reveal_Body_Inertia_Model` | `mj-data-spatial.adb:248` | [completed_no_unproved](logs/mj-data-spatial__reveal_body_inertia_model__adb_248.log) | 8 | 0 | 0 | 34.5 |

## Diagnostics

