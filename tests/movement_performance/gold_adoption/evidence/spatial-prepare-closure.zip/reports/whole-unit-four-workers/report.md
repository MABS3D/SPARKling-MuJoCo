# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-_cdjns88/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-data-spatial.adb:1` | [unproved_checks](logs/mj-data-spatial__whole_unit.log) | 391 | 2 | 0 | 174.5 |

## Diagnostics

### mj-data-spatial__whole_unit

- `mj-data-spatial.adb:67` (medium): postcondition might fail, cannot prove Center (0) = Zero [provers reached time limit before completing the proof]
- `mj-data-spatial.ads:7` (medium): postcondition might fail [provers reached time limit before completing the proof]

