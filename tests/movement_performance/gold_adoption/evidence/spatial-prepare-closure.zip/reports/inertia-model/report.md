# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-5bbpqywm/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Body_Inertia_Model` | `mj-data-spatial.adb:238` | [analysis_error](logs/mj-data-spatial__body_inertia_model__adb_238.log) | 0 | 0 | 8 | 2.1 |
| `Reveal_Body_Inertia_Model` | `mj-data-spatial.adb:247` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-data-spatial__body_inertia_model__adb_238

- `mj-data-spatial.adb:252` (error): operator for type "Inertia" defined at mj-spatial_kernels.ads:8 is not directly visible
- `mj-data-spatial.adb:252` (error): use clause would make operation legal
- `mj-data-spatial.adb:278` (error): incompatible ghost policies in effect
- `mj-data-spatial.adb:278` (error): "Body_Inertia_Model" declared at line 238 with ghost policy "Ignore"
- `mj-data-spatial.adb:278` (error): "Body_Inertia_Model" used at line 278 with ghost policy "Check"
- `mj-data-spatial.adb:342` (error): incompatible ghost policies in effect
- `mj-data-spatial.adb:342` (error): "Body_Inertia_Model" declared at line 238 with ghost policy "Ignore"
- `mj-data-spatial.adb:342` (error): "Body_Inertia_Model" used at line 342 with ghost policy "Check"

