from pathlib import Path
import subprocess,json,time
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');proof=Path('/var/tmp/sparkling-compact-retry-mass-proof2/results.json')
for attempt in range(800):
 d=json.loads(proof.read_text())
 if all(not r['status'].startswith('not_run') for r in d['results']):break
 time.sleep(1)
else:raise RuntimeError('leaf proof unfinished')
print([(r['target']['name'],r['status'],r.get('unproved')) for r in d['results']],flush=True)
