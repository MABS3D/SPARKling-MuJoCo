from pathlib import Path
import json,shutil,hashlib,os,subprocess,re
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');base=Path('/var/tmp/sparkling-compact-retry-inline');out=Path('/var/tmp/sparkling-compact-retry-canonical');out.mkdir();shutil.copytree(base/'current',out/'current');(out/'baseline').symlink_to(base/'baseline');(out/'movement_c').symlink_to(base/'movement_c')
root=out/'current/source/experimental/smooth/src'
p=root/'mj-data.ads';s=p.read_text();a=s.index('   function Uses_Compact_Mass');b=s.index('   function Caches_Bounded',a);s=s[:a]+s[b:];s=s.replace('Mass_Bounded (D)','Array_Bounded (D.Dynamics.Mass)')
s=s.replace('Has_Real_Layout (D.Dynamics.Mass, D.Nv * D.Nv)','Has_Real_Layout (D.Dynamics.Mass, MJ.Ancestor_Rows.Count (D.Ancestors))',1)
s=s.replace('and then not Uses_Compact_Mass (D)','and then MJ.Ancestor_Rows.Count (D.Ancestors) = D.Nv * D.Nv')
a=s.index('   function Mass_Entry (D : Simulation; Row, Column : Natural) return Real is');b=s.index('   function Force_Value',a)
s=s[:a]+'''   function Mass_Entry (D : Simulation; Row, Column : Natural) return Real is
     (MJ.Compact_Inertia.Value_At (D.Ancestors, D.Dynamics.Mass.all, Row, Column));
'''+s[b:]
a=s.index('   function Symmetric_Mass (D : Simulation) return Boolean is');b=s.index('   --  Limit the mutable formal',a)
s=s[:a]+'''   function Symmetric_Mass (D : Simulation) return Boolean is
     (Is_Ready (D) and then (for all I in 0 .. D.Nv - 1 =>
         (for all J in 0 .. D.Nv - 1 => Mass_Entry (D, I, J) = Mass_Entry (D, J, I))));
'''+s[b:];p.write_text(s)
p=root/'mj-data.adb';s=p.read_text();s=s.replace('procedure Allocate_Dynamics (B : in out Force_Buffers; Nv : Natural)','procedure Allocate_Dynamics (B : in out Force_Buffers; Nv, Nm : Natural)').replace('Pre => Nv <= Max_Dofs\n       and then B.Mass','Pre => Nv <= Max_Dofs and then Nm <= MJ.Ancestor_Rows.Max_Entries\n       and then B.Mass').replace('Has_Real_Layout (B.Mass, Nv * Nv)','Has_Real_Layout (B.Mass, Nm)').replace('B.Mass := Zero_Array (Nv * Nv);','B.Mass := Zero_Array (Nm);').replace('Allocate_Dynamics (D.Dynamics, D.Nv);','Allocate_Dynamics (D.Dynamics, D.Nv, MJ.Ancestor_Rows.Count (D.Ancestors));')
a=s.index('         if Uses_Compact_Mass (D) then');b=s.index('         end if;',a)+len('         end if;');s=s[:a]+'''         MJ.Compact_Inertia.Expand (D.Ancestors, D.Dynamics.Mass.all, Dense);'''+s[b:];p.write_text(s)
p=root/'mj-data-inertia_phase.adb';s=p.read_text();a=s.index('   procedure Try_Assemble_CRB');b=s.index('   procedure Try_Assemble_Compact',a);s=s[:a]+s[b:]
a=s.index('      if D.Nv >= 3 then',s.index('   procedure Assemble'));b=s.index('      if Used_CRB then\n         D.Cache.Mass_Valid',a)
s=s[:a]+'''      if D.Nv >= 3 then
         Spatial.Prepare (D, Spatial_Ok);
         if Spatial_Ok then Try_Assemble_Compact (D, Used_CRB); end if;
      end if;
'''+s[b:]
a=s.index('      D.Dynamics.Mass.all := [others => 0.0];',s.index('   procedure Assemble'));b=s.index('   end Assemble;',a)
chunk=s[a:b];packstart=chunk.index('      if Uses_Compact_Mass (D) then');packend=chunk.index('      D.Cache.Mass_Valid := True;',packstart)
chunk=chunk[:packstart]+'''      MJ.Ancestor_Rows.Copy_Matrix (D.Ancestors, D.Dynamics.Mass.all, D.Dynamics.Mass.all);
'''+chunk[packend:]
chunk=chunk.replace('D.Dynamics.Mass','D.Scratch.Factor').replace('Symmetric_Mass (D)','MJ.Smooth_Dynamics.Symmetric (D.Scratch.Factor.all, D.Nv)')
chunk=chunk.replace('MJ.Ancestor_Rows.Copy_Matrix (D.Ancestors, D.Scratch.Factor.all, D.Scratch.Factor.all);','MJ.Ancestor_Rows.Copy_Matrix (D.Ancestors, D.Scratch.Factor.all, D.Dynamics.Mass.all);')
s=s[:a]+chunk+s[b:]
a=s.index('      if Uses_Compact_Mass (D) then',s.index('   procedure Load_Ancestor_Factor'));b=s.index('      end if;',a)+len('      end if;');s=s[:a]+'''      D.Scratch.Ancestor_Factor.all := D.Dynamics.Mass.all;'''+s[b:]
s=s.replace('      D.Scratch.Factor.all := D.Dynamics.Mass.all;', '      MJ.Compact_Inertia.Expand (D.Ancestors, D.Dynamics.Mass.all, D.Scratch.Factor.all);')
p.write_text(s)
project=out/'current/movement_bench.gpr';project.write_text(project.read_text().replace(str(base/'current'),str(out/'current')))
tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH']
with (out/'current/trial-build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(project),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((base/'build.json').read_text());d['builds']['current'].update(binary=str(out/'current/bin/movement_bench'),binary_sha256=sha(out/'current/bin/movement_bench'),sources={str(p.relative_to(out/'current/source')):sha(p) for p in (out/'current/source').rglob('*.ad?')});d['sources']=d['builds']['current']['sources'];d['trial']='canonical compact mass, dense only for fallback and Strict';(out/'build.json').write_text(json.dumps(d,indent=2)+'\n');print('canonical built',flush=True)
with Path(str(out)+'-pilot.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python',str(repo/'tests/movement_performance/c_parity_six/compare.py'),'--build',str(out),'--out',str(out)+'-pilot','--toolchain-root',str(tc),'--cpu','12','--blocks','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('canonical pilot done',flush=True)
