from pathlib import Path
import json,shutil,hashlib,os,subprocess
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');base=Path('/var/tmp/sparkling-compact-retry-direct');out=Path('/var/tmp/sparkling-compact-retry-static');out.mkdir();shutil.copytree(base/'current',out/'current');(out/'baseline').symlink_to(base/'baseline');(out/'movement_c').symlink_to(base/'movement_c')
root=out/'current/source/experimental/smooth/src'
for p in root.glob('mj-data*.ad?'):
 s=p.read_text()
 s=s.replace('      D.Cache.Mass_Compact := False;\n','').replace('                  D.Cache.Mass_Compact := Compact;\n','')
 s=s.replace('D.Cache.Mass_Compact','Uses_Compact_Mass (D)')
 if p.name=='mj-data.ads':
  s=s.replace('      --  The mass buffer retains dense capacity for Strict/fallback. Only\n      --  the ancestor-row prefix contains live values when this flag is set.\n      Mass_Compact : Boolean := False;\n','')
  s=s.replace('   function Mass_Bounded (D : Simulation)', '   function Uses_Compact_Mass (D : Simulation) return Boolean is\n     (D.Solver_Policy = Compatible and then D.Nv >= 3);\n\n   function Mass_Bounded (D : Simulation)')
  s=s.replace('and then not Cache.Force_Valid and then not Cache.Mass_Compact;', 'and then not Cache.Force_Valid;')
 if p.name=='mj-data.adb':s=s.replace('      Cache.Mass_Compact := False;\n','')
 if p.name=='mj-data-inertia_phase.adb':
  needle='      D.Cache.Mass_Valid := True;\n      Result := Success;\n      pragma Assert (Stable_Ready (D));\n   end Assemble;'
  replacement='''      if Uses_Compact_Mass (D) then
         declare
            Packed : Real_Array (0 .. MJ.Ancestor_Rows.Count (D.Ancestors) - 1) := [others => 0.0];
         begin
            MJ.Ancestor_Rows.Copy_Matrix (D.Ancestors, D.Dynamics.Mass.all, Packed);
            D.Dynamics.Mass (Packed'Range) := Packed;
         end;
      end if;
'''+needle
  assert needle in s;s=s.replace(needle,replacement)
 p.write_text(s)
project=out/'current/movement_bench.gpr';project.write_text(project.read_text().replace(str(base/'current'),str(out/'current')))
tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH']
with (out/'current/trial-build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(project),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((base/'build.json').read_text());d['builds']['current'].update(binary=str(out/'current/bin/movement_bench'),binary_sha256=sha(out/'current/bin/movement_bench'),sources={str(p.relative_to(out/'current/source')):sha(p) for p in (out/'current/source').rglob('*.ad?')});d['sources']=d['builds']['current']['sources'];d['trial']='compact retry fixed representation per policy and size';(out/'build.json').write_text(json.dumps(d,indent=2)+'\n');print('static built',flush=True)
with Path(str(out)+'-pilot.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python',str(repo/'tests/movement_performance/c_parity_six/compare.py'),'--build',str(out),'--out',str(out)+'-pilot','--toolchain-root',str(tc),'--cpu','12','--blocks','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('static pilot done',flush=True)
