from pathlib import Path
import importlib.util,os,subprocess
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');spec=importlib.util.spec_from_file_location('pf',repo/'experimental/smooth/tools/prove_fragments.py');pf=importlib.util.module_from_spec(spec);spec.loader.exec_module(pf)
src=Path('/var/tmp/sparkling-compact-retry-canonical/current/source');out=Path('/var/tmp/sparkling-compact-retry-canonical-checked');out.mkdir()
p=pf.isolated_project(src,out,'smooth_probe');s=p.read_text().replace('project Fragment is','project Fragment is\n   for Main use ("smooth_probe.adb");\n   for Exec_Dir use "bin";');p.write_text(s)
tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH']
with (out/'build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(p),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('checked build complete')
