from pathlib import Path
import importlib.util,os,subprocess,json,hashlib
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');spec=importlib.util.spec_from_file_location('pf',repo/'experimental/smooth/tools/prove_fragments.py');pf=importlib.util.module_from_spec(spec);spec.loader.exec_module(pf)
src=Path('/var/tmp/sparkling-compact-canonical-source');root=Path('/var/tmp/sparkling-compact-retry-helper-tests');root.mkdir();tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH'];results=[]
for mode in ['checked','release']:
 out=root/mode;out.mkdir();p=pf.isolated_project(src,out,'compact_inertia_test');s=p.read_text().replace('project Fragment is','project Fragment is\n   for Main use ("compact_inertia_test.adb");\n   for Exec_Dir use "bin";')
 if mode=='release':s=s.replace('"-O0", "-g", "-gnata", "-gnato", "-gnatVa"','"-O3", "-gnatp", "-gnatn", "-march=native"')
 p.write_text(s)
 with (out/'build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(p),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 result=subprocess.check_output([str(out/'bin/compact_inertia_test')],text=True);(out/'test.log').write_text(result);results.append(dict(mode=mode,result=result));print(mode,result,flush=True)
(root/'results.json').write_text(json.dumps(dict(status='passed',results=results,source_sha256={str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*.ad?')}),indent=2)+'\n')
