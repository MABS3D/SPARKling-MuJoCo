from pathlib import Path
import subprocess
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
for n in [1,2]:
 out=f'/var/tmp/sparkling-compact-retry-canonical-confirm{n}'
 with Path(out+'.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python',str(repo/'tests/movement_performance/c_parity_six/compare.py'),'--build','/var/tmp/sparkling-compact-retry-canonical','--out',out,'--toolchain-root','/var/tmp/sparkling-matrix-recovery/toolchains','--cpu','12','--blocks','24'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(n,'done',flush=True)
