from pathlib import Path
import json,subprocess,time
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');gates=[Path('/var/tmp/sparkling-compact-retry-final-numerics-'+p+'/results.json') for p in ['compatible','strict']]+[Path('/var/tmp/sparkling-compact-retry-final-guards/results.json')]
for attempt in range(800):
 if all(p.exists() and json.loads(p.read_text()).get('status')=='passed' for p in gates):break
 time.sleep(1)
else:raise RuntimeError('final validation gates did not pass')
for n in [1,2]:
 out=f'/var/tmp/sparkling-compact-retry-final-session{n}'
 with Path(out+'.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python',str(repo/'tests/movement_performance/c_parity_six/compare.py'),'--build','/var/tmp/sparkling-compact-retry-final-build','--out',out,'--toolchain-root','/var/tmp/sparkling-matrix-recovery/toolchains','--cpu','12','--blocks','24'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(n,'final session complete',flush=True)
subprocess.run(['python3',str(repo/'tests/movement_performance/c_parity_six/summarize.py'),'--session','/var/tmp/sparkling-compact-retry-final-session1','--session','/var/tmp/sparkling-compact-retry-final-session2','--out','/var/tmp/sparkling-compact-retry-final-summary.json'],check=True)
