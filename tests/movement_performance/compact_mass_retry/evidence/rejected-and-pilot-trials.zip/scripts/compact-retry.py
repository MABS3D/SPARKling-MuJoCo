from pathlib import Path
import json,shutil,hashlib,os,subprocess,re
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');base=Path('/var/tmp/sparkling-scan-build');proto=Path('/var/tmp/sparkling-compact-build5/current/source');tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains')
env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for mode in ['columns','parents','direct']:
 out=Path('/var/tmp/sparkling-compact-retry-'+mode);out.mkdir(exist_ok=True);shutil.copytree(base/'current',out/'current',dirs_exist_ok=True);
 if not (out/'baseline').exists():(out/'baseline').symlink_to(base/'current')
 if not (out/'movement_c').exists():(out/'movement_c').symlink_to(base/'movement_c')
 src=out/'current/source/experimental/smooth/src'
 for unit in ['mj-data.ads','mj-data.adb','mj-data-inertia_phase.adb']:
  shutil.copy2(proto/'experimental/smooth/src'/unit,src/unit)
 p=src/'mj-data-inertia_phase.adb';s=p.read_text();a=s.index('   procedure Try_Assemble_CRB');z=s.index('   end Try_Assemble_CRB;',a)+len('   end Try_Assemble_CRB;')
 original=(repo/'experimental/smooth/src/mj-data-inertia_phase.adb').read_text();x=original.index('   procedure Try_Assemble_CRB');y=original.index('   end Try_Assemble_CRB;',x)+len('   end Try_Assemble_CRB;');dense=original[x:y]
 compact=dense.replace('Try_Assemble_CRB','Try_Assemble_Compact').replace('with Global => null,','with Inline_Always, Global => null,',1).replace("Mass'Last = D.Nv * D.Nv - 1","Mass'Last = MJ.Ancestor_Rows.Count (D.Ancestors) - 1")
 compact=compact.replace('\n       and then MJ.Smooth_Dynamics.Symmetric (Mass, D.Nv)','')
 compact=compact.replace('      package T renames MJ.Smooth_Topology;','      package T renames MJ.Smooth_Topology;\n      package AR renames MJ.Ancestor_Rows;')
 compact=compact.replace('MJ.Smooth_Dynamics.Work_Array (Mass)\n           and then MJ.Smooth_Dynamics.Symmetric (Mass, D.Nv)','MJ.Smooth_Dynamics.Work_Array (Mass)').replace('MJ.Smooth_Dynamics.Work_Array (Mass)\n                    and then MJ.Smooth_Dynamics.Symmetric (Mass, D.Nv)','MJ.Smooth_Dynamics.Work_Array (Mass)')
 compact=compact.replace('            MJ.Smooth_Dynamics.Store_Symmetric\n              (Mass, D.Nv, I, I, T.Fixed_Inertia (D.Topology, I));','            Mass (AR.Start (D.Ancestors, I) + AR.Length (D.Ancestors, I) - 1) := T.Fixed_Inertia (D.Topology, I);')
 compact=compact.replace('               J : Integer := I;','               J : Integer := I;\n               Address : Integer := AR.Start (D.Ancestors, I) + AR.Length (D.Ancestors, I) - 1;')
 compact=compact.replace('                  MJ.Smooth_Dynamics.Store_Symmetric (Mass, D.Nv, I, J, Value);','                  Mass (Address) := Value;\n                  Address := Address - 1;')
 if mode=='columns':
  compact=compact.replace('               while J >= 0 loop','               for A in reverse 0 .. AR.Length (D.Ancestors, I) - 1 loop\n                  J := AR.Column (D.Ancestors, I, A);').replace('                  pragma Loop_Variant (Decreases => J);','').replace('                  J := T.Parent_Dof (D.Topology, J);','')
 call='''               if Compact then
                  Try_Assemble_Compact (D, Candidate, Used_CRB);
               else
                  Try_Assemble_CRB (D, Candidate, Used_CRB);
               end if;'''
 if mode=='direct':
  # Diagnostic candidate: direct owner access avoids an aliased D/Mass parameter pair.
  compact=compact.replace('(D : Simulation; Mass : out Real_Array; Ok : out Boolean)','(D : in out Simulation; Ok : out Boolean)')
  begin=compact.index('   is\n');compact=compact[:compact.index('     with Inline_Always')]+compact[begin:]
  compact=compact.replace('Mass := [others => 0.0];','D.Dynamics.Mass (0 .. AR.Count (D.Ancestors) - 1) := [others => 0.0];')
  compact=re.sub(r'(?<![.\w])Mass \(', 'D.Dynamics.Mass (',compact)
  compact=compact.replace('Work_Array (Mass)','Work_Array (D.Dynamics.Mass (0 .. AR.Count (D.Ancestors) - 1))')
  call=call.replace('Try_Assemble_Compact (D, Candidate, Used_CRB);','Try_Assemble_Compact (D, Used_CRB);')
 s=s[:a]+dense+'\n\n'+compact+s[z:]
 s=s.replace('               Try_Assemble_CRB (D, Compact, Candidate, Used_CRB);',call)
 if mode=='direct':s=s.replace('                  D.Dynamics.Mass (0 .. Last) := Candidate;','                  if not Compact then D.Dynamics.Mass (0 .. Last) := Candidate; end if;')
 p.write_text(s)
 project=out/'current/movement_bench.gpr';project.write_text(project.read_text().replace(str(base/'current'),str(out/'current')).replace('for Source_Files use (', 'for Source_Files use (\"mj-compact_inertia.ads\", \"mj-compact_inertia.adb\", '))
 with (out/'current/trial-build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(project),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 d=json.loads((base/'build.json').read_text());d['builds']['baseline']=d['builds']['current'];d['builds']['current']=dict(binary=str(out/'current/bin/movement_bench'),binary_sha256=sha(out/'current/bin/movement_bench'),sources={str(p.relative_to(out/'current/source')):sha(p) for p in (out/'current/source').rglob('*.ad?')});d['sources']=d['builds']['current']['sources'];d['trial']='compact retry '+mode;d['baseline_note']='accepted scan-only candidate, not original bf265';(out/'build.json').write_text(json.dumps(d,indent=2)+'\n');print(mode,'built',flush=True)
for mode in ['columns','parents','direct']:
 out=Path('/var/tmp/sparkling-compact-retry-'+mode)
 with Path(str(out)+'-pilot.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python',str(repo/'tests/movement_performance/c_parity_six/compare.py'),'--build',str(out),'--out',str(out)+'-pilot','--toolchain-root',str(tc),'--cpu','12','--blocks','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(mode,'pilot done',flush=True)
