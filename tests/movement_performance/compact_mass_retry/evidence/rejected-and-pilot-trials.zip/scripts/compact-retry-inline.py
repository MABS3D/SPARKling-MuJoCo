from pathlib import Path
import json,shutil,hashlib,os,subprocess
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');base=Path('/var/tmp/sparkling-compact-retry-static');tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains')
env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for mode in ['inline','overwrite']:
 out=Path('/var/tmp/sparkling-compact-retry-'+mode);out.mkdir();shutil.copytree(base/'current',out/'current');(out/'baseline').symlink_to(base/'baseline');(out/'movement_c').symlink_to(base/'movement_c')
 p=out/'current/source/experimental/smooth/src/mj-data-inertia_phase.adb';s=p.read_text().replace('   end Try_Assemble_CRB;','   end Try_Assemble_CRB;\n   pragma Inline_Always (Try_Assemble_CRB);').replace('   end Try_Assemble_Compact;','   end Try_Assemble_Compact;\n   pragma Inline_Always (Try_Assemble_Compact);')
 if mode=='overwrite':
  old='      D.Dynamics.Mass (0 .. AR.Count (D.Ancestors) - 1) := [others => 0.0];';assert old in s;s=s.replace(old,'      -- Each live ancestor entry is assigned before publication.');
 p.write_text(s);project=out/'current/movement_bench.gpr';project.write_text(project.read_text().replace(str(base/'current'),str(out/'current')))
 with (out/'current/trial-build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(project),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 d=json.loads((base/'build.json').read_text());d['builds']['current'].update(binary=str(out/'current/bin/movement_bench'),binary_sha256=sha(out/'current/bin/movement_bench'),sources={str(p.relative_to(out/'current/source')):sha(p) for p in (out/'current/source').rglob('*.ad?')});d['sources']=d['builds']['current']['sources'];d['trial']='compact retry static '+mode;(out/'build.json').write_text(json.dumps(d,indent=2)+'\n');print(mode,'built',flush=True)
for mode in ['inline','overwrite']:
 out=Path('/var/tmp/sparkling-compact-retry-'+mode)
 with Path(str(out)+'-pilot.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python',str(repo/'tests/movement_performance/c_parity_six/compare.py'),'--build',str(out),'--out',str(out)+'-pilot','--toolchain-root',str(tc),'--cpu','12','--blocks','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(mode,'pilot done',flush=True)
