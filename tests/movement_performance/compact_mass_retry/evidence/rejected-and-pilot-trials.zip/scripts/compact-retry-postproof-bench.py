from pathlib import Path
import json,subprocess,time
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
for attempt in range(1000):
 active=subprocess.check_output(['ps','-eo','args='],text=True).splitlines()
 if not any(a.startswith('python3 experimental/smooth/tools/prove_fragments.py ') and '/var/tmp/sparkling-compact-retry-' in a for a in active):break
 time.sleep(1)
else:raise RuntimeError('proof jobs did not finish')
with Path('/var/tmp/sparkling-compact-retry-modular-pilot.log').open('w') as log:
 subprocess.run(['/var/tmp/sparkling-movement-env/bin/python',str(repo/'tests/movement_performance/c_parity_six/compare.py'),'--build','/var/tmp/sparkling-compact-retry-modular-build','--out','/var/tmp/sparkling-compact-retry-modular-pilot','--toolchain-root','/var/tmp/sparkling-matrix-recovery/toolchains','--cpu','12','--blocks','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('modular pilot complete',flush=True)
