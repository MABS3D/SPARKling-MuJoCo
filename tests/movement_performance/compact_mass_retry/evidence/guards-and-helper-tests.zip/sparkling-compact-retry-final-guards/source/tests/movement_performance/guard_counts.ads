package Guard_Counts is
   Enabled : Boolean := False;
   Full_Checks, Mutable_Checks : Natural := 0;
end Guard_Counts;
