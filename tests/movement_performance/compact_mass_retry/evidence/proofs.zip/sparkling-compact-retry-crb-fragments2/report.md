# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-gpfu__su/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Composite` | `mj-data-inertia_phase.adb:17` | [unproved_checks](logs/mj-data-inertia_phase__load_composite__adb_17.log) | 22 | 5 | 0 | 25.5 |
| `Accumulate_Composite` | `mj-data-inertia_phase.adb:37` | [unproved_checks](logs/mj-data-inertia_phase__accumulate_composite__adb_37.log) | 13 | 2 | 0 | 25.5 |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:67` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_compact__adb_67.log) | 30 | 4 | 0 | 46.9 |

## Diagnostics

### mj-data-inertia_phase__load_composite__adb_17

- `mj-data-inertia_phase.adb:17` (medium): "Composite" might not be initialized in "Load_Composite" [reason for check: OUT parameter should be fully initialized on return] [possible fix: initialize "Composite" on all paths, make "Composite" an IN OUT parameter or annotate it with aspect Relaxed_Initialization]
- `mj-data-inertia_phase.adb:22` (medium): "Composite" might not be initialized
- `mj-data-inertia_phase.adb:30` (medium): "Composite" might not be initialized
- `mj-data-inertia_phase.adb:32` (medium): "Composite" might not be initialized
- `mj-data-inertia_phase.adb:17` (medium): "Composite" might not be initialized in "Load_Composite"

### mj-data-inertia_phase__accumulate_composite__adb_37

- `mj-data-inertia_phase.adb:44` (medium): postcondition might fail, cannot prove I (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:44` (medium): in inlined expression function body at mj-spatial_kernels.ads:25

### mj-data-inertia_phase__try_assemble_compact__adb_67

- `mj-data-inertia_phase.adb:81` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:81` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:98` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:98` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94

