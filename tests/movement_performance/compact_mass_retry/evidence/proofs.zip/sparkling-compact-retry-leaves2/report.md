# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-lq2wxkw8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Get_Mass_Matrix` | `mj-data.adb:1211` | [completed_no_unproved](logs/mj-data__get_mass_matrix__adb_1211.log) | 17 | 0 | 0 | 51.2 |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:16` | [analysis_error](logs/mj-data-inertia_phase__try_assemble_compact__adb_16.log) | 0 | 0 | 5 | 3.8 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_compact__adb_16

- `mj-data-inertia_phase.adb:30` (error): pragma Annotate Hide_Info must appear at the beginning of a subprogram, entry, or package body, or just after a subprogram, entry, or package body or declaration
- `mj-data-inertia_phase.adb:31` (error): pragma Annotate Hide_Info must appear at the beginning of a subprogram, entry, or package body, or just after a subprogram, entry, or package body or declaration
- `mj-data-inertia_phase.adb:32` (error): pragma Annotate Hide_Info must appear at the beginning of a subprogram, entry, or package body, or just after a subprogram, entry, or package body or declaration
- `mj-data-inertia_phase.adb:33` (error): pragma Annotate Hide_Info must appear at the beginning of a subprogram, entry, or package body, or just after a subprogram, entry, or package body or declaration
- `mj-data-inertia_phase.adb:34` (error): pragma Annotate Hide_Info must appear at the beginning of a subprogram, entry, or package body, or just after a subprogram, entry, or package body or declaration

