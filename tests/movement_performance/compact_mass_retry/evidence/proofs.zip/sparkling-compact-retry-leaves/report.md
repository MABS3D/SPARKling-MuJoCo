# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-_zfkdkr4/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Allocate_Dynamics` | `mj-data.adb:424` | [completed_no_unproved](logs/mj-data__allocate_dynamics__adb_424.log) | 22 | 0 | 0 | 21.2 |
| `Get_Mass_Matrix` | `mj-data.adb:1211` | [unproved_checks](logs/mj-data__get_mass_matrix__adb_1211.log) | 17 | 3 | 0 | 43.0 |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:16` | [analysis_error](logs/mj-data-inertia_phase__try_assemble_compact__adb_16.log) | 0 | 0 | 18 | 3.1 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:423` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-data__get_mass_matrix__adb_1211

- `mj-data.adb:1227` (medium): assertion might fail, cannot prove Dense (Dense'First + (I * D.Nv + J)) = Mass_Entry (D, I, J) [provers reached time limit before completing the proof]
- `mj-data.ads:224` (medium): overflow check might fail, cannot prove upper bound for Dense'First + (I * Velocity_Count (D) + J) [reason for check: result of addition must fit in a 32-bits machine integer] [possible fix: use pragma Overflow_Mode or switch -gnato13 or unit SPARK.Big_Integers] [provers reached time limit before completing the proof]
- `mj-data.ads:224` (medium): array index check might fail [reason for check: result of addition must be a valid index into the array] [provers reached time limit before completing the proof]

### mj-data-inertia_phase__try_assemble_compact__adb_16

- `mj-data-inertia_phase.adb:23` (error): incompatible ghost policies in effect
- `mj-data-inertia_phase.adb:23` (error): "Configuration" declared at mj-data.ads:48 with ghost policy "Ignore"
- `mj-data-inertia_phase.adb:23` (error): "Configuration" used at line 23 with ghost policy "Check"
- `mj-data-inertia_phase.adb:23` (error): incompatible ghost policies in effect
- `mj-data-inertia_phase.adb:23` (error): "Configuration" declared at mj-data.ads:48 with ghost policy "Ignore"
- `mj-data-inertia_phase.adb:23` (error): "Configuration" used at line 23 with ghost policy "Check"
- `mj-data-inertia_phase.adb:24` (error): incompatible ghost policies in effect
- `mj-data-inertia_phase.adb:24` (error): "Position_Values" declared at mj-data.ads:83 with ghost policy "Ignore"
- 10 more diagnostics in the individual log.

