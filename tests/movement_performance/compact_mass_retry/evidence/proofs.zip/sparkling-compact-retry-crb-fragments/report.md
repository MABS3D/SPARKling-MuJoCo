# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-821khmcx/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Composite` | `mj-data-inertia_phase.adb:17` | [analysis_error](logs/mj-data-inertia_phase__load_composite__adb_17.log) | 0 | 0 | 1 | 17.0 |
| `Accumulate_Composite` | `mj-data-inertia_phase.adb:37` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:67` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-data-inertia_phase__load_composite__adb_17

- `mj-data-inertia_phase.adb:52` (error): non-scalar object or object with address clause declared before loop-invariant is not yet supported

