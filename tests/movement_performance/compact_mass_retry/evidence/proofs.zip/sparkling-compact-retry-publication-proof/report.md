# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-hejprkdj/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Assemble` | `mj-data-inertia_phase.adb:121` | [proof_timeout](logs/mj-data-inertia_phase__assemble__adb_121.log) | 0 | 0 | 0 | 300.1 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:470` | [unproved_checks](logs/mj-data-inertia_phase__load_ancestor_factor__adb_470.log) | 39 | 12 | 0 | 97.6 |

## Diagnostics

### mj-data-inertia_phase__load_ancestor_factor__adb_470

- `mj-data-inertia_phase.adb:476` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:497` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:497` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:499` (medium): float overflow check might fail [reason for check: result of floating-point addition must be bounded] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:499` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:503` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:503` (medium): in inlined expression function body at mj-data.ads:634
- `mj-data-inertia_phase.adb:506` (medium): loop invariant might fail in first iteration [provers reached time limit before completing the proof]
- 4 more diagnostics in the individual log.

