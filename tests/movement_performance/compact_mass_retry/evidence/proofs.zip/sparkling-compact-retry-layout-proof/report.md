# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-lm9ga_vr/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Storage_Ready` | `mj-data.ads:600` | [completed_no_unproved](logs/mj-data__storage_ready__ads_600.log) | 18 | 0 | 0 | 25.8 |
| `Mass_Entry` | `mj-data.ads:712` | [completed_no_unproved](logs/mj-data__mass_entry__ads_712.log) | 2 | 0 | 0 | 9.3 |
| `Symmetric_Mass` | `mj-data.ads:742` | [unproved_checks](logs/mj-data__symmetric_mass__ads_742.log) | 2 | 2 | 0 | 14.9 |
| `Prove_Readiness_Compatibility` | `mj-data.adb:25` | [completed_no_unproved](logs/mj-data__prove_readiness_compatibility__adb_25.log) | 2 | 0 | 0 | 20.0 |
| `Initialize` | `mj-data.adb:822` | [proof_timeout](logs/mj-data__initialize__adb_822.log) | 0 | 0 | 0 | 120.1 |
| `Create` | `mj-data.adb:870` | [unproved_checks](logs/mj-data__create__adb_870.log) | 2 | 1 | 0 | 33.2 |
| `Reset` | `mj-data.adb:1092` | [unproved_checks](logs/mj-data__reset__adb_1092.log) | 37 | 13 | 0 | 73.7 |

## Diagnostics

### mj-data__symmetric_mass__ads_742

- `mj-data.ads:744` (medium): precondition might fail, cannot prove Mass_Current (D) [possible fix: subprogram at line 70 should mention D in a precondition] [provers reached time limit before completing the proof]
- `mj-data.ads:744` (medium): precondition might fail, cannot prove Mass_Current (D) [possible fix: subprogram at line 70 should mention D in a precondition] [provers reached time limit before completing the proof]

### mj-data__create__adb_870

- `mj-data.ads:104` (medium): postcondition might fail [provers reached time limit before completing the proof]

### mj-data__reset__adb_1092

- `mj-data.adb:1108` (medium): assertion might fail, cannot prove Stable_Ready (D) [provers reached time limit before completing the proof]
- `mj-data.adb:1108` (medium): in inlined expression function body at mj-data.ads:638
- `mj-data.adb:1109` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1111` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1111` (medium): range check might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1112` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1112` (medium): range check might fail [provers reached time limit before completing the proof]
- `mj-data.adb:1113` (medium): assertion might fail [provers reached time limit before completing the proof]
- 5 more diagnostics in the individual log.

