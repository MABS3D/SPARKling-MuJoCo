# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-l1nm3l1v/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:16` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_compact__adb_16.log) | 61 | 10 | 0 | 393.8 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_compact__adb_16

- `mj-data-inertia_phase.adb:30` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:30` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:49` (medium): initialization check might fail [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:55` (medium): initialization check might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:55` (medium): initialization check might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:62` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:62` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:68` (medium): initialization check might fail [provers reached time and memory limit before completing the proof]
- 3 more diagnostics in the individual log.

