# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-i7bqgksi/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:68` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_compact__adb_68.log) | 26 | 4 | 0 | 64.0 |
| `Assemble` | `mj-data-inertia_phase.adb:120` | [proof_timeout](logs/mj-data-inertia_phase__assemble__adb_120.log) | 0 | 0 | 0 | 300.3 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:460` | [unproved_checks](logs/mj-data-inertia_phase__load_ancestor_factor__adb_460.log) | 39 | 13 | 0 | 107.2 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_compact__adb_68

- `mj-data-inertia_phase.adb:82` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:82` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:99` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:99` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94

### mj-data-inertia_phase__load_ancestor_factor__adb_460

- `mj-data-inertia_phase.adb:466` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:487` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:487` (medium): precondition might fail [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:489` (medium): float overflow check might fail [reason for check: result of floating-point addition must be bounded] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:489` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:493` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:493` (medium): in inlined expression function body at mj-data.ads:634
- `mj-data-inertia_phase.adb:495` (medium): loop invariant might fail in first iteration [provers reached time limit before completing the proof]
- 5 more diagnostics in the individual log.

