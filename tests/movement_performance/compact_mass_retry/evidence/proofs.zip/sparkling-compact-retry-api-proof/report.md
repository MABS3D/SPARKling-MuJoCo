# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-6mn2z1am/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Expose_Dense_Mass` | `mj-data.adb:1211` | [unproved_checks](logs/mj-data__expose_dense_mass__adb_1211.log) | 45 | 7 | 0 | 158.8 |
| `Get_Mass_Matrix` | `mj-data.adb:1242` | [completed_no_unproved](logs/mj-data__get_mass_matrix__adb_1242.log) | 18 | 0 | 0 | 29.0 |

## Diagnostics

### mj-data__expose_dense_mass__adb_1211

- `mj-data.adb:1219` (medium): overflow check might fail, cannot prove upper bound for Dense'First + (I * D.Nv + J) [reason for check: result of addition must fit in a 32-bits machine integer] [possible fix: use pragma Overflow_Mode or switch -gnato13 or unit SPARK.Big_Integers] [provers reached time limit before completing the proof]
- `mj-data.adb:1220` (medium): precondition might fail, cannot prove Mass_Current (D) [provers reached time and memory limit before completing the proof]
- `mj-data.adb:1230` (medium): precondition might fail, cannot prove Mass_Current (D) [provers reached time and memory limit before completing the proof]
- `mj-data.adb:1234` (medium): precondition might fail, cannot prove Mass_Current (D) [provers reached time and memory limit before completing the proof]
- `mj-data.adb:1237` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Dense'First + (R * N + K) in Dense'Range [provers reached time limit before completing the proof]
- `mj-data.adb:1237` (medium): overflow check might fail, cannot prove upper bound for Dense'First + (R * N + K) [reason for check: result of addition must fit in a 32-bits machine integer] [possible fix: use pragma Overflow_Mode or switch -gnato13 or unit SPARK.Big_Integers] [provers reached time limit before completing the proof]
- `mj-data.adb:1238` (medium): precondition might fail, cannot prove Mass_Current (D) [provers reached time and memory limit before completing the proof]

