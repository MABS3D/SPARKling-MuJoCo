# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-qo2mech2/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load_Composite` | `mj-data-inertia_phase.adb:17` | [completed_no_unproved](logs/mj-data-inertia_phase__load_composite__adb_17.log) | 29 | 0 | 0 | 84.0 |
| `Accumulate_Composite` | `mj-data-inertia_phase.adb:38` | [completed_no_unproved](logs/mj-data-inertia_phase__accumulate_composite__adb_38.log) | 13 | 0 | 0 | 62.4 |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:68` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_compact__adb_68.log) | 31 | 4 | 0 | 54.7 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_compact__adb_68

- `mj-data-inertia_phase.adb:82` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:82` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:99` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:99` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94

