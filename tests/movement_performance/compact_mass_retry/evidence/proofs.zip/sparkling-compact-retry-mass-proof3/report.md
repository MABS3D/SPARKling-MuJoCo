# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-pp6mob6l/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:16` | interrupted | 0 | 0 | 0 | 0.0 |
| `Assemble` | `mj-data-inertia_phase.adb:93` | not_run_interrupted | 0 | 0 | 0 | 0.0 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:424` | not_run_interrupted | 0 | 0 | 0 | 0.0 |

## Diagnostics

