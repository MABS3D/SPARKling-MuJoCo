# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-brg5nnts/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Create` | `mj-data.adb:870` | [unproved_checks](logs/mj-data__create__adb_870.log) | 2 | 1 | 0 | 66.7 |
| `Initialize` | `mj-data.adb:822` | [unproved_checks](logs/mj-data__initialize__adb_822.log) | 16 | 6 | 0 | 232.6 |

## Diagnostics

### mj-data__create__adb_870

- `mj-data.ads:104` (medium): postcondition might fail [provers reached time limit before completing the proof]

### mj-data__initialize__adb_822

- `mj-data.adb:824` (medium): postcondition might fail [provers reached time limit before completing the proof]
- `mj-data.adb:856` (medium): precondition might fail, cannot prove B.Qpos = null [provers reached time limit before completing the proof]
- `mj-data.adb:857` (medium): precondition might fail, cannot prove B.Bodies = null [provers reached time limit before completing the proof]
- `mj-data.adb:858` (medium): precondition might fail, cannot prove B.Mass = null [provers reached time limit before completing the proof]
- `mj-data.adb:859` (medium): precondition might fail, cannot prove B.Length = null [provers reached time limit before completing the proof]
- `mj-data.adb:860` (medium): precondition might fail, cannot prove B.Ancestor_Factor = null [provers reached time limit before completing the proof]

