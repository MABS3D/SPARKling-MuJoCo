# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-p1n_g75r/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Clear` | `mj-compact_inertia.adb:2` | [completed_no_unproved](logs/mj-compact_inertia__clear__adb_2.log) | 2 | 0 | 0 | 3.6 |
| `Store` | `mj-compact_inertia.adb:6` | [completed_no_unproved](logs/mj-compact_inertia__store__adb_6.log) | 5 | 0 | 0 | 3.1 |

## Diagnostics

