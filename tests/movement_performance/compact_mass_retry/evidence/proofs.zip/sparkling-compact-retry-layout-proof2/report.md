# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-1yp2lo0l/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Symmetric_Mass` | `mj-data.ads:742` | [completed_no_unproved](logs/mj-data__symmetric_mass__ads_742.log) | 4 | 0 | 0 | 25.4 |
| `Reset` | `mj-data.adb:1092` | [unproved_checks](logs/mj-data__reset__adb_1092.log) | 37 | 1 | 0 | 172.9 |

## Diagnostics

### mj-data__reset__adb_1092

- `mj-data.ads:123` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached time and memory limit before completing the proof]

