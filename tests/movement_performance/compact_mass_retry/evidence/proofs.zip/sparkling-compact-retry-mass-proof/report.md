# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-eqj8q51h/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:16` | [analysis_error](logs/mj-data-inertia_phase__try_assemble_compact__adb_16.log) | 0 | 0 | 4 | 16.9 |
| `Assemble` | `mj-data-inertia_phase.adb:92` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:423` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_compact__adb_16

- `mj-data-inertia_phase.adb:39` (error): subtype constraint cannot depend on variable input "D" [E0007]
- `mj-data-inertia_phase.adb:39` (error): use instead a constant initialized to the expression with variable input
- `mj-data-inertia_phase.adb:39` (error): launch "gnatprove --explain=E0007" for more information
- `mj-data-inertia_phase.adb:39` (error): subtype constraint cannot depend on variable input "D"

