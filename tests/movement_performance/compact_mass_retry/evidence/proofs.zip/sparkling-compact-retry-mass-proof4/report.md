# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-dge_qxjt/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:16` | [proof_timeout](logs/mj-data-inertia_phase__try_assemble_compact__adb_16.log) | 0 | 0 | 0 | 180.2 |
| `Assemble` | `mj-data-inertia_phase.adb:91` | [proof_timeout](logs/mj-data-inertia_phase__assemble__adb_91.log) | 0 | 0 | 0 | 180.3 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:431` | [unproved_checks](logs/mj-data-inertia_phase__load_ancestor_factor__adb_431.log) | 39 | 5 | 0 | 118.5 |

## Diagnostics

### mj-data-inertia_phase__load_ancestor_factor__adb_431

- `mj-data-inertia_phase.adb:437` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:463` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Storage_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:463` (medium): in inlined expression function body at mj-data.ads:634
- `mj-data-inertia_phase.adb:468` (medium): loop invariant might fail in first iteration [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:468` (medium): loop invariant might not be preserved by an arbitrary iteration [provers reached time limit before completing the proof]

