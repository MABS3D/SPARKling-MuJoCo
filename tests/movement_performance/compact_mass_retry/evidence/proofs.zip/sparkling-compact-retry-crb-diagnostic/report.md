# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-bj2so9j9/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_Compact` | `mj-data-inertia_phase.adb:16` | [unproved_checks](logs/mj-data-inertia_phase__try_assemble_compact__adb_16.log) | 63 | 25 | 0 | 55.1 |

## Diagnostics

### mj-data-inertia_phase__try_assemble_compact__adb_16

- `mj-data-inertia_phase.adb:27` (medium): range check might fail, cannot prove upper bound for Motions'Length [provers gave up before completing the proof]
- `mj-data-inertia_phase.adb:29` (medium): range check might fail, cannot prove upper bound for Mass'Length [provers gave up before completing the proof]
- `mj-data-inertia_phase.adb:30` (medium): postcondition might fail, cannot prove X in Work_Real [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:30` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-data-inertia_phase.adb:45` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Composite (K)'Initialized [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:46` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove I (0) in -Limit .. Limit [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:46` (medium): in inlined expression function body at mj-spatial_kernels.ads:25
- `mj-data-inertia_phase.adb:46` (medium): initialization check might fail [provers reached time limit before completing the proof]
- 18 more diagnostics in the individual log.

