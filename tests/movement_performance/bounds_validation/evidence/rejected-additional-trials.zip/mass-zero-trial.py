from pathlib import Path
import json,shutil,hashlib,os,subprocess
base=Path('/var/tmp/sparkling-abs-build4');source=base/'baseline';out=Path('/var/tmp/sparkling-mass-zero-trial');out.mkdir();shutil.copytree(source,out/'current');(out/'baseline').symlink_to(source);(out/'movement_c').symlink_to(base/'movement_c')
p=out/'current/source/experimental/smooth/src/mj-data-inertia_phase.adb';s=p.read_text();s=s.replace('      D.Dynamics.Mass.all := [others => 0.0];\n','',1);p.write_text(s)
project=out/'current/movement_bench.gpr';project.write_text(project.read_text().replace(str(source),str(out/'current')))
env=os.environ.copy();tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH']
with (out/'current/trial-build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(project),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((base/'build.json').read_text());d['builds']['current'].update(binary=str(out/'current/bin/movement_bench'),binary_sha256=sha(out/'current/bin/movement_bench'),sources={str(p.relative_to(out/'current/source')):sha(p) for p in (out/'current/source').rglob('*.ad?')});d['sources']=d['builds']['current']['sources'];d['trial']='remove redundant first mass zeroing; original bound predicates';(out/'build.json').write_text(json.dumps(d,indent=2)+'\n');print('Zero trial built',flush=True)
with Path(str(out)+'-pilot.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python','/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tests/movement_performance/c_parity_six/compare.py','--build',str(out),'--out',str(out)+'-pilot','--toolchain-root',str(tc),'--cpu','12','--blocks','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Zero trial measured',flush=True)
