from pathlib import Path
import json,shutil,hashlib,os,subprocess
base=Path('/var/tmp/sparkling-abs-build4');source=base/'baseline';tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env=os.environ.copy();env['PATH']=':'.join(str(next((tc/t).glob('*/bin'))) for t in ['gnat','gprbuild','gnatprove'])+':'+env['PATH'];roots=[]
for mode in ['abs','tiny','both']:
 out=Path('/var/tmp/sparkling-scan-'+mode);out.mkdir();roots.append(out);shutil.copytree(source,out/'current');(out/'baseline').symlink_to(source);(out/'movement_c').symlink_to(base/'movement_c')
 p=out/'current/source/experimental/smooth/src/mj-bounds_kernels.adb';s=p.read_text()
 if mode in ['abs','both']:s=s.replace('Values (I) not in -Limit .. Limit','not (abs Values (I) <= Limit)')
 if mode in ['tiny','both']:
  s=s.replace("   begin\n      for I in Values'Range loop",'''   begin
      if Values'Length <= 8 then
         for I in Values'Range loop
            pragma Loop_Optimize (No_Vector);
            if Values (I) not in -Limit .. Limit then return False; end if;
            pragma Loop_Invariant
              (Static => (for all J in Values'First .. I => Values (J) in -Limit .. Limit));
         end loop;
         return True;
      end if;
      for I in Values'Range loop''')
 p.write_text(s)
 project=out/'current/movement_bench.gpr';project.write_text(project.read_text().replace(str(source),str(out/'current')))
 with (out/'current/trial-build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(project),'-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((base/'build.json').read_text());d['builds']['current'].update(binary=str(out/'current/bin/movement_bench'),binary_sha256=sha(out/'current/bin/movement_bench'),sources={str(p.relative_to(out/'current/source')):sha(p) for p in (out/'current/source').rglob('*.ad?')});d['sources']=d['builds']['current']['sources'];d['trial']='array scan only: '+mode;(out/'build.json').write_text(json.dumps(d,indent=2)+'\n');print('Built',mode,flush=True)
for out in roots:
 with Path(str(out)+'-pilot.log').open('w') as log:subprocess.run(['/var/tmp/sparkling-movement-env/bin/python','/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tests/movement_performance/c_parity_six/compare.py','--build',str(out),'--out',str(out)+'-pilot','--toolchain-root',str(tc),'--cpu','12','--blocks','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Measured',out,flush=True)
