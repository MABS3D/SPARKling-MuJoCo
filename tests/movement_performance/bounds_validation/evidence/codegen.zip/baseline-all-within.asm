
/var/tmp/sparkling-scan-build/baseline/bin/movement_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000007d90 <mj__bounds_kernels__all_within>:
    7d90:	movslq (%rsi),%rdx
    7d93:	movslq 0x4(%rsi),%rax
    7d97:	mov    %rdi,%r8
    7d9a:	vbroadcastsd %xmm0,%zmm3
    7da0:	mov    $0x1,%ecx
    7da5:	cmp    %eax,%edx
    7da7:	jg     7eb3 <mj__bounds_kernels__all_within+0x123>
    7dad:	vxorpd 0xed1bb(%rip),%xmm0,%xmm0        # f4f70 <ada__numerics__long_elementary_functions__two_pi+0x340>
    7db5:	sub    %rdx,%rax
    7db8:	vpxor  %xmm1,%xmm1,%xmm1
    7dbc:	lea    0x1(%rax),%rsi
    7dc0:	vbroadcastsd %xmm0,%zmm0
    7dc6:	cmp    $0x6,%rax
    7dca:	jbe    7ec0 <mj__bounds_kernels__all_within+0x130>
    7dd0:	sub    $0x7,%rax
    7dd4:	shr    $0x3,%rax
    7dd8:	lea    0x1(%rax),%rdx
    7ddc:	xor    %eax,%eax
    7dde:	nop
    7ddf:	data16 cs nopw 0x0(%rax,%rax,1)
    7dea:	data16 cs nopw 0x0(%rax,%rax,1)
    7df5:	data16 cs nopw 0x0(%rax,%rax,1)
    7e00:	mov    %rax,%rcx
    7e03:	shl    $0x6,%rcx
    7e07:	vmovupd (%r8,%rcx,1),%zmm2
    7e0e:	inc    %rax
    7e11:	vcmpgtpd %zmm3,%zmm2,%k0
    7e18:	vcmpltpd %zmm0,%zmm2,%k1
    7e1f:	korb   %k1,%k0,%k0
    7e23:	vpmovm2q %k0,%zmm2
    7e29:	vpsubq %zmm2,%zmm1,%zmm1
    7e2f:	cmp    %rdx,%rax
    7e32:	jb     7e00 <mj__bounds_kernels__all_within+0x70>
    7e34:	shl    $0x3,%rdx
    7e38:	cmp    %rdx,%rsi
    7e3b:	je     7e89 <mj__bounds_kernels__all_within+0xf9>
    7e3d:	sub    %rdx,%rsi
    7e40:	mov    $0x8,%eax
    7e45:	xor    %edi,%edi
    7e47:	xor    %ecx,%ecx
    7e49:	cmp    %rsi,%rax
    7e4c:	sbb    %rdi,%rcx
    7e4f:	cmovb  %rax,%rsi
    7e53:	vpbroadcastw %esi,%xmm2
    7e59:	vpcmpnleuw 0xed21c(%rip),%xmm2,%k1        # f5080 <ada__numerics__long_elementary_functions__two_pi+0x450>
    7e64:	vmovupd (%r8,%rdx,8),%zmm2{%k1}{z}
    7e6b:	vcmpltpd %zmm0,%zmm2,%k2
    7e72:	vcmpgtpd %zmm3,%zmm2,%k0
    7e79:	korb   %k2,%k0,%k0
    7e7d:	vpmovm2q %k0,%zmm0
    7e83:	vpsubq %zmm0,%zmm1,%zmm1{%k1}
    7e89:	vextracti64x4 $0x1,%zmm1,%ymm0
    7e90:	vpaddq %ymm1,%ymm0,%ymm1
    7e94:	vextracti64x2 $0x1,%ymm1,%xmm0
    7e9b:	vpaddq %xmm1,%xmm0,%xmm0
    7e9f:	vpshufd $0xee,%xmm0,%xmm1
    7ea4:	vpaddq %xmm1,%xmm0,%xmm0
    7ea8:	vmovq  %xmm0,%rax
    7ead:	test   %rax,%rax
    7eb0:	sete   %cl
    7eb3:	mov    %ecx,%eax
    7eb5:	vzeroupper
    7eb8:	ret
    7eb9:	nopl   0x0(%rax)
    7ec0:	xor    %edx,%edx
    7ec2:	jmp    7e3d <mj__bounds_kernels__all_within+0xad>

Disassembly of section .fini:
