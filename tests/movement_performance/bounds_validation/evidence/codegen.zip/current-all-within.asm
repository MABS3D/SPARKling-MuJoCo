
/var/tmp/sparkling-scan-build/current/bin/movement_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000007d90 <mj__bounds_kernels__all_within>:
    7d90:	movslq (%rsi),%rdx
    7d93:	movslq 0x4(%rsi),%rax
    7d97:	mov    %rdi,%r8
    7d9a:	vbroadcastsd %xmm0,%zmm0
    7da0:	mov    $0x1,%ecx
    7da5:	cmp    %eax,%edx
    7da7:	jg     7ea3 <mj__bounds_kernels__all_within+0x113>
    7dad:	sub    %rdx,%rax
    7db0:	vbroadcastsd 0xed1a6(%rip),%zmm3        # f4f60 <ada__numerics__long_elementary_functions__two_pi+0x330>
    7dba:	vpxor  %xmm1,%xmm1,%xmm1
    7dbe:	lea    0x1(%rax),%rsi
    7dc2:	cmp    $0x6,%rax
    7dc6:	jbe    7eb0 <mj__bounds_kernels__all_within+0x120>
    7dcc:	sub    $0x7,%rax
    7dd0:	shr    $0x3,%rax
    7dd4:	lea    0x1(%rax),%rdx
    7dd8:	xor    %eax,%eax
    7dda:	nopl   0x0(%rax,%rax,1)
    7ddf:	data16 cs nopw 0x0(%rax,%rax,1)
    7dea:	data16 cs nopw 0x0(%rax,%rax,1)
    7df5:	data16 cs nopw 0x0(%rax,%rax,1)
    7e00:	mov    %rax,%rcx
    7e03:	shl    $0x6,%rcx
    7e07:	vandpd (%r8,%rcx,1),%zmm3,%zmm2
    7e0e:	inc    %rax
    7e11:	vcmpgtpd %zmm0,%zmm2,%k0
    7e18:	vpmovm2q %k0,%zmm2
    7e1e:	vpsubq %zmm2,%zmm1,%zmm1
    7e24:	cmp    %rdx,%rax
    7e27:	jb     7e00 <mj__bounds_kernels__all_within+0x70>
    7e29:	shl    $0x3,%rdx
    7e2d:	cmp    %rdx,%rsi
    7e30:	je     7e79 <mj__bounds_kernels__all_within+0xe9>
    7e32:	sub    %rdx,%rsi
    7e35:	mov    $0x8,%eax
    7e3a:	xor    %edi,%edi
    7e3c:	xor    %ecx,%ecx
    7e3e:	cmp    %rsi,%rax
    7e41:	sbb    %rdi,%rcx
    7e44:	cmovb  %rax,%rsi
    7e48:	vpbroadcastw %esi,%xmm2
    7e4e:	vpcmpnleuw 0xed227(%rip),%xmm2,%k1        # f5080 <ada__numerics__long_elementary_functions__two_pi+0x450>
    7e59:	vmovupd (%r8,%rdx,8),%zmm2{%k1}{z}
    7e60:	vandpd %zmm3,%zmm2,%zmm2
    7e66:	vcmpgtpd %zmm0,%zmm2,%k0
    7e6d:	vpmovm2q %k0,%zmm0
    7e73:	vpsubq %zmm0,%zmm1,%zmm1{%k1}
    7e79:	vextracti64x4 $0x1,%zmm1,%ymm0
    7e80:	vpaddq %ymm1,%ymm0,%ymm1
    7e84:	vextracti64x2 $0x1,%ymm1,%xmm0
    7e8b:	vpaddq %xmm1,%xmm0,%xmm0
    7e8f:	vpshufd $0xee,%xmm0,%xmm1
    7e94:	vpaddq %xmm1,%xmm0,%xmm0
    7e98:	vmovq  %xmm0,%rax
    7e9d:	test   %rax,%rax
    7ea0:	sete   %cl
    7ea3:	mov    %ecx,%eax
    7ea5:	vzeroupper
    7ea8:	ret
    7ea9:	nopl   0x0(%rax)
    7eb0:	xor    %edx,%edx
    7eb2:	jmp    7e32 <mj__bounds_kernels__all_within+0xa2>

Disassembly of section .fini:
