# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-nyts5sop/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Bounded` | `mj-smooth_math.adb:5` | [completed_no_unproved](logs/mj-smooth_math__bounded__adb_5.log) | 1 | 0 | 0 | 3.3 |
| `Bounded` | `mj-spatial_kernels.adb:3` | [completed_no_unproved](logs/mj-spatial_kernels__bounded__adb_3.log) | 1 | 0 | 0 | 4.1 |
| `Bounded` | `mj-smooth_math.adb:11` | [completed_no_unproved](logs/mj-smooth_math__bounded__adb_11.log) | 1 | 0 | 0 | 2.9 |
| `Bounded` | `mj-spatial_kernels.adb:13` | [completed_no_unproved](logs/mj-spatial_kernels__bounded__adb_13.log) | 1 | 0 | 0 | 4.3 |
| `Bounded` | `mj-smooth_math.adb:17` | [completed_no_unproved](logs/mj-smooth_math__bounded__adb_17.log) | 1 | 0 | 0 | 3.8 |
| `Multiply` | `mj-smooth_math.adb:124` | [unproved_checks](logs/mj-smooth_math__multiply__adb_124.log) | 116 | 9 | 0 | 71.6 |
| `Multiply` | `mj-spatial_kernels.adb:119` | [unproved_checks](logs/mj-spatial_kernels__multiply__adb_119.log) | 100 | 1 | 0 | 29.1 |

## Diagnostics

### mj-smooth_math__multiply__adb_124

- `mj-smooth_math.adb:138` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:139` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:140` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:140` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:141` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:141` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:142` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:142` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- 1 more diagnostics in the individual log.

### mj-spatial_kernels__multiply__adb_119

- `mj-spatial_kernels.ads:113` (medium): postcondition might fail, cannot prove Bounded (Multiply'Result, 1.0e54) [provers reached time limit before completing the proof]

