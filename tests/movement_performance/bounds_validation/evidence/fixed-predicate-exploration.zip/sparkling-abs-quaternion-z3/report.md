# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-rpl0dhlj/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Multiply` | `mj-smooth_math.adb:124` | [unproved_checks](logs/mj-smooth_math__multiply__adb_124.log) | 116 | 49 | 0 | 145.9 |

## Diagnostics

### mj-smooth_math__multiply__adb_124

- `mj-smooth_math.adb:128` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:128` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:129` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:129` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:130` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:130` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:131` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:131` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- 41 more diagnostics in the individual log.

