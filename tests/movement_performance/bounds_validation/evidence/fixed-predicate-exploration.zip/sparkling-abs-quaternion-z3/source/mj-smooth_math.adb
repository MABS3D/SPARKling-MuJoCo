with Ada.Numerics.Long_Elementary_Functions;

package body MJ.Smooth_Math with SPARK_Mode is
   --  Inline for execution; use the exact interval postcondition in proofs.
   function Bounded (V : Vector; Limit : Real := Work_Limit) return Boolean is
   begin
      return (abs V (0) <= Limit and then abs V (1) <= Limit
      and then abs V (2) <= Limit);
   end Bounded;

   function Bounded (Q : Quaternion; Limit : Real) return Boolean is
   begin
      return (abs Q (0) <= Limit and then abs Q (1) <= Limit
      and then abs Q (2) <= Limit and then abs Q (3) <= Limit);
   end Bounded;

   function Bounded (R : Matrix; Limit : Real) return Boolean is
   begin
      return (abs R (0, 0) <= Limit and then abs R (0, 1) <= Limit
      and then abs R (0, 2) <= Limit and then abs R (1, 0) <= Limit
      and then abs R (1, 1) <= Limit and then abs R (1, 2) <= Limit
      and then abs R (2, 0) <= Limit and then abs R (2, 1) <= Limit
      and then abs R (2, 2) <= Limit);
   end Bounded;

   package Math renames Ada.Numerics.Long_Elementary_Functions;

   function "+" (A, B : Vector) return Vector is
     ([A (0) + B (0), A (1) + B (1), A (2) + B (2)]);
   function "-" (A, B : Vector) return Vector is
     ([A (0) - B (0), A (1) - B (1), A (2) - B (2)]);
   function "-" (A : Vector) return Vector is ([-A (0), -A (1), -A (2)]);
   function "*" (S : Real; V : Vector) return Vector is
     ([S * V (0), S * V (1), S * V (2)]);
   function Dot (A, B : Vector) return Real is
     ((A (0) * B (0) + A (1) * B (1)) + A (2) * B (2));
   function Cross (A, B : Vector) return Vector is
      --  Typed intermediate products give each subtraction a local bound;
      --  they preserve the specified floating-point evaluation order.
      subtype Product is Real range -2.0e300 .. 2.0e300;
      P12 : constant Product := A (1) * B (2);
      P21 : constant Product := A (2) * B (1);
      P20 : constant Product := A (2) * B (0);
      P02 : constant Product := A (0) * B (2);
      P01 : constant Product := A (0) * B (1);
      P10 : constant Product := A (1) * B (0);
      Result : constant Vector := [P12 - P21, P20 - P02, P01 - P10];
   begin
      pragma Assert (Static => Bounded (Result, 8.0e300));
      pragma Assert (Result (0) = A (1)*B (2) - A (2)*B (1));
      pragma Assert (Result (1) = A (2)*B (0) - A (0)*B (2));
      pragma Assert (Result (2) = A (0)*B (1) - A (1)*B (0));
      pragma Assert (Static => (if Bounded (A, 1.0e60) and then Bounded (B, 1.0e12)
        then Result (0) in -1.0e73 .. 1.0e73));
      pragma Assert (Static => (if Bounded (A, 1.0e60) and then Bounded (B, 1.0e12)
        then Result (1) in -1.0e73 .. 1.0e73));
      pragma Assert (Static => (if Bounded (A, 1.0e60) and then Bounded (B, 1.0e12)
        then Result (2) in -1.0e73 .. 1.0e73));
      pragma Assert (Static => (if Bounded (A, 1.0e90) and then Bounded (B, 1.0e24)
        then Result (0) in -1.0e115 .. 1.0e115));
      pragma Assert (Static => (if Bounded (A, 1.0e90) and then Bounded (B, 1.0e24)
        then Result (1) in -1.0e115 .. 1.0e115));
      pragma Assert (Static => (if Bounded (A, 1.0e90) and then Bounded (B, 1.0e24)
        then Result (2) in -1.0e115 .. 1.0e115));
      pragma Assert (Static => (if Bounded (A, 1.0e70) and then Bounded (B, 1.0e115)
        then Result (0) in -1.0e186 .. 1.0e186));
      pragma Assert (Static => (if Bounded (A, 1.0e70) and then Bounded (B, 1.0e115)
        then Result (1) in -1.0e186 .. 1.0e186));
      pragma Assert (Static => (if Bounded (A, 1.0e70) and then Bounded (B, 1.0e115)
        then Result (2) in -1.0e186 .. 1.0e186));
      return Result;
   end Cross;

   function Apply (R : Matrix; V : Vector) return Vector is
      subtype Product is Real range -2.0e281 .. 2.0e281;
      P00 : constant Product := R (0, 0)*V (0);
      P01 : constant Product := R (0, 1)*V (1);
      P02 : constant Product := R (0, 2)*V (2);
      P10 : constant Product := R (1, 0)*V (0);
      P11 : constant Product := R (1, 1)*V (1);
      P12 : constant Product := R (1, 2)*V (2);
      P20 : constant Product := R (2, 0)*V (0);
      P21 : constant Product := R (2, 1)*V (1);
      P22 : constant Product := R (2, 2)*V (2);
      subtype Row_Sum is Real range -1.0e282 .. 1.0e282;
      R0 : constant Row_Sum := P00 + P01 + P02;
      R1 : constant Row_Sum := P10 + P11 + P12;
      R2 : constant Row_Sum := P20 + P21 + P22;
      Result : constant Vector := [R0, R1, R2];
   begin
      pragma Assert (Bounded (Result, 1.0e282));
      pragma Assert (Result (0) = R (0, 0)*V (0) + R (0, 1)*V (1) + R (0, 2)*V (2));
      pragma Assert (Result (1) = R (1, 0)*V (0) + R (1, 1)*V (1) + R (1, 2)*V (2));
      pragma Assert (Result (2) = R (2, 0)*V (0) + R (2, 1)*V (1) + R (2, 2)*V (2));
      return Result;
   end Apply;

   function Apply_Transpose (R : Matrix; V : Vector) return Vector is
      subtype Product is Real range -2.0e281 .. 2.0e281;
      P00 : constant Product := R (0, 0)*V (0);
      P01 : constant Product := R (1, 0)*V (1);
      P02 : constant Product := R (2, 0)*V (2);
      P10 : constant Product := R (0, 1)*V (0);
      P11 : constant Product := R (1, 1)*V (1);
      P12 : constant Product := R (2, 1)*V (2);
      P20 : constant Product := R (0, 2)*V (0);
      P21 : constant Product := R (1, 2)*V (1);
      P22 : constant Product := R (2, 2)*V (2);
      subtype Row_Sum is Real range -1.0e282 .. 1.0e282;
      R0 : constant Row_Sum := P00 + P01 + P02;
      R1 : constant Row_Sum := P10 + P11 + P12;
      R2 : constant Row_Sum := P20 + P21 + P22;
      Result : constant Vector := [R0, R1, R2];
   begin
      pragma Assert (Bounded (Result, 1.0e282));
      pragma Assert (Result (0) = R (0, 0)*V (0) + R (1, 0)*V (1) + R (2, 0)*V (2));
      pragma Assert (Result (1) = R (0, 1)*V (0) + R (1, 1)*V (1) + R (2, 1)*V (2));
      pragma Assert (Result (2) = R (0, 2)*V (0) + R (1, 2)*V (1) + R (2, 2)*V (2));
      return Result;
   end Apply_Transpose;

   --  Scalar-first Hamilton product. R(A*B) = R(A) R(B).
   --  Each product and accumulated component has its own checked bound.
   function Multiply (A, B : Quaternion) return Quaternion is
      pragma Assert (Static => (for all X of A => X in -2.0 .. 2.0));
      pragma Assert (Static => (for all X of B => X in -2.0 .. 2.0));
      subtype Product is Real range -4.0 .. 4.0;
      P00 : constant Product := A (0)*B (0);
      P11 : constant Product := A (1)*B (1);
      P22 : constant Product := A (2)*B (2);
      P33 : constant Product := A (3)*B (3);
      P01 : constant Product := A (0)*B (1);
      P10 : constant Product := A (1)*B (0);
      P23 : constant Product := A (2)*B (3);
      P32 : constant Product := A (3)*B (2);
      P02 : constant Product := A (0)*B (2);
      P13 : constant Product := A (1)*B (3);
      P20 : constant Product := A (2)*B (0);
      P31 : constant Product := A (3)*B (1);
      P03 : constant Product := A (0)*B (3);
      P12 : constant Product := A (1)*B (2);
      P21 : constant Product := A (2)*B (1);
      P30 : constant Product := A (3)*B (0);
      subtype Component is Real range -32.0 .. 32.0;
      C0 : constant Component := P00 - P11 - P22 - P33;
      C1 : constant Component := P01 + P10 + P23 - P32;
      C2 : constant Component := P02 - P13 + P20 + P31;
      C3 : constant Component := P03 + P12 - P21 + P30;
      Result : constant Quaternion := [C0, C1, C2, C3];
   begin
      pragma Assert (Bounded (Result, 32.0));
      pragma Assert (Result (0) = A (0)*B (0) - A (1)*B (1) - A (2)*B (2) - A (3)*B (3));
      pragma Assert (Result (1) = A (0)*B (1) + A (1)*B (0) + A (2)*B (3) - A (3)*B (2));
      pragma Assert (Result (2) = A (0)*B (2) - A (1)*B (3) + A (2)*B (0) + A (3)*B (1));
      pragma Assert (Result (3) = A (0)*B (3) + A (1)*B (2) - A (2)*B (1) + A (3)*B (0));
      return Result;
   end Multiply;

   procedure Expose_Unit_Quaternion (Q : Quaternion) with Ghost => Static,
     Global => null, Pre => Unit_Quaternion (Q), Post => Bounded (Q, 1.000001)
   is
   begin
      null;
   end Expose_Unit_Quaternion;
   function Rotation (Q : Quaternion) return Matrix is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Unit_Quaternion);
   begin
      Expose_Unit_Quaternion (Q);
      pragma Assert (Static => (for all X of Q => X in -1.000001 .. 1.000001));
      declare
      subtype Square is Real range 0.0 .. 2.0;
      subtype Product is Real range -2.0 .. 2.0;
      XX : constant Square := Q (1)*Q (1);
      YY : constant Square := Q (2)*Q (2);
      ZZ : constant Square := Q (3)*Q (3);
      XY : constant Product := Q (1)*Q (2);
      XZ : constant Product := Q (1)*Q (3);
      YZ : constant Product := Q (2)*Q (3);
      WX : constant Product := Q (0)*Q (1);
      WY : constant Product := Q (0)*Q (2);
      WZ : constant Product := Q (0)*Q (3);
      subtype Component is Real range -8.0 .. 8.0;
      R00 : constant Component := 1.0 - 2.0*(YY + ZZ);
      R01 : constant Component := 2.0*(XY - WZ);
      R02 : constant Component := 2.0*(XZ + WY);
      R10 : constant Component := 2.0*(XY + WZ);
      R11 : constant Component := 1.0 - 2.0*(XX + ZZ);
      R12 : constant Component := 2.0*(YZ - WX);
      R20 : constant Component := 2.0*(XZ - WY);
      R21 : constant Component := 2.0*(YZ + WX);
      R22 : constant Component := 1.0 - 2.0*(XX + YY);
      Result : constant Matrix :=
        [0 => [R00, R01, R02], 1 => [R10, R11, R12], 2 => [R20, R21, R22]];
   begin
      pragma Assert (Result (0, 0) = 1.0 - 2.0*(Q (2)*Q (2) + Q (3)*Q (3)));
      pragma Assert (Result (0, 1) = 2.0*(Q (1)*Q (2) - Q (0)*Q (3)));
      pragma Assert (Result (0, 2) = 2.0*(Q (1)*Q (3) + Q (0)*Q (2)));
      pragma Assert (Result (1, 0) = 2.0*(Q (1)*Q (2) + Q (0)*Q (3)));
      pragma Assert (Result (1, 1) = 1.0 - 2.0*(Q (1)*Q (1) + Q (3)*Q (3)));
      pragma Assert (Result (1, 2) = 2.0*(Q (2)*Q (3) - Q (0)*Q (1)));
      pragma Assert (Result (2, 0) = 2.0*(Q (1)*Q (3) - Q (0)*Q (2)));
      pragma Assert (Result (2, 1) = 2.0*(Q (2)*Q (3) + Q (0)*Q (1)));
      pragma Assert (Result (2, 2) = 1.0 - 2.0*(Q (1)*Q (1) + Q (2)*Q (2)));
      return Result;
      end;
   end Rotation;

   function Axis_Angle (V : Vector; Angle : Real) return Quaternion is
      pragma Assert (Static => (for all X of V => X in -1.000001 .. 1.000001));
      subtype Trig_Component is Real range -1.0 .. 1.0;
      subtype Axis_Component is Real range -1.000001 .. 1.000001;
      Half : constant Real := 0.5 * Angle;
      S : constant Trig_Component := Math.Sin (Half);
      C : constant Trig_Component := Math.Cos (Half);
      X : constant Axis_Component := S * V (0);
      Y : constant Axis_Component := S * V (1);
      Z : constant Axis_Component := S * V (2);
   begin
      return [C, X, Y, Z];
   end Axis_Angle;

   function Scaled_Vector (V : Vector) return Vector is
      Scale : constant Real := Scale_Of (V);
   begin
      pragma Assert (abs V (0) <= Scale and then abs V (1) <= Scale and then abs V (2) <= Scale);
      declare
         X : constant Unit_Component := Unit_Ratio (V (0), Scale);
         Y : constant Unit_Component := Unit_Ratio (V (1), Scale);
         Z : constant Unit_Component := Unit_Ratio (V (2), Scale);
      begin
         return [X, Y, Z];
      end;
   end Scaled_Vector;

   function Scaled_Quaternion (Q : Quaternion) return Quaternion is
      Scale : constant Real := Scale_Of (Q);
   begin
      pragma Assert (abs Q (0) <= Scale and then abs Q (1) <= Scale
                     and then abs Q (2) <= Scale and then abs Q (3) <= Scale);
      declare
         W : constant Unit_Component := Unit_Ratio (Q (0), Scale);
         X : constant Unit_Component := Unit_Ratio (Q (1), Scale);
         Y : constant Unit_Component := Unit_Ratio (Q (2), Scale);
         Z : constant Unit_Component := Unit_Ratio (Q (3), Scale);
      begin
         return [W, X, Y, Z];
      end;
   end Scaled_Quaternion;

   function Unit_Ratio (X, Scale : Real) return Unit_Component is (X / Scale);

   function Scaled_Norm (V : Vector) return Real is
      T : constant Vector := Scaled_Vector (V);
   begin
      return Math.Sqrt ((T (0)*T (0) + T (1)*T (1)) + T (2)*T (2));
   end Scaled_Norm;

   function Scaled_Norm (Q : Quaternion) return Real is
      T : constant Quaternion := Scaled_Quaternion (Q);
   begin
      pragma Assert (Static => (for all X of T => X in -1.0 .. 1.0));
      return Math.Sqrt (((T (0)*T (0) + T (1)*T (1)) + T (2)*T (2)) + T (3)*T (3));
   end Scaled_Norm;

   procedure Normalize (V : in out Vector; Success : out Boolean) is
      Norm : Real;
      Temp : Vector := Zero;
   begin
      Success := False;
      if not Bounded (V) or else Scale_Of (V) = 0.0 then
         return;
      end if;
      Temp := Scaled_Vector (V);
      Norm := Scaled_Norm (V);
      if Norm < 1.0 or else Norm > 2.0 then
         return;
      end if;
      Temp := [Temp (0)/Norm, Temp (1)/Norm, Temp (2)/Norm];
      if not Unit_Vector (Temp) then
         return;
      end if;
      V := Temp;
      Success := True;
   end Normalize;

   procedure Normalize (Q : in out Quaternion; Success : out Boolean) is
      Norm : Real;
      Temp : Quaternion := [others => 0.0];
   begin
      Success := False;
      if not Bounded (Q, Work_Limit) or else Scale_Of (Q) < Min_Val then
         return;
      end if;
      Temp := Scaled_Quaternion (Q);
      Norm := Scaled_Norm (Q);
      if Norm < 1.0 or else Norm > 2.0 then
         return;
      end if;
      Temp := [Temp (0)/Norm, Temp (1)/Norm, Temp (2)/Norm, Temp (3)/Norm];
      if not Unit_Quaternion (Temp) then
         return;
      end if;
      Q := Temp;
      Success := True;
   end Normalize;

   function Read_Vector (A : Real_Array; Offset : Natural) return Vector is
     ([A (Offset), A (Offset + 1), A (Offset + 2)]);
   function Read_Quaternion (A : Real_Array; Offset : Natural) return Quaternion is
     ([A (Offset), A (Offset + 1), A (Offset + 2), A (Offset + 3)]);
   procedure Write_Vector (A : in out Real_Array; Offset : Natural; V : Vector) is
   begin
      for K in Axis loop
         A (Offset + K) := V (K);
         pragma Loop_Invariant
           (for all I in A'Range =>
              (if I in Offset .. Offset + K then A (I) = V (I - Offset)
               else A (I) = A'Loop_Entry (I)));
      end loop;
   end Write_Vector;
end MJ.Smooth_Math;
