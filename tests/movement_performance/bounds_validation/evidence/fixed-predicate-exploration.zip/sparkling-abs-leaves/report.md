# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-jbktwsr8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Bounded` | `mj-spatial_kernels.ads:17` | [completed_no_unproved](logs/mj-spatial_kernels__bounded__ads_17.log) | 1 | 0 | 0 | 3.3 |
| `Bounded` | `mj-spatial_kernels.ads:30` | [completed_no_unproved](logs/mj-spatial_kernels__bounded__ads_30.log) | 1 | 0 | 0 | 3.1 |
| `Bounded` | `mj-smooth_math.ads:18` | [completed_no_unproved](logs/mj-smooth_math__bounded__ads_18.log) | 1 | 0 | 0 | 3.1 |
| `Bounded` | `mj-smooth_math.ads:25` | [completed_no_unproved](logs/mj-smooth_math__bounded__ads_25.log) | 1 | 0 | 0 | 2.8 |
| `Bounded` | `mj-smooth_math.ads:31` | [completed_no_unproved](logs/mj-smooth_math__bounded__ads_31.log) | 1 | 0 | 0 | 3.1 |
| `All_Within` | `mj-bounds_kernels.adb:2` | [completed_no_unproved](logs/mj-bounds_kernels__all_within__adb_2.log) | 7 | 0 | 0 | 3.1 |
| `Array_Bounded` | `mj-data.ads:502` | [completed_no_unproved](logs/mj-data__array_bounded__ads_502.log) | 8 | 0 | 0 | 18.9 |
| `Within_Work` | `mj-data.ads:750` | [completed_no_unproved](logs/mj-data__within_work__ads_750.log) | 1 | 0 | 0 | 6.6 |

## Diagnostics

