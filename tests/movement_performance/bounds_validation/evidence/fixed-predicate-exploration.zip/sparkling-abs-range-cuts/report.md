# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-pbaboc9e/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Multiply` | `mj-smooth_math.adb:105` | [unproved_checks](logs/mj-smooth_math__multiply__adb_105.log) | 116 | 10 | 0 | 75.2 |
| `Rotation` | `mj-smooth_math.adb:146` | [unproved_checks](logs/mj-smooth_math__rotation__adb_146.log) | 142 | 1 | 0 | 21.2 |
| `Axis_Angle` | `mj-smooth_math.adb:189` | [completed_no_unproved](logs/mj-smooth_math__axis_angle__adb_189.log) | 16 | 0 | 0 | 7.7 |
| `Scaled_Norm` | `mj-smooth_math.adb:233` | [completed_no_unproved](logs/mj-smooth_math__scaled_norm__adb_233.log) | 21 | 0 | 0 | 5.7 |
| `Scaled_Norm` | `mj-smooth_math.adb:239` | [unproved_checks](logs/mj-smooth_math__scaled_norm__adb_239.log) | 28 | 1 | 0 | 10.9 |

## Diagnostics

### mj-smooth_math__multiply__adb_105

- `mj-smooth_math.adb:118` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:119` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:120` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:121` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:121` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:122` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:122` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:123` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- 2 more diagnostics in the individual log.

### mj-smooth_math__rotation__adb_146

- `mj-smooth_math.ads:119` (medium): postcondition might fail, cannot prove Bounded (Rotation'Result, 8.0) [provers reached time limit before completing the proof]

### mj-smooth_math__scaled_norm__adb_239

- `mj-smooth_math.adb:243` (medium): float overflow check might fail [reason for check: result of floating-point addition must be bounded] [provers reached time limit before completing the proof]

