# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-rv4rap8m/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Bounded` | `mj-smooth_math.adb:5` | [analysis_error](logs/mj-smooth_math__bounded__adb_5.log) | 0 | 0 | 2 | 1.8 |
| `Bounded` | `mj-spatial_kernels.adb:3` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Bounded` | `mj-smooth_math.adb:11` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Bounded` | `mj-spatial_kernels.adb:13` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Bounded` | `mj-smooth_math.adb:17` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Multiply` | `mj-smooth_math.adb:124` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Multiply` | `mj-spatial_kernels.adb:119` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-smooth_math__bounded__adb_5

- `mj-smooth_math.adb:5` (error): not fully conformant with declaration at mj-smooth_math.ads:18
- `mj-smooth_math.adb:5` (error): default expression for "Limit" does not match

