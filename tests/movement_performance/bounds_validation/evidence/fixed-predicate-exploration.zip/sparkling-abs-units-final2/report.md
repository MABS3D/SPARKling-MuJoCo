# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-q40lexc4/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-smooth_math.adb:1` | [unproved_checks](logs/mj-smooth_math__whole_unit.log) | 721 | 14 | 0 | 183.0 |
| `whole unit` | `mj-spatial_kernels.adb:1` | [unproved_checks](logs/mj-spatial_kernels__whole_unit.log) | 415 | 9 | 0 | 127.1 |
| `whole unit` | `mj-bounds_kernels.adb:1` | [completed_no_unproved](logs/mj-bounds_kernels__whole_unit.log) | 7 | 0 | 0 | 3.3 |
| `whole unit` | `mj-compact_inertia.adb:1` | [unproved_checks](logs/mj-compact_inertia__whole_unit.log) | 149 | 5 | 0 | 55.6 |

## Diagnostics

### mj-smooth_math__whole_unit

- `mj-smooth_math.adb:116` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:117` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:118` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:119` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:119` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:120` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:120` (medium): range check might fail [reason for check: default component value must fit in the type] [provers reached time limit before completing the proof]
- `mj-smooth_math.adb:121` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [provers reached time limit before completing the proof]
- 6 more diagnostics in the individual log.

### mj-spatial_kernels__whole_unit

- `mj-spatial_kernels.adb:19` (medium): range check might fail [reason for check: default component value must fit in the type] [possible fix: precondition of subprogram at mj-spatial_kernels.ads:51 should mention Col and Row] [provers reached time limit before completing the proof]
- `mj-spatial_kernels.adb:20` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [possible fix: precondition of subprogram at mj-spatial_kernels.ads:51 should mention Col and Row] [provers reached time limit before completing the proof]
- `mj-spatial_kernels.adb:21` (medium): float overflow check might fail [reason for check: result of floating-point multiplication must be bounded] [possible fix: precondition of subprogram at mj-spatial_kernels.ads:51 should mention Col and Row] [provers reached time limit before completing the proof]
- `mj-spatial_kernels.adb:21` (medium): range check might fail [reason for check: default component value must fit in the type] [possible fix: precondition of subprogram at mj-spatial_kernels.ads:51 should mention Col and Row] [provers reached time limit before completing the proof]
- `mj-spatial_kernels.adb:128` (medium): float overflow check might fail [reason for check: result of floating-point subtraction must be bounded] [provers reached time limit before completing the proof]
- `mj-spatial_kernels.adb:145` (medium): float overflow check might fail [reason for check: result of floating-point addition must be bounded] [provers reached time limit before completing the proof]
- `mj-spatial_kernels.ads:127` (medium): postcondition might fail, cannot prove Bounded (Multiply'Result, 1.0e54) [provers reached time limit before completing the proof]
- `mj-spatial_kernels.ads:139` (medium): postcondition might fail, cannot prove Dot'Result in -1.0e68 .. 1.0e68 [provers reached time limit before completing the proof]
- 1 more diagnostics in the individual log.

### mj-compact_inertia__whole_unit

- `mj-compact_inertia.adb:61` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Dense (Dense'First + Offset (N, K, L)) = Value_At (P, Mass, K, L) [possible fix: precondition of subprogram at mj-compact_inertia.ads:52 should mention Mass] [provers reached time limit before completing the proof]
- `mj-compact_inertia.adb:82` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove X in Work_Real [provers reached time limit before completing the proof]
- `mj-compact_inertia.adb:82` (medium): in inlined expression function body at mj-smooth_dynamics.ads:94
- `mj-compact_inertia.adb:84` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Target (Target'First + B) = Projected (SS.Load_Motion (Motions, 6 * AR.Column (P, Row, B)), Product, Armature, B = AR.Length (P, Row) - 1) [provers reached time limit before completing the proof]
- `mj-compact_inertia.ads:58` (medium): postcondition might fail, cannot prove Dense (Dense'First + Offset (AR.Size (P), I, J)) = Value_At (P, Mass, I, J) [provers reached time limit before completing the proof]

