# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-by6oo98v/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Dot` | `mj-smooth_math.adb:16` | [completed_no_unproved](logs/mj-smooth_math__dot__adb_16.log) | 13 | 0 | 0 | 11.4 |
| `Dot` | `mj-spatial_kernels.adb:110` | [completed_no_unproved](logs/mj-spatial_kernels__dot__adb_110.log) | 31 | 0 | 0 | 25.1 |
| `Frame_Offset` | `mj-spatial_kernels.adb:5` | [completed_no_unproved](logs/mj-spatial_kernels__frame_offset__adb_5.log) | 10 | 0 | 0 | 3.6 |

## Diagnostics

