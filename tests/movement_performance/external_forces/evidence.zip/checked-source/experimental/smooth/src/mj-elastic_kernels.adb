package body MJ.Elastic_Kernels with SPARK_Mode is
   function Squared_Length (A, B : Particle) return Real is
      subtype Difference is Real range -2.0e10 .. 2.0e10;
      subtype Square is Real range 0.0 .. 5.0e20;
      X : constant Difference := B.Position (0) - A.Position (0);
      Y : constant Difference := B.Position (1) - A.Position (1);
      Z : constant Difference := B.Position (2) - A.Position (2);
      XX : constant Square := X * X;
      YY : constant Square := Y * Y;
      ZZ : constant Square := Z * Z;
      XY : constant Real range 0.0 .. 1.1e21 := XX + YY;
   begin
      return XY + ZZ;
   end Squared_Length;
   function Edge_Length (A, B : Particle) return Real is
     (Ada.Numerics.Long_Elementary_Functions.Sqrt (Squared_Length (A, B)));
   function Direction (A, B : Particle; Length : Real) return Vector is
   begin
      if Length < Min_Val then return [1.0, 0.0, 0.0]; end if;
      declare
         Inv : constant Real range 0.0 .. 1.0e15 := 1.0 / Length;
      begin
      return [(B.Position (0) - A.Position (0)) * Inv,
              (B.Position (1) - A.Position (1)) * Inv,
              (B.Position (2) - A.Position (2)) * Inv];
      end;
   end Direction;
   function Project_Velocity (P : Particle; D : Vector) return Real is
      subtype Product is Real range -3.1e35 .. 3.1e35;
      X : constant Product := D (0) * P.Velocity (0);
      Y : constant Product := D (1) * P.Velocity (1);
      Z : constant Product := D (2) * P.Velocity (2);
      XY : constant Real range -6.3e35 .. 6.3e35 := X + Y;
   begin
      if P.Pinned then return 0.0; end if;
      return XY + Z;
   end Project_Velocity;
   function Measure (A, B : Particle) return Geometry is
      L : constant Real := Edge_Length (A, B);
      D : Vector;
   begin
      if L > 1.0e11 then
         return (False, Zero, 0.0, 0.0);
      end if;
      D := Direction (A, B, L);
      return (True, D, L, -Project_Velocity (A, D) + Project_Velocity (B, D));
   end Measure;
   function Force (G : Geometry; Rest, Stiffness, Damping : Nonneg_Tier0)
     return Edge_Force is
      S : constant Real range -2.0e21 .. 2.0e21 := Stiffness * (Rest - G.Length);
      D : constant Real range -4.0e46 .. 4.0e46 := (-Damping) * G.Speed;
   begin
      return (Spring => [G.Direction (0) * S, G.Direction (1) * S, G.Direction (2) * S],
              Damper => [G.Direction (0) * D, G.Direction (1) * D, G.Direction (2) * D]);
   end Force;
   function Advance_Velocity (Velocity : Tier0_Real; Mass : Mass_Value;
     Spring, Damper : Real; Applied, Gravity : Tier0_Real; Dt : Time_Step) return Real is
      Passive : constant Real range -3.0e80 .. 3.0e80 := Spring + Damper;
      Weight : constant Real range -2.0e20 .. 2.0e20 := Mass * Gravity;
      Internal : constant Real range -4.0e80 .. 4.0e80 := Passive + Weight;
      Total : constant Real range -5.0e80 .. 5.0e80 := Internal + Applied;
      Acceleration : constant Real range -6.0e90 .. 6.0e90 := Total / Mass;
      Delta_V : constant Real range -7.0e90 .. 7.0e90 := Dt * Acceleration;
   begin
      return Velocity + Delta_V;
   end Advance_Velocity;
end MJ.Elastic_Kernels;
