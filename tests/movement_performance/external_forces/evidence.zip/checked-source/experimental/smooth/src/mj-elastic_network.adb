package body MJ.Elastic_Network with SPARK_Mode is
   procedure Bound_Add (A, B : Real; N : Count) is
   begin
      null;
   end Bound_Add;
   function Component (P : Particle_Array; E : Edge; V : Vertex;
                       K : Axis; Damper : Boolean) return Real is
      F : Edge_Force;
      X : Real;
   begin
      if P (V).Pinned or else (V /= E.A and then V /= E.B) then return 0.0; end if;
      F := Force (Measure (P (E.A), P (E.B)), E.Rest, E.Stiffness, E.Damping);
      X := (if Damper then F.Damper (K) else F.Spring (K));
      return (if V = E.A then -X else X);
   end Component;
   function Prefix (P : Particle_Array; E : Edge_Array; N : Count;
                    V : Vertex; K : Axis; Damper : Boolean) return Real is
      A, B : Real;
   begin
      if N = 0 then return 0.0; end if;
      A := Prefix (P, E, N - 1, V, K, Damper);
      B := Component (P, E (N), V, K, Damper);
      Bound_Add (A, B, N - 1);
      return A + B;
   end Prefix;
   procedure Forces (P : Particle_Array; E : Edge_Array; F : out Force_Array; Result : out Status) is
      Load : Edge_Force;
      G : Geometry;
   begin
      Result := Numeric_Limit;
      F := [others => (Spring => Zero, Damper => Zero)];
      for I in E'Range loop
         pragma Loop_Invariant (Static => (for all V in P'Range =>
           (for all K in Axis =>
             F (V).Spring (K) = Prefix (P, E, I - 1, V, K, False)
             and then F (V).Damper (K) = Prefix (P, E, I - 1, V, K, True))));
         G := Measure (P (E (I).A), P (E (I).B));
         if not G.Admissible then
            F := [others => (Spring => Zero, Damper => Zero)];
            return;
         end if;
         Load := Force (G, E (I).Rest, E (I).Stiffness, E (I).Damping);
         for V in Vertex range E (I).A .. E (I).A loop
            if not P (V).Pinned then
               for K in Axis loop
                  F (V).Spring (K) := F (V).Spring (K) - Load.Spring (K);
                  F (V).Damper (K) := F (V).Damper (K) - Load.Damper (K);
               end loop;
            end if;
         end loop;
         for V in Vertex range E (I).B .. E (I).B loop
            if not P (V).Pinned then
               for K in Axis loop
                  F (V).Spring (K) := F (V).Spring (K) + Load.Spring (K);
                  F (V).Damper (K) := F (V).Damper (K) + Load.Damper (K);
               end loop;
            end if;
         end loop;
      end loop;
      Result := Success;
   end Forces;
   procedure Step (P : in out Particle_Array; E : Edge_Array;
                   Applied : Input_Array; Gravity : Input_Vector;
                   Dt : Time_Step; Result : out Status) is
      F : Force_Array (P'Range);
      Next : Particle_Array := P;
      Velocity, Position : Real;
   begin
      Result := Numeric_Limit;
      Forces (P, E, F, Result);
      if Result /= Success then return; end if;
      Result := Numeric_Limit;
      for V in P'Range loop
         pragma Loop_Invariant (Static => (for all W in P'Range =>
           Next (W).Mass = P (W).Mass and then Next (W).Pinned = P (W).Pinned));
         pragma Loop_Invariant (Static => (for all W in 1 .. V - 1 =>
           (if P (W).Pinned then Next (W) = P (W) else
            (for all K in Axis =>
              Next (W).Velocity (K) = Advance_Velocity
                (P (W).Velocity (K), P (W).Mass, F (W).Spring (K), F (W).Damper (K),
                 Applied (W) (K), Gravity (K), Dt)
              and then Next (W).Position (K) = P (W).Position (K) + Dt * Next (W).Velocity (K)))));
         if not P (V).Pinned then
            for K in Axis loop
               pragma Loop_Invariant (Static => (for all J in Axis'First .. K - 1 =>
                 Next (V).Velocity (J) = Advance_Velocity
                   (P (V).Velocity (J), P (V).Mass, F (V).Spring (J), F (V).Damper (J),
                    Applied (V) (J), Gravity (J), Dt)
                 and then Next (V).Position (J) = P (V).Position (J) + Dt * Next (V).Velocity (J)));
               Velocity := Advance_Velocity
                 (P (V).Velocity (K), P (V).Mass, F (V).Spring (K), F (V).Damper (K),
                  Applied (V) (K), Gravity (K), Dt);
               if Velocity not in Tier0_Real then return; end if;
               Position := P (V).Position (K) + Dt * Velocity;
               if Position not in Tier0_Real then return; end if;
               Next (V).Velocity (K) := Velocity;
               Next (V).Position (K) := Position;
            end loop;
         end if;
      end loop;
      P := Next;
      Result := Success;
   end Step;
end MJ.Elastic_Network;
