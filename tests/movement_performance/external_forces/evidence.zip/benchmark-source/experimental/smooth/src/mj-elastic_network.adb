package body MJ.Elastic_Network with SPARK_Mode is
   procedure Bound_Add (A, B : Real; N : Count) is
   begin
      pragma Assert (Budget (N) + 1.0e74 <= Budget (N + 1));
      pragma Assert (-Budget (N) - 1.0e74 >= -Budget (N + 1));
   end Bound_Add;
   function Load (P : Particle_Array; E : Edge) return Edge_Force is
     (Force (Measure (P (E.A), P (E.B)), E.Rest, E.Stiffness, E.Damping));
   function Prefix (P : Particle_Array; E : Edge_Array; N : Count;
                    V : Vertex; K : Axis; Damper : Boolean) return Real is
      A, B : Real;
   begin
      if N = 0 then return 0.0; end if;
      A := Prefix (P, E, N - 1, V, K, Damper);
      B := Component (P, E (N), V, K, Damper);
      Bound_Add (A, B, N - 1);
      return A + B;
   end Prefix;
   procedure Accumulate_Edge (P : Particle_Array; Item : Edge; F : in out Force_Array)
     with Global => null,
     Pre => P'First = 1 and then P'Length in 1 .. Max_Count
       and then F'First = P'First and then F'Last = P'Last
       and then Item.A in P'Range and then Item.B in P'Range and then Item.A /= Item.B
       and then (for all V in F'Range => Bounded (F (V).Spring, 1.0e80)
         and then Bounded (F (V).Damper, 1.0e80));
   pragma Postcondition (Static => (for all V in F'Range => (for all K in Axis =>
      F (V).Spring (K) = F'Old (V).Spring (K) + Component (P, Item, V, K, False)
      and then F (V).Damper (K) = F'Old (V).Damper (K) + Component (P, Item, V, K, True))));
   procedure Accumulate_Edge (P : Particle_Array; Item : Edge; F : in out Force_Array) is
      Contribution : constant Edge_Force := Load (P, Item);
   begin
         declare
            V : constant Vertex := Item.A;
         begin
            if not P (V).Pinned then
               for K in Axis loop
                  F (V).Spring (K) := F (V).Spring (K) - Contribution.Spring (K);
                  F (V).Damper (K) := F (V).Damper (K) - Contribution.Damper (K);
               end loop;
            end if;
         end;
         declare
            V : constant Vertex := Item.B;
         begin
            if not P (V).Pinned then
               for K in Axis loop
                  F (V).Spring (K) := F (V).Spring (K) + Contribution.Spring (K);
                  F (V).Damper (K) := F (V).Damper (K) + Contribution.Damper (K);
               end loop;
            end if;
         end;
   end Accumulate_Edge;
   procedure Forces (P : Particle_Array; E : Edge_Array; F : out Force_Array; Result : out Status) is
      G : Geometry;
   begin
      Result := Numeric_Limit;
      F := [others => (Spring => Zero, Damper => Zero)];
      for I in E'Range loop
         pragma Loop_Invariant (Static => (for all V in P'Range =>
           (for all K in Axis =>
             F (V).Spring (K) = Prefix (P, E, I - 1, V, K, False)
             and then F (V).Damper (K) = Prefix (P, E, I - 1, V, K, True))));
         G := Measure (P (E (I).A), P (E (I).B));
         if not G.Admissible then
            F := [others => (Spring => Zero, Damper => Zero)];
            return;
         end if;
         Accumulate_Edge (P, E (I), F);
      end loop;
      Result := Success;
   end Forces;
   procedure Advance_Particle (P : in out Particle; F : Edge_Force;
     Applied, Gravity : Input_Vector; Dt : Time_Step; Result : out Status)
     with Global => null,
     Pre => Bounded (F.Spring, 1.0e80) and then Bounded (F.Damper, 1.0e80),
     Post => (if Result /= Success or else P'Old.Pinned then P = P'Old else
       P.Mass = P'Old.Mass and then P.Pinned = P'Old.Pinned and then
       (for all K in Axis => P.Velocity (K) = Advance_Velocity
         (P'Old.Velocity (K), P'Old.Mass, F.Spring (K), F.Damper (K), Applied (K), Gravity (K), Dt)
         and then P.Position (K) = P'Old.Position (K) + Dt * P.Velocity (K)));
   procedure Advance_Particle (P : in out Particle; F : Edge_Force;
     Applied, Gravity : Input_Vector; Dt : Time_Step; Result : out Status) is
      Candidate : Particle := P;
      Velocity, Position : Real;
   begin
      Result := Success;
      if P.Pinned then return; end if;
      Result := Numeric_Limit;
      for K in Axis loop
         pragma Loop_Invariant (for all J in Axis'First .. K - 1 =>
           Candidate.Velocity (J) = Advance_Velocity
             (P.Velocity (J), P.Mass, F.Spring (J), F.Damper (J), Applied (J), Gravity (J), Dt)
           and then Candidate.Position (J) = P.Position (J) + Dt * Candidate.Velocity (J));
         Velocity := Advance_Velocity
           (P.Velocity (K), P.Mass, F.Spring (K), F.Damper (K), Applied (K), Gravity (K), Dt);
         if Velocity not in Tier0_Real then return; end if;
         Position := P.Position (K) + Dt * Velocity;
         if Position not in Tier0_Real then return; end if;
         Candidate.Velocity (K) := Velocity;
         Candidate.Position (K) := Position;
      end loop;
      P := Candidate;
      Result := Success;
   end Advance_Particle;
   procedure Step (P : in out Particle_Array; E : Edge_Array;
                   Applied : Input_Array; Gravity : Input_Vector;
                   Dt : Time_Step; Result : out Status) is
      F : Force_Array (P'Range);
      Next : Particle_Array := P;
   begin
      Result := Numeric_Limit;
      Forces (P, E, F, Result);
      if Result /= Success then return; end if;
      Result := Numeric_Limit;
      for V in P'Range loop
         pragma Loop_Invariant (Static => (for all W in P'Range =>
           Next (W).Mass = P (W).Mass and then Next (W).Pinned = P (W).Pinned));
         pragma Loop_Invariant (Static => (for all W in 1 .. V - 1 =>
           (if P (W).Pinned then Next (W) = P (W) else
            (for all K in Axis =>
              Next (W).Velocity (K) = Advance_Velocity
                (P (W).Velocity (K), P (W).Mass, F (W).Spring (K), F (W).Damper (K),
                 Applied (W) (K), Gravity (K), Dt)
              and then Next (W).Position (K) = P (W).Position (K) + Dt * Next (W).Velocity (K)))));
         Advance_Particle (Next (V), F (V), Applied (V), Gravity, Dt, Result);
         if Result /= Success then return; end if;
      end loop;
      P := Next;
      Result := Success;
   end Step;
end MJ.Elastic_Network;
