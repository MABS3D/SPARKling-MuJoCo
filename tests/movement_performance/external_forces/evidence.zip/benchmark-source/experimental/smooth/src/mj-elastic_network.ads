with MJ.Types; use MJ.Types;
with MJ.Elastic_Kernels; use MJ.Elastic_Kernels;

--  Standalone contact-free Cartesian flex-edge network. The rigid-body
--  MJ.Data loader still rejects flex; this API does not silently enable it.
package MJ.Elastic_Network with SPARK_Mode is
   Max_Count : constant := 4_096;
   subtype Count is Natural range 0 .. Max_Count;
   subtype Vertex is Positive range 1 .. Max_Count;
   type Particle_Array is array (Positive range <>) of Particle;
   type Edge is record
      A, B : Vertex;
      Rest, Stiffness, Damping : Nonneg_Tier0;
   end record;
   type Edge_Array is array (Positive range <>) of Edge;
   type Force_Array is array (Positive range <>) of Edge_Force;
   type Input_Array is array (Positive range <>) of Input_Vector;
   type Status is (Success, Numeric_Limit);
   function Valid (P : Particle_Array; E : Edge_Array) return Boolean is
     (P'First = 1 and then P'Length in 1 .. Max_Count
      and then E'First = 1 and then E'Length <= Max_Count
      and then (for all X of E => X.A in P'Range and then X.B in P'Range and then X.A /= X.B))
     with Global => null;
   function Budget (N : Count) return Real is
     (Real (3 * N + 2) * (2.0 ** 250)) with Ghost => Static, Global => null;
   procedure Bound_Add (A, B : Real; N : Count)
     with Ghost => Static, Global => null,
     Pre => N < Max_Count and then A in -(Real (3 * N + 2) * (2.0 ** 250)) .. (Real (3 * N + 2) * (2.0 ** 250))
       and then B in -1.0e74 .. 1.0e74,
     Post => A + B in -(Real (3 * N + 5) * (2.0 ** 250)) .. (Real (3 * N + 5) * (2.0 ** 250));
   function Load (P : Particle_Array; E : Edge) return Edge_Force
     with Global => null,
     Pre => E.A in P'Range and then E.B in P'Range,
     Post => Bounded (Load'Result.Spring, 1.0e74)
       and then Bounded (Load'Result.Damper, 1.0e74)
       and then Load'Result = Force (Measure (P (E.A), P (E.B)), E.Rest, E.Stiffness, E.Damping);
   function Component (P : Particle_Array; E : Edge; V : Vertex;
                       K : Axis; Damper : Boolean) return Real is
     (if P (V).Pinned or else (V /= E.A and then V /= E.B) then 0.0
      elsif V = E.A then
        (if Damper then -Load (P, E).Damper (K) else -Load (P, E).Spring (K))
      else (if Damper then Load (P, E).Damper (K) else Load (P, E).Spring (K)))
     with Ghost => Static, Global => null,
     Pre => E.A in P'Range and then E.B in P'Range and then V in P'Range,
     Post => Component'Result in -1.0e74 .. 1.0e74;
   function Prefix (P : Particle_Array; E : Edge_Array; N : Count;
                    V : Vertex; K : Axis; Damper : Boolean) return Real
     with Ghost => Static, Global => null,
     Pre => Valid (P, E) and then N <= E'Length and then V in P'Range,
     Subprogram_Variant => (Decreases => N),
     Post => Prefix'Result in -Budget (N) .. Budget (N) and then
       Prefix'Result = (if N = 0 then 0.0 else
         Prefix (P, E, N - 1, V, K, Damper) + Component (P, E (N), V, K, Damper));
   procedure Forces (P : Particle_Array; E : Edge_Array; F : out Force_Array; Result : out Status)
     with Global => null,
     Pre => Valid (P, E) and then F'First = 1 and then F'Length = P'Length;
   pragma Postcondition (Static => (for all V in P'Range =>
       Bounded (F (V).Spring, 1.0e80) and then Bounded (F (V).Damper, 1.0e80)
       and then (if Result = Success then (for all K in Axis =>
         F (V).Spring (K) = Prefix (P, E, E'Length, V, K, False)
         and then F (V).Damper (K) = Prefix (P, E, E'Length, V, K, True)))));
   procedure Step (P : in out Particle_Array; E : Edge_Array;
                   Applied : Input_Array; Gravity : Input_Vector;
                   Dt : Time_Step; Result : out Status)
     with Global => null,
     Pre => Valid (P, E) and then Applied'First = 1 and then Applied'Length = P'Length;
   pragma Postcondition (Static => Valid (P, E) and then
       (if Result /= Success then P = P'Old else
        (for all V in P'Range => P (V).Mass = P'Old (V).Mass
         and then P (V).Pinned = P'Old (V).Pinned
         and then (if P'Old (V).Pinned then P (V) = P'Old (V) else
           (for all K in Axis =>
             P (V).Velocity (K) = Advance_Velocity
               (P'Old (V).Velocity (K), P'Old (V).Mass,
                Prefix (P'Old, E, E'Length, V, K, False),
                Prefix (P'Old, E, E'Length, V, K, True), Applied (V) (K), Gravity (K), Dt)
             and then P (V).Position (K) = P'Old (V).Position (K) + Dt * P (V).Velocity (K))))));
end MJ.Elastic_Network;
