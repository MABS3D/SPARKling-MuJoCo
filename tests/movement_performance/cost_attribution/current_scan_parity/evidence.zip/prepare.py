from pathlib import Path
p=Path('tests/movement_performance/cost_attribution/build.py').read_text()
p=p.replace("base=a.frozen/'baseline'", "base=a.frozen/'current'")
start=p.index('def modify('); end=p.index('for kind in (a.only',start)
p=p[:start]+'''def modify(src,kind):
    groups = {
      'pose_guards':['mj-data-pipeline.adb'],
      'spatial_guards':['mj-data-spatial.adb'],
      'force_guards':['mj-data-forces_phase.adb','mj-fused_rne.adb'],
      'inertia_guards':['mj-data-inertia_phase.adb'],
      'row_guards':['mj-solver_kernels.adb'],
      'reduction_guards':['mj-solver_reductions.adb']}
    selected=sum(groups.values(),[]) if kind=='all_guards' else groups.get(kind,[])
    changes=[]
    for name in selected:
        path=src/'experimental/smooth/src'/name
        old=path.read_text(); new=old
        if name in ('mj-solver_kernels.adb','mj-solver_reductions.adb'):
            new=re.sub(r"Rejected := (?:Rejected \\+ )?Boolean'Pos \\([^;]+;",'Rejected := 0;',new)
        else:
            pattern=re.compile(r'(?m)^(\\s*)(?:if|elsif)\\s+([^;]+?)\\s+then(?=\\s*(?:\\n|return;|pragma))')
            def sub(m):
                cond=m.group(2)
                if any(x in cond for x in ('Within_Work (','Bounded (','Division_Bounded (','not in Tier0_Real')) and not any(x in cond for x in (' loop',' begin',' end','pragma','=>')):
                    return m.group(0).replace(cond,'False',1)
                return m.group(0)
            new=pattern.sub(sub,new)
            new=re.sub(r'Ok := (?:Motion_Bounded|Bounded) \\([^;]+;', 'Ok := True;',new)
        assert new!=old,(kind,name)
        path.write_text(new)
        changes.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=name,tofile=name))
    return ''.join(changes)
''' + p[end:]
p=p.replace("('baseline','scans','phase_scans','guards','both','fused','compact','combined','no_vector')", "('baseline','pose_guards','spatial_guards','force_guards','inertia_guards','row_guards','reduction_guards','all_guards','no_vector')")
Path('/var/tmp/sparkling-cost-current-20260927/build.py').write_text(p)
m=Path('tests/movement_performance/cost_attribution/measure.py').read_text()
m=m.replace("P(__file__).resolve().parents[1]/'run.py'", "P('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tests/movement_performance/run.py')")
m=m.replace("('crb_chain_24','ancestor_star_24','ancestor_forest_24','simple_mixed_8')", "('hinge_motor','branched_multijoint','chain_12','crb_no_damping','crb_chain_24','ancestor_star_24','ancestor_forest_24','ancestor_branches_24','simple_hinges_6','simple_sliders_6','simple_mixed_8')")
m=m.replace("stats_ns={v:h.stats", "ratio_to_c={v:h.ratio(timings[v],timings['c'],rng) for v in variants},stats_ns={v:h.stats")
Path('/var/tmp/sparkling-cost-current-20260927/measure.py').write_text(m)
