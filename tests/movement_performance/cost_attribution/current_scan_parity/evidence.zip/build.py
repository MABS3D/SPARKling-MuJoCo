#!/usr/bin/env python3
"""DIAGNOSTIC ONLY: deliberately unproved guard ablations, never production sources."""
import argparse, pathlib, shutil, subprocess, os, re, json, hashlib, difflib
P=pathlib.Path
ap=argparse.ArgumentParser(); ap.add_argument('--frozen',type=P,required=True); ap.add_argument('--out',type=P,required=True); ap.add_argument('--toolchains',type=P,required=True); ap.add_argument('--only', nargs='+')
a=ap.parse_args(); a.out.mkdir(parents=True,exist_ok=bool(a.only))
env=os.environ.copy(); env['PATH']=':'.join(str(next((a.toolchains/t).glob('*/bin'))) for t in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
base=a.frozen/'current'; records=json.loads((a.out/'manifest.json').read_text()) if a.only else {}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def modify(src,kind):
    groups = {
      'pose_guards':['mj-data-pipeline.adb'],
      'spatial_guards':['mj-data-spatial.adb'],
      'force_guards':['mj-data-forces_phase.adb','mj-fused_rne.adb'],
      'inertia_guards':['mj-data-inertia_phase.adb'],
      'row_guards':['mj-solver_kernels.adb'],
      'reduction_guards':['mj-solver_reductions.adb']}
    selected=sum(groups.values(),[]) if kind=='all_guards' else groups.get(kind,[])
    changes=[]
    for name in selected:
        path=src/'experimental/smooth/src'/name
        old=path.read_text(); new=old
        if name in ('mj-solver_kernels.adb','mj-solver_reductions.adb'):
            new=re.sub(r"Rejected := (?:Rejected \+ )?Boolean'Pos \([^;]+;",'Rejected := 0;',new)
        else:
            pattern=re.compile(r'(?m)^(\s*)(?:if|elsif)\s+([^;]+?)\s+then(?=\s*(?:\n|return;|pragma))')
            def sub(m):
                cond=m.group(2)
                if any(x in cond for x in ('Within_Work (','Bounded (','Division_Bounded (','not in Tier0_Real')) and not any(x in cond for x in (' loop',' begin',' end','pragma','=>')):
                    return m.group(0).replace(cond,'False',1)
                return m.group(0)
            new=pattern.sub(sub,new)
            new=re.sub(r'Ok := (?:Motion_Bounded|Bounded) \([^;]+;', 'Ok := True;',new)
        assert new!=old,(kind,name)
        path.write_text(new)
        changes.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=name,tofile=name))
    return ''.join(changes)
for kind in (a.only or ('baseline','pose_guards','spatial_guards','force_guards','inertia_guards','row_guards','reduction_guards','all_guards','no_vector')):
    root=a.out/kind; root.mkdir(); shutil.copytree(base/'source',root/'source')
    patch=''
    if kind in ('compact','combined'):
        for p in (a.frozen/'current/source/experimental/smooth/src').iterdir():
            q=root/'source/experimental/smooth/src'/p.name
            if p.is_file() and (not q.exists() or p.read_bytes()!=q.read_bytes()):
                old=q.read_text() if q.exists() else ''; new=p.read_text(); patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=p.name,tofile=p.name)); shutil.copy2(p,q)
    patch+=modify(root/'source',kind)
    project=next(base.glob('*.gpr')).read_text().replace(str(base),str(root))
    if kind in ('compact','combined'):
        project=next((a.frozen/'current').glob('*.gpr')).read_text().replace(str(a.frozen/'current'),str(root))
    if kind=='no_vector': project=project.replace('"-O3",','"-O3", "-fno-tree-vectorize", "-fno-tree-slp-vectorize",')
    (root/'fragment.gpr').write_text(project); (root/'changes.patch').write_text(patch)
    with (root/'build.log').open('w') as log: subprocess.run(['gprbuild','-P',str(root/'fragment.gpr'),'-j4'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    records[kind]={'binary':str(root/'bin/movement_bench'),'binary_sha256':sha(root/'bin/movement_bench'),'source_hashes':{str(p.relative_to(root/'source')):sha(p) for p in sorted((root/'source').rglob('*')) if p.is_file()},'patch_sha256':sha(root/'changes.patch')}
    print(kind,'built',flush=True)
reference=json.loads((a.frozen/'build.json').read_text())['builds']['c']
assert sha(P(reference['library']))==reference['library_sha256']
records['c']={'binary':str(a.frozen/'movement_c'),'binary_sha256':sha(a.frozen/'movement_c'),'library':reference['library'],'library_sha256':reference['library_sha256']}
(a.out/'manifest.json').write_text(json.dumps(records,indent=2))
