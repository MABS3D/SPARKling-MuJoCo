from pathlib import Path
import json
r=Path('/var/tmp/sparkling-cost-current-20260927')
sessions=[json.loads((r/f'session{i}/measurements.json').read_text()) for i in (1,2)]
assert all(s['complete'] for s in sessions)
rows=[x for s in sessions for x in s['summary']]
models=list(dict.fromkeys(x['case'].rsplit('-',1)[0] for x in rows))
report=['# Numerical-guard cost after scan parity','', 'Commit `677e75474f81e76cc0c99dd7eeb2edb22d5f6af9`. Diagnostic only; no runtime source changes or new proof claims.','', 'Two sessions, CPU 12, 20 balanced blocks per case; 11 models × 3 initial states, 10 variants including C. Each invocation: 2 warmups, 4 timed trajectories of 100 steps. Preparation and I/O excluded. Checks: qpos/qvel/time against C reference, atol=rtol=2e-10; diagnostic Ada values must equal baseline serialized values. Ratios use paired blocks and bootstrap 95% confidence intervals (10,000 resamples). Ranges below cover 3 states × 2 sessions, not confidence intervals.','', '| Model | Baseline / C | All selected guards removed / C | Step-time saving | CI95 entirely below baseline |','|---|---:|---:|---:|---:|']
fmt=lambda v:f'{min(v):.3f}–{max(v):.3f}'
for model in models:
 rr=[x for x in rows if x['case'].rsplit('-',1)[0]==model]
 report.append(f"| {model} | {fmt([x['ratio_to_c']['baseline']['median'] for x in rr])} | {fmt([x['ratio_to_c']['all_guards']['median'] for x in rr])} | {fmt([100*(1-x['ratio_to_baseline']['all_guards']['median']) for x in rr])}% | {sum(x['ratio_to_baseline']['all_guards']['ci95'][1]<1 for x in rr)}/6 |")
report+=['','## Isolated families','','Effects cannot be added: branch removal changes generated code and can interact with vectorization. A negative saving is a slowdown.','','| Family | Saving range across all cases | CI95 below baseline |','|---|---:|---:|']
for v in sessions[0]['manifest']:
 if v in ('baseline','c'):continue
 report.append(f"| {v} | {fmt([100*(1-x['ratio_to_baseline'][v]['median']) for x in rows])}% | {sum(x['ratio_to_baseline'][v]['ci95'][1]<1 for x in rows)}/66 |")
report+=['','Scope: selected Bounded/Within_Work/Division_Bounded checks and solver rejection reductions, including checks moved into MJ.Fused_RNE. Time/state-integration guards, normalisation, pivot clamping and other algorithmic branches remain. Strict-only changes in the diagnostic patch do not establish a measured benefit on the Compatible movement path. no_vector disables tree/SLP vectorization; it measures the benefit of existing vectorization, not a missing optimization. Compact mass assembly and gravity/bias fusion were not remeasured; their old costs must not be treated as current.','',f"Maximum C-reference error: {max(e for x in rows for e in x['max_c_reference_error'].values()):.17g}. Maximum diagnostic-Ada difference: {max(e for x in rows for v,e in x['max_ada_error'].items() if v!='c'):.17g}.",'','Raw data retain block timings, medians, MAD, p95 and confidence intervals. p95 concerns trajectory-average step times, not individual-step latency. Diagnostic patches and hashes are archived for reproduction.']
(r/'report.md').write_text('\n'.join(report)+'\n');print('\n'.join(report))
