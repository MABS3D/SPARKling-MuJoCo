from pathlib import Path
import hashlib,json,subprocess,platform
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco'); root=Path('/var/tmp/sparkling-cost-current-20260927')
frozen=Path('/var/tmp/sparkling-scan-parity-20260927/build-validated/current/source')
hashes={str(p.relative_to(frozen)):hashlib.sha256(p.read_bytes()).hexdigest() for p in frozen.rglob('*') if p.is_file()}
for name,digest in hashes.items():
 assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
meta={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_hashes':hashes,'source_count':len(hashes),'platform':platform.platform(),'cpuinfo':Path('/proc/cpuinfo').read_text().split('\n\n')[0],'scope':'Diagnostic selected numerical-guard ablations and vectorization. No new compact-mass or fused-gravity experiment. No proof claim for modified variants.','reference_build':json.loads(Path('/var/tmp/sparkling-scan-parity-20260927/build-validated/build.json').read_text())}
(root/'metadata.json').write_text(json.dumps(meta,indent=2));print('verified',len(hashes),'source hashes',meta['commit'])
