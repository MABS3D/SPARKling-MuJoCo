from pathlib import Path
import json,hashlib,zipfile,shutil
r=Path('/var/tmp/sparkling-cost-current-20260927');repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');dest=repo/'tests/movement_performance/cost_attribution/current_scan_parity';dest.mkdir(exist_ok=True)
m=json.loads((r/'build/manifest.json').read_text())
for v,record in m.items():
 assert hashlib.sha256(Path(record['binary']).read_bytes()).hexdigest()==record['binary_sha256']
 if v!='c':
  for name,h in record['source_hashes'].items():assert hashlib.sha256((r/'build'/v/'source'/name).read_bytes()).hexdigest()==h
files={}
for p in r.glob('*.py'):files[p.name]=p
files['metadata.json']=r/'metadata.json';files['manifest.json']=r/'build/manifest.json'
for s in (1,2):files[f'session{s}/measurements.json']=r/f'session{s}/measurements.json'
for v,record in m.items():
 files[f'binaries/{v}']=Path(record['binary'])
 if v!='c':
  for name in ('changes.patch','fragment.gpr','build.log'):files[f'variants/{v}/{name}']=r/'build'/v/name
for p in (r/'build/baseline/source').rglob('*'):
 if p.is_file():files['source/'+str(p.relative_to(r/'build/baseline/source'))]=p
for p in Path('/var/tmp/sparkling-scan-parity-20260927/session1/timings').iterdir():
 if p.suffix in ('.input','.mjb') or p.name.endswith('.expected.json'):files['inputs/'+p.name]=p
files['harness/run.py']=repo/'tests/movement_performance/run.py'
files['reference/'+Path(m['c']['library']).name]=Path(m['c']['library'])
checks={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()}
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('SHA256.json',json.dumps(checks,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in checks.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
shutil.copy2(r/'report.md',dest/'README.md')
(dest/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in (archive,dest/'README.md')))
print('Archived',len(files),'files;',archive.stat().st_size,'bytes')
rows=[x for i in (1,2) for x in json.loads((r/f'session{i}/measurements.json').read_text())['summary']]
for model in ('crb_chain_24','ancestor_star_24','ancestor_forest_24'):
 rr=[x for x in rows if x['case'].startswith(model+'-')]
 print(model,{v:[round(min(100*(1-x['ratio_to_baseline'][v]['median']) for x in rr),2),round(max(100*(1-x['ratio_to_baseline'][v]['median']) for x in rr),2)] for v in ('force_guards','row_guards')})
