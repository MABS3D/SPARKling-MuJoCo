from pathlib import Path
import json,shutil,sys,os,subprocess,hashlib
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');root=Path(__file__).resolve().parent;out=root/'build-final';out.mkdir()
sys.path.insert(0,str(repo/'experimental/smooth/tools'));from prove_fragments import isolated_project
import importlib.util
spec=importlib.util.spec_from_file_location('gold_build',repo/'tests/movement_performance/gold_adoption/build.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);FLAGS=module.FLAGS
ref=Path('/var/tmp/sparkling-scan-parity-20260927/build-validated'); meta=json.loads((ref/'build.json').read_text());base=ref/'current/source'
env=os.environ.copy();env['PATH']=':'.join(str(next((Path('/var/tmp/sparkling-matrix-recovery/toolchains')/x).glob('*/bin'))) for x in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
builds={'c':meta['builds']['c']}
for kind in ('baseline','current','checked'):
 d=out/kind;d.mkdir();src=d/'source';shutil.copytree(base,src)
 # Add the numerical probe (not in the old movement-only source snapshot).
 probe=Path('experimental/smooth/tests/smooth_probe.adb');(src/probe).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/probe,src/probe)
 if kind!='baseline':
  for p in (repo/'experimental/smooth/src').glob('*.ad?'):shutil.copy2(p,src/'experimental/smooth/src'/p.name)
 main='smooth_probe' if kind=='checked' else 'movement_bench'
 p=isolated_project(src,d,main);text=p.read_text().replace('project Fragment is',f'project Fragment is\n   for Main use ("{main}.adb");\n   for Exec_Dir use "bin";')
 if kind!='checked':
  start=text.index('        ("-gnat2022"');end=text.index(';',start);text=text[:start]+'('+', '.join('"'+x+'"' for x in FLAGS)+')'+text[end:]
  text=text.replace('end Fragment;','   package Linker is\n      for Default_Switches ("Ada") use ("-flto", "-Wl,--gc-sections");\n   end Linker;\nend Fragment;')
 p.write_text(text);cmd=['gprbuild','-P',str(p),'-j4']
 with (d/'build.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 builds[kind]={'binary':str(d/'bin'/main),'binary_sha256':sha(d/'bin'/main),'sources':{str(p.relative_to(src)):sha(p) for p in src.rglob('*.ad?')},'command':cmd};print(kind,'built',flush=True)
(out/'movement_c').symlink_to(ref/'movement_c');meta.update(builds=builds);(out/'build.json').write_text(json.dumps(meta,indent=2))
(out/'manifest.json').write_text(json.dumps({k:dict(v,binary=str(out/'movement_c')) if k=='c' else v for k,v in builds.items() if k!='checked'},indent=2))
