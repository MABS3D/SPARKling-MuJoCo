from pathlib import Path
p=Path('experimental/smooth/src/mj-data-forces_phase.adb');s=p.read_text()
i=Path('experimental/smooth/src/mj-data-inertia_phase.adb').read_text()
a=i.index('   procedure Transfer_Inertia_Bound');b=i.index('   procedure Equal_Composite_Transitive',a)
h=i[a:b].replace('Transfer_Inertia_Bound','Transfer_Motion_Bound').replace('SK.Inertia','SK.Motion').replace('Composite_Array','Motion_Array').replace('CB.Budget','MJ.Gravity_Bounds.Budget').replace('CW.Weight_Array','MJ.Composite_Weights.Weight_Array').replace('Preserve_Weighted_Prefix','Preserve_Gravity_Prefix')
s=s.replace('   procedure Advance_Joint',h+'   procedure Advance_Joint',1)
s=s.replace('      Vel := Current_Velocity;\n      Acc := Current_Acceleration;','      Vel := Current_Velocity;\n      Transfer_Motion_Bound (Current_Velocity, Vel, 1.0e12);\n      Acc := Current_Acceleration;')
a=s.index('   procedure Backward_Bodies');b=s.index('   procedure Store_Force_Entry',a);t=s[a:b]
t=t.replace('            Sum : SK.Motion;','            Sum : SK.Motion;\n            Old_Gravity : constant Motion_Array := Gravity with Ghost => Static;\n            Old_Weights : constant CW.Weight_Array := Weights with Ghost => Static;')
t=t.replace('         end;\n      end loop;','            Preserve_Gravity_Prefix (Old_Gravity, Gravity, Old_Weights, Weights, B, P);\n         end;\n      end loop;')
s=s[:a]+t+s[b:]
a=s.index('   procedure Passive_Buffers');b=s.index('   procedure Passive_Bounded_Buffers',a);t=s[a:b].replace('      Result := Numeric_Limit;\n','')
s=s[:a]+t+s[b:];p.write_text(s)
