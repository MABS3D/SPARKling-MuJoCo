from pathlib import Path
import json,hashlib,re
r=Path(__file__).resolve().parent;repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
accepted={'gravity-leaves':['Budget','Budget_Bounds','Bound_Wrench_Sum'],'gravity-scalar':['Bound_Sum'],'force-leaves':['Body_Wrenches'],'forward-parallel':['Forward_Bodies'],'force-callers':['Recursive_Forces_Buffers'],'ghost-leaves-final':['Transfer_Motion_Bound','Preserve_Gravity_Prefix'],'forward-one-final':['Forward_One_Body'],'backward-final':['Backward_Bodies']}
def span(path,name):
 s=path.read_text();matches=list(re.finditer(r'^   (function|procedure)\s+(\w+)',s,re.M))
 for i,m in enumerate(matches):
  if m.group(2)==name:return s[m.start():matches[i+1].start() if i+1<len(matches) else len(s)]
 raise ValueError((path,name))
rows=[]
for folder,names in accepted.items():
 data=json.loads((r/folder/'results.json').read_text())
 for name in names:
  matches=[x for x in data['results'] if x['target']['name']==name];assert len(matches)==1
  row=matches[0];assert row['status']=='completed_no_unproved',(folder,name,row['status'])
  f=row['target']['file'];snap=Path(data['snapshot'])/'experimental/smooth/src'/f;active=repo/'experimental/smooth/src'/f
  old=span(snap,name);new=span(active,name);assert old==new,(folder,name,'span changed')
  rows.append({'name':name,'file':f,'report':folder,'proof_checks':row['proof_checks'],'unproved':row['unproved'],'errors':row['errors'],'source_span_sha256':hashlib.sha256(new.encode()).hexdigest(),'command':row['command']})
# Declarations/constants in the new package are identical to the proved snapshot.
scalar=json.loads((r/'gravity-scalar/results.json').read_text())
for ext in ('adb','ads'):
 f=f'mj-gravity_bounds.{ext}';assert (repo/'experimental/smooth/src'/f).read_bytes()==(Path(scalar['snapshot'])/'experimental/smooth/src'/f).read_bytes()
build=json.loads((r/'adopted/build.json').read_text())
for name,digest in build['builds']['current']['sources'].items():
 assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
result={'baseline_commit':'677e75474f81e76cc0c99dd7eeb2edb22d5f6af9','scopes':rows,'proof_checks':sum(x['proof_checks'] for x in rows),'unproved':0,'scope':'Local changed force bounds and caller contracts. No full physical dynamics theorem. Existing public contracts unchanged; private Backward_Bodies preconditions strengthened only to guarantees established by its caller.','source_match':'All final movement build sources match repository; all accepted subprogram bodies match their proof snapshots exactly. Line-only and timed-out attempts excluded.'}
(r/'proof-closure.json').write_text(json.dumps(result,indent=2));print([(x['name'],x['proof_checks']) for x in rows]);print('Total',result['proof_checks'])
