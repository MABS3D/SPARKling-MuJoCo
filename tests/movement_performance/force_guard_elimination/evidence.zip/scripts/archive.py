from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');dest=repo/'tests/movement_performance/force_guard_elimination';dest.mkdir(exist_ok=True)
files={}
def addtree(base,prefix):
 for p in base.rglob('*'):
  if p.is_file():files[prefix+'/'+str(p.relative_to(base))]=p
for p in r.glob('*.py'):files['scripts/'+p.name]=p
for p in r.glob('*.json'):files['metadata/'+p.name]=p
for folder in r.iterdir():
 if not folder.is_dir():continue
 if (folder/'results.json').exists() and (folder/'manifest.json').exists():
  addtree(folder,'proofs/'+folder.name)
  m=json.loads((folder/'manifest.json').read_text());snapshot=Path(m['snapshot']);addtree(snapshot,'snapshots/'+folder.name)
 elif folder.name in ('session1','session2','isolation-session1','isolation-session2') or folder.name.startswith(('adopted-numerics-','adopted-boundary-strict','adopted-boundary-compatible')):
  addtree(folder,'results/'+folder.name)
for folder in ('build-final','adopted'):
 files['builds/'+folder+'/build.json']=r/folder/'build.json'
for name,root,main in [('baseline',r/'build-final/baseline','movement_bench'),('both-guards',r/'build-final/current','movement_bench'),('adopted',r/'isolation/gravity_only','movement_bench'),('checked',r/'adopted/checked','smooth_probe'),('boundary',r/'adopted-boundary-release','smooth_probe')]:
 addtree(root/'source','sources/'+name)
 files['binaries/'+name]=root/'bin'/main
 for p in [*root.glob('*.gpr'),*root.glob('*.json'),*root.glob('*.log')]:files['builds/'+name+'/'+p.name]=p
m=json.loads((r/'adopted/build.json').read_text());reference=m['builds']['c'];files['binaries/reference-c']=r/'adopted/movement_c';files['binaries/'+Path(reference['library']).name]=Path(reference['library'])
for p in Path('/var/tmp/sparkling-scan-parity-20260927/session1/timings').iterdir():
 if p.suffix in ('.input','.mjb') or p.name.endswith('.expected.json'):files['timing-inputs/'+p.name]=p
for rel in ('experimental/smooth/tools/prove_fragments.py','experimental/smooth/tools/compare_numerics.py','tests/movement_performance/run.py','tests/movement_performance/gold_adoption/build.py','tests/movement_performance/gold_adoption/check_force_boundary.py','tools/guarded.py'):
 files['harness/'+rel]=repo/rel
files['docs/force-guard-elimination.md']=repo/'docs/force-guard-elimination.md'
for name in ('proof-closure.json','performance.json'):shutil.copy2(r/name,dest/name)
# Verify tested release and active sources before publishing local evidence.
measured=json.loads((r/'isolation/manifest.json').read_text())['gravity_only']
assert hashlib.sha256(Path(measured['binary']).read_bytes()).hexdigest()==measured['binary_sha256']==m['builds']['current']['binary_sha256']
for name,h in m['builds']['current']['sources'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,name
assert (repo/'experimental/smooth/src/mj-data-forces_phase.ads').read_bytes()==(r/'build-final/baseline/source/experimental/smooth/src/mj-data-forces_phase.ads').read_bytes()
for policy in ('strict','compatible'):
 for prefix in ('adopted-numerics','adopted-boundary'):
  results=json.loads((r/f'{prefix}-{policy}/results.json').read_text());assert results['status']=='passed',(prefix,policy)
patch=subprocess.check_output(['git','diff','--','experimental/smooth/src/mj-data-forces_phase.adb'],cwd=repo,text=True);(r/'adopted.patch').write_text(patch);files['metadata/adopted.patch']=r/'adopted.patch'
checks={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()};zpath=dest/'evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for n,p in files.items():z.write(p,n)
 z.writestr('SHA256.json',json.dumps(checks,indent=2))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for n,h in checks.items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
(dest/'README.md').write_text('# Proved gravity guard elimination\n\nSee [the report](../../../docs/force-guard-elimination.md).\n\n`proof-closure.json` lists the 11 accepted local scopes (295 proof obligations, zero open). `evidence.zip` includes failed and superseded attempts explicitly, final and previous sources, compiler commands/flags/hashes, numerical results, and all timing sessions. Only `gravity_only` from `isolation-session1` and `isolation-session2` is adopted; the both-guard candidate is not. Its measured release binary SHA256 is `'+measured['binary_sha256']+'`.\n\nArchived scripts preserve the original absolute work paths; adjust these paths and the toolchain root when reproducing on another machine. All archive members are checked by SHA256.json. Existing unchanged dependency proofs are inherited from the scan-parity checkpoint at commit 677e7547; the new local proof totals do not count those old proofs again.\n')
(dest/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(dest.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Archived',len(files),'members;',zpath.stat().st_size,'bytes. Source, binary, numeric result and archive checks passed.')
