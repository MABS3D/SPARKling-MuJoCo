from pathlib import Path
import json
r=Path(__file__).resolve().parent
sessions=[json.loads((r/f'isolation-session{i}/measurements.json').read_text()) for i in (1,2)];assert all(x['complete'] for x in sessions)
rows=[x for s in sessions for x in s['summary']];models=list(dict.fromkeys(x['case'].rsplit('-',1)[0] for x in rows));v='gravity_only'
def rng(a,digits=2):return f'{min(a):.{digits}f}–{max(a):.{digits}f}'
lines=['| Modello | Riduzione tempo/passo (%) | Rapporto nuovo/C | IC95 interamente migliore / peggiore |','|---|---:|---:|---:|']
for model in models:
 rr=[x for x in rows if x['case'].rsplit('-',1)[0]==model];ratios=[x['ratio_to_baseline'][v] for x in rr]
 lines.append(f"| {model} | {rng([100*(1-x['median']) for x in ratios])} | {rng([x['ratio_to_c'][v]['median'] for x in rr],3)} | {sum(x['ci95'][1]<1 for x in ratios)}/6 ; {sum(x['ci95'][0]>1 for x in ratios)}/6 |")
summary={'complete':True,'variant':v,'sessions':['isolation-session1','isolation-session2'],'blocks':24,'cases':33,'models':11,'steps':100,'samples':4,'cpu':12,'records':sum(len(s['records']) for s in sessions),'max_ada_error':max(x['max_ada_error'][v] for x in rows),'max_c_error':max(x['max_c_reference_error'][v] for x in rows),'summary':rows}
(r/'performance.json').write_text(json.dumps(summary,indent=2));(r/'performance.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines));print('Ada error:',summary['max_ada_error'],'C error:',summary['max_c_error'])
