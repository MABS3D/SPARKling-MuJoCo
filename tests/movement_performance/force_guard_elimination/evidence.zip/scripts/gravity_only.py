from pathlib import Path
import shutil,json,os,subprocess,hashlib
r=Path(__file__).resolve().parent;build=r/'build-final';dest=r/'isolation';dest.mkdir();variant=dest/'gravity_only';variant.mkdir();shutil.copytree(build/'current/source',variant/'source')
f=Path('experimental/smooth/src/mj-data-forces_phase.adb');old=(build/'baseline/source'/f).read_text();s=(variant/'source'/f).read_text()
a=old.index('   procedure Passive_Buffers');b=old.index('   procedure Passive_Bounded_Buffers',a);x=s.index('   procedure Passive_Buffers');y=s.index('   procedure Passive_Bounded_Buffers',x);(variant/'source'/f).write_text(s[:x]+old[a:b]+s[y:])
p=(build/'current/movement_bench.gpr').read_text().replace(str(build/'current'),str(variant));(variant/'movement_bench.gpr').write_text(p)
env=os.environ.copy();env['PATH']=':'.join(str(next((Path('/var/tmp/sparkling-matrix-recovery/toolchains')/x).glob('*/bin'))) for x in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
with (variant/'build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(variant/'movement_bench.gpr'),'-j4'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
m=json.loads((build/'manifest.json').read_text());p=variant/'bin/movement_bench';m['gravity_only']={'binary':str(p),'binary_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};(dest/'manifest.json').write_text(json.dumps(m,indent=2));print('gravity_only built')
