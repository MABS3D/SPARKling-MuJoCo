from pathlib import Path
s=Path('experimental/smooth/src')
for ext in ('ads','adb'):
 x=(s/f'mj-composite_bounds.{ext}').read_text().replace('MJ.Composite_Bounds','MJ.Gravity_Bounds').replace('2.0 ** 119','2.0 ** 159').replace('Bound_Inertia_Sum','Bound_Wrench_Sum').replace('MJ.Spatial_Kernels.Inertia','MJ.Spatial_Kernels.Motion').replace('MJ.Spatial_Kernels.Add (','MJ.Spatial_Kernels.Add_Wrenches (').replace('1.0e36','1.0e48').replace('1.0e40','1.0e54')
 for i in range(6,10):x=x.replace(f'      Bound_Sum (A ({i}), B ({i}), NA, NB);\n','')
 (s/f'mj-gravity_bounds.{ext}').write_text(x)
p=s/'mj-data-forces_phase.adb';x=p.read_text();x='with MJ.Gravity_Bounds;\nwith MJ.Composite_Weights;\n'+x
# Tighten only the gravity result, using the existing Gravity_Force contract.
a=x.index('   procedure Body_Wrenches');b=x.index('   procedure Backward_Bodies')
t=x[a:b]
t=t.replace('SK.Bounded (Gravity, 1.0e54)','SK.Bounded (Gravity, 1.0e48)').replace('SK.Bounded (Gravity_Out, 1.0e54)','SK.Bounded (Gravity_Out, 1.0e48)').replace('for all X of Gravity => SK.Bounded (X, 1.0e54)','for all X of Gravity => SK.Bounded (X, 1.0e48)').replace('Store_Motion_Prefix (Gravity, B, G, 1.0e54)','Store_Motion_Prefix (Gravity, B, G, 1.0e48)').replace('SK.Bounded (Gravity (K), 1.0e54)','SK.Bounded (Gravity (K), 1.0e48)')
x=x[:a]+t+x[b:]
a=x.index('   procedure Backward_Bodies');b=x.index('   procedure Store_Force_Entry',a)
t=x[a:b]
t=t.replace('Body_Config (B).Parent <= B','(if B = 0 then Body_Config (B).Parent = 0 else Body_Config (B).Parent < B)')
t=t.replace('and then (for all X of Gravity => SK.Bounded (X, 1.0e54)),','and then (for all X of Gravity => SK.Bounded (X, 1.0e48)),',1)
t=t.replace('   is\n   begin','''   is
      package GB renames MJ.Gravity_Bounds;
      package CW renames MJ.Composite_Weights;
      Weights : CW.Weight_Array (Gravity'Range) with Ghost => Static;
   begin
      CW.Initialize (Weights);
      GB.Budget_Bounds (1);''',1)
t=t.replace('         declare\n            P', '''         pragma Loop_Invariant (Static => CW.Prefix_Sum (Weights, Weights'Length) <= Max_Bodies);
         pragma Loop_Invariant (Static => (for all K in Weights'Range =>
           (if K <= B then Weights (K) > 0 else Weights (K) = 0)));
         pragma Loop_Invariant (Static => (for all K in 0 .. B =>
           Weights (K) > 0 and then SK.Bounded (Gravity (K), GB.Budget (Weights (K)))));
         declare
            P''',1)
t=t.replace('               Sum := SK.Add_Wrenches (Gravity (P), Gravity (B));\n               if not SK.Bounded (Sum, 1.0e54) then return; end if;','''               CW.Pair_Bound (Weights, Weights'Length, P, B);
               GB.Bound_Wrench_Sum (Gravity (P), Gravity (B), Weights (P), Weights (B));
               GB.Budget_Bounds (Weights (P) + Weights (B));
               Sum := SK.Add_Wrenches (Gravity (P), Gravity (B));''')
t=t.replace('               Gravity (P) := Sum;\n            end if;','''               Gravity (P) := Sum;
               CW.Transfer (Weights, B, P);
            else
               CW.Discard (Weights, B);
            end if;''',1)
x=x[:a]+t+x[b:]
# The scalar Passive_Force already returns Tier1, well inside Work_Real.
a=x.index('   procedure Passive_Buffers');b=x.index('   procedure Passive_Bounded_Buffers',a)
t=x[a:b].replace('            if not Within_Work (Value) then return; end if;','            pragma Assert (Static => Within_Work (Value));')
x=x[:a]+t+x[b:]
p.write_text(x)
