from pathlib import Path
import shutil,json,os,subprocess,hashlib,sys
r=Path(__file__).resolve().parent;repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');variant=r/'isolation/gravity_only';src=variant/'source';f=Path('experimental/smooth/src/mj-data-forces_phase.adb');shutil.copy2(src/f,repo/f)
b=r/'adopted';b.mkdir();(b/'current').symlink_to(variant);(b/'baseline').symlink_to(r/'build-final/baseline');(b/'movement_c').symlink_to(r/'build-final/movement_c');c=b/'checked';c.mkdir();shutil.copytree(src,c/'source')
sys.path.insert(0,str(repo/'experimental/smooth/tools'));from prove_fragments import isolated_project
p=isolated_project(c/'source',c,'smooth_probe');p.write_text(p.read_text().replace('project Fragment is','project Fragment is\n   for Main use ("smooth_probe.adb");\n   for Exec_Dir use "bin";'))
env=os.environ.copy();env['PATH']=':'.join(str(next((Path('/var/tmp/sparkling-matrix-recovery/toolchains')/x).glob('*/bin'))) for x in ('gnat','gprbuild','gnatprove'))+':'+env['PATH']
with (c/'build.log').open('w') as log:subprocess.run(['gprbuild','-P',str(p),'-j4'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((r/'build-final/build.json').read_text())
for v,root,main in [('current',variant,'movement_bench'),('checked',c,'smooth_probe')]:m['builds'][v]={'binary':str(root/'bin'/main),'binary_sha256':sha(root/'bin'/main),'sources':{str(p.relative_to(root/'source')):sha(p) for p in (root/'source').rglob('*.ad?')}}
(b/'build.json').write_text(json.dumps(m,indent=2));print('Adopted release identical to measured gravity_only:',m['builds']['current']['binary_sha256'])
