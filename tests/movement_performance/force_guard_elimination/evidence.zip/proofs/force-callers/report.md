# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-g86f07fw/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Forward_Bodies` | `mj-data-forces_phase.adb:155` | [proof_timeout](logs/mj-data-forces_phase__forward_bodies__adb_155.log) | 0 | 0 | 0 | 120.2 |
| `Backward_Bodies` | `mj-data-forces_phase.adb:227` | [proof_timeout](logs/mj-data-forces_phase__backward_bodies__adb_227.log) | 0 | 0 | 0 | 90.2 |
| `Recursive_Forces_Buffers` | `mj-data-forces_phase.adb:324` | [completed_no_unproved](logs/mj-data-forces_phase__recursive_forces_buffers__adb_324.log) | 30 | 0 | 0 | 32.6 |

## Diagnostics

