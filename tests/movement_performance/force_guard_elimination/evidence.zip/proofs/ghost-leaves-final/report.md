# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-tlaw99r4/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Transfer_Motion_Bound` | `mj-data-forces_phase.adb:37` | [completed_no_unproved](logs/mj-data-forces_phase__transfer_motion_bound__adb_37.log) | 3 | 0 | 0 | 15.7 |
| `Preserve_Gravity_Prefix` | `mj-data-forces_phase.adb:46` | [completed_no_unproved](logs/mj-data-forces_phase__preserve_gravity_prefix__adb_46.log) | 32 | 0 | 0 | 17.4 |
| `Passive_Buffers` | `mj-data-forces_phase.adb:429` | [completed_no_unproved](logs/mj-data-forces_phase__passive_buffers__adb_429.log) | 32 | 0 | 0 | 8.9 |

## Diagnostics

