# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-bfcoj2uk/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Body_Wrenches` | `mj-data-forces_phase.adb:58` | [completed_no_unproved](logs/mj-data-forces_phase__body_wrenches__adb_58.log) | 16 | 0 | 0 | 78.6 |
| `Forward_One_Body` | `mj-data-forces_phase.adb:77` | [proof_timeout](logs/mj-data-forces_phase__forward_one_body__adb_77.log) | 0 | 0 | 0 | 90.2 |
| `Passive_Buffers` | `mj-data-forces_phase.adb:387` | [completed_with_warnings](logs/mj-data-forces_phase__passive_buffers__adb_387.log) | 32 | 0 | 0 | 8.9 |

## Diagnostics

### mj-data-forces_phase__passive_buffers__adb_387

- `mj-data-forces_phase.adb:405` (warning): unused assignment

