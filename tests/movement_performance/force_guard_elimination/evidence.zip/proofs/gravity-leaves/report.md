# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-36j7r81b/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Bound_Sum` | `mj-gravity_bounds.adb:2` | [unproved_checks](logs/mj-gravity_bounds__bound_sum__adb_2.log) | 14 | 1 | 0 | 10.2 |
| `Budget_Bounds` | `mj-gravity_bounds.adb:6` | [completed_no_unproved](logs/mj-gravity_bounds__budget_bounds__adb_6.log) | 1 | 0 | 0 | 2.8 |
| `Bound_Wrench_Sum` | `mj-gravity_bounds.adb:10` | [completed_no_unproved](logs/mj-gravity_bounds__bound_wrench_sum__adb_10.log) | 14 | 0 | 0 | 21.6 |
| `Budget` | `mj-gravity_bounds.ads:7` | [completed_no_unproved](logs/mj-gravity_bounds__budget__ads_7.log) | 2 | 0 | 0 | 2.3 |

## Diagnostics

### mj-gravity_bounds__bound_sum__adb_2

- `mj-gravity_bounds.ads:13` (medium): postcondition might fail [provers reached time limit before completing the proof]

