# Compact mass experiment

Frozen baseline: `bf265c8f544e8e151c62a30634cd1d44ea613c3d` on `spark-port`.
`baseline.json` hashes the baseline smooth units; `build.py` verifies them before
building baseline/current release executables and checked validation programs.
The C executable/library must match the supplied reference build manifest.

See [scope, results, proof status and remaining work](../../../docs/compact-mass.md).

```sh
python3 tests/movement_performance/compact_mass/build.py \
  --out /var/tmp/compact-build --toolchain-root TOOLCHAINS \
  --reference-build PINNED_C_BUILD
PYTHON_WITH_MUJOCO tests/movement_performance/c_parity_six/compare.py \
  --build /var/tmp/compact-build --out /var/tmp/compact-session1 \
  --toolchain-root TOOLCHAINS --cpu 12 --blocks 24
```

Run the comparison twice into independent output directories with no competing
build/proof jobs. The shared `summarize.py` accepts both `--session` paths.
Use `experimental/smooth/tools/compare_numerics.py` with the checked probe,
24 samples, both policies, and `tests/tree_invariants/fixtures` for correctness.
`check_paths.py` accepts the build and generated timing fixtures; it counts
compact/dense assembly, dense gathers and readiness guards, and requires exact
agreement with release trajectory outputs. Its timing is not benchmark evidence.

`compact_inertia_test.adb` checks independent parent-walk expectations for empty,
singleton, chain, star, forest and 256 independent DOFs; structural zeros,
nonzero output lower bounds, projected values and rejected rows. The checked
smooth probe additionally verifies dense mass queries at high array bounds,
invalid sizes, repeated queries, and independent mass/acceleration freshness.

The evidence includes source-addressed proof snapshots, failed diagnostics,
checked numerical results, build inputs/logs, path instrumentation and both
performance sessions. `SHA256SUMS` pins the archived artifacts. A zero-check
invocation or timeout is not counted as a proof.
