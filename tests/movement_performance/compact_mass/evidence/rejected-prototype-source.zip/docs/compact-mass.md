# Direct compact mass assembly

The Compatible CRB path now computes mass entries directly in full ancestor
rows (root first, diagonal last), following MuJoCo 3.14.0 `mj_crb`. It no longer
constructs a dense matrix and then gathers its structural entries for each
solve. The existing ordered spatial product and dot expression, armature,
reverse body accumulation, and simple-DOF diagonal shortcut are retained.

Strict and the Jacobian fallback retain the dense path. No value is discarded
by a numerical sparsity tolerance. This remains the experimental scalar-joint
smooth simulator, not full MuJoCo feature or formal equivalence coverage.

## Representation and cost

The mass allocation still has dense capacity for Strict/fallback; a private
format flag identifies the live ancestor-row prefix. This change reduces
traffic and work, not the persistent allocation size. Assembly uses a compact
candidate and copies its prefix on success. Each factorization still copies
the compact mass into mutable factor workspace before optional Euler damping.
There is no new allocation/deallocator policy or new trusted body.

`Mass_Entry` uses canonical symmetric indices. An ancestor's own row length
determines its only possible offset in another ancestor row; one membership
check therefore implements constant-time lookup, including exact structural
zeros. `Get_Mass_Matrix` expands to caller-owned dense storage in O(nv²), outside
the measured stepping loop, preserving its public contract and arbitrary valid
array lower bounds.

The remaining readiness checks inspect only live compact mass entries when the
format flag is set. Their frequency remains one full and three mutable checks
per standard benchmark step. Thus this is a reduction in each mass scan's width,
not removal of the remaining phase guards.

Instrumentation on 400 steps per model confirmed these active entries:

| Model | Prior dense entries | Compact entries |
| --- | ---: | ---: |
| chain 12 | 144 | 78 |
| chain 24 | 576 | 300 |
| star 24 | 576 | 47 |
| forest 24 | 576 | 84 |
| branches 24 | 576 | 102 |
| independent hinges/sliders 6 | 36 | 6 |
| independent mixed 8 | 64 | 8 |

The ten models with at least three DOFs each used 400 compact assemblies and
zero dense-to-packed gathers in the timed region. The one-DOF model retains
its existing dense path. Instrumented outputs match release outputs exactly;
instrumented timings are not performance evidence.

## Verification scope

The complete `MJ.Compact_Inertia` unit passes 149 proof checks with no open
obligations, after the small-subprogram diagnostics. Readiness changes were also
checked against the actuation unit (81 checks), `Update_Poses` (133),
`Ensure_Cartesian_Motion` (40), and the public mass getter (21). These are
contract-specific checks, not a count of physical theorems. Proof snapshots,
failed diagnostic attempts, and individual statuses are retained in the evidence.
The new contracts describe exact floating-point projection, bounded accepted
rows, a numeric rejection witness, exact lookup/structural zeros, dense
expansion, symmetry, and row preservation. The existing public dense-mass
contract is preserved. The old readiness-equivalence lemma is explicitly scoped
to dense storage: its historical full-buffer predicate is not an invariant of
unused compact-buffer capacity.

The row-call precondition and its explicit motion-buffer invariant also pass.
Two selected assembly-interface checks remain open in bounded diagnostics:
the candidate-length precondition of `Try_Assemble_CRB`, and the destination
prefix-slice range on publication. These are size/frame proof-engineering gaps,
not closed Gold results or mathematical exceptions; checked executions cover
them on the recorded models. They are archived alongside the successful proofs.

The overall physical CRB proof, force/solver/Euler composition, and all supported
model topology-to-physics relations remain pending. Differential comparisons
and leaf proofs do not close those claims. Timeouts are pending proof engineering,
not mathematical exceptions to Gold. Existing warnings and modeled deallocation
are retained; no assumptions or check suppressions were added.

## Reproduction

The frozen baseline is commit `bf265c8f544e8e151c62a30634cd1d44ea613c3d`.
`tests/movement_performance/compact_mass/baseline.json` pins its smooth sources.
Use the sibling `build.py` to build baseline Ada, current Ada, a checked numerical
probe, and checked structural tests, against the hash-verified normal SIMD C
reference. `check_paths.py` verifies guards and the compact path separately.
The existing `c_parity_six/compare.py` and `summarize.py` run and summarize the
integrated movement sessions. Evidence and commands are archived alongside this
experiment. Numerical comparisons use MuJoCo 3.14.0 and atol/rtol 2e-10.
