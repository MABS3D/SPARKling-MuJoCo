package Guard_Counts is
   Enabled : Boolean := False;
   Full_Checks, Mutable_Checks : Natural := 0;
   Compact_Assemblies, Dense_Assemblies, Dense_Packs : Natural := 0;
   Compact_Entries, Dense_Entries : Natural := 0;
end Guard_Counts;
