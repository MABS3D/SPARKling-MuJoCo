# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-s9yikfan/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 60` | `mj-data-inertia_phase.adb:60` | [completed_no_proof_checks](logs/mj-data-inertia_phase__adb_line_60.log) | 0 | 0 | 0 | 64.2 |
| `line 86` | `mj-data-inertia_phase.adb:86` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_86.log) | 1 | 0 | 0 | 88.0 |
| `line 135` | `mj-data-inertia_phase.adb:135` | [unproved_checks](logs/mj-data-inertia_phase__adb_line_135.log) | 1 | 1 | 0 | 69.8 |
| `line 137` | `mj-data-inertia_phase.adb:137` | [unproved_checks](logs/mj-data-inertia_phase__adb_line_137.log) | 8 | 1 | 0 | 80.0 |

## Diagnostics

### mj-data-inertia_phase__adb_line_135

- `mj-data-inertia_phase.adb:135` (medium): precondition might fail, cannot prove Mass'Last = (if Compact then MJ.Ancestor_Rows.Count (D.Ancestors) else D.Nv * D.Nv) - 1 [provers reached time and memory limit before completing the proof]

### mj-data-inertia_phase__adb_line_137

- `mj-data-inertia_phase.adb:137` (medium): range check might fail [reason for check: slice bounds must fit in the underlying array] [provers reached time and memory limit before completing the proof]

