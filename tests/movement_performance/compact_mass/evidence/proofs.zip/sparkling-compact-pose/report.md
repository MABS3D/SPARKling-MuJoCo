# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4u_hs90m/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Update_Poses` | `mj-data-pipeline.adb:493` | [completed_no_unproved](logs/mj-data-pipeline__update_poses__adb_493.log) | 133 | 0 | 0 | 233.6 |
| `Ensure_Cartesian_Motion` | `mj-data-pipeline.adb:623` | [completed_with_warnings](logs/mj-data-pipeline__ensure_cartesian_motion__adb_623.log) | 40 | 0 | 0 | 236.2 |

## Diagnostics

### mj-data-pipeline__ensure_cartesian_motion__adb_623

- `mj-data-pipeline.adb:654` (warning): "Joints" is set by "Build_Bodies" but not used after the call

