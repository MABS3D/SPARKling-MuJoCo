# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-27u3c8m3/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Lower_Entry` | `mj-compact_inertia.adb:2` | [analysis_error](logs/mj-compact_inertia__lower_entry__adb_2.log) | 0 | 0 | 4 | 2.1 |
| `Projected` | `mj-compact_inertia.adb:36` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Project_Row` | `mj-compact_inertia.adb:42` | not_run_analysis | 0 | 0 | 0 | 0.0 |
| `Expand` | `mj-compact_inertia.adb:17` | not_run_analysis | 0 | 0 | 0 | 0.0 |

## Diagnostics

### mj-compact_inertia__lower_entry__adb_2

- `mj-compact_inertia.adb:23` (error): reserved word "entry" cannot be used as identifier
- `mj-compact_inertia.adb:26` (error): binary operator expected
- `mj-compact_inertia.adb:28` (error): binary operator expected
- `mj-compact_inertia.adb:32` (error): binary operator expected

