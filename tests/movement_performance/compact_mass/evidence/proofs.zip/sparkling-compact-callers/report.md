# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-s1q_iyst/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 108` | `mj-data-inertia_phase.adb:108` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_108.log) | 2 | 0 | 0 | 72.3 |
| `line 609` | `mj-data-inertia_phase.adb:609` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_609.log) | 2 | 0 | 0 | 56.4 |
| `line 754` | `mj-data-pipeline.adb:754` | [completed_no_unproved](logs/mj-data-pipeline__adb_line_754.log) | 1 | 0 | 0 | 32.8 |
| `line 811` | `mj-data-pipeline.adb:811` | [completed_no_unproved](logs/mj-data-pipeline__adb_line_811.log) | 1 | 0 | 0 | 30.5 |
| `line 10` | `mj-data-inertia.adb:10` | [completed_no_unproved](logs/mj-data-inertia__adb_line_10.log) | 1 | 0 | 0 | 7.6 |
| `line 18` | `mj-data-inertia.adb:18` | [completed_no_unproved](logs/mj-data-inertia__adb_line_18.log) | 1 | 0 | 0 | 7.9 |

## Diagnostics

