# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-7jkb1is3/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 60` | `mj-data-inertia_phase.adb:60` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_60.log) | 2 | 0 | 0 | 72.3 |
| `line 61` | `mj-data-inertia_phase.adb:61` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_61.log) | 1 | 0 | 0 | 47.2 |
| `line 86` | `mj-data-inertia_phase.adb:86` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_86.log) | 1 | 0 | 0 | 84.5 |

## Diagnostics

