# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-p4_uqgln/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Ordered_Rows` | `mj-compact_inertia.adb:17` | [unproved_checks](logs/mj-compact_inertia__ordered_rows__adb_17.log) | 3 | 1 | 0 | 23.2 |
| `Expand_Row` | `mj-compact_inertia.adb:19` | [completed_no_unproved](logs/mj-compact_inertia__expand_row__adb_19.log) | 14 | 0 | 0 | 5.8 |
| `Expand` | `mj-compact_inertia.adb:30` | [unproved_checks](logs/mj-compact_inertia__expand__adb_30.log) | 31 | 1 | 0 | 23.4 |

## Diagnostics

### mj-compact_inertia__ordered_rows__adb_17

- `mj-compact_inertia.ads:41` (medium): postcondition might fail, cannot prove Offset (N, Earlier, J) < Offset (N, Later, 0) [provers reached time limit before completing the proof]

### mj-compact_inertia__expand__adb_30

- `mj-compact_inertia.adb:44` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Dense (Dense'First + Offset (N, K, L)) = Value_At (P, Mass, K, L) [possible fix: precondition of subprogram at mj-compact_inertia.ads:52 should mention Mass] [provers reached time limit before completing the proof]

