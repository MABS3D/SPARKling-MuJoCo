# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-uflmk30v/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 78` | `mj-data-inertia_phase.adb:78` | [unproved_checks](logs/mj-data-inertia_phase__adb_line_78.log) | 1 | 1 | 0 | 92.8 |
| `line 128` | `mj-data-inertia_phase.adb:128` | [unproved_checks](logs/mj-data-inertia_phase__adb_line_128.log) | 8 | 1 | 0 | 83.3 |

## Diagnostics

### mj-data-inertia_phase__adb_line_78

- `mj-data-inertia_phase.adb:78` (medium): precondition might fail, cannot prove Row < AR.Size (P) [provers reached time and memory limit before completing the proof]

### mj-data-inertia_phase__adb_line_128

- `mj-data-inertia_phase.adb:128` (medium): range check might fail [reason for check: slice bounds must fit in the underlying array] [provers reached time and memory limit before completing the proof]

