# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-74me2njk/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Mass_Bounded` | `mj-data.ads:531` | [completed_no_unproved](logs/mj-data__mass_bounded__ads_531.log) | 6 | 0 | 0 | 22.2 |
| `Mass_Entry` | `mj-data.ads:723` | [completed_no_unproved](logs/mj-data__mass_entry__ads_723.log) | 5 | 0 | 0 | 9.9 |
| `Symmetric_Mass` | `mj-data.ads:755` | [completed_no_unproved](logs/mj-data__symmetric_mass__ads_755.log) | 12 | 0 | 0 | 25.2 |
| `Invalidate` | `mj-data.adb:74` | [completed_with_warnings](logs/mj-data__invalidate__adb_74.log) | 1 | 0 | 0 | 6.6 |
| `Get_Mass_Matrix` | `mj-data.adb:1212` | [unproved_checks](logs/mj-data__get_mass_matrix__adb_1212.log) | 15 | 1 | 0 | 38.0 |
| `Prove_Readiness_Compatibility` | `mj-data.adb:25` | [completed_no_unproved](logs/mj-data__prove_readiness_compatibility__adb_25.log) | 2 | 0 | 0 | 12.4 |
| `Phase_Ready` | `mj-data.ads:653` | [completed_no_unproved](logs/mj-data__phase_ready__ads_653.log) | 1 | 0 | 0 | 8.1 |

## Diagnostics

### mj-data__invalidate__adb_74

- `mj-data.ads:766` (warning): unused initial value of "Cache"

### mj-data__get_mass_matrix__adb_1212

- `mj-data.ads:224` (medium): postcondition might fail, cannot prove Dense (Dense'First + (I * Velocity_Count (D) + J)) = Mass_Entry (D, I, J) [provers reached time limit before completing the proof]

