# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-bgc9_40b/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 59` | `mj-data-inertia_phase.adb:59` | [completed_no_unproved](logs/mj-data-inertia_phase__adb_line_59.log) | 2 | 0 | 0 | 67.0 |
| `line 84` | `mj-data-inertia_phase.adb:84` | [unproved_checks](logs/mj-data-inertia_phase__adb_line_84.log) | 1 | 1 | 0 | 74.5 |

## Diagnostics

### mj-data-inertia_phase__adb_line_84

- `mj-data-inertia_phase.adb:84` (medium): precondition might fail, cannot prove X in -1.0e12 .. 1.0e12 [provers reached time and memory limit before completing the proof]

