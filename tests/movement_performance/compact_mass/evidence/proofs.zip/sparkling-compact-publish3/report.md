# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-_m5xgn1k/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 135` | `mj-data-inertia_phase.adb:135` | [unproved_checks](logs/mj-data-inertia_phase__adb_line_135.log) | 8 | 1 | 0 | 91.3 |
| `line 137` | `mj-data-inertia_phase.adb:137` | [completed_no_proof_checks](logs/mj-data-inertia_phase__adb_line_137.log) | 0 | 0 | 0 | 50.8 |

## Diagnostics

### mj-data-inertia_phase__adb_line_135

- `mj-data-inertia_phase.adb:135` (medium): range check might fail [reason for check: slice bounds must fit in the underlying array] [provers reached time and memory limit before completing the proof]

