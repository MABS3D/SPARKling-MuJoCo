# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-5y016wbh/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Get_Mass_Matrix` | `mj-data.adb:1212` | [unproved_checks](logs/mj-data__get_mass_matrix__adb_1212.log) | 21 | 1 | 0 | 61.4 |

## Diagnostics

### mj-data__get_mass_matrix__adb_1212

- `mj-data.adb:1232` (medium): assertion might fail, cannot prove Dense (Dense'First + (I * D.Nv + J)) = Mass_Entry (D, I, J) [provers reached time limit before completing the proof]

