# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-yncdbkr0/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Lower_Entry` | `mj-compact_inertia.adb:2` | [completed_no_unproved](logs/mj-compact_inertia__lower_entry__adb_2.log) | 19 | 0 | 0 | 5.6 |
| `Projected` | `mj-compact_inertia.adb:36` | [completed_no_unproved](logs/mj-compact_inertia__projected__adb_36.log) | 7 | 0 | 0 | 14.9 |
| `Project_Row` | `mj-compact_inertia.adb:42` | [unproved_checks](logs/mj-compact_inertia__project_row__adb_42.log) | 33 | 1 | 0 | 76.7 |
| `Expand` | `mj-compact_inertia.adb:17` | [unproved_checks](logs/mj-compact_inertia__expand__adb_17.log) | 42 | 8 | 0 | 142.5 |

## Diagnostics

### mj-compact_inertia__project_row__adb_42

- `mj-compact_inertia.ads:64` (medium): range check might fail, cannot prove upper bound for Target'Length [provers reached time limit before completing the proof]

### mj-compact_inertia__expand__adb_17

- `mj-compact_inertia.adb:26` (medium): loop invariant might fail in first iteration, cannot prove Dense (Dense'First + K * N + L) = Value_At (P, Mass, K, L) [provers reached time limit before completing the proof]
- `mj-compact_inertia.adb:26` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Dense (Dense'First + K * N + L) = Value_At (P, Mass, K, L) [provers reached time limit before completing the proof]
- `mj-compact_inertia.ads:40` (medium): overflow check might fail, cannot prove upper bound for Dense'First + I * AR.Size (P) + J [reason for check: result of addition must fit in a 32-bits machine integer] [possible fix: use pragma Overflow_Mode or switch -gnato13 or unit SPARK.Big_Integers] [provers reached time limit before completing the proof]
- `mj-compact_inertia.ads:43` (medium): postcondition might fail, cannot prove Dense (Dense'First + I * AR.Size (P) + J) = Dense (Dense'First + J * AR.Size (P) + I) [provers reached time limit before completing the proof]
- `mj-compact_inertia.ads:43` (medium): overflow check might fail, cannot prove upper bound for Dense'First + I * AR.Size (P) + J [reason for check: result of addition must fit in a 32-bits machine integer] [possible fix: use pragma Overflow_Mode or switch -gnato13 or unit SPARK.Big_Integers] [provers reached time limit before completing the proof]
- `mj-compact_inertia.ads:43` (medium): array index check might fail [reason for check: result of addition must be a valid index into the array] [provers reached time limit before completing the proof]
- `mj-compact_inertia.ads:44` (medium): overflow check might fail, cannot prove upper bound for Dense'First + J * AR.Size (P) + I [reason for check: result of addition must fit in a 32-bits machine integer] [possible fix: use pragma Overflow_Mode or switch -gnato13 or unit SPARK.Big_Integers] [provers reached time limit before completing the proof]
- `mj-compact_inertia.ads:44` (medium): array index check might fail [reason for check: result of addition must be a valid index into the array] [provers reached time limit before completing the proof]

