# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-j6dbatzt/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Expand_Row` | `mj-compact_inertia.adb:17` | [unproved_checks](logs/mj-compact_inertia__expand_row__adb_17.log) | 13 | 4 | 0 | 6.3 |
| `Expand` | `mj-compact_inertia.adb:27` | [unproved_checks](logs/mj-compact_inertia__expand__adb_27.log) | 26 | 1 | 0 | 20.4 |

## Diagnostics

### mj-compact_inertia__expand_row__adb_17

- `mj-compact_inertia.adb:23` (medium): "Target" might not be initialized
- `mj-compact_inertia.ads:39` (medium): "Target" might not be initialized in "Expand_Row" [reason for check: OUT parameter should be fully initialized on return] [possible fix: initialize "Target" on all paths, make "Target" an IN OUT parameter or annotate it with aspect Relaxed_Initialization]
- `mj-compact_inertia.ads:45` (medium): "Target" might not be initialized
- `mj-compact_inertia.ads:39` (medium): "Target" might not be initialized in "Expand_Row"

### mj-compact_inertia__expand__adb_27

- `mj-compact_inertia.adb:36` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove Dense (Dense'First + Offset (N, K, L)) = Value_At (P, Mass, K, L) [possible fix: precondition of subprogram at mj-compact_inertia.ads:47 should mention Mass] [provers reached time limit before completing the proof]

