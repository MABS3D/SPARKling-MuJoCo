# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-koik4nyo/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Expand` | `mj-compact_inertia.adb:39` | [analysis_error](logs/mj-compact_inertia__expand__adb_39.log) | 0 | 0 | 1 | 3.1 |

## Diagnostics

### mj-compact_inertia__expand__adb_39

- `mj-compact_inertia.adb:50` (error): non-scalar object or object with address clause declared before loop-invariant is not yet supported

