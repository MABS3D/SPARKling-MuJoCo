# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-hfn48204/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 61` | `mj-data-inertia_phase.adb:61` | [unproved_checks](logs/mj-data-inertia_phase__adb_line_61.log) | 3 | 1 | 0 | 89.2 |

## Diagnostics

### mj-data-inertia_phase__adb_line_61

- `mj-data-inertia_phase.adb:61` (medium): pointer dereference check might fail [provers reached time and memory limit before completing the proof]

