# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4dufuzmu/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Compute` | `mj-data-actuation_phase.adb:2` | [unproved_checks](logs/mj-data-actuation_phase__compute__adb_2.log) | 33 | 1 | 0 | 121.2 |
| `Compute` | `mj-smooth_actuation.adb:39` | [completed_no_unproved](logs/mj-smooth_actuation__compute__adb_39.log) | 80 | 0 | 0 | 32.3 |

## Diagnostics

### mj-data-actuation_phase__compute__adb_2

- `mj-data-actuation_phase.ads:19` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time and memory limit before completing the proof]

