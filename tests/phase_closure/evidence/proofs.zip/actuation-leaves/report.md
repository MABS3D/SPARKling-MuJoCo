# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-b_2veu4v/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Transmission` | `mj-smooth_kernels.adb:2` | [completed_no_unproved](logs/mj-smooth_kernels__transmission__adb_2.log) | 3 | 0 | 0 | 4.1 |
| `Control_Value` | `mj-smooth_kernels.adb:4` | [completed_no_unproved](logs/mj-smooth_kernels__control_value__adb_4.log) | 4 | 0 | 0 | 3.3 |
| `Affine_Force` | `mj-smooth_kernels.adb:7` | [completed_no_unproved](logs/mj-smooth_kernels__affine_force__adb_7.log) | 19 | 0 | 0 | 15.2 |
| `Project_Force` | `mj-smooth_kernels.adb:19` | [completed_no_unproved](logs/mj-smooth_kernels__project_force__adb_19.log) | 4 | 0 | 0 | 3.6 |
| `Euler_Value` | `mj-smooth_kernels.adb:82` | [completed_no_unproved](logs/mj-smooth_kernels__euler_value__adb_82.log) | 6 | 0 | 0 | 3.8 |
| `Equal_Transitive` | `mj-smooth_kernels.adb:87` | [completed_no_unproved](logs/mj-smooth_kernels__equal_transitive__adb_87.log) | 1 | 0 | 0 | 3.8 |

## Diagnostics

