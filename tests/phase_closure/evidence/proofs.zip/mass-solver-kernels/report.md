# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-htvk95dw/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Try_Assemble_CRB` | `mj-data-inertia_phase.adb:16` | [proof_timeout](logs/mj-data-inertia_phase__try_assemble_crb__adb_16.log) | 0 | 0 | 0 | 300.3 |
| `Load_Ancestor_Factor` | `mj-data-inertia_phase.adb:416` | [unproved_checks](logs/mj-data-inertia_phase__load_ancestor_factor__adb_416.log) | 32 | 4 | 0 | 113.0 |
| `Damping_Present` | `mj-data-inertia_phase.adb:612` | [completed_no_unproved](logs/mj-data-inertia_phase__damping_present__adb_612.log) | 9 | 0 | 0 | 11.1 |

## Diagnostics

### mj-data-inertia_phase__load_ancestor_factor__adb_416

- `mj-data-inertia_phase.adb:422` (medium): postcondition might fail, cannot prove State_Values (D) = State_Values (D)'Old [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:453` (medium): loop invariant might fail in first iteration [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:457` (medium): assertion might fail, cannot prove Storage_Ready (D) [provers reached time and memory limit before completing the proof]
- `mj-data-inertia_phase.adb:457` (medium): in inlined expression function body at mj-data.ads:633

