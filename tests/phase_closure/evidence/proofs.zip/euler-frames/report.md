# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-36w6vqa1/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Integrate` | `mj-data-euler.adb:5` | [unproved_checks](logs/mj-data-euler__integrate__adb_5.log) | 64 | 17 | 0 | 289.2 |

## Diagnostics

### mj-data-euler__integrate__adb_5

- `mj-data-euler.adb:23` (medium): precondition might fail, cannot prove Ctrl'First = 0 [provers reached time limit before completing the proof]
- `mj-data-euler.adb:31` (medium): precondition might fail, cannot prove A'First = B'First [provers reached time limit before completing the proof]
- `mj-data-euler.adb:31` (medium): in inlined expression function body at mj-smooth_kernels.ads:69
- `mj-data-euler.adb:32` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data-euler.adb:33` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data-euler.adb:33` (medium): pointer dereference check might fail [provers reached time limit before completing the proof]
- `mj-data-euler.adb:34` (medium): assertion might fail, cannot prove Stable_Ready (D) [provers reached time and memory limit before completing the proof]
- `mj-data-euler.adb:34` (medium): in inlined expression function body at mj-data.ads:637
- 9 more diagnostics in the individual log.

