# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-vawo8s0p/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Compute` | `mj-data-actuation_phase.adb:41` | [unproved_checks](logs/mj-data-actuation_phase__compute__adb_41.log) | 11 | 1 | 0 | 52.5 |

## Diagnostics

### mj-data-actuation_phase__compute__adb_41

- `mj-data-actuation_phase.ads:23` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached memory limit before completing the proof]

