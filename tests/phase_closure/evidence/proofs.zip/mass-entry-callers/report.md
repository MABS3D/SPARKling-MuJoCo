# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-ww8x1nb0/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `line 754` | `mj-data-pipeline.adb:754` | [completed_no_unproved](logs/mj-data-pipeline__adb_line_754.log) | 1 | 0 | 0 | 49.4 |
| `line 10` | `mj-data-inertia.adb:10` | [completed_no_unproved](logs/mj-data-inertia__adb_line_10.log) | 1 | 0 | 0 | 8.1 |

## Diagnostics

