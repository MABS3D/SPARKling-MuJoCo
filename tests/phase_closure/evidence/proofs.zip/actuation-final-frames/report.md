# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4xkhsneu/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Compute` | `mj-data-actuation_phase.adb:2` | [unproved_checks](logs/mj-data-actuation_phase__compute__adb_2.log) | 37 | 3 | 0 | 175.4 |

## Diagnostics

### mj-data-actuation_phase__compute__adb_2

- `mj-data-actuation_phase.adb:44` (medium): assertion might fail [provers reached time and memory limit before completing the proof]
- `mj-data-actuation_phase.adb:45` (medium): assertion might fail [provers reached time and memory limit before completing the proof]
- `mj-data-actuation_phase.ads:23` (medium): postcondition might fail, cannot prove Configuration (D) = Configuration (D)'Old [provers reached time and memory limit before completing the proof]

