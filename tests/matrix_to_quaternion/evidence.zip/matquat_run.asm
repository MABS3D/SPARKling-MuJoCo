0000000000003fc0 <matquat_run>:
    3fc0:	85 ff                	test   edi,edi
    3fc2:	0f 84 ec 02 00 00    	je     42b4 <matquat_run+0x2f4>
    3fc8:	c5 fb 10 25 f0 6a 02 	vmovsd xmm4,QWORD PTR [rip+0x26af0]        # 2aac0 <_fini+0x54>
    3fcf:	00 
    3fd0:	c5 fb 10 2d 80 8c 02 	vmovsd xmm5,QWORD PTR [rip+0x28c80]        # 2cc58 <system__os_lib__standin+0xc>
    3fd7:	00 
    3fd8:	48 89 d1             	mov    rcx,rdx
    3fdb:	45 31 c9             	xor    r9d,r9d
    3fde:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
    3fe2:	31 d2                	xor    edx,edx
    3fe4:	49 89 c8             	mov    r8,rcx
    3fe7:	48 89 f0             	mov    rax,rsi
    3fea:	c5 fb 10 50 20       	vmovsd xmm2,QWORD PTR [rax+0x20]
    3fef:	c5 fb 10 08          	vmovsd xmm1,QWORD PTR [rax]
    3ff3:	c5 fb 10 40 40       	vmovsd xmm0,QWORD PTR [rax+0x40]
    3ff8:	c5 eb 58 f1          	vaddsd xmm6,xmm2,xmm1
    3ffc:	c5 cb 58 f0          	vaddsd xmm6,xmm6,xmm0
    4000:	c5 f9 2f f3          	vcomisd xmm6,xmm3
    4004:	77 3a                	ja     4040 <matquat_run+0x80>
    4006:	c5 f9 2f ca          	vcomisd xmm1,xmm2
    400a:	41 0f 97 c3          	seta   r11b
    400e:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    4012:	41 0f 97 c2          	seta   r10b
    4016:	45 84 d3             	test   r11b,r10b
    4019:	0f 85 f2 01 00 00    	jne    4211 <matquat_run+0x251>
    401f:	c5 f9 2f d0          	vcomisd xmm2,xmm0
    4023:	c5 db 5c c9          	vsubsd xmm1,xmm4,xmm1
    4027:	0f 86 89 01 00 00    	jbe    41b6 <matquat_run+0x1f6>
    402d:	c5 eb 58 d1          	vaddsd xmm2,xmm2,xmm1
    4031:	41 ba 02 00 00 00    	mov    r10d,0x2
    4037:	c5 eb 5c c0          	vsubsd xmm0,xmm2,xmm0
    403b:	eb 12                	jmp    404f <matquat_run+0x8f>
    403d:	0f 1f 00             	nop    DWORD PTR [rax]
    4040:	c5 f3 58 cc          	vaddsd xmm1,xmm1,xmm4
    4044:	45 31 d2             	xor    r10d,r10d
    4047:	c5 f3 58 ca          	vaddsd xmm1,xmm1,xmm2
    404b:	c5 f3 58 c0          	vaddsd xmm0,xmm1,xmm0
    404f:	c5 f9 2f c3          	vcomisd xmm0,xmm3
    4053:	0f 84 27 01 00 00    	je     4180 <matquat_run+0x1c0>
    4059:	c5 f9 54 05 1f 8d 02 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x28d1f]        # 2cd80 <system__secondary_stack__invalid_memory_size+0xa8>
    4060:	00 
    4061:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    4065:	c5 fb 59 c5          	vmulsd xmm0,xmm0,xmm5
    4069:	c5 f9 2f 05 ef 8b 02 	vcomisd xmm0,QWORD PTR [rip+0x28bef]        # 2cc60 <system__os_lib__standin+0x14>
    4070:	00 
    4071:	0f 82 09 01 00 00    	jb     4180 <matquat_run+0x1c0>
    4077:	c5 f9 2f 05 e9 8b 02 	vcomisd xmm0,QWORD PTR [rip+0x28be9]        # 2cc68 <system__os_lib__standin+0x1c>
    407e:	00 
    407f:	0f 87 fb 00 00 00    	ja     4180 <matquat_run+0x1c0>
    4085:	c5 fb 10 78 30       	vmovsd xmm7,QWORD PTR [rax+0x30]
    408a:	c5 7b 10 50 10       	vmovsd xmm10,QWORD PTR [rax+0x10]
    408f:	c5 fb 10 70 18       	vmovsd xmm6,QWORD PTR [rax+0x18]
    4094:	c5 7b 10 40 08       	vmovsd xmm8,QWORD PTR [rax+0x8]
    4099:	c5 fb 10 48 38       	vmovsd xmm1,QWORD PTR [rax+0x38]
    409e:	c5 fb 10 50 28       	vmovsd xmm2,QWORD PTR [rax+0x28]
    40a3:	41 83 fa 01          	cmp    r10d,0x1
    40a7:	0f 84 b5 01 00 00    	je     4262 <matquat_run+0x2a2>
    40ad:	41 83 fa 02          	cmp    r10d,0x2
    40b1:	0f 84 12 01 00 00    	je     41c9 <matquat_run+0x209>
    40b7:	45 85 d2             	test   r10d,r10d
    40ba:	0f 85 68 01 00 00    	jne    4228 <matquat_run+0x268>
    40c0:	c5 7b 10 1d a8 8b 02 	vmovsd xmm11,QWORD PTR [rip+0x28ba8]        # 2cc70 <system__os_lib__standin+0x24>
    40c7:	00 
    40c8:	c5 f3 5c ca          	vsubsd xmm1,xmm1,xmm2
    40cc:	c5 2b 5c d7          	vsubsd xmm10,xmm10,xmm7
    40d0:	c4 c1 4b 5c f0       	vsubsd xmm6,xmm6,xmm8
    40d5:	c4 c1 73 59 cb       	vmulsd xmm1,xmm1,xmm11
    40da:	c4 41 2b 59 d3       	vmulsd xmm10,xmm10,xmm11
    40df:	c4 c1 4b 59 f3       	vmulsd xmm6,xmm6,xmm11
    40e4:	c5 73 5e c8          	vdivsd xmm9,xmm1,xmm0
    40e8:	c5 ab 5e d0          	vdivsd xmm2,xmm10,xmm0
    40ec:	c5 cb 5e f0          	vdivsd xmm6,xmm6,xmm0
    40f0:	c4 c1 33 59 f9       	vmulsd xmm7,xmm9,xmm9
    40f5:	c5 fb 59 c8          	vmulsd xmm1,xmm0,xmm0
    40f9:	c5 f3 58 cf          	vaddsd xmm1,xmm1,xmm7
    40fd:	c5 eb 59 fa          	vmulsd xmm7,xmm2,xmm2
    4101:	c5 f3 58 cf          	vaddsd xmm1,xmm1,xmm7
    4105:	c5 cb 59 fe          	vmulsd xmm7,xmm6,xmm6
    4109:	c5 f3 58 cf          	vaddsd xmm1,xmm1,xmm7
    410d:	c5 fb 10 3d 4b 8b 02 	vmovsd xmm7,QWORD PTR [rip+0x28b4b]        # 2cc60 <system__os_lib__standin+0x14>
    4114:	00 
    4115:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    4119:	c5 f9 2f f9          	vcomisd xmm7,xmm1
    411d:	0f 87 dc 00 00 00    	ja     41ff <matquat_run+0x23f>
    4123:	c4 41 79 14 c9       	vunpcklpd xmm9,xmm0,xmm9
    4128:	c5 f3 5c c4          	vsubsd xmm0,xmm1,xmm4
    412c:	c5 f9 54 05 4c 8c 02 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x28c4c]        # 2cd80 <system__secondary_stack__invalid_memory_size+0xa8>
    4133:	00 
    4134:	c5 e9 14 d6          	vunpcklpd xmm2,xmm2,xmm6
    4138:	62 73 b5 28 18 ca 01 	vinsertf64x2 ymm9,ymm9,xmm2,0x1
    413f:	c5 f9 2f c7          	vcomisd xmm0,xmm7
    4143:	0f 87 53 01 00 00    	ja     429c <matquat_run+0x2dc>
    4149:	c4 41 7d 11 08       	vmovupd YMMWORD PTR [r8],ymm9
    414e:	48 ff c2             	inc    rdx
    4151:	48 83 c0 48          	add    rax,0x48
    4155:	49 83 c0 20          	add    r8,0x20
    4159:	48 83 fa 40          	cmp    rdx,0x40
    415d:	0f 85 87 fe ff ff    	jne    3fea <matquat_run+0x2a>
    4163:	41 ff c1             	inc    r9d
    4166:	44 39 cf             	cmp    edi,r9d
    4169:	0f 85 73 fe ff ff    	jne    3fe2 <matquat_run+0x22>
    416f:	c5 f8 77             	vzeroupper
    4172:	c3                   	ret
    4173:	66 90                	xchg   ax,ax
    4175:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    417c:	00 00 00 00 
    4180:	c5 fd 28 05 38 69 02 	vmovapd ymm0,YMMWORD PTR [rip+0x26938]        # 2aac0 <_fini+0x54>
    4187:	00 
    4188:	55                   	push   rbp
    4189:	48 8d 35 d0 81 02 00 	lea    rsi,[rip+0x281d0]        # 2c360 <prefix.9+0xc20>
    4190:	48 8d 3d 49 68 03 00 	lea    rdi,[rip+0x36849]        # 3a9e0 <program_error>
    4197:	48 c1 e2 05          	shl    rdx,0x5
    419b:	48 89 e5             	mov    rbp,rsp
    419e:	48 83 e4 e0          	and    rsp,0xffffffffffffffe0
    41a2:	c5 fd 11 04 11       	vmovupd YMMWORD PTR [rcx+rdx*1],ymm0
    41a7:	48 8d 15 da 68 02 00 	lea    rdx,[rip+0x268da]        # 2aa88 <_fini+0x1c>
    41ae:	c5 f8 77             	vzeroupper
    41b1:	e8 52 30 00 00       	call   7208 <__gnat_raise_exception>
    41b6:	c5 f3 5c ca          	vsubsd xmm1,xmm1,xmm2
    41ba:	41 ba 03 00 00 00    	mov    r10d,0x3
    41c0:	c5 f3 58 c0          	vaddsd xmm0,xmm1,xmm0
    41c4:	e9 86 fe ff ff       	jmp    404f <matquat_run+0x8f>
    41c9:	c5 2b 5c d7          	vsubsd xmm10,xmm10,xmm7
    41cd:	c5 fb 10 3d 9b 8a 02 	vmovsd xmm7,QWORD PTR [rip+0x28a9b]        # 2cc70 <system__os_lib__standin+0x24>
    41d4:	00 
    41d5:	c5 f3 58 ca          	vaddsd xmm1,xmm1,xmm2
    41d9:	c5 f9 28 d0          	vmovapd xmm2,xmm0
    41dd:	c4 c1 4b 58 f0       	vaddsd xmm6,xmm6,xmm8
    41e2:	c5 2b 59 d7          	vmulsd xmm10,xmm10,xmm7
    41e6:	c5 cb 59 f7          	vmulsd xmm6,xmm6,xmm7
    41ea:	c5 f3 59 cf          	vmulsd xmm1,xmm1,xmm7
    41ee:	c5 4b 5e c8          	vdivsd xmm9,xmm6,xmm0
    41f2:	c5 f3 5e f0          	vdivsd xmm6,xmm1,xmm0
    41f6:	c5 ab 5e c0          	vdivsd xmm0,xmm10,xmm0
    41fa:	e9 f1 fe ff ff       	jmp    40f0 <matquat_run+0x130>
    41ff:	c5 fd 28 05 b9 68 02 	vmovapd ymm0,YMMWORD PTR [rip+0x268b9]        # 2aac0 <_fini+0x54>
    4206:	00 
    4207:	c4 c1 7d 11 00       	vmovupd YMMWORD PTR [r8],ymm0
    420c:	e9 3d ff ff ff       	jmp    414e <matquat_run+0x18e>
    4211:	c5 f3 58 cc          	vaddsd xmm1,xmm1,xmm4
    4215:	41 ba 01 00 00 00    	mov    r10d,0x1
    421b:	c5 f3 5c ca          	vsubsd xmm1,xmm1,xmm2
    421f:	c5 f3 5c c0          	vsubsd xmm0,xmm1,xmm0
    4223:	e9 27 fe ff ff       	jmp    404f <matquat_run+0x8f>
    4228:	c5 7b 10 1d 40 8a 02 	vmovsd xmm11,QWORD PTR [rip+0x28a40]        # 2cc70 <system__os_lib__standin+0x24>
    422f:	00 
    4230:	c4 c1 4b 5c f0       	vsubsd xmm6,xmm6,xmm8
    4235:	c5 f3 58 ca          	vaddsd xmm1,xmm1,xmm2
    4239:	c4 c1 43 58 fa       	vaddsd xmm7,xmm7,xmm10
    423e:	c4 41 4b 59 c3       	vmulsd xmm8,xmm6,xmm11
    4243:	c4 c1 43 59 fb       	vmulsd xmm7,xmm7,xmm11
    4248:	c5 f9 28 f0          	vmovapd xmm6,xmm0
    424c:	c4 c1 73 59 cb       	vmulsd xmm1,xmm1,xmm11
    4251:	c5 43 5e c8          	vdivsd xmm9,xmm7,xmm0
    4255:	c5 f3 5e d0          	vdivsd xmm2,xmm1,xmm0
    4259:	c5 bb 5e c0          	vdivsd xmm0,xmm8,xmm0
    425d:	e9 8e fe ff ff       	jmp    40f0 <matquat_run+0x130>
    4262:	c5 7b 10 0d 06 8a 02 	vmovsd xmm9,QWORD PTR [rip+0x28a06]        # 2cc70 <system__os_lib__standin+0x24>
    4269:	00 
    426a:	c5 f3 5c ca          	vsubsd xmm1,xmm1,xmm2
    426e:	c4 c1 4b 58 f0       	vaddsd xmm6,xmm6,xmm8
    4273:	c4 c1 43 58 fa       	vaddsd xmm7,xmm7,xmm10
    4278:	c4 c1 4b 59 f1       	vmulsd xmm6,xmm6,xmm9
    427d:	c4 c1 73 59 c9       	vmulsd xmm1,xmm1,xmm9
    4282:	c4 c1 43 59 f9       	vmulsd xmm7,xmm7,xmm9
    4287:	c5 79 28 c8          	vmovapd xmm9,xmm0
    428b:	c5 cb 5e d0          	vdivsd xmm2,xmm6,xmm0
    428f:	c5 c3 5e f0          	vdivsd xmm6,xmm7,xmm0
    4293:	c5 f3 5e c0          	vdivsd xmm0,xmm1,xmm0
    4297:	e9 54 fe ff ff       	jmp    40f0 <matquat_run+0x130>
    429c:	c5 db 5e c9          	vdivsd xmm1,xmm4,xmm1
    42a0:	c4 e2 7d 19 c9       	vbroadcastsd ymm1,xmm1
    42a5:	c4 c1 75 59 c9       	vmulpd ymm1,ymm1,ymm9
    42aa:	c4 c1 7d 11 08       	vmovupd YMMWORD PTR [r8],ymm1
    42af:	e9 9a fe ff ff       	jmp    414e <matquat_run+0x18e>
    42b4:	c3                   	ret
    42b5:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    42bc:	00 00 00 
    42bf:	90                   	nop
