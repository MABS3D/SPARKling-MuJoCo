from pathlib import Path
import hashlib, json, subprocess, zipfile, sys, re
repo=Path(sys.argv[1]); run=Path(sys.argv[2]); target=repo/'tests/matrix_to_quaternion'
commands=json.loads((run/'commands-all.json').read_text())
assert commands[-1]['name']=='performance-2' and all(x['code']==0 for x in commands)
manifest=json.loads((run/'source-manifest.json').read_text())
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
proofs={}
for unit in ['mj-quaternions','mj-poses','mj-rotations']:
    d=json.loads((run/'logs'/f'{unit}.spark').read_text())
    warnings=[m for section in ['proof','flow','warn_error'] for m in d[section] if m.get('severity')=='warning']
    assert not [m for section in ['proof','flow','warn_error'] for m in d[section] if m.get('severity') not in ('info','warning')]
    assert not d['skip_proof'] and not d['skip_flow_proof'] and not d['pragma_assume']
    assert d['progress']=='PROGRESS_PROOF' and d['stop_reason']=='STOP_REASON_NONE'
    proofs[unit]={'proof_checks':sum(m['severity']=='info' for m in d['proof']),
                 'flow_checks':sum(m['severity']=='info' for m in d['flow']), 'warnings':warnings}
numerics={}
for path in sorted((run/'logs').glob('numeric-*.log')):
    numerics[path.stem]=json.loads(path.read_text().splitlines()[0])
performance=[json.loads((run/f'performance-{s}.json').read_text()) for s in (1,2)]
binaries={}
for suite in ['matrix_to_quaternion','quaternions','poses']:
    for mode in ['development','validation','release']:
        path=run/'snapshot/tests'/suite/'build'/mode/'bin/main'
        binaries[f'{suite}/{mode}']=hashlib.sha256(path.read_bytes()).hexdigest()
summary={'scope':'complete quaternion, pose and rotation units, including existing code; no whole-engine or ideal-real accuracy claim',
         'source_sha256':{p:h for p,h in manifest.items() if p.startswith('src/')},
         'proofs':proofs,'numerics':numerics,'binary_sha256':binaries,
         'performance':[{k:v for k,v in d.items() if k!='results'} | {'results':[{k:v for k,v in row.items() if k!='samples'} for row in d['results']]} for d in performance]}
(run/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(target/'results.json').write_text((run/'summary.json').read_text())
binary=run/'snapshot/tests/matrix_to_quaternion/build/release/bin/main'
assembly=subprocess.check_output(['objdump','-d','-Mintel',str(binary)],text=True)
for name in ['matquat_run','c_run']:
    match=re.search(r'^([0-9a-f]+ <'+name+r'>:.*?)(?=\n\n)',assembly,re.M|re.S)
    assert match
    (run/f'{name}.asm').write_text(match[1]+'\n')
    assert not re.search(r'\bv(?:f|fn)m(?:add|sub)',match[1])
symbols=subprocess.check_output(['nm','--defined-only',str(binary)],text=True)
assert 'quaternions__model__' not in symbols and 'equal_normalization' not in symbols
(run/'codegen.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
 'no_fma_in_measured_wrappers':True,'no_executable_quaternion_ghost_model_or_congruence_symbols':True},indent=2)+'\n')
contents={}
for relative in manifest:contents['snapshot/'+relative]=(run/'snapshot'/relative).read_bytes()
contents['snapshot/tests/matrix_to_quaternion/proof.gpr']=(run/'snapshot/tests/matrix_to_quaternion/proof.gpr').read_bytes()
for path in sorted((run/'logs').glob('*')):
    if path.is_file():contents['logs/'+path.name]=path.read_bytes()
for path in sorted(run.iterdir()):
    if path.is_file() and path.suffix in ['.json','.asm','.log']:
        contents[path.name]=path.read_bytes()
for session in (1,2):
    lines=(run/f'host-session{session}.txt').read_text().splitlines()
    contents[f'host-provers-session{session}.txt']=('\n'.join(line for line in lines if re.search(r'gnatprove|gnatwhy3|cvc5|altergo|gprbuild|loadavg:',line))+'\n').encode()
contents['package_results.py']=Path(__file__).read_bytes()
contents['SHA256SUMS']=(''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(contents.items()))).encode()
archive=target/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(contents.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS').decode().splitlines():
        h,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==h
(target/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in [archive,target/'results.json']))
print(json.dumps({'proofs':{k:{'proof':v['proof_checks'],'flow':v['flow_checks'],'warnings':len(v['warnings'])} for k,v in proofs.items()},'archive_files':len(contents),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
