0000000000004550 <c_run>:
    4550:	48 89 f1             	mov    rcx,rsi
    4553:	48 89 d6             	mov    rsi,rdx
    4556:	85 ff                	test   edi,edi
    4558:	0f 84 6b 01 00 00    	je     46c9 <c_run+0x179>
    455e:	c5 fb 10 25 5a 65 02 	vmovsd xmm4,QWORD PTR [rip+0x2655a]        # 2aac0 <_fini+0x54>
    4565:	00 
    4566:	c5 fb 10 3d ea 86 02 	vmovsd xmm7,QWORD PTR [rip+0x286ea]        # 2cc58 <system__os_lib__standin+0xc>
    456d:	00 
    456e:	c5 fb 10 1d fa 86 02 	vmovsd xmm3,QWORD PTR [rip+0x286fa]        # 2cc70 <system__os_lib__standin+0x24>
    4575:	00 
    4576:	c5 fb 10 2d e2 86 02 	vmovsd xmm5,QWORD PTR [rip+0x286e2]        # 2cc60 <system__os_lib__standin+0x14>
    457d:	00 
    457e:	c5 7d 28 05 3a 65 02 	vmovapd ymm8,YMMWORD PTR [rip+0x2653a]        # 2aac0 <_fini+0x54>
    4585:	00 
    4586:	45 31 c0             	xor    r8d,r8d
    4589:	4c 8d 89 00 12 00 00 	lea    r9,[rcx+0x1200]
    4590:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    4594:	90                   	nop
    4595:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    459c:	00 00 00 00 
    45a0:	48 89 c8             	mov    rax,rcx
    45a3:	48 89 f2             	mov    rdx,rsi
    45a6:	eb 4c                	jmp    45f4 <c_run+0xa4>
    45a8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    45af:	00 
    45b0:	c5 6b 5c dc          	vsubsd xmm11,xmm2,xmm4
    45b4:	c5 21 54 1d c4 87 02 	vandpd xmm11,xmm11,XMMWORD PTR [rip+0x287c4]        # 2cd80 <system__secondary_stack__invalid_memory_size+0xa8>
    45bb:	00 
    45bc:	c5 79 2f dd          	vcomisd xmm11,xmm5
    45c0:	76 21                	jbe    45e3 <c_run+0x93>
    45c2:	c5 db 5e d2          	vdivsd xmm2,xmm4,xmm2
    45c6:	c5 f1 14 c8          	vunpcklpd xmm1,xmm1,xmm0
    45ca:	c4 c1 31 14 c2       	vunpcklpd xmm0,xmm9,xmm10
    45cf:	62 f3 fd 28 18 c1 01 	vinsertf64x2 ymm0,ymm0,xmm1,0x1
    45d6:	c4 e2 7d 19 d2       	vbroadcastsd ymm2,xmm2
    45db:	c5 fd 59 c2          	vmulpd ymm0,ymm0,ymm2
    45df:	c5 fd 11 02          	vmovupd YMMWORD PTR [rdx],ymm0
    45e3:	48 83 c0 48          	add    rax,0x48
    45e7:	48 83 c2 20          	add    rdx,0x20
    45eb:	4c 39 c8             	cmp    rax,r9
    45ee:	0f 84 c6 00 00 00    	je     46ba <c_run+0x16a>
    45f4:	c5 fb 10 08          	vmovsd xmm1,QWORD PTR [rax]
    45f8:	c5 fb 10 50 20       	vmovsd xmm2,QWORD PTR [rax+0x20]
    45fd:	c5 7b 10 48 40       	vmovsd xmm9,QWORD PTR [rax+0x40]
    4602:	c5 f3 58 c2          	vaddsd xmm0,xmm1,xmm2
    4606:	c4 c1 7b 58 c1       	vaddsd xmm0,xmm0,xmm9
    460b:	c5 f9 2f c6          	vcomisd xmm0,xmm6
    460f:	0f 86 bb 00 00 00    	jbe    46d0 <c_run+0x180>
    4615:	c5 f3 58 cc          	vaddsd xmm1,xmm1,xmm4
    4619:	c5 f3 58 ca          	vaddsd xmm1,xmm1,xmm2
    461d:	c4 c1 73 58 c9       	vaddsd xmm1,xmm1,xmm9
    4622:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    4626:	c5 73 59 cf          	vmulsd xmm9,xmm1,xmm7
    462a:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    462e:	c5 7b 10 50 38       	vmovsd xmm10,QWORD PTR [rax+0x38]
    4633:	c5 2b 5c 50 28       	vsubsd xmm10,xmm10,QWORD PTR [rax+0x28]
    4638:	c5 2b 59 d3          	vmulsd xmm10,xmm10,xmm3
    463c:	c4 41 2b 5e d1       	vdivsd xmm10,xmm10,xmm9
    4641:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    4646:	c5 fb 10 48 10       	vmovsd xmm1,QWORD PTR [rax+0x10]
    464b:	c5 f3 5c 48 30       	vsubsd xmm1,xmm1,QWORD PTR [rax+0x30]
    4650:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
    4654:	c4 c1 73 5e c9       	vdivsd xmm1,xmm1,xmm9
    4659:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    465e:	c5 fb 10 40 18       	vmovsd xmm0,QWORD PTR [rax+0x18]
    4663:	c5 fb 5c 40 08       	vsubsd xmm0,xmm0,QWORD PTR [rax+0x8]
    4668:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    466c:	c4 c1 7b 5e c1       	vdivsd xmm0,xmm0,xmm9
    4671:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    4676:	c4 41 2b 59 da       	vmulsd xmm11,xmm10,xmm10
    467b:	c4 c1 33 59 d1       	vmulsd xmm2,xmm9,xmm9
    4680:	c4 c1 6b 58 d3       	vaddsd xmm2,xmm2,xmm11
    4685:	c5 73 59 d9          	vmulsd xmm11,xmm1,xmm1
    4689:	c4 c1 6b 58 d3       	vaddsd xmm2,xmm2,xmm11
    468e:	c5 7b 59 d8          	vmulsd xmm11,xmm0,xmm0
    4692:	c4 c1 6b 58 d3       	vaddsd xmm2,xmm2,xmm11
    4697:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    469b:	c5 f9 2f ea          	vcomisd xmm5,xmm2
    469f:	0f 86 0b ff ff ff    	jbe    45b0 <c_run+0x60>
    46a5:	48 83 c0 48          	add    rax,0x48
    46a9:	c5 7d 11 02          	vmovupd YMMWORD PTR [rdx],ymm8
    46ad:	48 83 c2 20          	add    rdx,0x20
    46b1:	4c 39 c8             	cmp    rax,r9
    46b4:	0f 85 3a ff ff ff    	jne    45f4 <c_run+0xa4>
    46ba:	41 ff c0             	inc    r8d
    46bd:	44 39 c7             	cmp    edi,r8d
    46c0:	0f 85 da fe ff ff    	jne    45a0 <c_run+0x50>
    46c6:	c5 f8 77             	vzeroupper
    46c9:	c3                   	ret
    46ca:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    46d0:	c4 c1 79 2f c9       	vcomisd xmm1,xmm9
    46d5:	76 0a                	jbe    46e1 <c_run+0x191>
    46d7:	c5 f9 2f ca          	vcomisd xmm1,xmm2
    46db:	0f 87 cf 00 00 00    	ja     47b0 <c_run+0x260>
    46e1:	c4 c1 79 2f d1       	vcomisd xmm2,xmm9
    46e6:	c5 db 5c c9          	vsubsd xmm1,xmm4,xmm1
    46ea:	77 64                	ja     4750 <c_run+0x200>
    46ec:	c5 f3 5c ca          	vsubsd xmm1,xmm1,xmm2
    46f0:	c4 c1 73 58 c9       	vaddsd xmm1,xmm1,xmm9
    46f5:	c5 f3 51 c1          	vsqrtsd xmm0,xmm1,xmm1
    46f9:	c5 fb 59 c7          	vmulsd xmm0,xmm0,xmm7
    46fd:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    4702:	c5 7b 10 48 18       	vmovsd xmm9,QWORD PTR [rax+0x18]
    4707:	c5 33 5c 48 08       	vsubsd xmm9,xmm9,QWORD PTR [rax+0x8]
    470c:	c5 33 59 cb          	vmulsd xmm9,xmm9,xmm3
    4710:	c5 33 5e c8          	vdivsd xmm9,xmm9,xmm0
    4714:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    4718:	c5 7b 10 50 10       	vmovsd xmm10,QWORD PTR [rax+0x10]
    471d:	c5 2b 58 50 30       	vaddsd xmm10,xmm10,QWORD PTR [rax+0x30]
    4722:	c5 2b 59 d3          	vmulsd xmm10,xmm10,xmm3
    4726:	c5 2b 5e d0          	vdivsd xmm10,xmm10,xmm0
    472a:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    472f:	c5 fb 10 48 28       	vmovsd xmm1,QWORD PTR [rax+0x28]
    4734:	c5 f3 58 48 38       	vaddsd xmm1,xmm1,QWORD PTR [rax+0x38]
    4739:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
    473d:	c5 f3 5e c8          	vdivsd xmm1,xmm1,xmm0
    4741:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    4746:	e9 2b ff ff ff       	jmp    4676 <c_run+0x126>
    474b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    4750:	c5 eb 58 c9          	vaddsd xmm1,xmm2,xmm1
    4754:	c4 c1 73 5c c9       	vsubsd xmm1,xmm1,xmm9
    4759:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    475d:	c5 f3 59 cf          	vmulsd xmm1,xmm1,xmm7
    4761:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    4766:	c5 fb 10 40 10       	vmovsd xmm0,QWORD PTR [rax+0x10]
    476b:	c5 fb 5c 40 30       	vsubsd xmm0,xmm0,QWORD PTR [rax+0x30]
    4770:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    4774:	c5 7b 5e c9          	vdivsd xmm9,xmm0,xmm1
    4778:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    477c:	c5 7b 10 50 08       	vmovsd xmm10,QWORD PTR [rax+0x8]
    4781:	c5 2b 58 50 18       	vaddsd xmm10,xmm10,QWORD PTR [rax+0x18]
    4786:	c5 2b 59 d3          	vmulsd xmm10,xmm10,xmm3
    478a:	c5 2b 5e d1          	vdivsd xmm10,xmm10,xmm1
    478e:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    4793:	c5 fb 10 40 28       	vmovsd xmm0,QWORD PTR [rax+0x28]
    4798:	c5 fb 58 40 38       	vaddsd xmm0,xmm0,QWORD PTR [rax+0x38]
    479d:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    47a1:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
    47a5:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    47aa:	e9 c7 fe ff ff       	jmp    4676 <c_run+0x126>
    47af:	90                   	nop
    47b0:	c5 f3 58 c4          	vaddsd xmm0,xmm1,xmm4
    47b4:	c5 fb 5c c2          	vsubsd xmm0,xmm0,xmm2
    47b8:	c4 c1 7b 5c c1       	vsubsd xmm0,xmm0,xmm9
    47bd:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    47c1:	c5 7b 59 d7          	vmulsd xmm10,xmm0,xmm7
    47c5:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    47ca:	c5 fb 10 40 38       	vmovsd xmm0,QWORD PTR [rax+0x38]
    47cf:	c5 fb 5c 40 28       	vsubsd xmm0,xmm0,QWORD PTR [rax+0x28]
    47d4:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    47d8:	c4 41 7b 5e ca       	vdivsd xmm9,xmm0,xmm10
    47dd:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    47e1:	c5 fb 10 48 08       	vmovsd xmm1,QWORD PTR [rax+0x8]
    47e6:	c5 f3 58 48 18       	vaddsd xmm1,xmm1,QWORD PTR [rax+0x18]
    47eb:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
    47ef:	c4 c1 73 5e ca       	vdivsd xmm1,xmm1,xmm10
    47f4:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    47f9:	c5 fb 10 40 10       	vmovsd xmm0,QWORD PTR [rax+0x10]
    47fe:	c5 fb 58 40 30       	vaddsd xmm0,xmm0,QWORD PTR [rax+0x30]
    4803:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    4807:	c4 c1 7b 5e c2       	vdivsd xmm0,xmm0,xmm10
    480c:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    4811:	e9 60 fe ff ff       	jmp    4676 <c_run+0x126>
    4816:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    481d:	00 00 00 
