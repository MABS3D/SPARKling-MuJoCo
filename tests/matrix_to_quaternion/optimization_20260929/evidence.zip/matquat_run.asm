0000000000003fc0 <matquat_run>:
    3fc0:	85 ff                	test   edi,edi
    3fc2:	0f 84 09 03 00 00    	je     42d1 <matquat_run+0x311>
    3fc8:	55                   	push   rbp
    3fc9:	48 89 d1             	mov    rcx,rdx
    3fcc:	45 31 c9             	xor    r9d,r9d
    3fcf:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
    3fd3:	48 89 e5             	mov    rbp,rsp
    3fd6:	48 83 e4 c0          	and    rsp,0xffffffffffffffc0
    3fda:	48 83 ec 40          	sub    rsp,0x40
    3fde:	c5 fb 10 1d 1a 6b 02 	vmovsd xmm3,QWORD PTR [rip+0x26b1a]        # 2ab00 <_fini+0x54>
    3fe5:	00 
    3fe6:	c5 fb 10 25 b2 6b 02 	vmovsd xmm4,QWORD PTR [rip+0x26bb2]        # 2aba0 <__gnat_ada_main_program_name+0x18>
    3fed:	00 
    3fee:	31 d2                	xor    edx,edx
    3ff0:	49 89 c8             	mov    r8,rcx
    3ff3:	48 89 f0             	mov    rax,rsi
    3ff6:	c5 fb 10 68 20       	vmovsd xmm5,QWORD PTR [rax+0x20]
    3ffb:	c5 fb 10 08          	vmovsd xmm1,QWORD PTR [rax]
    3fff:	c5 fb 10 40 40       	vmovsd xmm0,QWORD PTR [rax+0x40]
    4004:	c5 d3 58 f1          	vaddsd xmm6,xmm5,xmm1
    4008:	c5 cb 58 f0          	vaddsd xmm6,xmm6,xmm0
    400c:	c5 f9 2f f2          	vcomisd xmm6,xmm2
    4010:	77 3e                	ja     4050 <matquat_run+0x90>
    4012:	c5 f9 2f cd          	vcomisd xmm1,xmm5
    4016:	41 0f 97 c3          	seta   r11b
    401a:	c5 f9 2f c8          	vcomisd xmm1,xmm0
    401e:	41 0f 97 c2          	seta   r10b
    4022:	45 84 d3             	test   r11b,r10b
    4025:	0f 85 1f 02 00 00    	jne    424a <matquat_run+0x28a>
    402b:	c5 f9 2f e8          	vcomisd xmm5,xmm0
    402f:	c5 e3 5c c9          	vsubsd xmm1,xmm3,xmm1
    4033:	0f 86 b5 01 00 00    	jbe    41ee <matquat_run+0x22e>
    4039:	c5 d3 58 e9          	vaddsd xmm5,xmm5,xmm1
    403d:	41 ba 02 00 00 00    	mov    r10d,0x2
    4043:	c5 d3 5c c0          	vsubsd xmm0,xmm5,xmm0
    4047:	eb 16                	jmp    405f <matquat_run+0x9f>
    4049:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    4050:	c5 f3 58 cb          	vaddsd xmm1,xmm1,xmm3
    4054:	45 31 d2             	xor    r10d,r10d
    4057:	c5 f3 58 cd          	vaddsd xmm1,xmm1,xmm5
    405b:	c5 f3 58 c0          	vaddsd xmm0,xmm1,xmm0
    405f:	c5 f9 2f c2          	vcomisd xmm0,xmm2
    4063:	0f 84 57 01 00 00    	je     41c0 <matquat_run+0x200>
    4069:	c5 f9 54 05 bf 8d 02 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x28dbf]        # 2ce30 <system__secondary_stack__invalid_memory_size+0xa8>
    4070:	00 
    4071:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    4075:	c5 fb 59 ec          	vmulsd xmm5,xmm0,xmm4
    4079:	c5 f9 2f 2d 97 8c 02 	vcomisd xmm5,QWORD PTR [rip+0x28c97]        # 2cd18 <system__os_lib__standin+0xc>
    4080:	00 
    4081:	0f 82 39 01 00 00    	jb     41c0 <matquat_run+0x200>
    4087:	c5 f9 2f 2d 91 8c 02 	vcomisd xmm5,QWORD PTR [rip+0x28c91]        # 2cd20 <system__os_lib__standin+0x14>
    408e:	00 
    408f:	0f 87 2b 01 00 00    	ja     41c0 <matquat_run+0x200>
    4095:	c5 fb 10 70 10       	vmovsd xmm6,QWORD PTR [rax+0x10]
    409a:	c5 7b 10 50 30       	vmovsd xmm10,QWORD PTR [rax+0x30]
    409f:	c5 7b 10 48 08       	vmovsd xmm9,QWORD PTR [rax+0x8]
    40a4:	c5 fb 10 48 18       	vmovsd xmm1,QWORD PTR [rax+0x18]
    40a9:	c5 7b 10 40 28       	vmovsd xmm8,QWORD PTR [rax+0x28]
    40ae:	c5 fb 10 78 38       	vmovsd xmm7,QWORD PTR [rax+0x38]
    40b3:	41 83 fa 01          	cmp    r10d,0x1
    40b7:	0f 84 a4 01 00 00    	je     4261 <matquat_run+0x2a1>
    40bd:	41 83 fa 02          	cmp    r10d,0x2
    40c1:	0f 84 3a 01 00 00    	je     4201 <matquat_run+0x241>
    40c7:	45 85 d2             	test   r10d,r10d
    40ca:	0f 85 c7 01 00 00    	jne    4297 <matquat_run+0x2d7>
    40d0:	c4 c1 43 5c f8       	vsubsd xmm7,xmm7,xmm8
    40d5:	c4 c1 73 5c c9       	vsubsd xmm1,xmm1,xmm9
    40da:	c4 c1 4b 5c f2       	vsubsd xmm6,xmm6,xmm10
    40df:	c5 f9 14 c7          	vunpcklpd xmm0,xmm0,xmm7
    40e3:	c5 f9 28 fd          	vmovapd xmm7,xmm5
    40e7:	c5 c9 14 f1          	vunpcklpd xmm6,xmm6,xmm1
    40eb:	62 f3 fd 28 18 c6 01 	vinsertf64x2 ymm0,ymm0,xmm6,0x1
    40f2:	c5 f9 28 f5          	vmovapd xmm6,xmm5
    40f6:	c5 fd 59 0d a2 6a 02 	vmulpd ymm1,ymm0,YMMWORD PTR [rip+0x26aa2]        # 2aba0 <__gnat_ada_main_program_name+0x18>
    40fd:	00 
    40fe:	c5 f9 28 c3          	vmovapd xmm0,xmm3
    4102:	c5 c9 14 ed          	vunpcklpd xmm5,xmm6,xmm5
    4106:	c5 f9 14 c7          	vunpcklpd xmm0,xmm0,xmm7
    410a:	62 f3 fd 28 18 c5 01 	vinsertf64x2 ymm0,ymm0,xmm5,0x1
    4111:	c5 f5 5e c8          	vdivpd ymm1,ymm1,ymm0
    4115:	c5 f5 59 e9          	vmulpd ymm5,ymm1,ymm1
    4119:	c5 fd 29 0c 24       	vmovapd YMMWORD PTR [rsp],ymm1
    411e:	c4 c1 7e 7f 08       	vmovdqu YMMWORD PTR [r8],ymm1
    4123:	c5 d1 15 f5          	vunpckhpd xmm6,xmm5,xmm5
    4127:	c5 d3 58 c6          	vaddsd xmm0,xmm5,xmm6
    412b:	62 f3 fd 28 19 ee 01 	vextractf64x2 xmm6,ymm5,0x1
    4132:	62 f3 d5 28 03 ed 03 	valignq ymm5,ymm5,ymm5,0x3
    4139:	c5 fb 58 c6          	vaddsd xmm0,xmm0,xmm6
    413d:	c5 fb 58 c5          	vaddsd xmm0,xmm0,xmm5
    4141:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
    4145:	c5 f9 2f c5          	vcomisd xmm0,xmm5
    4149:	0f 84 e9 00 00 00    	je     4238 <matquat_run+0x278>
    414f:	c5 f9 54 05 d9 8c 02 	vandpd xmm0,xmm0,XMMWORD PTR [rip+0x28cd9]        # 2ce30 <system__secondary_stack__invalid_memory_size+0xa8>
    4156:	00 
    4157:	c5 fb 10 35 b9 8b 02 	vmovsd xmm6,QWORD PTR [rip+0x28bb9]        # 2cd18 <system__os_lib__standin+0xc>
    415e:	00 
    415f:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    4163:	c5 f9 2f f0          	vcomisd xmm6,xmm0
    4167:	0f 87 cb 00 00 00    	ja     4238 <matquat_run+0x278>
    416d:	c5 fb 5c eb          	vsubsd xmm5,xmm0,xmm3
    4171:	c5 d1 54 2d b7 8c 02 	vandpd xmm5,xmm5,XMMWORD PTR [rip+0x28cb7]        # 2ce30 <system__secondary_stack__invalid_memory_size+0xa8>
    4178:	00 
    4179:	c5 f9 2f ee          	vcomisd xmm5,xmm6
    417d:	76 12                	jbe    4191 <matquat_run+0x1d1>
    417f:	c5 e3 5e c0          	vdivsd xmm0,xmm3,xmm0
    4183:	c4 e2 7d 19 c0       	vbroadcastsd ymm0,xmm0
    4188:	c5 fd 59 c1          	vmulpd ymm0,ymm0,ymm1
    418c:	c4 c1 7d 11 00       	vmovupd YMMWORD PTR [r8],ymm0
    4191:	48 ff c2             	inc    rdx
    4194:	48 83 c0 48          	add    rax,0x48
    4198:	49 83 c0 20          	add    r8,0x20
    419c:	48 83 fa 40          	cmp    rdx,0x40
    41a0:	0f 85 50 fe ff ff    	jne    3ff6 <matquat_run+0x36>
    41a6:	41 ff c1             	inc    r9d
    41a9:	44 39 cf             	cmp    edi,r9d
    41ac:	0f 85 3c fe ff ff    	jne    3fee <matquat_run+0x2e>
    41b2:	c5 f8 77             	vzeroupper
    41b5:	c9                   	leave
    41b6:	c3                   	ret
    41b7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
    41be:	00 00 
    41c0:	c5 fd 28 05 38 69 02 	vmovapd ymm0,YMMWORD PTR [rip+0x26938]        # 2ab00 <_fini+0x54>
    41c7:	00 
    41c8:	48 8d 35 51 82 02 00 	lea    rsi,[rip+0x28251]        # 2c420 <prefix.9+0xc20>
    41cf:	48 8d 3d 0a 68 03 00 	lea    rdi,[rip+0x3680a]        # 3a9e0 <program_error>
    41d6:	48 c1 e2 05          	shl    rdx,0x5
    41da:	c5 fd 11 04 11       	vmovupd YMMWORD PTR [rcx+rdx*1],ymm0
    41df:	48 8d 15 e2 68 02 00 	lea    rdx,[rip+0x268e2]        # 2aac8 <_fini+0x1c>
    41e6:	c5 f8 77             	vzeroupper
    41e9:	e8 5a 30 00 00       	call   7248 <__gnat_raise_exception>
    41ee:	c5 f3 5c cd          	vsubsd xmm1,xmm1,xmm5
    41f2:	41 ba 03 00 00 00    	mov    r10d,0x3
    41f8:	c5 f3 58 c0          	vaddsd xmm0,xmm1,xmm0
    41fc:	e9 5e fe ff ff       	jmp    405f <matquat_run+0x9f>
    4201:	c5 33 58 c9          	vaddsd xmm9,xmm9,xmm1
    4205:	c5 3b 58 c7          	vaddsd xmm8,xmm8,xmm7
    4209:	c5 f9 28 fd          	vmovapd xmm7,xmm5
    420d:	c4 c1 4b 5c f2       	vsubsd xmm6,xmm6,xmm10
    4212:	c4 c1 79 14 c0       	vunpcklpd xmm0,xmm0,xmm8
    4217:	c4 c1 49 14 f1       	vunpcklpd xmm6,xmm6,xmm9
    421c:	62 f3 cd 28 18 c0 01 	vinsertf64x2 ymm0,ymm6,xmm0,0x1
    4223:	c5 f9 28 f3          	vmovapd xmm6,xmm3
    4227:	c5 fd 59 0d b1 69 02 	vmulpd ymm1,ymm0,YMMWORD PTR [rip+0x269b1]        # 2abe0 <__gnat_ada_main_program_name+0x58>
    422e:	00 
    422f:	c5 f9 28 c5          	vmovapd xmm0,xmm5
    4233:	e9 ca fe ff ff       	jmp    4102 <matquat_run+0x142>
    4238:	c5 fd 28 05 c0 68 02 	vmovapd ymm0,YMMWORD PTR [rip+0x268c0]        # 2ab00 <_fini+0x54>
    423f:	00 
    4240:	c4 c1 7d 11 00       	vmovupd YMMWORD PTR [r8],ymm0
    4245:	e9 47 ff ff ff       	jmp    4191 <matquat_run+0x1d1>
    424a:	c5 f3 58 cb          	vaddsd xmm1,xmm1,xmm3
    424e:	41 ba 01 00 00 00    	mov    r10d,0x1
    4254:	c5 f3 5c cd          	vsubsd xmm1,xmm1,xmm5
    4258:	c5 f3 5c c0          	vsubsd xmm0,xmm1,xmm0
    425c:	e9 fe fd ff ff       	jmp    405f <matquat_run+0x9f>
    4261:	c4 c1 43 5c f8       	vsubsd xmm7,xmm7,xmm8
    4266:	c5 33 58 c9          	vaddsd xmm9,xmm9,xmm1
    426a:	c4 c1 4b 58 f2       	vaddsd xmm6,xmm6,xmm10
    426f:	c5 c1 14 c0          	vunpcklpd xmm0,xmm7,xmm0
    4273:	c5 f9 28 fb          	vmovapd xmm7,xmm3
    4277:	c5 31 14 ce          	vunpcklpd xmm9,xmm9,xmm6
    427b:	c5 f9 28 f5          	vmovapd xmm6,xmm5
    427f:	62 d3 fd 28 18 c1 01 	vinsertf64x2 ymm0,ymm0,xmm9,0x1
    4286:	c5 fd 59 0d 32 69 02 	vmulpd ymm1,ymm0,YMMWORD PTR [rip+0x26932]        # 2abc0 <__gnat_ada_main_program_name+0x38>
    428d:	00 
    428e:	c5 f9 28 c5          	vmovapd xmm0,xmm5
    4292:	e9 6b fe ff ff       	jmp    4102 <matquat_run+0x142>
    4297:	c4 c1 4b 58 f2       	vaddsd xmm6,xmm6,xmm10
    429c:	c5 3b 58 c7          	vaddsd xmm8,xmm8,xmm7
    42a0:	c5 f9 28 fd          	vmovapd xmm7,xmm5
    42a4:	c4 c1 73 5c c9       	vsubsd xmm1,xmm1,xmm9
    42a9:	c5 39 14 c0          	vunpcklpd xmm8,xmm8,xmm0
    42ad:	c5 f9 28 c5          	vmovapd xmm0,xmm5
    42b1:	c5 f1 14 ce          	vunpcklpd xmm1,xmm1,xmm6
    42b5:	c5 f9 28 f5          	vmovapd xmm6,xmm5
    42b9:	c5 f9 28 eb          	vmovapd xmm5,xmm3
    42bd:	62 d3 f5 28 18 c8 01 	vinsertf64x2 ymm1,ymm1,xmm8,0x1
    42c4:	c5 f5 59 0d 34 69 02 	vmulpd ymm1,ymm1,YMMWORD PTR [rip+0x26934]        # 2ac00 <__gnat_ada_main_program_name+0x78>
    42cb:	00 
    42cc:	e9 31 fe ff ff       	jmp    4102 <matquat_run+0x142>
    42d1:	c3                   	ret
    42d2:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    42d9:	00 00 00 
    42dc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
