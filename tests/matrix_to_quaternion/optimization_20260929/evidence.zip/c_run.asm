0000000000004570 <c_run>:
    4570:	48 89 f1             	mov    rcx,rsi
    4573:	48 89 d6             	mov    rsi,rdx
    4576:	85 ff                	test   edi,edi
    4578:	0f 84 6b 01 00 00    	je     46e9 <c_run+0x179>
    457e:	c5 fb 10 25 7a 65 02 	vmovsd xmm4,QWORD PTR [rip+0x2657a]        # 2ab00 <_fini+0x54>
    4585:	00 
    4586:	c5 fb 10 3d 12 66 02 	vmovsd xmm7,QWORD PTR [rip+0x26612]        # 2aba0 <__gnat_ada_main_program_name+0x18>
    458d:	00 
    458e:	c5 fb 10 1d 12 66 02 	vmovsd xmm3,QWORD PTR [rip+0x26612]        # 2aba8 <__gnat_ada_main_program_name+0x20>
    4595:	00 
    4596:	c5 fb 10 2d 7a 87 02 	vmovsd xmm5,QWORD PTR [rip+0x2877a]        # 2cd18 <system__os_lib__standin+0xc>
    459d:	00 
    459e:	c5 7d 28 05 5a 65 02 	vmovapd ymm8,YMMWORD PTR [rip+0x2655a]        # 2ab00 <_fini+0x54>
    45a5:	00 
    45a6:	45 31 c0             	xor    r8d,r8d
    45a9:	4c 8d 89 00 12 00 00 	lea    r9,[rcx+0x1200]
    45b0:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
    45b4:	90                   	nop
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    45bc:	00 00 00 00 
    45c0:	48 89 c8             	mov    rax,rcx
    45c3:	48 89 f2             	mov    rdx,rsi
    45c6:	eb 4c                	jmp    4614 <c_run+0xa4>
    45c8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    45cf:	00 
    45d0:	c5 6b 5c dc          	vsubsd xmm11,xmm2,xmm4
    45d4:	c5 21 54 1d 54 88 02 	vandpd xmm11,xmm11,XMMWORD PTR [rip+0x28854]        # 2ce30 <system__secondary_stack__invalid_memory_size+0xa8>
    45db:	00 
    45dc:	c5 79 2f dd          	vcomisd xmm11,xmm5
    45e0:	76 21                	jbe    4603 <c_run+0x93>
    45e2:	c5 db 5e d2          	vdivsd xmm2,xmm4,xmm2
    45e6:	c5 f1 14 c8          	vunpcklpd xmm1,xmm1,xmm0
    45ea:	c4 c1 31 14 c2       	vunpcklpd xmm0,xmm9,xmm10
    45ef:	62 f3 fd 28 18 c1 01 	vinsertf64x2 ymm0,ymm0,xmm1,0x1
    45f6:	c4 e2 7d 19 d2       	vbroadcastsd ymm2,xmm2
    45fb:	c5 fd 59 c2          	vmulpd ymm0,ymm0,ymm2
    45ff:	c5 fd 11 02          	vmovupd YMMWORD PTR [rdx],ymm0
    4603:	48 83 c0 48          	add    rax,0x48
    4607:	48 83 c2 20          	add    rdx,0x20
    460b:	4c 39 c8             	cmp    rax,r9
    460e:	0f 84 c6 00 00 00    	je     46da <c_run+0x16a>
    4614:	c5 fb 10 08          	vmovsd xmm1,QWORD PTR [rax]
    4618:	c5 fb 10 50 20       	vmovsd xmm2,QWORD PTR [rax+0x20]
    461d:	c5 7b 10 48 40       	vmovsd xmm9,QWORD PTR [rax+0x40]
    4622:	c5 f3 58 c2          	vaddsd xmm0,xmm1,xmm2
    4626:	c4 c1 7b 58 c1       	vaddsd xmm0,xmm0,xmm9
    462b:	c5 f9 2f c6          	vcomisd xmm0,xmm6
    462f:	0f 86 bb 00 00 00    	jbe    46f0 <c_run+0x180>
    4635:	c5 f3 58 cc          	vaddsd xmm1,xmm1,xmm4
    4639:	c5 f3 58 ca          	vaddsd xmm1,xmm1,xmm2
    463d:	c4 c1 73 58 c9       	vaddsd xmm1,xmm1,xmm9
    4642:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    4646:	c5 73 59 cf          	vmulsd xmm9,xmm1,xmm7
    464a:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    464e:	c5 7b 10 50 38       	vmovsd xmm10,QWORD PTR [rax+0x38]
    4653:	c5 2b 5c 50 28       	vsubsd xmm10,xmm10,QWORD PTR [rax+0x28]
    4658:	c5 2b 59 d3          	vmulsd xmm10,xmm10,xmm3
    465c:	c4 41 2b 5e d1       	vdivsd xmm10,xmm10,xmm9
    4661:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    4666:	c5 fb 10 48 10       	vmovsd xmm1,QWORD PTR [rax+0x10]
    466b:	c5 f3 5c 48 30       	vsubsd xmm1,xmm1,QWORD PTR [rax+0x30]
    4670:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
    4674:	c4 c1 73 5e c9       	vdivsd xmm1,xmm1,xmm9
    4679:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    467e:	c5 fb 10 40 18       	vmovsd xmm0,QWORD PTR [rax+0x18]
    4683:	c5 fb 5c 40 08       	vsubsd xmm0,xmm0,QWORD PTR [rax+0x8]
    4688:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    468c:	c4 c1 7b 5e c1       	vdivsd xmm0,xmm0,xmm9
    4691:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    4696:	c4 41 2b 59 da       	vmulsd xmm11,xmm10,xmm10
    469b:	c4 c1 33 59 d1       	vmulsd xmm2,xmm9,xmm9
    46a0:	c4 c1 6b 58 d3       	vaddsd xmm2,xmm2,xmm11
    46a5:	c5 73 59 d9          	vmulsd xmm11,xmm1,xmm1
    46a9:	c4 c1 6b 58 d3       	vaddsd xmm2,xmm2,xmm11
    46ae:	c5 7b 59 d8          	vmulsd xmm11,xmm0,xmm0
    46b2:	c4 c1 6b 58 d3       	vaddsd xmm2,xmm2,xmm11
    46b7:	c5 eb 51 d2          	vsqrtsd xmm2,xmm2,xmm2
    46bb:	c5 f9 2f ea          	vcomisd xmm5,xmm2
    46bf:	0f 86 0b ff ff ff    	jbe    45d0 <c_run+0x60>
    46c5:	48 83 c0 48          	add    rax,0x48
    46c9:	c5 7d 11 02          	vmovupd YMMWORD PTR [rdx],ymm8
    46cd:	48 83 c2 20          	add    rdx,0x20
    46d1:	4c 39 c8             	cmp    rax,r9
    46d4:	0f 85 3a ff ff ff    	jne    4614 <c_run+0xa4>
    46da:	41 ff c0             	inc    r8d
    46dd:	44 39 c7             	cmp    edi,r8d
    46e0:	0f 85 da fe ff ff    	jne    45c0 <c_run+0x50>
    46e6:	c5 f8 77             	vzeroupper
    46e9:	c3                   	ret
    46ea:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    46f0:	c4 c1 79 2f c9       	vcomisd xmm1,xmm9
    46f5:	76 0a                	jbe    4701 <c_run+0x191>
    46f7:	c5 f9 2f ca          	vcomisd xmm1,xmm2
    46fb:	0f 87 cf 00 00 00    	ja     47d0 <c_run+0x260>
    4701:	c4 c1 79 2f d1       	vcomisd xmm2,xmm9
    4706:	c5 db 5c c9          	vsubsd xmm1,xmm4,xmm1
    470a:	77 64                	ja     4770 <c_run+0x200>
    470c:	c5 f3 5c ca          	vsubsd xmm1,xmm1,xmm2
    4710:	c4 c1 73 58 c9       	vaddsd xmm1,xmm1,xmm9
    4715:	c5 f3 51 c1          	vsqrtsd xmm0,xmm1,xmm1
    4719:	c5 fb 59 c7          	vmulsd xmm0,xmm0,xmm7
    471d:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    4722:	c5 7b 10 48 18       	vmovsd xmm9,QWORD PTR [rax+0x18]
    4727:	c5 33 5c 48 08       	vsubsd xmm9,xmm9,QWORD PTR [rax+0x8]
    472c:	c5 33 59 cb          	vmulsd xmm9,xmm9,xmm3
    4730:	c5 33 5e c8          	vdivsd xmm9,xmm9,xmm0
    4734:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    4738:	c5 7b 10 50 10       	vmovsd xmm10,QWORD PTR [rax+0x10]
    473d:	c5 2b 58 50 30       	vaddsd xmm10,xmm10,QWORD PTR [rax+0x30]
    4742:	c5 2b 59 d3          	vmulsd xmm10,xmm10,xmm3
    4746:	c5 2b 5e d0          	vdivsd xmm10,xmm10,xmm0
    474a:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    474f:	c5 fb 10 48 28       	vmovsd xmm1,QWORD PTR [rax+0x28]
    4754:	c5 f3 58 48 38       	vaddsd xmm1,xmm1,QWORD PTR [rax+0x38]
    4759:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
    475d:	c5 f3 5e c8          	vdivsd xmm1,xmm1,xmm0
    4761:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    4766:	e9 2b ff ff ff       	jmp    4696 <c_run+0x126>
    476b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    4770:	c5 eb 58 c9          	vaddsd xmm1,xmm2,xmm1
    4774:	c4 c1 73 5c c9       	vsubsd xmm1,xmm1,xmm9
    4779:	c5 f3 51 c9          	vsqrtsd xmm1,xmm1,xmm1
    477d:	c5 f3 59 cf          	vmulsd xmm1,xmm1,xmm7
    4781:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    4786:	c5 fb 10 40 10       	vmovsd xmm0,QWORD PTR [rax+0x10]
    478b:	c5 fb 5c 40 30       	vsubsd xmm0,xmm0,QWORD PTR [rax+0x30]
    4790:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    4794:	c5 7b 5e c9          	vdivsd xmm9,xmm0,xmm1
    4798:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    479c:	c5 7b 10 50 08       	vmovsd xmm10,QWORD PTR [rax+0x8]
    47a1:	c5 2b 58 50 18       	vaddsd xmm10,xmm10,QWORD PTR [rax+0x18]
    47a6:	c5 2b 59 d3          	vmulsd xmm10,xmm10,xmm3
    47aa:	c5 2b 5e d1          	vdivsd xmm10,xmm10,xmm1
    47ae:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    47b3:	c5 fb 10 40 28       	vmovsd xmm0,QWORD PTR [rax+0x28]
    47b8:	c5 fb 58 40 38       	vaddsd xmm0,xmm0,QWORD PTR [rax+0x38]
    47bd:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    47c1:	c5 fb 5e c1          	vdivsd xmm0,xmm0,xmm1
    47c5:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    47ca:	e9 c7 fe ff ff       	jmp    4696 <c_run+0x126>
    47cf:	90                   	nop
    47d0:	c5 f3 58 c4          	vaddsd xmm0,xmm1,xmm4
    47d4:	c5 fb 5c c2          	vsubsd xmm0,xmm0,xmm2
    47d8:	c4 c1 7b 5c c1       	vsubsd xmm0,xmm0,xmm9
    47dd:	c5 fb 51 c0          	vsqrtsd xmm0,xmm0,xmm0
    47e1:	c5 7b 59 d7          	vmulsd xmm10,xmm0,xmm7
    47e5:	c5 7b 11 52 08       	vmovsd QWORD PTR [rdx+0x8],xmm10
    47ea:	c5 fb 10 40 38       	vmovsd xmm0,QWORD PTR [rax+0x38]
    47ef:	c5 fb 5c 40 28       	vsubsd xmm0,xmm0,QWORD PTR [rax+0x28]
    47f4:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    47f8:	c4 41 7b 5e ca       	vdivsd xmm9,xmm0,xmm10
    47fd:	c5 7b 11 0a          	vmovsd QWORD PTR [rdx],xmm9
    4801:	c5 fb 10 48 08       	vmovsd xmm1,QWORD PTR [rax+0x8]
    4806:	c5 f3 58 48 18       	vaddsd xmm1,xmm1,QWORD PTR [rax+0x18]
    480b:	c5 f3 59 cb          	vmulsd xmm1,xmm1,xmm3
    480f:	c4 c1 73 5e ca       	vdivsd xmm1,xmm1,xmm10
    4814:	c5 fb 11 4a 10       	vmovsd QWORD PTR [rdx+0x10],xmm1
    4819:	c5 fb 10 40 10       	vmovsd xmm0,QWORD PTR [rax+0x10]
    481e:	c5 fb 58 40 30       	vaddsd xmm0,xmm0,QWORD PTR [rax+0x30]
    4823:	c5 fb 59 c3          	vmulsd xmm0,xmm0,xmm3
    4827:	c4 c1 7b 5e c2       	vdivsd xmm0,xmm0,xmm10
    482c:	c5 fb 11 42 18       	vmovsd QWORD PTR [rdx+0x18],xmm0
    4831:	e9 60 fe ff ff       	jmp    4696 <c_run+0x126>
    4836:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    483d:	00 00 00 
