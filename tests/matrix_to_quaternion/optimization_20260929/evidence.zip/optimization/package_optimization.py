from pathlib import Path
import hashlib,json,re,subprocess,zipfile,shutil
base=Path(__file__).parent;run=base/'accepted-evidence';out=base/'deliverable';out.mkdir(exist_ok=True)
commands=json.loads((run/'commands-all.json').read_text())
assert commands[-1]['name']=='performance-2' and all(c['code']==0 for c in commands)
manifest=json.loads((run/'source-manifest.json').read_text())
assert all(hashlib.sha256((run/'snapshot'/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
proofs={}
for unit in ['mj-quaternions','mj-poses','mj-rotations']:
 d=json.loads((run/'logs'/f'{unit}.spark').read_text());assert not any(d[k] for k in ['skip_proof','skip_flow_proof','pragma_assume'])
 assert d['progress']=='PROGRESS_PROOF' and d['stop_reason']=='STOP_REASON_NONE'
 assert all(m['severity'] in ['info','warning'] for k in ['proof','flow','warn_error'] for m in d[k])
 proofs[unit]={'proof':sum(m['severity']=='info' for m in d['proof']),'flow':sum(m['severity']=='info' for m in d['flow']), 'unproved':0,'warnings':[m for k in ['proof','flow','warn_error'] for m in d[k] if m['severity']=='warning']}
num={p.stem:json.loads(p.read_text().splitlines()[0]) for p in sorted((run/'logs').glob('numeric-*.log'))}
comparisons=[json.loads((base/f'comparison-{i}.json').read_text()) for i in [1,2]]
binary=run/'snapshot/tests/matrix_to_quaternion/build/release/bin/main';sha=hashlib.sha256(binary.read_bytes()).hexdigest()
assert all(c['binary_sha256']['new_ada']==sha for c in comparisons)
assembly=subprocess.check_output(['objdump','-d','-Mintel',str(binary)],text=True)
for name in ['matquat_run','c_run']:
 a=re.search(r'^([0-9a-f]+ <'+name+r'>:.*?)(?=\n\n)',assembly,re.M|re.S)[1];(run/(name+'.asm')).write_text(a+'\n');assert not re.search(r'\bv(?:f|fn)m(?:add|sub)',a)
a=(run/'matquat_run.asm').read_text();assert 'vdivpd' in a and 'vmulpd' in a
symbols=subprocess.check_output(['nm','--defined-only',str(binary)],text=True);assert 'quaternions__model__' not in symbols and 'equal_normalization' not in symbols
integration=json.loads((run/'unit-integration.json').read_text());assert integration['code']==0
summary={'unit_integration':integration,'date':'2026-09-29','scope':'matrix-to-quaternion kernel on the recorded CPU; no integrated dynamics performance claim', 'source_sha256':{p:h for p,h in manifest.items() if p.startswith('src/')},'proofs':proofs,'numerics':num,'codegen':{'binary_sha256':sha,'packed_division_and_squares':True,'no_fma':True,'no_executable_quaternion_ghost_symbols':True},'comparison_sessions':[{k:v for k,v in d.items() if k!='results'}|{'results':[{k:v for k,v in r.items() if k!='samples'} for r in d['results']]} for d in comparisons]}
(out/'results.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile(base/'compare.py',out/'compare.py')
contents={}
for p in manifest:contents['snapshot/'+p]=(run/'snapshot'/p).read_bytes()
contents['snapshot/tests/matrix_to_quaternion/proof.gpr']=(run/'snapshot/tests/matrix_to_quaternion/proof.gpr').read_bytes()
for p in (run/'logs').iterdir():
 if p.is_file():contents['logs/'+p.name]=p.read_bytes()
for p in run.iterdir():
 if p.is_file() and p.suffix in ['.json','.asm','.log']:contents[p.name]=p.read_bytes()
for name in ['comparison-1.json','comparison-2.json','reference-release.json','compare.py','package_optimization.py','original.adb']:contents['optimization/'+name]=(base/name).read_bytes()
for name in ['source-manifest.json','commands-performance.json','performance-1.json','performance-2.json']:contents['baseline/'+name]=(base/'baseline'/name).read_bytes()
contents['results.json']=(out/'results.json').read_bytes()
contents['SHA256SUMS']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in sorted(contents.items())).encode()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for k,v in sorted(contents.items()):z.writestr(k,v)
with zipfile.ZipFile(out/'evidence.zip') as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/p).read_bytes()).hexdigest()+'  '+p+'\n' for p in ['evidence.zip','results.json','compare.py']))
print(json.dumps({k:{'proof':v['proof'],'flow':v['flow'],'warnings':len(v['warnings'])} for k,v in proofs.items()},indent=2))
