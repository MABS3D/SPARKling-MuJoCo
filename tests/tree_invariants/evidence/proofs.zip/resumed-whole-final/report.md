# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-7x6to9gn/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-smooth_math.adb:1` | [completed_no_unproved](logs/mj-smooth_math__whole_unit.log) | 718 | 0 | 0 | 128.3 |
| `whole unit` | `mj-pose_arithmetic.adb:1` | [completed_no_unproved](logs/mj-pose_arithmetic__whole_unit.log) | 156 | 0 | 0 | 111.5 |
| `whole unit` | `mj-tree_error_budgets.adb:1` | [completed_no_unproved](logs/mj-tree_error_budgets__whole_unit.log) | 177 | 0 | 0 | 25.4 |

## Diagnostics

