# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-4dz0s0yf/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Config_Dot` | `mj-smooth_dynamics.adb:4` | [completed_no_unproved](logs/mj-smooth_dynamics__config_dot__adb_4.log) | 16 | 0 | 0 | 4.8 |
| `Apply_Config` | `mj-smooth_dynamics.adb:20` | [completed_no_unproved](logs/mj-smooth_dynamics__apply_config__adb_20.log) | 12 | 0 | 0 | 13.8 |
| `Cross_Component` | `mj-smooth_dynamics.adb:32` | [completed_no_unproved](logs/mj-smooth_dynamics__cross_component__adb_32.log) | 10 | 0 | 0 | 5.3 |
| `Cross_Local` | `mj-smooth_dynamics.adb:46` | [completed_no_unproved](logs/mj-smooth_dynamics__cross_local__adb_46.log) | 12 | 0 | 0 | 11.6 |
| `Cross_Transport` | `mj-smooth_dynamics.adb:57` | [completed_no_unproved](logs/mj-smooth_dynamics__cross_transport__adb_57.log) | 12 | 0 | 0 | 11.1 |
| `Transport_Velocity` | `mj-smooth_dynamics.adb:78` | [completed_no_unproved](logs/mj-smooth_dynamics__transport_velocity__adb_78.log) | 11 | 0 | 0 | 5.3 |
| `Center_Acceleration` | `mj-smooth_dynamics.adb:83` | [completed_no_unproved](logs/mj-smooth_dynamics__center_acceleration__adb_83.log) | 33 | 0 | 0 | 17.4 |
| `Quaternion_Bounds` | `mj-smooth_dynamics.adb:2` | [completed_no_unproved](logs/mj-smooth_dynamics__quaternion_bounds__adb_2.log) | 2 | 0 | 0 | 3.3 |

## Diagnostics

