# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-zvs4s2l7/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Widen_Rotation_Bounds` | `mj-data-pipeline.adb:17` | [completed_no_unproved](logs/mj-data-pipeline__widen_rotation_bounds__adb_17.log) | 3 | 0 | 0 | 18.6 |
| `Identity_Is_Unit` | `mj-data-pipeline.adb:26` | [completed_no_unproved](logs/mj-data-pipeline__identity_is_unit__adb_26.log) | 1 | 0 | 0 | 3.0 |
| `Normalize_Orientation` | `mj-data-pipeline.adb:33` | [completed_no_unproved](logs/mj-data-pipeline__normalize_orientation__adb_33.log) | 1 | 0 | 0 | 3.0 |
| `Fixed_Position` | `mj-data-pipeline.adb:41` | [completed_no_unproved](logs/mj-data-pipeline__fixed_position__adb_41.log) | 29 | 0 | 0 | 35.5 |
| `Fixed_Frame` | `mj-data-pipeline.adb:80` | [completed_no_unproved](logs/mj-data-pipeline__fixed_frame__adb_80.log) | 13 | 0 | 0 | 46.1 |
| `Store_Body_Pose` | `mj-data-pipeline.adb:107` | [completed_no_unproved](logs/mj-data-pipeline__store_body_pose__adb_107.log) | 9 | 0 | 0 | 4.3 |
| `Expose_Body_Bounds` | `mj-data-pipeline.adb:126` | [completed_no_unproved](logs/mj-data-pipeline__expose_body_bounds__adb_126.log) | 3 | 0 | 0 | 7.3 |
| `Establish_Body_Bounds` | `mj-data-pipeline.adb:135` | [completed_no_unproved](logs/mj-data-pipeline__establish_body_bounds__adb_135.log) | 3 | 0 | 0 | 3.0 |
| `Joint_Orientation` | `mj-data-pipeline.adb:145` | [completed_no_unproved](logs/mj-data-pipeline__joint_orientation__adb_145.log) | 8 | 0 | 0 | 7.0 |
| `Expose_Unit_Vector` | `mj-data-pipeline.adb:166` | [completed_no_unproved](logs/mj-data-pipeline__expose_unit_vector__adb_166.log) | 2 | 0 | 0 | 3.3 |
| `Apply_One_Joint` | `mj-data-pipeline.adb:173` | [completed_no_unproved](logs/mj-data-pipeline__apply_one_joint__adb_173.log) | 34 | 0 | 0 | 49.5 |
| `Finalize_Body_Frame` | `mj-data-pipeline.adb:269` | [completed_no_unproved](logs/mj-data-pipeline__finalize_body_frame__adb_269.log) | 11 | 0 | 0 | 14.3 |
| `Joint_Displacement` | `mj-data-pipeline.adb:302` | [completed_no_unproved](logs/mj-data-pipeline__joint_displacement__adb_302.log) | 4 | 0 | 0 | 3.0 |
| `Build_One_Body` | `mj-data-pipeline.adb:309` | [completed_no_unproved](logs/mj-data-pipeline__build_one_body__adb_309.log) | 52 | 0 | 0 | 48.2 |
| `Initialize_World` | `mj-data-pipeline.adb:373` | [completed_no_unproved](logs/mj-data-pipeline__initialize_world__adb_373.log) | 1 | 0 | 0 | 4.0 |
| `Build_Bodies` | `mj-data-pipeline.adb:381` | [completed_no_unproved](logs/mj-data-pipeline__build_bodies__adb_381.log) | 63 | 0 | 0 | 30.2 |
| `Copy_Motion` | `mj-data-pipeline.adb:577` | [completed_no_unproved](logs/mj-data-pipeline__copy_motion__adb_577.log) | 1 | 0 | 0 | 5.0 |
| `Copy_Motions` | `mj-data-pipeline.adb:597` | [completed_no_unproved](logs/mj-data-pipeline__copy_motions__adb_597.log) | 25 | 0 | 0 | 5.3 |
| `Expose_State_Layout` | `mj-data-pipeline.adb:456` | [completed_no_unproved](logs/mj-data-pipeline__expose_state_layout__adb_456.log) | 12 | 0 | 0 | 7.3 |
| `Expose_Stable_Ready` | `mj-data-pipeline.adb:471` | [completed_no_unproved](logs/mj-data-pipeline__expose_stable_ready__adb_471.log) | 5 | 0 | 0 | 10.8 |
| `Establish_Stable_Ready` | `mj-data-pipeline.adb:481` | [completed_no_unproved](logs/mj-data-pipeline__establish_stable_ready__adb_481.log) | 5 | 0 | 0 | 5.0 |

## Diagnostics

