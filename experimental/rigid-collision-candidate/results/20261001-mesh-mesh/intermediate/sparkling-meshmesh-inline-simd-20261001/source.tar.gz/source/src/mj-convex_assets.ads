with MJ.Types; use MJ.Types;
with MJ.Rigid_Geometry; use MJ.Rigid_Geometry;
with MJ.Contact_Geometry; use MJ.Contact_Geometry;
with MJ.Rigid_Math;
package MJ.Convex_Assets with SPARK_Mode is
   type Dot_Block is array (Natural range 0 .. 3) of Real;
   --  Independent binary64 dots allow SIMD across vertices without
   --  reassociating an individual dot or changing the ordered maximum.
   function Four_Dots (V : Vertex_Array; First : Natural; D : Vec) return Dot_Block
     with Global => null, Inline,
       Pre => First in V'Range and then 3 <= V'Last-First and then MJ.Rigid_Math.Bounded (D)
         and then (for all K in First .. First+3 => MJ.Rigid_Math.Bounded (V (K))),
       Post => (for all K in 0 .. 3 => Four_Dots'Result (K) = MJ.Rigid_Math.Dot (V (First+K), D));
   --  Run once when immutable assets are installed.  Collision procedures
   --  carry this predicate as a precondition, rather than rescanning assets.
   function Valid_Graph (S : Object; G : Graph_Array) return Boolean with Global => null;
   function Best_Vertex (V : Vertex_Array; First, Length : Natural; D : Vec; Seed : Natural) return Natural
     with Global => null,
       Pre => Length > 0 and then First in V'Range and then Length-1 <= V'Last-First
         and then Seed in First .. First+(Length-1) and then MJ.Rigid_Math.Bounded (D)
         and then (for all K in First .. First+(Length-1) => MJ.Rigid_Math.Bounded (V (K))),
       Post => Best_Vertex'Result in First .. First+(Length-1)
         and then (for all K in First .. First+(Length-1) =>
           MJ.Rigid_Math.Dot (V (K), D) <= MJ.Rigid_Math.Dot (V (Best_Vertex'Result), D))
         and then (if (for all K in First .. First+(Length-1) =>
           MJ.Rigid_Math.Dot (V (K), D) <= MJ.Rigid_Math.Dot (V (Seed), D)) then Best_Vertex'Result = Seed);
end MJ.Convex_Assets;
