package body MJ.Face_Selection with SPARK_Mode is
   function Earliest_Minimum (D : Distances; Threshold : Real) return Integer is
      Best : Real := Threshold;
      Ret : Integer := -1;
   begin
      for K in D'Range loop
         pragma Loop_Invariant (Ret = -1 or else Ret in D'First .. K-1);
         pragma Loop_Invariant (if Ret = -1 then Best = Threshold else Best = D (Ret) and Best < Threshold);
         pragma Loop_Invariant (for all J in D'First .. K-1 => D (J) >= Best);
         pragma Loop_Invariant (if Ret >= 0 then (for all J in D'First .. Ret-1 => D (J) > Best));
         if D (K) < Best then Best := D (K); Ret := K; end if;
      end loop;
      return Ret;
   end Earliest_Minimum;
end MJ.Face_Selection;
