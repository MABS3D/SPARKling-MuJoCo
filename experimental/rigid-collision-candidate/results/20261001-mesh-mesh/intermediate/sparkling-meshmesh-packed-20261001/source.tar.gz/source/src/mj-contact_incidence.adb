package body MJ.Contact_Incidence with SPARK_Mode is
   function Find_Corner (F : Facet; Vertex : Natural) return Natural is
   begin
      for K in 0 .. F.Length-1 loop
         pragma Loop_Invariant (for all J in 0 .. K-1 => F.Indices (J) /= Vertex);
         if F.Indices (K) = Vertex then return K; end if;
      end loop;
      return F.Length;
   end Find_Corner;

   function Model_Count (F : Facet_Array; Vertex : Natural; Last : Integer) return Natural is
     (if F'Length = 0 or else Last < F'First then 0 else Model_Count (F, Vertex, Last-1)
       + (if Find_Corner (F (Last), Vertex) < F (Last).Length then 1 else 0));

   function Vertex_Matches (L : Lookup; F : Facet_Array; Vertex : Natural) return Boolean is
     (L.Size (Vertex) <= Max_Incidences-L.Start (Vertex)
      and then L.Size (Vertex) = Model_Count (F, L.First+Vertex, F'Last)
      and then (for all K in 0 .. L.Size (Vertex)-1 =>
        L.Data (L.Start (Vertex)+K).Face in F'Range
        and then L.Data (L.Start (Vertex)+K).Position < F (L.Data (L.Start (Vertex)+K).Face).Length
        and then F (L.Data (L.Start (Vertex)+K).Face).Indices (L.Data (L.Start (Vertex)+K).Position) = L.First+Vertex
        and then (if K > 0 then L.Data (L.Start (Vertex)+K-1).Face < L.Data (L.Start (Vertex)+K).Face)));

   function Matches (L : Lookup; F : Facet_Array) return Boolean is
     (not L.Ready or else (F'Length <= Max_Incidences
      and then L.First_Facet = F'First and then L.Facet_Count = F'Length
      and then (L.Length = 0 or else L.Length-1 <= Natural'Last-L.First)
      and then (for all V in 0 .. L.Length-1 => Vertex_Matches (L, F, V))));

   function Describes (L : Lookup; First_Vertex, Vertex_Count : Natural) return Boolean is
     (L.Ready and L.First = First_Vertex and L.Length = Vertex_Count);

   function Has_Vertex (L : Lookup; Vertex : Natural) return Boolean is
     (L.Ready and then Vertex >= L.First and then Vertex-L.First < L.Length
      and then L.Size (Vertex-L.First) <= Max_Incidences-L.Start (Vertex-L.First));

   function Covers (L : Lookup; S : Object; F : Facet_Array) return Boolean is
     (L.Ready and then S.Kind = Hull and then S.Length > 0
      and then Has_Vertex (L, S.First)
      and then S.Length <= L.Length-(S.First-L.First)
      and then F'Length <= Max_Incidences
      and then L.First_Facet = F'First and then L.Facet_Count = F'Length);

   function Count (L : Lookup; Vertex : Natural) return Natural is
     (L.Size (Vertex-L.First));

   function Item (L : Lookup; Vertex, Number : Natural) return Corner is
     (L.Data (L.Start (Vertex-L.First)+Number));

   procedure Build (First_Vertex, Vertex_Count : Natural; F : Facet_Array;
                    L : out Lookup; Result : out Status) is
      Used, Begin_At, Position : Natural := 0;
   begin
      L := Empty_Lookup; Result := Success;
      if Vertex_Count > Max_Indexed_Vertices or F'Length > Max_Incidences then Result := Capacity_Limit; return; end if;
      L.First := First_Vertex; L.Length := Vertex_Count;
      L.First_Facet := F'First; L.Facet_Count := F'Length;
      for Vertex in 0 .. Vertex_Count-1 loop
         pragma Loop_Invariant (Used <= Max_Incidences);
         pragma Loop_Invariant (L.First = First_Vertex and L.Length = Vertex_Count);
         pragma Loop_Invariant (L.First_Facet = F'First and L.Facet_Count = F'Length);
         pragma Loop_Invariant (for all V in 0 .. Vertex-1 => Vertex_Matches (L, F, V));
         pragma Loop_Invariant (for all V in 0 .. Vertex-1 => L.Start (V)+L.Size (V) <= Used);
         Begin_At := Used;
         for Face in F'Range loop
            pragma Loop_Invariant (Used in Begin_At .. Max_Incidences);
            pragma Loop_Invariant (Used-Begin_At = Model_Count (F, First_Vertex+Vertex, Face-1));
            pragma Loop_Invariant (for all V in 0 .. Vertex-1 => Vertex_Matches (L, F, V));
            pragma Loop_Invariant (for all V in 0 .. Vertex-1 => L.Start (V)+L.Size (V) <= Begin_At);
            pragma Loop_Invariant (for all E in Begin_At .. Used-1 =>
              L.Data (E).Face in F'First .. Face-1
              and then L.Data (E).Position < F (L.Data (E).Face).Length
              and then F (L.Data (E).Face).Indices (L.Data (E).Position) = First_Vertex+Vertex
              and then (if E > Begin_At then L.Data (E-1).Face < L.Data (E).Face));
            Position := Find_Corner (F (Face), First_Vertex+Vertex);
            if Position < F (Face).Length then
               if Used = Max_Incidences then L := Empty_Lookup; Result := Capacity_Limit; return; end if;
               L.Data (Used) := (Face => Face, Position => Position); Used := Used+1;
            end if;
         end loop;
         L.Start (Vertex) := Begin_At; L.Size (Vertex) := Used-Begin_At;
      end loop;
      L.Ready := True;
   end Build;
end MJ.Contact_Incidence;
