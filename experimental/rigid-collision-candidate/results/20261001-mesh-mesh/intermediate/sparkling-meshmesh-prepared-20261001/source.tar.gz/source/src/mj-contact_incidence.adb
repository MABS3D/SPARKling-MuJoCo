package body MJ.Contact_Incidence with SPARK_Mode is
   function Find_Corner (F : Facet; Vertex : Natural) return Natural is
   begin
      for K in 0 .. F.Length-1 loop
         pragma Loop_Invariant (for all J in 0 .. K-1 => F.Indices (J) /= Vertex);
         if F.Indices (K) = Vertex then return K; end if;
      end loop;
      return F.Length;
   end Find_Corner;

   function Has_Vertex (L : Lookup; Vertex : Natural) return Boolean is
     (L.Ready and then Vertex >= L.First and then Vertex-L.First < L.Length
      and then L.Size (Vertex-L.First) <= Max_Incidences-L.Start (Vertex-L.First));

   function Covers (L : Lookup; S : Object; F : Facet_Array) return Boolean is
     (L.Ready and then S.Kind = Hull and then S.Length > 0
      and then Has_Vertex (L, S.First)
      and then S.Length <= L.Length-(S.First-L.First)
      and then L.First_Facet = F'First and then L.Facet_Count = F'Length);

   function Count (L : Lookup; Vertex : Natural) return Natural is
     (L.Size (Vertex-L.First));

   function Item (L : Lookup; Vertex, Number : Natural) return Corner is
     (L.Data (L.Start (Vertex-L.First)+Number));

   procedure Build (First_Vertex, Vertex_Count : Natural; F : Facet_Array;
                    L : out Lookup; Result : out Status) is
      Used, Begin_At, Position : Natural := 0;
   begin
      L := Empty_Lookup; Result := Success;
      if Vertex_Count > Max_Indexed_Vertices then Result := Capacity_Limit; return; end if;
      L.First := First_Vertex; L.Length := Vertex_Count;
      L.First_Facet := F'First; L.Facet_Count := F'Length;
      for Vertex in 0 .. Vertex_Count-1 loop
         Begin_At := Used;
         for Face in F'Range loop
            Position := Find_Corner (F (Face), First_Vertex+Vertex);
            if Position < F (Face).Length then
               if Used = Max_Incidences then L := Empty_Lookup; Result := Capacity_Limit; return; end if;
               L.Data (Used) := (Face => Face, Position => Position); Used := Used+1;
            end if;
         end loop;
         L.Start (Vertex) := Begin_At; L.Size (Vertex) := Used-Begin_At;
      end loop;
      L.Ready := True;
   end Build;
end MJ.Contact_Incidence;
