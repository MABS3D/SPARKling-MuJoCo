with MJ.Types; use MJ.Types;
with MJ.Rigid_Geometry; use MJ.Rigid_Geometry;
with MJ.Contact_Geometry; use MJ.Contact_Geometry;

package MJ.Contact_Incidence with SPARK_Mode is
   --  Immutable vertex-to-polygon map, compiled once with the mesh assets.
   --  Capacity exhaustion is explicit; callers can retain the scanning path.
   Max_Indexed_Vertices : constant := 8192;
   Max_Incidences : constant := 65536;
   type Lookup is private;
   Empty_Lookup : constant Lookup;
   type Corner is record
      Face : Natural;
      Position : Natural range 0 .. Max_Facet_Vertices-1;
   end record;

   function Find_Corner (F : Facet; Vertex : Natural) return Natural
     with Global => null, Inline,
       Post => Find_Corner'Result <= F.Length
         and then (if Find_Corner'Result < F.Length then
           F.Indices (Find_Corner'Result) = Vertex
           and then (for all K in 0 .. Find_Corner'Result-1 => F.Indices (K) /= Vertex)
           else (for all K in 0 .. F.Length-1 => F.Indices (K) /= Vertex));

   function Covers (L : Lookup; S : Object; F : Facet_Array) return Boolean
     with Global => null, Inline;
   function Has_Vertex (L : Lookup; Vertex : Natural) return Boolean
     with Global => null, Inline;
   function Count (L : Lookup; Vertex : Natural) return Natural
     with Global => null, Inline, Pre => Has_Vertex (L, Vertex);
   function Item (L : Lookup; Vertex, Number : Natural) return Corner
     with Global => null, Inline,
       Pre => Has_Vertex (L, Vertex) and then Number < Count (L, Vertex);

   --  The lookup must be rebuilt if the facet/vertex IDs change.  Covers
   --  checks ranges; it does not establish identity of mutable asset data.
   procedure Build (First_Vertex, Vertex_Count : Natural; F : Facet_Array;
                    L : out Lookup; Result : out Status)
     with Global => null,
       Pre => Vertex_Count = 0 or else Vertex_Count-1 <= Natural'Last-First_Vertex,
       Post => (if Result /= Success then L = Empty_Lookup);
private
   subtype Vertex_Id is Natural range 0 .. Max_Indexed_Vertices-1;
   subtype Entry_Id is Natural range 0 .. Max_Incidences-1;
   type Offsets is array (Vertex_Id) of Natural range 0 .. Max_Incidences;
   type Entries is array (Entry_Id) of Corner;
   type Lookup is record
      Ready : Boolean := False;
      First, First_Facet, Facet_Count : Natural := 0;
      Length : Natural range 0 .. Max_Indexed_Vertices := 0;
      Start, Size : Offsets := [others => 0];
      Data : Entries := [others => (Face => 0, Position => 0)];
   end record;
   Empty_Lookup : constant Lookup := (others => <>);
end MJ.Contact_Incidence;
