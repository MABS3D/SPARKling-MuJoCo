package body MJ.Face_Selection with SPARK_Mode is
   type Lane is range 0 .. 3;
   type Quad is array (Lane) of Real;
   type Witnesses is array (Lane) of Integer;
   function Min_4 (A, B : Quad) return Quad with Inline, Global => null,
     Post => (for all I in Lane => Min_4'Result (I) = Real'Min (A (I), B (I))) is
     ([Real'Min (A (0), B (0)), Real'Min (A (1), B (1)),
       Real'Min (A (2), B (2)), Real'Min (A (3), B (3))]);

   function Vector_Minimum (D : Distances; Threshold : Real) return Real is
      Best : Quad := [others => Threshold];
      Witness : Witnesses := [others => -1] with Ghost;
      Groups : constant Natural := D'Length/4;
      Base : Natural;
      Ret : Real;
   begin
      for G in 0 .. Groups-1 loop
         pragma Loop_Invariant (for all I in Lane =>
           (if Witness (I) < 0 then Best (I) = Threshold else
             Witness (I) in D'First .. D'First+4*G-1 and then Best (I) = D (Witness (I)) and Best (I) <= Threshold));
         pragma Loop_Invariant (for all J in D'First .. D'First+4*G-1 => D (J) >= Best (Lane ((J-D'First) mod 4)));
         Base := D'First+4*G;
         declare Previous : constant Quad := Best with Ghost; begin
            Best := Min_4 (Best, [D (Base), D (Base+1), D (Base+2), D (Base+3)]);
            for I in Lane loop
               if D (Base+Natural (I)) < Previous (I) then Witness (I) := Base+Natural (I); end if;
            end loop;
         end;
      end loop;
      Ret := Real'Min (Real'Min (Best (0), Best (1)), Real'Min (Best (2), Best (3)));
      if D'Length mod 4 > 0 then
         for K in D'First+4*Groups .. D'Last loop
            pragma Loop_Invariant (Ret <= Threshold);
            pragma Loop_Invariant (for all J in D'First .. K-1 => D (J) >= Ret);
            pragma Loop_Invariant (if Ret < Threshold then (for some J in D'First .. K-1 => D (J) = Ret));
            Ret := Real'Min (Ret, D (K));
         end loop;
      end if;
      return Ret;
   end Vector_Minimum;

   function Earliest_Minimum (D : Distances; Threshold : Real) return Integer is
      Best : Real := Threshold;
      Ret : Integer := -1;
   begin
      for K in D'Range loop
         pragma Loop_Invariant (Ret = -1 or else Ret in D'First .. K-1);
         pragma Loop_Invariant (if Ret = -1 then Best = Threshold else Best = D (Ret) and Best < Threshold);
         pragma Loop_Invariant (for all J in D'First .. K-1 => D (J) >= Best);
         pragma Loop_Invariant (if Ret >= 0 then (for all J in D'First .. Ret-1 => D (J) > Best));
         if D (K) < Best then Best := D (K); Ret := K; end if;
      end loop;
      return Ret;
   end Earliest_Minimum;
   function Select_Face (D : Distances; Threshold : Real) return Integer is
      Best : Real;
   begin
      if D'Length < 16 or D'Length > 65536 then return Earliest_Minimum (D, Threshold); end if;
      Best := Vector_Minimum (D, Threshold);
      if Best >= Threshold then return -1; end if;
      for K in D'Range loop
         pragma Loop_Invariant (for all J in D'First .. K-1 => D (J) > Best);
         if D (K) = Best then return K; end if;
      end loop;
      return -1;
   end Select_Face;
end MJ.Face_Selection;
