with MJ.Types; use MJ.Types;
package MJ.Face_Selection with SPARK_Mode is
   type Distances is array (Natural range <>) of Real;
   --  First strict minimum below Threshold, or -1 if none exists.
   function Earliest_Minimum (D : Distances; Threshold : Real) return Integer
     with Global => null, Inline,
       Post => (if Earliest_Minimum'Result < 0 then
         Earliest_Minimum'Result = -1 and then (for all X of D => X >= Threshold)
         else Earliest_Minimum'Result in D'Range
           and then D (Earliest_Minimum'Result) < Threshold
           and then (for all X of D => X >= D (Earliest_Minimum'Result))
           and then (for all K in D'First .. Earliest_Minimum'Result-1 =>
             D (K) > D (Earliest_Minimum'Result)));
   function Vector_Minimum (D : Distances; Threshold : Real) return Real
     with Global => null,
       Pre => D'Length in 1 .. 65536,
       Post => Vector_Minimum'Result <= Threshold
         and then (for all X of D => X >= Vector_Minimum'Result)
         and then (if Vector_Minimum'Result < Threshold then
           (for some X of D => X = Vector_Minimum'Result));
   function Select_Face (D : Distances; Threshold : Real) return Integer
     with Global => null, Inline,
       Post => (if Select_Face'Result < 0 then
         Select_Face'Result = -1 and then (for all X of D => X >= Threshold)
         else Select_Face'Result in D'Range
           and then D (Select_Face'Result) < Threshold
           and then (for all X of D => X >= D (Select_Face'Result))
           and then (for all K in D'First .. Select_Face'Result-1 => D (K) > D (Select_Face'Result)));
end MJ.Face_Selection;
