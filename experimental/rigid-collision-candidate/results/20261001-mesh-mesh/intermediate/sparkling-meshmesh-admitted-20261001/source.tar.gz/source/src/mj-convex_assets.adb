with MJ.Rigid_Math; use MJ.Rigid_Math;
package body MJ.Convex_Assets with SPARK_Mode is
   function Valid_Graph (S : Object; G : Graph_Array) return Boolean is
      N, Edge_Start, Start, Last : Natural;
      Terminated : Boolean;
   begin
      if S.Graph_Length = 0 then return True; end if;
      if S.Kind /= Hull or S.First_Graph not in G'Range then return False; end if;
      if S.Graph_Length-1 > G'Last-S.First_Graph or S.Graph_Length < 3 then return False; end if;
      if G (S.First_Graph) <= 0 then return False; end if;
      N := Natural (G (S.First_Graph));
      if N = 0 or N > (S.Graph_Length-3)/2 then return False; end if;
      Edge_Start := S.First_Graph+2+2*N; Last := S.First_Graph+(S.Graph_Length-1);
      for Seed of S.Extrema loop if Seed >= N then return False; end if; end loop;
      for K in 0 .. N-1 loop
         if G (S.First_Graph+2+N+K) < 0 or else G (S.First_Graph+2+N+K) >= S.Length then return False; end if;
         if G (S.First_Graph+2+K) < 0 or else G (S.First_Graph+2+K) > Last-Edge_Start then return False; end if;
         Start := Edge_Start+G (S.First_Graph+2+K); Terminated := False;
         for J in Start .. Last loop
            if G (J) < 0 then Terminated := True; exit; end if;
            if G (J) >= N then return False; end if;
         end loop;
         if not Terminated then return False; end if;
      end loop;
      return True;
   end Valid_Graph;
   function Seed_Coordinate (X : Real) return Natural is
     (1 + Boolean'Pos (X > 0.4) - Boolean'Pos (X < -0.4));
   function Best_Vertex (V : Vertex_Array; First, Length : Natural; D : Vec; Seed : Natural) return Natural is
      Best : Natural := Seed;
      Seed_Value : constant Real := Dot (V (Seed), D);
      Best_Value : Real := Seed_Value;
      Value : Real;
   begin
      for K in First .. First+(Length-1) loop
         pragma Loop_Invariant (Best in First .. First+(Length-1));
         pragma Loop_Invariant (Bounded (V (Best)));
         pragma Loop_Invariant (Best_Value = Dot (V (Best), D));
         pragma Loop_Invariant (for all J in First .. K-1 => Dot (V (J), D) <= Best_Value);
         pragma Loop_Invariant (Seed_Value <= Best_Value);
         pragma Loop_Invariant (if Best_Value = Seed_Value then Best = Seed);
         Value := Dot (V (K), D);
         if Value > Best_Value then Best := K; Best_Value := Value; end if;
      end loop;
      return Best;
   end Best_Vertex;
end MJ.Convex_Assets;
