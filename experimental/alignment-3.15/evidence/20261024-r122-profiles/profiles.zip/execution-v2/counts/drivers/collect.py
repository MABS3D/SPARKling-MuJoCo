#!/usr/bin/env python3
"""Only execute after the coordinator grants the heavy slot.

One immutable r122 engine, one fresh shared -pg build, six separate gmon files.
No runtime source modifications. Summaries contain counts, never sampled costs.
"""
import argparse,bisect,collections,hashlib,json,os,re,shutil,struct,subprocess,sys
from pathlib import Path
import numpy as np
MODELS=['membrane_Newton_3','free','element_2_sphere','element_mixed_pyramidal_3','element_elastic_cross_elliptic_6','element_elastic_self_bvh_pyramidal_3']
TARGETS={'Factor_Values':'mj__constraint_solvers__packed_cholesky__factor_values','Build_Gram':'mj__constraint_solvers__hessian_assembly__build_gram','Update_Flat':'mj__constraint_solvers__cholesky_updates__update_flat','Solve_With_Force':'mj__constraint_solvers__solve_with_force'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def symbols(binary):
    result=[]
    for line in subprocess.check_output(['nm','-S','--defined-only',str(binary)],text=True).splitlines():
        parts=line.split()
        if len(parts)==4 and parts[2] in ('t','T','w','W') and int(parts[1],16)>0:
            result.append((int(parts[0],16),int(parts[1],16),parts[3]))
    return sorted(result)
def matches(name,base):return name==base or name.startswith(base+'.')
def arc_counts(binary,gmon):
    syms=symbols(binary);starts=[s[0] for s in syms]
    def locate(pc):
        i=bisect.bisect_right(starts,pc)-1
        if i>=0 and pc<syms[i][0]+syms[i][1]:return syms[i][2]
        return '<unmapped>'
    data=gmon.read_bytes();assert data[:4]==b'gmon' and struct.unpack_from('<I',data,4)[0]==1
    offset=20;incoming=collections.Counter();arcs=collections.Counter()
    while offset<len(data):
        tag=data[offset];offset+=1
        if tag==0:
            _,_,n,_,_,_=struct.unpack_from('<QQII15sc',data,offset)
            offset+=40+2*n
        elif tag==1:
            caller,callee,count=struct.unpack_from('<QQI',data,offset);offset+=20
            incoming[locate(callee)]+=count;arcs[locate(caller),locate(callee)]+=count
        else:raise ValueError(('Unsupported gmon record',tag,offset))
    assert offset==len(data)
    out={}
    for short,base in TARGETS.items():
        group=[s for s in syms if matches(s[2],base)];assert group,(short,'symbol missing')
        instrumented={}
        for _,_,name in group:
            asm=subprocess.check_output(['objdump','-d','--no-show-raw-insn','--disassemble='+name,str(binary)],text=True)
            instrumented[name]='mcount' in asm or '__fentry__' in asm
            if name.endswith('.cold') or '.cold.' in name:
                assert incoming[name]==0,(short,name,'unexpected incoming mcount to cold split')
            else:
                assert instrumented[name],(short,name,'not visibly instrumented; count would be unavailable')
        out[short]=dict(calls=sum(incoming[name] for _,_,name in group),symbols=[dict(address=hex(a),size=z,name=n,incoming_calls=incoming[n],entry_instrumented=instrumented[n]) for a,z,n in group],arcs=[dict(caller=a,callee=b,calls=n) for (a,b),n in arcs.items() if any(b==x[2] for x in group)])
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--engine',type=Path,default=Path('/var/tmp/sparkling-alignment-315-reuse-release-r122-20261009'))
    p.add_argument('--cases',type=Path,default=Path('/var/tmp/sparkling-alignment-315-scatter-release-r111-20261009/constrained'))
    p.add_argument('--out',type=Path,default=Path('/var/tmp/sparkling-r122-profile-counts-20261009'))
    p.add_argument('--c-counts',type=Path,default=Path('/var/tmp/sparkling-c315-source-count-callsite-r121-20261009'))
    p.add_argument('--profile',type=Path,default=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/experimental/alignment-3.15/tests/profile_flex.py'))
    p.add_argument('--execute',action='store_true',help='Coordinator must first grant the heavy slot')
    a=p.parse_args();build=a.out/'build'
    commands=[[sys.executable,str(a.profile),'--engine',str(a.engine),'--cases',str(a.cases),'--out',str(a.out/'models'/name),'--build-root',str(build),'--model',name,'--sample','1','--batches','16','--cpu','0'] for name in MODELS]
    if not a.execute:
        print(json.dumps(dict(executed=False,commands=commands,scope='Plan only; no build or solver invocation'),indent=2));return
    manifest_path=a.engine/'manifest.json';manifest=json.loads(manifest_path.read_text());engine_result=json.loads((a.engine/'results.json').read_text())
    assert manifest['mode']=='release' and manifest['reference']=='3.15.0' and engine_result['complete']
    engine_sha=sha(manifest_path);profile_sha=sha(a.profile)
    def source_matches():return sha(manifest_path)==engine_sha and all(sha(a.engine/'source'/k)==v for k,v in manifest['sources'].items())
    assert source_matches()
    c=json.loads((a.c_counts/'results.json').read_text());assert c['complete'] and (c['sample'],c['steps'],c['batches'])==(1,100,16)
    crows={r['model']:r for r in c['rows'] if r['endpoint_forwards']==2}
    for name in MODELS:
        cr=crows[name];assert cr['validated_for_call_comparison']
        assert sha(a.cases/(name+'.mjb'))==cr['model_sha256']
        assert sha(a.cases/(name+'.input'))==cr['input_sha256']
        assert int((a.cases/(name+'.input')).read_text().splitlines()[0].split()[1])==100
    a.out.mkdir(parents=True,exist_ok=False);build.mkdir();(a.out/'drivers').mkdir()
    shutil.copy2(a.profile,a.out/'drivers/profile_flex.py');shutil.copy2(Path(__file__),a.out/'drivers/collect.py')
    owner=dict(engine=str(a.engine.resolve()),manifest_sha256=engine_sha,scope='This cache belongs exclusively to this immutable source snapshot and -pg profile configuration')
    (build/'owner.json').write_text(json.dumps(owner,indent=2)+'\n')
    result=dict(complete=False,scope='Exact instrumented function-entry counts, not sampled timing/cost percentages. Full process:16 trajectories ×(100 steps+2 preparatory Evaluate calls), no Ada warmup trajectory omitted.',manifest_sha256=engine_sha,engine=str(a.engine),profile_driver_sha256=profile_sha,collector_sha256=sha(Path(__file__)),c_results_sha256=sha(a.c_counts/'results.json'),commands=commands,rows=[])
    def save():(a.out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    save();binary_hash=None
    for name,command in zip(MODELS,commands,strict=True):
        assert source_matches() and sha(a.profile)==profile_sha
        with (a.out/(name+'.driver.log')).open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
        modeldir=a.out/'models'/name;profile=json.loads((modeldir/'results.json').read_text());assert profile['complete']
        binary=build/'release/bin/flex_constrained_probe';bh=sha(binary)
        if binary_hash is None:binary_hash=bh
        assert bh==binary_hash,'Shared build changed between models'
        assert profile['sample']==1 and profile['batches']==16 and profile['manifest_sha256']==engine_sha
        counts=arc_counts(binary,modeldir/'gmon.out');assert counts['Solve_With_Force']['calls']==1632,(name,counts['Solve_With_Force'])
        # Independently compare all16 published trajectory endpoints to C endpoint2.
        source_c=json.loads((a.c_counts/f'{name}-endpoints-2-instrumented.json').read_text())
        expected=np.array([t['state'] for t in source_c['trajectories'][c['warmup']:]])
        actual=np.array([np.fromstring(x.removeprefix('state '),sep=' ') for x in (modeldir/'trajectory.output').read_text().splitlines()[1::2]])
        assert actual.shape==expected.shape and np.allclose(actual,expected,atol=2e-9,rtol=2e-9)
        cr=crows[name];ctotal={k:cr['step_counts'][k]+cr['endpoint_counts'][k] for k in cr['step_counts']}
        comparisons={ak:dict(ada_calls=counts[ak]['calls'],c_calls=ctotal[ck],delta=counts[ak]['calls']-ctotal[ck]) for ak,ck in [('Factor_Values','cholFactorNumeric'),('Build_Gram','sqrMatTDSparseNumeric'),('Update_Flat','cholUpdateSparse')]}
        row=dict(model=name,profile_result_sha256=sha(modeldir/'results.json'),gmon_sha256=sha(modeldir/'gmon.out'),gprof_sha256=sha(modeldir/'gprof.txt'),binary_sha256=bh,trajectory_max_abs_vs_C_endpoint2=float(np.max(abs(actual-expected))),steps=1600,preparatory_evaluations=32,ada_counts=counts,c_fullprocess_counts=ctotal,comparison=comparisons)
        result['rows'].append(row);save();print(json.dumps(dict(model=name,comparison=comparisons,max_abs=row['trajectory_max_abs_vs_C_endpoint2'])),flush=True)
    assert source_matches() and sha(a.profile)==profile_sha
    result.update(complete=True,binary_sha256=binary_hash,source_hashes_unchanged=True);save()
    lines=['r122 Ada versus C3.15, full process16×(100+2) evaluations, six sample1 trajectories.','Counts only; short profile histogram is not used as cost attribution.','model | Ada/C Factor | Ada/C Gram | Ada/C sparse rank updates']
    for row in result['rows']:
        x=row['comparison'];lines.append(row['model']+' | '+' | '.join(f"{x[k]['ada_calls']}/{x[k]['c_calls']}" for k in ['Factor_Values','Build_Gram','Update_Flat']))
    lines+=['C scalar/elliptic helper counts, gate choices and update/downdate split are retained in JSON. Ada counts aggregate these paths; equality of totals does not prove identical intermediate arithmetic or cost. Final states are checked for all16 trajectories; the profile driver does not capture every Ada intermediate step.']
    (a.out/'counts-summary.txt').write_text('\n'.join(lines)+'\n');print(a.out/'results.json')
if __name__=='__main__':main()
