#!/usr/bin/env python3
"""Six exact-entry count runs and two longer diagnostic profiles from one frozen instrumented binary; requires coordinator slot."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,subprocess,sys
import numpy as np
PLAN=Path(__file__).resolve().parent
ENGINE=Path('/var/tmp/sparkling-alignment-315-reuse-release-r122-20261009')
OUT=Path('/var/tmp/sparkling-r122-profiles-20261024-v2')
PROFILE=PLAN/'frozen/experimental/alignment-3.15/tests/profile_flex.py'
MODELS=['membrane_Newton_3','free','element_2_sphere','element_mixed_pyramidal_3','element_elastic_cross_elliptic_6','element_elastic_self_bvh_pyramidal_3']
LONG=['free','element_elastic_cross_elliptic_6']
EXPECTED_MANIFEST='cdc29de6b5b5076568a99f5e196c8861d6d162dab687f7f9d0e605cae2b4cdc4'
EXPECTED_RELEASE_BINARY='637cbe2ea3d5788b2d9a16e1cb25e22a4147a88625612cc9e013c86756d00df9'
EXPECTED_C_LIBRARY='d3a1476dd52e220031aca40b2b00f69d1febce2ee85c57d5015f68b0cc72afa9'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def verify():
 expected=json.loads((PLAN/'plan-hashes.json').read_text())
 assert all(sha(PLAN/p)==v for p,v in expected.items()),'Frozen driver/input/C receipt changed'
 assert sha(ENGINE/'manifest.json')==EXPECTED_MANIFEST
 manifest=json.loads((ENGINE/'manifest.json').read_text())
 assert all(sha(ENGINE/'source'/p)==v for p,v in manifest['sources'].items())
 assert sha(ENGINE/'force-build/release/bin/flex_constrained_probe')==EXPECTED_RELEASE_BINARY
 assert json.loads((ENGINE/'results.json').read_text())['complete']
 assert sha('/var/tmp/sparkling-movement315-env/lib/python3.12/site-packages/mujoco/libmujoco.so.3.15.0')==EXPECTED_C_LIBRARY
 return len(expected)+len(manifest['sources'])+3

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--execute',action='store_true')
 args=parser.parse_args()
 short=[sys.executable,str(PLAN/'collect.py'),'--engine',str(ENGINE),'--cases',str(PLAN/'cases'),
        '--out',str(OUT/'counts'),'--c-counts',str(PLAN/'c-counts'),'--profile',str(PROFILE),'--execute']
 longs=[[sys.executable,str(PROFILE),'--engine',str(ENGINE),'--cases',str(PLAN/'cases'),
         '--out',str(OUT/'sampling'/name),'--build-root',str(OUT/'counts/build'),
         '--model',name,'--sample','1','--batches','2000','--cpu','0'] for name in LONG]
 if not args.execute:
  print(json.dumps(dict(executed=False,short=short,long=longs),indent=2));return
 assert not OUT.exists(),'Use fresh output suffix; never restart over completed data'
 checked=verify();OUT.mkdir();receipt=dict(complete=False,checked_before=checked,commands=[short,*longs],
  scope='Immutable r122 only. Historical C3.15 counters. Exact instrumented entry counts separated from sampled main-executable self-time; no release timing or full-port claim.',
  working_tree_note='HEAD context570128a; live worktree is changing for3.17 and ghost proofs. No equality to current worktree is required; only frozen r122 source manifest is authoritative.',
  original_head='570128a07e176eeefc27a161ffe7cc659d0d1221',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),long=[])
 git=['/mnt/c/Program Files/Git/cmd/git.exe','-C','C:/Users/Chello/Desktop/Sparkling Mujoco']
 receipt['actual_head']=subprocess.check_output([*git,'rev-parse','HEAD'],text=True).strip()
 receipt['worktree_status']=subprocess.check_output([*git,'status','--short','--untracked-files=no'],text=True)
 def save():(OUT/'results.json').write_text(json.dumps(receipt,indent=2)+chr(10))
 save()
 with (OUT/'counts.log').open('w') as log:subprocess.run(short,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert json.loads((OUT/'counts/results.json').read_text())['complete'];receipt['short_complete']=True;save()
 shared=OUT/'counts/build/release/bin/flex_constrained_probe';binary_sha=sha(shared)
 spec=importlib.util.spec_from_file_location('r122_collector',PLAN/'collect.py');collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
 c=json.loads((PLAN/'c-counts/results.json').read_text());crows={r['model']:r for r in c['rows'] if r['endpoint_forwards']==2}
 assert c['source_commit']=='9ea3cdfcae93bf2cc4dc0e1a1627c5a39a1e06e5' and c['complete']
 for name,command in zip(LONG,longs,strict=True):
  verify();assert sha(shared)==binary_sha
  with (OUT/(name+'.sampling.log')).open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
  modeldir=OUT/'sampling'/name;profile=json.loads((modeldir/'results.json').read_text())
  assert profile['complete'] and sha(shared)==binary_sha
  counts=collector.arc_counts(shared,modeldir/'gmon.out');assert counts['Solve_With_Force']['calls']==204000
  cr=crows[name];ctotal={k:cr['step_counts'][k]+cr['endpoint_counts'][k] for k in cr['step_counts']}
  assert cr['repeated_trajectory_counts_identical'] and cr['validated_for_call_comparison']
  assert all(v%16==0 for v in ctotal.values())
  repeated={k:v//16*2000 for k,v in ctotal.items()}
  comparisons={ak:dict(ada_calls=counts[ak]['calls'],C315_expected_repeated_calls=repeated[ck],delta=counts[ak]['calls']-repeated[ck]) for ak,ck in [('Factor_Values','cholFactorNumeric'),('Build_Gram','sqrMatTDSparseNumeric'),('Update_Flat','cholUpdateSparse')]}
  subprocess.run([sys.executable,str(PLAN/'sample_summary.py'),'--binary',str(shared),'--gmon',str(modeldir/'gmon.out'),'--out',str(modeldir/'sampling-summary.json')],check=True)
  row=dict(model=name,batches=2000,steps=200000,preparatory_evaluations=4000,binary_sha256=binary_sha,
   counts=counts,comparison=comparisons,C315_count_scope='Derived by exact repetition of the validated deterministic per-trajectory C endpoint2 counter totals; not a new2000-trajectory C execution.',
   sampled_profile=str(modeldir/'sampling-summary.json'),sampled_profile_sha256=sha(modeldir/'sampling-summary.json'),
   trajectory_max_abs_vs_C315=profile['trajectory_max_abs'])
  receipt['long'].append(row);save();print(json.dumps(dict(model=name,comparison=comparisons)),flush=True)
 receipt.update(complete=True,checked_after=verify(),instrumented_binary_sha256=binary_sha,
                finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 print(OUT/'results.json',flush=True)
if __name__=='__main__':main()
