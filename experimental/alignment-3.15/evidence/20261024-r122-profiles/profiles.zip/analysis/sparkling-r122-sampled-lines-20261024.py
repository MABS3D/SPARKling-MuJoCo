from pathlib import Path
import argparse,collections,hashlib,json,struct,subprocess
p=argparse.ArgumentParser();p.add_argument('--model',required=True);a=p.parse_args()
root=Path('/var/tmp/sparkling-r122-profiles-20261024-v2');binary=root/'counts/build/release/bin/flex_constrained_probe';gmon=root/'sampling'/a.model/'gmon.out'
data=gmon.read_bytes();pos=20;pcs=[];weights=[];total=0
while pos<len(data):
 tag=data[pos];pos+=1
 if tag==0:
  low,high,n,rate,_,_=struct.unpack_from('<QQII15sc',data,pos);pos+=40
  values=struct.unpack_from('<'+'H'*n,data,pos);pos+=2*n
  assert (high-low)%n==0;stride=(high-low)//n
  for i,count in enumerate(values):
   if count:pcs.append(low+i*stride);weights.append(count);total+=count
 elif tag==1:pos+=20
 else:raise ValueError(tag)
text=subprocess.check_output(['addr2line','-f','-e',str(binary)],input='\n'.join(hex(x) for x in pcs)+'\n',text=True)
lines=text.splitlines();assert len(lines)==2*len(pcs)
alllines=collections.Counter();perfunction={};locations={}
for i,(pc,count) in enumerate(zip(pcs,weights,strict=True)):
 function,location=lines[2*i:2*i+2];alllines[function,location]+=count
 perfunction.setdefault(function,collections.Counter())[location]+=count
 locations.setdefault(location,[]).append(dict(pc=hex(pc),samples=count,function=function))
top=[dict(function=f,location=l,samples=c,percent_of_main_image_samples=100*c/total) for (f,l),c in alllines.most_common(50)]
selected={f:[dict(location=l,samples=c,percent_of_main_image_samples=100*c/total) for l,c in counts.most_common(12)] for f,counts in perfunction.items() if any(k in f.lower() for k in ['solve_with_force','prepare_and_solve','solve_compatible_buffers','is_ready','update_flat','backsolve_flat','build_gram','factor_values','sparse_row'])}
receipt=dict(model=a.model,scope='Offline addr2line mapping of existing4-byte gmon histogram-bin starts; diagnostic line attribution, potentially inline locations. Includes full process and instrumentation; not release timed-loop cost.',binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),gmon_sha256=hashlib.sha256(data).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),total_samples=total,nonempty_bins=len(pcs),top_lines=top,selected_functions=selected)
out=Path('/tmp')/('sparkling-r122-lines-'+a.model+'-20261024.json');out.write_text(json.dumps(receipt,indent=2)+'\n')
print('OUT',out)
print(json.dumps(dict(top_lines=top[:18],selected_functions=selected),indent=2))
