from pathlib import Path
import hashlib,importlib.util,json
plan=Path('/tmp/sparkling-r122-profile-plan-20261024-v2')
root=Path('/var/tmp/sparkling-r122-profiles-20261024-v2')
spec=importlib.util.spec_from_file_location('r122_exact_arcs',plan/'collect.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.TARGETS={'Solve_With_Force':'mj__constraint_solvers__solve_with_force','Solve_Compatible_Buffers':'mj__data__inertia_phase__solve_compatible_buffers','Prepare_And_Solve':'mj__data__constrained__prepare_and_solve','Is_Ready':'mj__data__is_ready'}
binary=root/'counts/build/release/bin/flex_constrained_probe';rows=[]
for model in ['free','element_elastic_cross_elliptic_6']:
 gmon=root/'sampling'/model/'gmon.out';counts=module.arc_counts(binary,gmon)
 rows.append(dict(model=model,batches=2000,steps=200000,preparatory_evaluations=4000,counts=counts,gmon_sha256=hashlib.sha256(gmon.read_bytes()).hexdigest()))
result=dict(scope='Exact recorded mcount incoming entries in this -pg binary, grouped sized-symbol clones; not a universal invocation count if frontend-inlined copies exist. No corresponding measured C counters for these four routines are available.',
 binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),parser_sha256=hashlib.sha256((plan/'collect.py').read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows)
p=Path('/tmp/sparkling-r122-runtime-entry-audit-20261024.json');p.write_text(json.dumps(result,indent=2)+'\n')
for row in rows:
 print(row['model'])
 for short,item in row['counts'].items():print(short,item['calls'],'CALLERS',sorted(item['arcs'],key=lambda x:x['calls'],reverse=True)[:8])
print('RESULT_SHA',hashlib.sha256(p.read_bytes()).hexdigest())
