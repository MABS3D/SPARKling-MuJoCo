from pathlib import Path
import ast,hashlib,json
old=Path('/tmp/sparkling-single-solve-quiet-r140-20261024.py')
text=old.read_text();tree=ast.parse(text)
expected=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXPECTED' for t in n.targets))
current=Path('/var/tmp/sparkling-support-fused-r145-315-release-20261024')
baseline=Path('/var/tmp/sparkling-single-solve-r140-315-release-20261024')
prefix=Path('/var/tmp/sparkling-support-fusion-time-r145-vs-r140-C315-20261024-v1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected={p:h for p,h in expected.items() if '/sparkling-single-solve-r140-' not in p and '/sparkling-alignment-315-reuse-release-r122-' not in p}
for d in [current,baseline]:
 r=json.loads((d/'results.json').read_text());assert r['complete'] and r['source_hashes_unchanged']
 for f in ['manifest.json','results.json','force-build/release/bin/flex_constrained_probe']: expected[str(d/f)]=sha(d/f)
for model in ['membrane_Newton_3','free','element_2_sphere','element_mixed_pyramidal_3','element_elastic_cross_elliptic_6','element_elastic_self_bvh_pyramidal_3']:
 for ext in ['input','mjb']:
  p=current/'constrained'/(model+'.'+ext)
  assert p.read_bytes()==(baseline/'constrained'/p.name).read_bytes(),p
  expected[str(p)]=sha(p)
changes={'EXPECTED':repr(expected),'CURRENT':f'Path({str(current)!r})','BASELINE':f'Path({str(baseline)!r})','PREFIX':f'Path({str(prefix)!r})','HEAD':repr('e4edda457ebd8495871bdcc07384ce6c61c0bf76')}
lines=text.splitlines(True)
for node in reversed(tree.body):
 if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in changes:
  name=node.targets[0].id;lines[node.lineno-1:node.end_lineno]=[name+' = '+changes[name]+'\n']
text=''.join(lines)
text=text.replace('frozen single-solve r140 versus r122','frozen fused-support r145 versus single-solve r140')
text=text.replace('Frozen r140 single-solve plus proof-only refinements versus r122; source manifests, not the base HEAD alone, identify the candidate.','Frozen r145 fused numerical admission/support collection and static proof refinements versus r140 single-solve; exact source manifests identify both candidates.')
out=Path('/tmp/sparkling-support-quiet-r145-20261024.py');out.write_text(text);ast.parse(text)
print(json.dumps(dict(wrapper=str(out),sha256=sha(out),expected_files=len(expected),models_identical=True)))
