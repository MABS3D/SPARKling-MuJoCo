from pathlib import Path
import json, hashlib, shutil, gzip, zipfile, ast
root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
base=Path('/var/tmp'); ev=root/'experimental/alignment-3.15/evidence'
dest=base/'sparkling-row-buffer-hessian-r109-archive-stage'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,q):
 q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists() and sha(q)==sha(p):return
 shutil.copyfile(p,q);assert sha(q)==sha(p)
def write(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);data=json.dumps(d,indent=2)+'\n'
 if p.exists() and p.read_text()==data:return
 p.write_text(data)
def compress(p,q):
 q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists() and gzip.decompress(q.read_bytes())==p.read_bytes():return
 q.write_bytes(gzip.compress(p.read_bytes(),mtime=0)); assert gzip.decompress(q.read_bytes())==p.read_bytes()
inv=json.loads((ev/'inventory.json').read_text());old=dict(inv['files'])
assert len(old)==16257
for n,h in old.items(): assert sha(ev/n)==h,n
dest.mkdir(parents=True,exist_ok=True)
engines={}
names=('mj-constraint_solvers.adb','mj-constraint_solvers-hessian_assembly.ads','mj-constraint_solvers-hessian_assembly.adb','mj-constraint_solvers-packed_cholesky.ads','mj-constraint_solvers-packed_cholesky.adb','mj-constraint_solvers-cone_kernels.ads','mj-constraint_solvers-cone_kernels.adb')
for stage in range(103,110):
 p=base/f'sparkling-alignment-315-rowgram-engine-r{stage}-20261008'
 m=json.loads((p/'manifest.json').read_text()); assert all(sha(p/'source'/n)==h for n,h in m['sources'].items())
 engines[sha(p/'manifest.json')]=stage
 copy(p/'manifest.json',dest/f'inputs/r{stage}/manifest.json')
 for name in names:copy(p/'source/experimental/constraint-solvers-candidate/src'/name,dest/f'inputs/r{stage}'/name)
 if stage==109:
  sources=m['sources']; final=m
  with zipfile.ZipFile(dest/'inputs/r109/core-sources.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
   for n in sources:z.write(p/'source'/n,n)
  with zipfile.ZipFile(dest/'inputs/r109/core-sources.zip') as z:
   assert set(z.namelist())==set(sources)
   assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in sources.items())
runner=(root/'experimental/alignment-3.15/tests/prove_flex.py').read_text()
tree=ast.parse(runner)
scope_dict=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SCOPES' for t in n.targets))
entries={}
for key,value in zip(scope_dict.keys,scope_dict.values,strict=True):
 k,v=ast.literal_eval(key),ast.literal_eval(value)
 assert k not in entries or entries[k]==v,('Conflicting scope override',k)
 entries[k]=v
assert entries['Hessian_Scatter_Row'][0]=='mj-constraint_solvers-hessian_assembly'
assert entries['Scatter_Row'][0]=='mj-constraint_solvers-sparse_cholesky'
no_frame=''.join(l for l in runner.splitlines(keepends=True) if '"Selection_Frame":' not in l)
old_scatter=no_frame.replace('"Hessian_Scatter_Row":','"Scatter_Row":')
old_before=old_scatter.replace('"Hessian_Before": ("mj-constraint_solvers-hessian_assembly", ".adb"','"Hessian_Before": ("mj-constraint_solvers-hessian_assembly", ".ads"')
versions={hashlib.sha256(s.encode()).hexdigest():s for s in (runner,no_frame,old_scatter,old_before)}
for h,s in versions.items():
 p=dest/'runners'/f'prove_flex-{h}.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
attempts=[]
for p in sorted(base.glob('sparkling-alignment-315-rowgram-*-scope-r*-20261008')):
 if not (p/'results.json').exists():continue
 d=json.loads((p/'results.json').read_text()); stage=engines[d['manifest_sha256']]
 assert d['runner_sha256'] in versions,(p,d['runner_sha256'])
 assert sha(p/'proof.log')==d['log_sha256']
 for n in ('results.json','proof.log','unit.spark.json'):
  if (p/n).exists():copy(p/n,dest/'attempts'/p.name/n)
 attempts.append(dict(stage=stage,scope=d['subprogram'],receipt=str((dest/'attempts'/p.name/'results.json').relative_to(dest)),checks=d.get('checks'),passed=d.get('passed',False),report_rejected=d.get('report_rejected'),open=[dict(file=e['file'],line=e['line'],message=e['message']['text']) for e in d.get('open',[])]))
write(dest/'attempts.json',attempts)
selected=[d for d in attempts if d['stage']==108 and d['passed']]
assert len(selected)==12 and sum(d['checks'] for d in selected)==228
# r109 changes only the local constant used to declare Build_Transpose.Cursor.
a=(base/'sparkling-alignment-315-rowgram-engine-r108-20261008/source/experimental/constraint-solvers-candidate/src/mj-constraint_solvers-hessian_assembly.adb').read_text()
b=(base/'sparkling-alignment-315-rowgram-engine-r109-20261008/source/experimental/constraint-solvers-candidate/src/mj-constraint_solvers-hessian_assembly.adb').read_text()
assert a.replace('      Cursor : Entry_Counts (1 .. P.N);','      Size : constant Positive := P.N;\n      Cursor : Entry_Counts (1 .. Size);')==b
m108=json.loads((base/'sparkling-alignment-315-rowgram-engine-r108-20261008/manifest.json').read_text())
assert [n for n,h in sources.items() if m108['sources'][n]!=h]==['experimental/constraint-solvers-candidate/src/mj-constraint_solvers-hessian_assembly.adb']
write(dest/'minimum-closure.json',dict(stage=108,checks=228,scopes=selected,
 scope='Gold exact single update/scatter/frame and structural lemmas; Before/Term_Value/Row_Value only prove model bounds. These minima do not prove global Gram, transpose constructor, factor, caller or dynamics.',
 final_stage_change='Only the local constant for Build_Transpose.Cursor changes in r109; all twelve scoped subprograms and their contracts are unchanged. These are r108 receipts, not fresh r109 unit proof.',
 dependencies={'Scatter_Row':['Selection_Frame','Flat_Column_Separate','Row_Selected'],'Selection_Frame':['Selected_Step'],'Selected_Step':['Flat_Column_Separate'],'Flat_Column_Separate':['Flat_Row_Ordered'],'Gram_Element_Flat':['Gram_Scaled'],'Term_Value':['Trace_Step'],'Row_Value':['Term_Value','Gram_Scale']}))
for n in ('build_flex','build_rowgram','prove_flex'):copy(root/f'experimental/alignment-3.15/tests/{n}.py',dest/(n+'.py'))
for name in ('row_gram_probe.adb','mass_values_probe.adb','factor_values_probe.adb','test_row_gram.py','test_mass_addition.py','test_sparse_cholesky.py'):
 copy(root/'experimental/constraint-solvers-candidate/tests'/name,dest/'tests'/name)
copy(root/'experimental/constraint-solvers-candidate/solvers.gpr',dest/'solvers.gpr')
copy(root/'tools/guarded.py',dest/'guarded.py')
copy(root/'experimental/alignment-3.15/overlays/remove-internal-flex.patch',dest/'remove-internal-flex.patch')
for p in [Path(__file__),base/'sparkling-rowgram-minima-r108.py',base/'sparkling-rowgram-minima-r108.json',base/'sparkling-rowgram-final-r109.py',base/'sparkling-rowgram-final-r109.json',base/'sparkling-rowgram-verify-r108.py',base/'sparkling-rowgram-verify-r109.json',base/'sparkling-rowgram-quiet-r109.py',base/'sparkling-rowgram-quiet-r109.json',base/'sparkling-rowgram-tail-r109.py']:
 copy(p,dest/'runners'/p.name)
for folder,label in [('sparkling-alignment-315-rowgram-native-r104-20261008','native-r104'),('sparkling-alignment-315-rowgram-native-r109-20261008','native'),('sparkling-alignment-315-rowgram-release-r109-20261008','release'),('sparkling-alignment-314-rowgram-regression-r109-20261008','production')]:
 p=base/folder;d=json.loads((p/'results.json').read_text());assert d['complete']
 m=json.loads((p/'manifest.json').read_text());assert all(sha(p/'source'/n)==h for n,h in m['sources'].items())
 if label in ('native','release'):assert all(m['sources'].get(n)==h for n,h in sources.items())
 for f in p.iterdir():
  if f.is_file():copy(f,dest/label/f.name)
 dirs=('row_gram_probe','mass_values_probe','factor_values_probe') if label.startswith('native') else ('state','forces','constrained')
 for name in dirs:
  q=p/name;rd=json.loads((q/'results.json').read_text());assert rd['cases']==rd['passed'] and not rd.get('failures')
  for f in q.rglob('*'):
   if not f.is_file() or f.suffix=='.so':continue
   out=dest/label/name/f.relative_to(q)
   if f.suffix in ('.txt','.output'):compress(f,out.with_name(out.name+'.gz'))
   else:copy(f,out)
 binaries={str(f.relative_to(p)):dict(sha256=sha(f),bytes=f.stat().st_size) for f in p.rglob('bin/*') if f.is_file()}
 write(dest/label/'binaries.json',binaries)
 if label=='native':
  for n in m['sources']:
   if n not in sources:copy(p/'source'/n,dest/'native-extra-inputs'/n)
for baseline in ('r96','r102'):
 p=base/f'sparkling-alignment-315-rowgram-time-r109-vs-{baseline}-quiet-20261008'
 d=json.loads((p/'results.json').read_text());assert d['complete'] and d['quiet_window'] and all(r['passed'] for r in d['results'])
 for f in p.rglob('*'):
  if f.is_file() and f.suffix!='.so':copy(f,dest/f'paired-time-vs-{baseline}'/f.relative_to(p))
for n in ('engine_util_sparse.c','engine_util_sparse.h','engine_util_solve.c','engine_solver.c'):
 copy(base/'sparkling-alignment-315-foundation-r6-20261007/source/mujoco/src/engine'/n,dest/'reference'/n)
write(dest/'results.json',dict(reference='3.15.0',source_count=len(sources),minimum_checks=228,minimum_scopes=12,minimum_stage=108,final_stage=109,gram_passed=237,gram_actual_c_bitwise=233,transpose_actual_c_cases=237,mass_passed=180,factor_passed=407,release_passed=390,production_passed=366,numerical_comparisons=1580,actual_c_numerical_comparisons=1576,whole_gram_gold_closed=False,whole_transpose_gold_closed=False,whole_factor_gold_closed=False,whole_solver_gold_closed=False,whole_dynamics_gold_closed=False,production_315_migrated=False,goal_complete=False,
 pending=[r for r in attempts if r['stage']==109 and not r['passed']],scope='Single-row C sparse Gram accumulation and flat scatter, across scalar and folded elliptic paths. C supernode batching, native slot-wise Hessian, general sparse mass union and legacy dense rank-update bridge remain pending.'))
for n,h in old.items():assert sha(ev/n)==h,n
copy(base/'archive-sparkling-rowgram-r109.py',dest/'runners/archive-sparkling-rowgram-r109-failed.py')
write(dest/'archive-failure.json',dict(operation='Initial uncompressed copy into the Windows repository',error='OSError errno 5: Input/output error while copying a native extra input; C: became full',partial_archive_indexed=False,authoritative_sources='All exact inputs, reports and outputs retained under /var/tmp'))
members={str(p.relative_to(dest)):sha(p) for p in dest.rglob('*') if p.is_file()}
write(dest/'archive-manifest.json',dict(files=members,count=len(members)))
packed=base/'sparkling-row-buffer-hessian-r109-complete.zip'
assert not packed.exists()
with zipfile.ZipFile(packed,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in dest.rglob('*'):
  if p.is_file():z.write(p,str(p.relative_to(dest)))
with zipfile.ZipFile(packed) as z:
 assert set(z.namelist())==set(members)|{'archive-manifest.json'}
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in members.items())
final_dest=ev/'20261008-row-buffer-hessian-r109'
assert all(not n.startswith('20261008-row-buffer-hessian-r109/') for n in old)
# Delete only this run's incomplete, unindexed generated copy. The complete
# reconstructed archive and every original input/output are safe on Linux.
if final_dest.exists():shutil.rmtree(final_dest)
final_dest.mkdir()
copy(packed,final_dest/'complete.zip')
assert sha(final_dest/'complete.zip')==sha(packed)
public=['results.json','attempts.json','minimum-closure.json','archive-manifest.json','archive-failure.json','inputs/r109/manifest.json']
for baseline in ('r96','r102'):
 public.extend([f'paired-time-vs-{baseline}/results.json',f'paired-time-vs-{baseline}/tail-audit.json'])
for name in public:copy(dest/name,final_dest/name)
write(final_dest/'archive.json',dict(zip_sha256=sha(packed),zip_bytes=packed.stat().st_size,members=len(members)+1,all_member_hashes_checked=True,linux_archive=str(packed),format='ZIP with per-member SHA-256 archive-manifest.json; exact runners, all stage sources, proof failures, numerical cases and raw timing remain inside complete.zip'))
for n,h in old.items():assert sha(ev/n)==h,n
for p in final_dest.rglob('*'):
 if p.is_file():inv['files'][str(p.relative_to(ev))]=sha(p)
inv['count']=inv['current_entries']=len(inv['files']);inv['row_buffer_prior_entries_preserved']=len(old)
(ev/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
for n,h in inv['files'].items():assert sha(ev/n)==h,n
print(json.dumps(dict(entries=len(inv['files']),prior_preserved=len(old),checks=228,scopes=12,archive_bytes=packed.stat().st_size,members=len(members)+1)))
