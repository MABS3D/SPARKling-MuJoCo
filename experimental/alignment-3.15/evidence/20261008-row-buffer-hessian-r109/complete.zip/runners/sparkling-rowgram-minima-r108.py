from pathlib import Path
import json, subprocess, hashlib, time
root = Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
runner = root/'experimental/alignment-3.15/tests/prove_flex.py'
engine = '/var/tmp/sparkling-alignment-315-rowgram-engine-r108-20261008'
scopes = [
 ('before','Hessian_Before'), ('trace','Trace_Step'),
 ('term','Term_Value'), ('row','Row_Value'),
 ('ordered','Packed_Flat_Row_Ordered'),
 ('separate','Packed_Flat_Column_Separate'), ('selected','Packed_Selected_Step'),
 ('membership','Packed_Row_Selected'), ('scaled','Gram_Scaled'),
 ('element','Gram_Element_Flat'), ('scatter','Hessian_Scatter_Row'),
 ('transpose','Build_Transpose'), ('gram','Build_Gram')]
rows=[]
for label, scope in scopes:
 out = Path('/var/tmp')/f'sparkling-alignment-315-rowgram-{label}-scope-r108-20261008'
 cmd=['python3',str(runner),'--engine',engine,'--out',str(out),'--subprogram',scope]
 start=time.monotonic(); run=subprocess.run(cmd,cwd=root)
 rows.append(dict(scope=scope,command=cmd,exit=run.returncode,seconds=time.monotonic()-start,
                  runner_sha256=hashlib.sha256(runner.read_bytes()).hexdigest()))
 Path('/var/tmp/sparkling-rowgram-minima-r108.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(scope,run.returncode,flush=True)
 # Preserve global gaps without blocking numerical/performance evaluation.
 if run.returncode and scope not in ('Hessian_Before','Build_Transpose','Build_Gram'):
  raise SystemExit(run.returncode)
