from pathlib import Path
import json, subprocess, time, hashlib, os, re
root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
py='/var/tmp/sparkling-movement315-env/bin/python'
driver=Path('/var/tmp/sparkling-alignment-315-flat-time-r67-quiet-20261008/benchmark_constrained.py')
current=Path('/var/tmp/sparkling-alignment-315-rowgram-release-r109-20261008')
assert json.loads((current/'results.json').read_text())['complete']
models=['membrane_Newton_3','free','element_2_sphere','element_mixed_pyramidal_3','element_elastic_cross_elliptic_6','element_elastic_self_bvh_pyramidal_3']
rows=[]
for stage,folder in [('r96','mass'),('r102','hessian')]:
 processes=subprocess.check_output(['ps','-eo','pid,comm,args'],text=True)
 blockers=[]
 for line in processes.splitlines()[1:]:
  pid,comm,args=line.split(None,2)
  if int(pid) in (os.getpid(),os.getppid()):continue
  if comm in ('gprbuild','gnatprove','gnat2why','gnatwhy3','gnat1','gcc','cc1','cc1plus','ninja','make','z3','cvc5','altergo') or (
    comm in ('init','/init') and re.search(r'\b(?:pytest|benchmark_generation)\b',args)):
   blockers.append(dict(pid=int(pid),process=comm))
 assert not blockers,('Concurrent workload',blockers)
 baseline=Path(f'/var/tmp/sparkling-alignment-315-{folder}-release-{stage}-20261008/force-build/release/bin/flex_constrained_probe')
 out=Path(f'/var/tmp/sparkling-alignment-315-rowgram-time-r109-vs-{stage}-quiet-20261008')
 cmd=[py,str(root/'tools/guarded.py'),'--cap-mb','2500','--timeout','600','--',py,str(driver),'--binary',str(current/'force-build/release/bin/flex_constrained_probe'),'--baseline',str(baseline),'--cases',str(current/'constrained'),'--out',str(out),'--blocks','24','--batches','16','--steps','100','--cpu','0','--quiet-window','--reference','3.15.0','--models',*models]
 start=time.monotonic();run=subprocess.run(cmd,cwd=root)
 rows.append(dict(baseline=stage,command=cmd,exit=run.returncode,seconds=time.monotonic()-start,runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),preflight_heavy_jobs=blockers))
 Path('/var/tmp/sparkling-rowgram-quiet-r109.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(stage,run.returncode,flush=True)
 if run.returncode:raise SystemExit(run.returncode)
