from pathlib import Path
import subprocess, json, hashlib, time
root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
py='/var/tmp/sparkling-movement315-env/bin/python'
rows=[]
for label,cmd in [
 ('native',[py,str(root/'experimental/alignment-3.15/tests/build_rowgram.py'),'--engine','/var/tmp/sparkling-alignment-315-rowgram-engine-r109-20261008','--out','/var/tmp/sparkling-alignment-315-rowgram-native-r109-20261008','--python',py,'--reference','/var/tmp/sparkling-alignment-315-foundation-r6-20261007/source/mujoco']),
 ('release',[py,str(root/'experimental/alignment-3.15/tests/build_flex.py'),'--foundation','/var/tmp/sparkling-alignment-315-foundation-r6-20261007','--out','/var/tmp/sparkling-alignment-315-rowgram-release-r109-20261008','--python',py,'--mode','release']),
 ('production',['/var/tmp/sparkling-movement-env/bin/python',str(root/'experimental/alignment-3.15/tests/build_flex.py'),'--foundation','/var/tmp/sparkling-alignment-314-foundation-r2-20261007','--out','/var/tmp/sparkling-alignment-314-rowgram-regression-r109-20261008','--python','/var/tmp/sparkling-movement-env/bin/python','--mode','release','--production-regression'])]:
 start=time.monotonic();r=subprocess.run(cmd,cwd=root)
 rows.append(dict(label=label,command=cmd,exit=r.returncode,seconds=time.monotonic()-start,runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
 Path('/var/tmp/sparkling-rowgram-verify-r109.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
