from pathlib import Path
import json,subprocess,time,hashlib
root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
runner=root/'experimental/alignment-3.15/tests/prove_flex.py'
rows=[]
for label,scope in [('transpose','Build_Transpose'),('gram','Build_Gram')]:
 out=f'/var/tmp/sparkling-alignment-315-rowgram-{label}-scope-r109-20261008'
 cmd=['python3',str(runner),'--engine','/var/tmp/sparkling-alignment-315-rowgram-engine-r109-20261008','--out',out,'--subprogram',scope,'--proof-timeout','1']
 start=time.monotonic();run=subprocess.run(cmd,cwd=root)
 rows.append(dict(scope=scope,command=cmd,exit=run.returncode,seconds=time.monotonic()-start,runner_sha256=hashlib.sha256(runner.read_bytes()).hexdigest()))
 Path('/var/tmp/sparkling-rowgram-final-r109.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(scope,run.returncode,flush=True)
run=subprocess.run(['python3','/var/tmp/sparkling-rowgram-verify-r108.py'],cwd=root)
raise SystemExit(run.returncode)
