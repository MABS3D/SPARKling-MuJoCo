#!/usr/bin/env python3
"""Reanalyse the exact completed historical C3.15 r122/r120 quiet run."""
from pathlib import Path
import hashlib
import json
import numpy as np

INPUT = Path('/var/tmp/sparkling-reuse-time-r122-vs-r120-C315-20261024-v1/results.json')
WATCH = Path(str(INPUT.parent)+'-watch.json')
OUTPUT = Path('/tmp/sparkling-reuse-timing-summary-r122-20261024')
EXPECTED_INPUT_SHA = '8bd82fec7f049248751875125062aded930f2c4c434d89983a6edeaf5cf1953f'
MODELS = ['membrane_Newton_3', 'free', 'element_2_sphere', 'element_mixed_pyramidal_3',
          'element_elastic_cross_elliptic_6', 'element_elastic_self_bvh_pyramidal_3']
DRAWS = 20000
SEED = 2026102401
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(INPUT) == EXPECTED_INPUT_SHA
report = json.loads(INPUT.read_text())
watch = json.loads(WATCH.read_text())
assert report['complete'] and report['reference'] == '3.15.0'
assert (report['blocks'], report['batches'], report['steps']) == (24,16,100)
assert report['affinity'] == [0] and report['warmup_trajectories_per_block'] == 1
assert all(watch[k] is True for k in ('complete','quiet_verified','integrity_verified','numeric_passed'))
assert watch['exit'] == 0 and watch['results_sha256'] == EXPECTED_INPUT_SHA
assert all(not watch[k]['failures'] for k in ('before','after'))
assert [r['model'] for r in report['results']] == MODELS
rng = np.random.default_rng(SEED)

def ci(values):
    return np.quantile(values, [.025,.975]).tolist()

def family_ci(values):
    # Six workload comparisons; Bonferroni percentile interval, diagnostic only.
    return np.quantile(values, [.05/(2*6), 1-.05/(2*6)]).tolist()

def resolved(interval):
    return 'faster' if interval[1] < 1 else 'slower' if interval[0] > 1 else 'unresolved'

def compare(a, b, indices):
    ar = a.mean(axis=1)
    br = b.mean(axis=1)
    mean_draws = ar[indices].mean(axis=1) / br[indices].mean(axis=1)
    ratios = ar/br
    median_draws = np.median(ratios[indices], axis=1)
    paired_mean_draws = ratios[indices].mean(axis=1)
    difference_draws = (ar-br)[indices].mean(axis=1)
    mean_ratio = float(ar.mean()/br.mean())
    median_ratio = float(np.median(ratios))
    mean_interval = ci(mean_draws)
    median_interval = ci(median_draws)
    adjusted_interval = family_ci(mean_draws)
    return dict(ratio_of_means=mean_ratio, bootstrap_95=mean_interval,
        duration_change_percent=100*(mean_ratio-1), duration_change_percent_95=[100*(x-1) for x in mean_interval],
        resolved_pointwise95=resolved(mean_interval),
        mean_ratio_bonferroni_six_models_interval=adjusted_interval,
        mean_ratio_bonferroni_six_models_resolved=resolved(adjusted_interval),
        median_of_paired_block_mean_ratios=median_ratio,
        median_of_paired_block_mean_ratios_95=median_interval,
        median_duration_change_percent=100*(median_ratio-1),
        median_duration_change_percent_95=[100*(x-1) for x in median_interval],
        median_resolved_pointwise95=resolved(median_interval),
        mean_of_paired_block_mean_ratios=float(ratios.mean()),
        mean_of_paired_block_mean_ratios_95=ci(paired_mean_draws),
        paired_mean_difference_us_per_step=float((ar-br).mean()),
        paired_mean_difference_us_per_step_95=ci(difference_draws))

rows=[]
for original in report['results']:
    assert original['passed'] and original['blocks_complete'] == 24 and original['sample'] == 1
    raw={k:np.asarray(original['raw_us'][k],dtype=float) for k in ('ada','baseline','c')}
    assert all(v.shape == (24,16) and np.all(np.isfinite(v)) and np.all(v>0) for v in raw.values())
    indices = rng.integers(0,24,size=(DRAWS,24))
    center={}
    tails={}
    tail_draws={}
    for language, values in raw.items():
        block_means = values.mean(axis=1)
        mean_draws = block_means[indices].mean(axis=1)
        center[language]=dict(mean_us_per_step=float(values.mean()),
            mean_us_per_step_95=ci(mean_draws),
            mean_us_per_100_step_trajectory=float(values.mean()*100),
            mean_us_per_100_step_trajectory_95=[x*100 for x in ci(mean_draws)],
            median_of_block_means_us_per_step=float(np.median(block_means)),
            trajectory_duration_sd_us=float(np.std(values*100,ddof=1)),
            block_mean_sd_us_per_step=float(np.std(block_means,ddof=1)))
        qdraws=np.empty(DRAWS)
        for start in range(0,DRAWS,1000):
            picked=values[indices[start:start+1000]].reshape(-1,24*16)
            qdraws[start:start+1000]=np.quantile(picked,.95,axis=1)
        tail_draws[language]=qdraws
        tails[language]=dict(p95_us_per_100_step_trajectory=float(np.quantile(values,.95)*100),
            p95_us_per_100_step_trajectory_95=[x*100 for x in ci(qdraws)])
    def tail_compare(denominator):
        point=float(np.quantile(raw['ada'],.95)/np.quantile(raw[denominator],.95))
        interval=ci(tail_draws['ada']/tail_draws[denominator])
        return dict(p95_ratio=point,bootstrap_95=interval,duration_change_percent=100*(point-1),
            duration_change_percent_95=[100*(x-1) for x in interval],resolved_pointwise95=resolved(interval))
    baseline=compare(raw['ada'],raw['baseline'],indices)
    c=compare(raw['ada'],raw['c'],indices)
    consistent=(baseline['resolved_pointwise95'] == baseline['median_resolved_pointwise95']
                and baseline['resolved_pointwise95'] != 'unresolved')
    rows.append(dict(model=original['model'],nv=original['nv'],sample=1,timing=center,
        r122_over_r120=baseline,r122_over_C315=c,trajectory_p95=tails,
        p95_r122_over_r120=tail_compare('baseline'),p95_r122_over_C315=tail_compare('c'),
        location_estimators_agree_on_resolved_direction=consistent,
        state_max_abs_vs_C315=original['state_max_abs'],
        model_sha256=original['model_sha256'],original_input_sha256=original['original_input_sha256']))
summary=dict(reference='Historical C3.15.0, not current C3.17.0; no latest-stable parity claim',
    scope='Frozen combined r122 Hessian/packed-update changes vs frozen r120 on six sample1 FLEX models; no arbitrary average across workloads or isolated-change attribution.',
    input=str(INPUT),input_sha256=sha(INPUT),watch=str(WATCH),watch_sha256=sha(WATCH),
    analysis_script=str(Path(__file__)),analysis_script_sha256=sha(__file__),
    binaries=report['binaries'],source_manifest_sha256={k:v['sha256'] for k,v in report['source_manifests'].items()},
    library_sha256=report['library_sha256'],quiet_scope=watch['scope'],
    integrity_verified=watch['integrity_verified'],numeric_passed=watch['numeric_passed'],
    paired_bootstrap=dict(draws=DRAWS,seed=SEED,unit='24 complete alternating blocks sampled with replacement, retaining all16 trajectories and all3 implementations per block',
        interval='Percentile bootstrap, pointwise95%; companion Bonferroni interval for six mean-ratio workload comparisons',
        mean_estimator='Ratio of arithmetic means of all per-step trajectory-average durations; mean of paired block ratios retained separately',
        median_estimator='Median of paired ratios of block-mean durations',
        tail_estimator='P95 of whole100-step trajectory duration; paired complete-block bootstrap. Not the distribution of individual-step latency.',
        caveats='24 block units, not384 independent trajectories. Percentile intervals assume blocks represent repeat variability. No cross-machine or cross-model generalization; no serial-dependence correction. Unresolved intervals do not prove equivalence.'),
    started_utc=watch['started_utc'],finished_utc=watch['finished_utc'],results=rows)
OUTPUT.with_suffix('.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['Historical C3.15; r122 vs r120. Duration change <0 means faster. All95% intervals are paired complete-block bootstrap,20000 draws. No aggregate across models.','',
       'model | mean us/step r122/r120/C | r122/r120 mean duration change[95%CI] | median paired ratio change[95%CI] | p95 trajectory change[95%CI] | mean r122/C[95%CI]']
for r in rows:
    m=r['r122_over_r120'];t=r['p95_r122_over_r120'];c=r['r122_over_C315'];u=r['timing']
    lines.append(f"{r['model']} | {u['ada']['mean_us_per_step']:.3f}/{u['baseline']['mean_us_per_step']:.3f}/{u['c']['mean_us_per_step']:.3f} | {m['duration_change_percent']:+.2f}%[{m['duration_change_percent_95'][0]:+.2f},{m['duration_change_percent_95'][1]:+.2f}] | {m['median_duration_change_percent']:+.2f}%[{m['median_duration_change_percent_95'][0]:+.2f},{m['median_duration_change_percent_95'][1]:+.2f}] | {t['duration_change_percent']:+.2f}%[{t['duration_change_percent_95'][0]:+.2f},{t['duration_change_percent_95'][1]:+.2f}] | {c['ratio_of_means']:.3f}x[{c['bootstrap_95'][0]:.3f},{c['bootstrap_95'][1]:.3f}]")
    lines.append('  mean-ratio direction with Bonferroni six-model interval: '+m['mean_ratio_bonferroni_six_models_resolved']+' '+str(m['mean_ratio_bonferroni_six_models_interval']))
text='\n'.join(lines)+'\n'
OUTPUT.with_suffix('.txt').write_text(text)
print(text)
print('SUMMARY_SHA256',sha(OUTPUT.with_suffix('.json')))
print('SCRIPT_SHA256',sha(__file__))
