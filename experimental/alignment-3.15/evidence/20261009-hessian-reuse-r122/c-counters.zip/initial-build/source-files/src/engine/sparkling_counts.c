#include "engine/sparkling_counts.h"
#include <stdatomic.h>
static _Atomic uint64_t counters[SPARK_COUNTER_COUNT];
void sparkling_count_add(enum sparkling_counter which, uint64_t amount) {
  atomic_fetch_add_explicit(counters+which, amount, memory_order_relaxed);
}
void sparkling_count_reset(void) {
  for (int i=0; i<SPARK_COUNTER_COUNT; ++i) atomic_store_explicit(counters+i, 0, memory_order_relaxed);
}
void sparkling_count_read(uint64_t* out) {
  for (int i=0; i<SPARK_COUNTER_COUNT; ++i) out[i]=atomic_load_explicit(counters+i, memory_order_relaxed);
}
