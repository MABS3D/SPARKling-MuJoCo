from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent;results=Path('/var/tmp/sparkling-c315-source-count-callsite-r121-20261009');wheel=Path('/var/tmp/sparkling-c315-wheel-count-results-20261009');plan=Path('/var/tmp/sparkling-c315-call-diagnostic-plan-20261009');cases=Path('/var/tmp/sparkling-alignment-315-scatter-release-r111-20261009/constrained');foundation=Path('/var/tmp/sparkling-alignment-315-foundation-r6-20261007/source/mujoco');dest=Path('/var/tmp/sparkling-c315-private-counters-r121-evidence-20261009.zip');files={}
def add(path,name):assert path.is_file();assert name not in files;files[name]=path
for name in ['prepare.py','build.py','run.py','capture.py','wheel_reference.py','counter_probe.c']:
 add(plan/name,'drivers/'+name)
for name in ['extend-callsite-counts.py','summarize.py','package_evidence.py']:
 add(root/name,'drivers/'+name)
for name in ['manifest.json','instrumentation.patch','build-result.json','build-commands.json','configure.log','build.log','probe-build.log','linkage.txt']:
 add(root/name,'build-receipts/'+name)
add(root/'build/compile_commands.json','build-receipts/compile_commands.json');add(root/'build/CMakeCache.txt','build-receipts/CMakeCache.txt')
for p in (root/'history/v1').rglob('*'):
 if p.is_file() and p.name not in ['counter_probe','libmujoco.so.3.15.0']:add(p,'initial-build/'+p.relative_to(root/'history/v1').as_posix())
manifest=json.loads((root/'manifest.json').read_text())
for name in manifest['modified_hashes']:add(root/'source'/name,'instrumented-source/'+name)
for name in manifest['original_hashes']:add(foundation/name,'reference-source/'+name)
for p in results.iterdir():
 if p.is_file():add(p,'results/'+p.name)
for p in wheel.iterdir():
 if p.is_file():add(p,'unchanged-wheel-evidence/'+p.name)
for name in ['membrane_Newton_3','free','element_2_sphere','element_mixed_pyramidal_3','element_elastic_cross_elliptic_6','element_elastic_self_bvh_pyramidal_3']:
 for suffix in ['.mjb','.input']:add(cases/(name+suffix),'cases/'+name+suffix)
add(Path('/var/tmp/sparkling-c315-source-count-results-r121-20261009/results.json'),'initial-results/results.json')
readme='''C3.15 private Hessian counters, final differentiated diagnostic, 2026-10-09.\n\nReference commit:9ea3cdfcae93bf2cc4dc0e1a1627c5a39a1e06e5. All6 models, sample1,100 steps,16 measured trajectories,1 excluded warmup; endpoint0 and supplemental endpoint2 are separate runs. Normal AVX intrinsics enabled, ffp-contract off, LTO off. No timings/gain attribution. All per-step states have maximum absolute difference0 against the unchanged wheel; solver statistics match, and exported Gram/factor counts match the earlier exact-wheel run every step/endpoint.\n\nRead results/counts-summary.json for per-step histograms and separate preparation counts. The three added callsite counters distinguish cone rank updates, quadratic updates and quadratic downdates; their sum equals all sparse rank updates at every measured step. Entry counts are not flop counts. Source build is not identical machine code to the measured wheel.\n\nOriginal commands:\n/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-call-diagnostic-plan-20261009/prepare.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009\n/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/build.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009\n/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/extend-callsite-counts.py\n/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/build.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009\n/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/run.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009 --cases /var/tmp/sparkling-alignment-315-scatter-release-r111-20261009/constrained --results /var/tmp/sparkling-c315-source-count-callsite-r121-20261009 --sample1 --steps100 --batches16 --warmup1\n/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/summarize.py /var/tmp/sparkling-c315-source-count-callsite-r121-20261009 /var/tmp/sparkling-c315-source-counters-r121-20261009\n\nFor another machine, supply a local Git repository containing the pinned upstream commit to prepare.py --git, the packaged reference-source directory to --foundation, and fresh output paths. Copy extend-callsite-counts.py/summarize.py into the output directory before executing. The extension script currently names the original Git checkout explicitly; adjust that path only or directly apply the final instrumentation.patch to a fresh pinned archive. Use the packaged cases directory for run.py --cases. Driver guard paths and summarizer wheel-evidence path also reflect the original machine; preserve hashes when replaying originals and record any path-only adaptation separately. Build/runtime guards are documented in build-commands.json and per-run guard logs.\n\nBuild objects and compiled libraries/executables are excluded; their hashes/linkage/compile commands are retained. Initial17-counter build receipt/source patch is preserved separately, followed by final20-counter patch/manifest. Prepared scripts precede execution; executed evidence is in build-receipts and results.\n'''.replace('--sample1 --steps100 --batches16 --warmup1','--sample 1 --steps 100 --batches 16 --warmup 1')
sha={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()};sha['README.txt']=hashlib.sha256(readme.encode()).hexdigest();filemanifest=json.dumps(dict(entries=sha,source_commit=manifest['commit'],scope='Self-contained text/raw-data diagnostic evidence; upstream archive pinned, compiled objects excluded.'),indent=2)+'\n'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('README.txt',readme);z.writestr('MANIFEST.json',filemanifest)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for name,digest in sha.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
receipt=dict(zip_path=str(dest),zip_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),size_bytes=dest.stat().st_size,entry_count=len(files)+2,crc_verified=True,all_entry_hashes_verified=True,source_commit=manifest['commit'])
Path(str(dest)+'.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
