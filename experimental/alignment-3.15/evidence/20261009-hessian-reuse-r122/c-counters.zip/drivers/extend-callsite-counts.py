from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
out=Path(__file__).resolve().parent;source=out/'source';mp=out/'manifest.json';manifest=json.loads(mp.read_text());oldmanifest=mp.read_bytes();history=out/'history/v1';history.mkdir(parents=True,exist_ok=False)
for name,digest in manifest['modified_hashes'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
for name in ['manifest.json','instrumentation.patch','build-result.json','build-commands.json','configure.log','build.log','probe-build.log','linkage.txt','counter_probe']:
 shutil.copy2(out/name,history/name)
oldbuild=json.loads((out/'build-result.json').read_text());shutil.copy2(oldbuild['library'],history/'libmujoco.so.3.15.0')
for name in manifest['modified_hashes']:
 p=history/'source-files'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,p)
p=source/'src/engine/engine_solver.c';s=p.read_text();needle='          mju_cholUpdateSparse(ctx->Lcone, LTJ+r*nnz, nv, 1,';assert s.count(needle)==1;s=s.replace(needle,'          sparkling_count_add(SPARK_ConeRankUpdate, 1);\n'+needle)
needle='        rank = mju_cholUpdateSparse(ctx->L, cholupd, nv, flag_update,';assert s.count(needle)==1;s=s.replace(needle,'        sparkling_count_add(flag_update ? SPARK_QuadraticRankUpdate : SPARK_QuadraticRankDowndate, 1);\n'+needle);p.write_text(s)
new=['ConeRankUpdate','QuadraticRankUpdate','QuadraticRankDowndate'];p=source/'src/engine/sparkling_counts.h';s=p.read_text();assert s.count('  SPARK_COUNTER_COUNT')==1;s=s.replace('  SPARK_COUNTER_COUNT',''.join('  SPARK_'+n+',\n' for n in new)+'  SPARK_COUNTER_COUNT');p.write_text(s)
manifest['counter_names']+=new;manifest['instrumentation_revision']=2;manifest['previous_manifest_sha256']=hashlib.sha256(oldmanifest).hexdigest();manifest['previous_artifact_snapshot']=str(history);manifest['modified_hashes']={n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in manifest['modified_hashes']}
patch='';repo='/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/mujoco'
for name in manifest['modified_hashes']:
 before='' if name.startswith('src/engine/sparkling_counts.') else subprocess.check_output(['git','-C',repo,'show',manifest['commit']+':'+name],text=True)
 patch+=''.join(difflib.unified_diff(before.splitlines(True),(source/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(out/'instrumentation.patch').write_text(patch);manifest['patch_sha256']=hashlib.sha256((out/'instrumentation.patch').read_bytes()).hexdigest();mp.write_text(json.dumps(manifest,indent=2)+'\n');(history/'preservation.json').write_text(json.dumps(dict(scope='First17-counter build preserved before adding three sparse-rank callsite counters',library_preserved=str(history/'libmujoco.so.3.15.0'),probe_preserved=str(history/'counter_probe'),original_library_sha256=oldbuild['library_sha256'],original_probe_sha256=oldbuild['probe_sha256']),indent=2)+'\n');print('Added callsite counters, original build/evidence preserved at',history)
