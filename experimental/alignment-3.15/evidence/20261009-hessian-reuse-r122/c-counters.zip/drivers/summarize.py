#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,collections,sys
p=Path(sys.argv[1]);r=json.loads((p/'results.json').read_text());source=Path(sys.argv[2]);m=json.loads((source/'manifest.json').read_text());names=m['counter_names'];prior=Path('/var/tmp/sparkling-c315-wheel-count-results-20261009');pw=json.loads((prior/'results.json').read_text());assert r['complete']
rows=[]
for row in r['rows']:
 model,ep=row['model'],row['endpoint_forwards'];raw=json.loads((p/f'{model}-endpoints-{ep}-instrumented.json').read_text());wr=json.loads((prior/f'{model}-ep{ep}-hooked.json').read_text());ts=raw['trajectories'][r['warmup']:];wt=wr['trajectories'][pw['warmup']:];assert len(ts)==len(wt)==r['batches'];hist={n:collections.Counter() for n in names};same=True
 for t,w in zip(ts,wt,strict=True):
  assert len(t['per_step'])==len(w['per_step'])==r['steps']
  for step,wstep in zip(t['per_step'],w['per_step'],strict=True):
   for n,value in zip(names,step['counts'],strict=True):hist[n][int(value)]+=1
   assert step['counts'][names.index('cholUpdateSparse')]==sum(step['counts'][names.index(n)] for n in ['ConeRankUpdate','QuadraticRankUpdate','QuadraticRankDowndate'])
   same &= [step['counts'][names.index('cholFactorNumeric')],step['counts'][names.index('sqrMatTDSparseNumeric')]]==wstep['counts']
  same &= [t['endpoint_counts'][names.index('cholFactorNumeric')],t['endpoint_counts'][names.index('sqrMatTDSparseNumeric')]]==w['endpoint_counts']
 summaries={n:dict(total=row['step_counts'][n],mean_per_step=row['step_counts'][n]/row['integration_steps'],histogram=dict(sorted(hist[n].items()))) for n in names}
 rows.append(dict(model=model,endpoint_forwards=ep,state_max_abs=row['state_max_abs'],states_and_stats_match=row['validated_for_call_comparison'],utility_counts_match_unchanged_wheel_every_step_and_endpoint=bool(same),repeated_counts_identical=row['repeated_trajectory_counts_identical'],steps=row['integration_steps'],counts=summaries,preparation_counts=row['endpoint_counts']))
 assert same
receipt=dict(complete=True,source_commit=m['commit'],scope='Source-instrumented C3.15 diagnostics, normal AVX; no timings. Compare all per-step states/solver stats with untouched wheel and both exported numeric counts with earlier exact-wheel hook run. Neither implies identical machine code.',results_sha256=hashlib.sha256((p/'results.json').read_bytes()).hexdigest(),source_manifest_sha256=hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest(),summarizer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),counter_scope='Hessian helpers count entries; gate counters count decisions, not all uses of cached decision; cholUpdateSparse includes all utility callers; three additional callsite counters separate cone rank updates and quadratic row updates/downdates. Their per-step sum is asserted equal to the utility total on these trajectories. GramSingleRows/GramBatchedRows count rows handled, not Gram calls.',rows=rows)
(p/'counts-summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
keys=['MakeHessian','FactorizeHessian','FactorizeRecompute','HessianIncremental','HessianConeFolded','HessianConeUpdate','cholUpdateSparse','ConeRankUpdate','QuadraticRankUpdate','QuadraticRankDowndate','GateFold','GateUpdate','NewtonCertificate']
lines=['Private C3.15 diagnostics; counts per measured step; no timing claim.','Columns: '+', '.join(keys)]
for row in rows:
 if row['endpoint_forwards']==0:lines.append(row['model']+': '+', '.join(f"{row['counts'][k]['mean_per_step']:.4g}" for k in keys)+f"; state maxabs={row['state_max_abs']:.3g}; exact-wheel utility counts match={row['utility_counts_match_unchanged_wheel_every_step_and_endpoint']}")
lines+=['All12 model/endpoint variants are preserved in JSON with per-step histograms and separate preparation counts.',receipt['counter_scope']]
(p/'counts-summary.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
