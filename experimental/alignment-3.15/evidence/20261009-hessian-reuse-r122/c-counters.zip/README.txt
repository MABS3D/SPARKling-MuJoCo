C3.15 private Hessian counters, final differentiated diagnostic, 2026-10-09.

Reference commit:9ea3cdfcae93bf2cc4dc0e1a1627c5a39a1e06e5. All6 models, sample1,100 steps,16 measured trajectories,1 excluded warmup; endpoint0 and supplemental endpoint2 are separate runs. Normal AVX intrinsics enabled, ffp-contract off, LTO off. No timings/gain attribution. All per-step states have maximum absolute difference0 against the unchanged wheel; solver statistics match, and exported Gram/factor counts match the earlier exact-wheel run every step/endpoint.

Read results/counts-summary.json for per-step histograms and separate preparation counts. The three added callsite counters distinguish cone rank updates, quadratic updates and quadratic downdates; their sum equals all sparse rank updates at every measured step. Entry counts are not flop counts. Source build is not identical machine code to the measured wheel.

Original commands:
/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-call-diagnostic-plan-20261009/prepare.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009
/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/build.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009
/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/extend-callsite-counts.py
/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/build.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009
/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/run.py --out /var/tmp/sparkling-c315-source-counters-r121-20261009 --cases /var/tmp/sparkling-alignment-315-scatter-release-r111-20261009/constrained --results /var/tmp/sparkling-c315-source-count-callsite-r121-20261009 --sample 1 --steps 100 --batches 16 --warmup 1
/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-r121-20261009/summarize.py /var/tmp/sparkling-c315-source-count-callsite-r121-20261009 /var/tmp/sparkling-c315-source-counters-r121-20261009

For another machine, supply a local Git repository containing the pinned upstream commit to prepare.py --git, the packaged reference-source directory to --foundation, and fresh output paths. Copy extend-callsite-counts.py/summarize.py into the output directory before executing. The extension script currently names the original Git checkout explicitly; adjust that path only or directly apply the final instrumentation.patch to a fresh pinned archive. Use the packaged cases directory for run.py --cases. Driver guard paths and summarizer wheel-evidence path also reflect the original machine; preserve hashes when replaying originals and record any path-only adaptation separately. Build/runtime guards are documented in build-commands.json and per-run guard logs.

Build objects and compiled libraries/executables are excluded; their hashes/linkage/compile commands are retained. Initial17-counter build receipt/source patch is preserved separately, followed by final20-counter patch/manifest. Prepared scripts precede execution; executed evidence is in build-receipts and results.
