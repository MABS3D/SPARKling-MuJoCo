#ifndef SPARKLING_COUNTS_H
#define SPARKLING_COUNTS_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define SPARK_EXPORT __attribute__((visibility("default")))
enum sparkling_counter {
  SPARK_MakeHessian,
  SPARK_HessianIncremental,
  SPARK_HessianConeFolded,
  SPARK_HessianConeUpdate,
  SPARK_FactorizeHessian,
  SPARK_FactorizeRecompute,
  SPARK_cholFactorNumeric,
  SPARK_sqrMatTDSparseNumeric,
  SPARK_NewtonEntry,
  SPARK_CGEntry,
  SPARK_NewtonCertificate,
  SPARK_CGCertificate,
  SPARK_GateFold,
  SPARK_GateUpdate,
  SPARK_GramSingleRows,
  SPARK_GramBatchedRows,
  SPARK_cholUpdateSparse,
  SPARK_ConeRankUpdate,
  SPARK_QuadraticRankUpdate,
  SPARK_QuadraticRankDowndate,
  SPARK_COUNTER_COUNT
};
SPARK_EXPORT void sparkling_count_reset(void);
SPARK_EXPORT void sparkling_count_read(uint64_t* out);
void sparkling_count_add(enum sparkling_counter which, uint64_t amount);
#ifdef __cplusplus
}
#endif
#endif
