"""Archive exact flat-update evidence after narrow retries; no build/proof caches."""
from pathlib import Path
import hashlib,json,zipfile

TMP=Path('/var/tmp')
ROOT=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
BASENAME='sparkling-flat-updates-evidence-r121-r122-20261009'
ARCHIVE=TMP/(BASENAME+'.zip')
MEMBERS=TMP/(BASENAME+'-members.json')
META=TMP/(BASENAME+'-archive.json')

def sha(data):return hashlib.sha256(data).hexdigest()

def main():
 assert not ARCHIVE.exists(), 'Do not replace an earlier archive.'
 members={};payload={};snapshots=[];attempts=[]
 def add(name,data):
  if name in payload: assert payload[name]==data
  else:payload[name]=data
 def file(path,name):add(name,path.read_bytes())
 engines=[
  'sparkling-flat-updates-r121-20261009',
  'sparkling-flat-updates-native-r121-20261009',
  'sparkling-flat-updates-native-r122-20261009',
  'sparkling-alignment-315-reuse-release-r122-20261009']
 for name in engines:
  base=TMP/name; manifest=json.loads((base/'manifest.json').read_text())
  file(base/'manifest.json','snapshots/'+name+'/manifest.json')
  for rel,digest in manifest['sources'].items():
   data=(base/'source'/rel).read_bytes();assert sha(data)==digest,(name,rel)
   add('source-blobs/'+digest,data)
  snapshots.append(dict(path=str(base),source_count=len(manifest['sources']),manifest_sha256=sha((base/'manifest.json').read_bytes())))
 for name in ['sparkling-flat-updates-native-r121-20261009','sparkling-flat-updates-native-r122-20261009']:
  base=TMP/name
  for p in base.rglob('*'):
   rel=p.relative_to(base)
   if not p.is_file() or any(part in ('source','build','bin','obj','cache','gnatprove','proof') for part in rel.parts):continue
   if rel.as_posix()=='manifest.json':continue
   if name.endswith('r121-20261009') and rel.as_posix()=='differential/reference.so':continue
   file(p,'native/'+name+'/'+rel.as_posix())
 for rev,scopes in [('r121',('flat_row_limits','flat_selection_frame','flat_row','update_flat')),('r122',('flat_lower_separate','flat_row'))]:
  for scope in scopes:
   base=TMP/('sparkling-flat-updates-'+scope+'-'+rev+'-20261009')
   if not (base/'results.json').is_file():
    assert rev=='r122'
    attempts.append(dict(path=str(base),scope=scope,not_launched=True,reason='Parent cancelled both pending retries to finish requested publication while goal is paused.'))
    continue
   d=json.loads((base/'results.json').read_text())
   attempts.append(dict(path=str(base),scope=d['subprogram'],exit=d['exit'],obligations_closed=d.get('obligations_closed',False),passed=d.get('passed',False),checks=d.get('checks'),open_count=len(d.get('open',[])),warnings_count=len(d.get('warnings',[]))))
   for fn in ('results.json','proof.log','unit.spark.json'):
    if (base/fn).is_file():file(base/fn,'proof/'+base.name+'/'+fn)
 for fn in ('sparkling-flat-updates-native-r121.py','sparkling-flat-updates-native-r122.py','sparkling-flat-row-proof-r122.py','sparkling-flat-row-proof-r122-summary-20261009.json','sparkling-flat-updates-evidence-notes-20261009.txt'):
  file(TMP/fn,'workflow/'+fn)
 runner=(ROOT/'experimental/alignment-3.15/tests/prove_flex.py').read_bytes()
 old=(TMP/'sparkling-flat-updates-prove_flex-r121-exact.py').read_bytes()
 expected=json.loads((TMP/'sparkling-flat-updates-flat_row-r121-20261009/results.json').read_text())['runner_sha256']
 assert sha(old)==expected
 add('runners/prove_flex-r121.py',old)
 add('runners/prove_flex-r122.py',runner)
 file(ROOT/'tools/guarded.py','runners/guarded.py')
 file(Path(__file__),'workflow/'+Path(__file__).name)
 audit=dict(snapshots=snapshots,attempts=attempts,
  source_layout='snapshots/<name>/manifest.json maps each source path to source-blobs/<SHA256>; reconstruct by copying those verified bytes.',
  excluded=['build/proof caches','manually generated reference.so in failed native r121 directory'],
  runner_reconstruction='r121 prove_flex bytes reconstructed by removing final helper scope from current runner; exact receipt SHA256 verified.',
  scope='Row rounded functional/frame contracts; whole Update_Flat ordered factor model and solver proof remain open. Sqrt warnings retained.')
 add('audit.json',(json.dumps(audit,indent=2)+'\n').encode())
 for name,data in payload.items():members[name]=dict(sha256=sha(data),size=len(data))
 with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name in sorted(payload):z.writestr(name,payload[name])
 with zipfile.ZipFile(ARCHIVE) as z:
  assert z.testzip() is None
  assert set(z.namelist())==set(members)
  for name,meta in members.items():
   data=z.read(name);assert len(data)==meta['size'] and sha(data)==meta['sha256']
 MEMBERS.write_text(json.dumps(members,indent=2)+'\n')
 result=dict(archive=str(ARCHIVE),sha256=sha(ARCHIVE.read_bytes()),size=ARCHIVE.stat().st_size,members=len(members),snapshots=len(snapshots),source_blobs=sum(k.startswith('source-blobs/') for k in members),proof_attempts=sum(not item.get('not_launched',False) for item in attempts),cancelled_scopes=sum(item.get('not_launched',False) for item in attempts),member_manifest=str(MEMBERS),member_manifest_sha256=sha(MEMBERS.read_bytes()),all_members_verified=True,caches_excluded=True)
 META.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
