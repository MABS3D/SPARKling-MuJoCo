"""Serialized narrow proof retry; run only when the heavy slot is released."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
ENGINE = Path('/var/tmp/sparkling-alignment-315-reuse-release-r122-20261009')
RUNNER = ROOT / 'experimental/alignment-3.15/tests/prove_flex.py'
SUMMARY = Path('/var/tmp/sparkling-flat-row-proof-r122-summary-20261009.json')
SCOPES = ('Flat_Lower_Separate', 'Flat_Row')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert not SUMMARY.exists(), 'Keep previous attempt; allocate a new path.'
    runner_hash = sha(RUNNER)
    manifest_hash = sha(ENGINE/'manifest.json')
    receipt = dict(engine=str(ENGINE), manifest_sha256=manifest_hash,
                   runner=str(RUNNER), runner_sha256=runner_hash,
                   wrapper_sha256=sha(Path(__file__)), attempts=[])
    for scope in SCOPES:
        out = Path('/var/tmp/sparkling-flat-updates-'+scope.lower()+'-r122-20261009')
        command = [sys.executable, str(RUNNER), '--engine', str(ENGINE),
                   '--out', str(out), '--subprogram', scope]
        assert sha(RUNNER) == runner_hash
        run = subprocess.run(command, cwd=ROOT)
        path = out/'results.json'
        result = json.loads(path.read_text()) if path.exists() else {}
        receipt['attempts'].append(dict(scope=scope, command=command,
            process_exit=run.returncode, receipt=str(path),
            receipt_sha256=sha(path) if path.exists() else None,
            obligations_closed=result.get('obligations_closed',False),
            passed=result.get('passed',False), checks=result.get('checks'),
            warnings=result.get('warnings'), open=result.get('open'),
            source_hashes_unchanged=result.get('source_hashes_unchanged')))
        receipt['runner_source_unchanged'] = sha(RUNNER)==runner_hash
        receipt['engine_manifest_unchanged'] = sha(ENGINE/'manifest.json')==manifest_hash
        SUMMARY.write_text(json.dumps(receipt,indent=2)+'\n')
        print(json.dumps(receipt['attempts'][-1]),flush=True)
        if not result.get('obligations_closed') or not result.get('source_hashes_unchanged'):
            break
    print(SUMMARY,flush=True)

if __name__ == '__main__':
    main()
