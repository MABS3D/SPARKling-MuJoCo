from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');v=Path('/var/tmp')
p315=v/'sparkling-movement315-env/bin/python';p314=v/'sparkling-movement-env/bin/python'
receipt=v/'sparkling-verify-reuse-r122-20261009.json';assert not receipt.exists();records=[]
env=os.environ.copy();tc=v/'sparkling-matrix-recovery/toolchains'
env['PATH']=':'.join(str(p) for name in ('gnat','gprbuild') for p in (tc/name).glob('*/bin'))+':'+env['PATH']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,cmd,cwd=r,cap=3000,timeout=600):
 log=v/('sparkling-reuse-r122-'+label+'.log');start=time.monotonic()
 command=[str(p315),str(r/'tools/guarded.py'),'--cap-mb',str(cap),'--timeout',str(timeout),'--',*map(str,cmd)]
 with log.open('w') as f:p=subprocess.run(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(label=label,command=command,exit=p.returncode,seconds=time.monotonic()-start,log=str(log),log_sha256=sha(log)))
 receipt.write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
release=v/'sparkling-alignment-315-reuse-release-r122-20261009'
run('release315',[p315,r/'experimental/alignment-3.15/tests/build_flex.py','--foundation',v/'sparkling-alignment-315-foundation-r6-20261007','--out',release,'--python',p315,'--mode','release'],timeout=1200)
# Isolated checked native solver harness on the exact runtime engine closure.
u=v/'sparkling-alignment-315-reuse-solver-r122-20261009';u.mkdir();source=u/'source';shutil.copytree(release/'source',source)
folder=Path('experimental/constraint-solvers-candidate')
for p in [r/folder/'solvers.gpr',*(r/folder/'tests').iterdir()]:
 if p.is_file() and p.suffix in ('.gpr','.ads','.adb','.py','.c'):
  target=source/p.relative_to(r);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
inputs={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}
(u/'manifest.json').write_text(json.dumps(dict(engine_manifest_sha256=sha(release/'manifest.json'),sources=inputs),indent=2)+'\n')
env.update(SOLVERS_BUILD_ROOT=str(u/'build'),SOLVERS_MODE='validation')
run('native-build',['gprbuild','-P',source/folder/'solvers.gpr','solvers_probe.adb','-j1'],cwd=source)
binary=u/'build/validation/bin/solvers_probe'
for version,py in [('3.15.0',p315),('3.14.0',p314)]:
 for layout in ['dense','sparse']:
  cmd=[py,source/folder/'tests/differential.py','--binary',binary,'--out',u/(version+'-'+layout+'.json'),'--reference-version',version,'--jacobian',layout]
  if layout=='sparse':cmd+=['--native-jacobian']
  run('solver-'+version+'-'+layout,cmd,cwd=source,cap=2500,timeout=240)
run('robustness',[p315,source/folder/'tests/robustness.py','--binary',binary,'--out',u/'robustness.json'],cwd=source,cap=2500,timeout=240)
run('synthetic-fold',[p315,v/'sparkling-fold-oracle-r121-20261009/synthetic_fold_oracle.py','--binary',binary,'--out',u/'synthetic-fold'],cwd=source,cap=2500,timeout=240)
assert all(sha(source/n)==h for n,h in inputs.items())
(u/'results.json').write_text(json.dumps(dict(complete=True,binary_sha256=sha(binary),source_hashes_unchanged=True,manifest_sha256=sha(u/'manifest.json')),indent=2)+'\n')
production=v/'sparkling-alignment-314-reuse-release-r122-20261009'
run('release314',[p314,r/'experimental/alignment-3.15/tests/build_flex.py','--foundation',v/'sparkling-alignment-314-foundation-r2-20261007','--out',production,'--python',p314,'--mode','release','--production-regression'],timeout=1200)
for engine in [release,production]:
 m=json.loads((engine/'manifest.json').read_text());assert all(sha(r/n)==h for n,h in m['original_sources'].items())
print('All final runtime inputs match checkout',flush=True)
