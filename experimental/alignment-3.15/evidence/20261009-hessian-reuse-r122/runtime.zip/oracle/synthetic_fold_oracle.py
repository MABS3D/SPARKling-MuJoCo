#!/usr/bin/env python3
"""Synthetic sparse-Newton fold/update coverage with an independent 1-D oracle.

No compilation. --prepare-only writes inputs/oracles without executing a solver.
C3.15's fold predicate is evaluated on the exact tridiagonal factor structure;
branch execution is predicted from the initial cone, not dynamically instrumented.
"""
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np

def force(t):
    # Residual [t,1,0], mu=friction=R=D=1.
    if t >= 1.0:return np.zeros(3)
    if t <= -1.0:return np.array([-t,-1.0,0.0])
    f=.5*(1.0-t)
    return np.array([f,-f,0.0])
def zone(t):return 'satisfied' if t>=1 else 'quadratic' if t<=-1 else 'cone'
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary',type=Path)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--test-dir',type=Path,default=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/experimental/constraint-solvers-candidate/tests'))
    p.add_argument('--prepare-only',action='store_true')
    a=p.parse_args()
    if not a.prepare_only and a.binary is None:p.error('--binary required unless --prepare-only')
    sys.path.insert(0,str(a.test_dir));from differential import encode,row,run
    a.out.mkdir(parents=True,exist_ok=False)
    n=16;mass=np.diag(np.full(n,2.0))+np.diag(np.full(n-1,-.5),1)+np.diag(np.full(n-1,-.5),-1)
    problems=[];oracles=[]
    # Reverse sparse factor has row widths [1,2,...,2]; parent(r)=r-1.
    widths=[1]+[2]*(n-1);pathcost=np.cumsum(widths);lflops=sum(w*w for w in widths)
    for index in [0,n-1]:
        unit=np.zeros(n);unit[index]=1.0;invcol=np.linalg.solve(mass,unit);kappa=1.0/invcol[index]
        jac=np.zeros((3,n));jac[0,index]=1.0
        for freevalue in [-2.0,0.0,2.0]:
            free=np.zeros(n);free[index]=freevalue
            lo,hi=-10.0,10.0
            assert kappa*(lo-freevalue)-force(lo)[0]<0<kappa*(hi-freevalue)-force(hi)[0]
            for _ in range(100):
                t=(lo+hi)*.5
                if kappa*(t-freevalue)-force(t)[0]>0:hi=t
                else:lo=t
            optimum=(lo+hi)*.5;expected=free+(optimum-freevalue)*invcol/invcol[index]
            for warm in [-3.0,0.0,3.0]:
                a0=np.zeros(n);a0[index]=warm
                name=f'chain16-dof{index+1}-free{freevalue:g}-warm{warm:g}'
                problem=dict(name=name,method=5,M=mass,J=jac,free=free,ref=[0.0,-1.0,0.0],a0=a0,f0=np.zeros(3),rows=[row(3,3),row(3,0),row(3,0)],iterations=1000,ls_iterations=100,tolerance=1e-12,scale=1.0)
                # Preserve the common contact-row support, including explicit zeros.
                problem['native_jacobian']=dict(layout='sparse',rowadr=[0,1,2],rownnz=[1,1,1],colind=[index]*3,values=[1.0,0.0,0.0])
                # differential.row defaults R=.1; use R=D=1 for the oracle.
                problem['rows']=[row(3,3,r=1.0),row(3,0,r=1.0),row(3,0,r=1.0)]
                U=3*int(pathcost[index]);S=3
                fold=10*U>3*(lflops+2*S)
                assert fold==(index==n-1)
                problems.append(problem);oracles.append(dict(name=name,a=expected.tolist(),f=force(optimum).tolist(),initial_zone=zone(warm),expected_final_zone=zone(optimum),fold_predicate_if_cone=fold,initial_cone_guarantees_first_Hessian_reaches_cone_gate=warm==0.0,gate_U=U,gate_S=S,gate_Lflops=lflops,gate_lhs=10*U,gate_rhs=3*(lflops+2*S),effective_mass=kappa,expected_last_coordinate=optimum))
    input_text=''.join(encode(x) for x in problems);(a.out/'problems.input').write_text(input_text)
    report=dict(executed=False,scope='Independent convex one-coordinate oracle, not a C simulator output. C3.15 gate structure/formula copied analytically; actual branch execution not instrumented.',cases=len(problems),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),differential_driver_sha256=hashlib.sha256((a.test_dir/'differential.py').read_bytes()).hexdigest(),input_sha256=hashlib.sha256(input_text.encode()).hexdigest(),oracles=oracles)
    if not a.prepare_only:
        actual=run(a.binary,problems);records=[]
        for problem,target,got in zip(problems,oracles,actual,strict=True):
            accel=np.array(target['a']);f=np.array(target['f']);residual=np.array(problem['J'])@got['a']-np.array(problem['ref']);imbalance=mass@(got['a']-np.array(problem['free']))-np.array(problem['J']).T@got['f']
            ok=got['status']=='CONVERGED' and np.allclose(got['a'],accel,atol=2e-8,rtol=2e-8) and np.allclose(got['f'],f,atol=2e-8,rtol=2e-8)
            records.append(dict(name=problem['name'],passed=bool(ok),status=got['status'],iterations=got['iterations'],acceleration_max_abs=float(np.max(abs(got['a']-accel))),force_max_abs=float(np.max(abs(got['f']-f))),balance_max_abs=float(np.max(abs(imbalance))),actual_final_zone=zone(residual[0])))
        report.update(executed=True,binary_sha256=hashlib.sha256(a.binary.read_bytes()).hexdigest(),passed=sum(r['passed'] for r in records),records=records)
    (a.out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(a.out/'results.json')
    if report['executed'] and report['passed']!=report['cases']:raise SystemExit(1)
if __name__=='__main__':main()
