import argparse,hashlib,json,zipfile
from pathlib import Path,PurePosixPath
p=argparse.ArgumentParser(description="Restore an exact frozen proof source snapshot")
p.add_argument("zip",type=Path);p.add_argument("revision",choices=["r110","r112","r113","r114","r115"]);p.add_argument("destination",type=Path)
a=p.parse_args();a.destination.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(a.zip) as z:
 raw=z.read("snapshots/"+a.revision+"/manifest.json");m=json.loads(raw)
 (a.destination/"manifest.json").write_bytes(raw)
 for name,h in m["sources"].items():
  q=PurePosixPath(name)
  if q.is_absolute() or ".." in q.parts: raise ValueError(name)
  data=z.read("source-blobs/"+h)
  if hashlib.sha256(data).hexdigest()!=h: raise ValueError(name)
  dest=a.destination/"source"/Path(*q.parts);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 print(str(a.destination),len(m["sources"]),"verified source files")
