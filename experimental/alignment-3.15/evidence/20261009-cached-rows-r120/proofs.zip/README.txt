Proof evidence r110-r115, 2026-10-09

This archive preserves all 25 indexed proof attempts, including advisories,
timeouts and open obligations. It contains no build/prover caches.

Exact frozen sources are stored once per SHA256 under source-blobs/. Each of
the five snapshots has its complete original manifest mapping source-relative
paths to these blobs (445 source files per snapshot). All blobs were read from
the immutable snapshot and checked against that manifest. This is a complete
frozen proof-source closure, not merely the two edited Hessian files. The
original_sources fields are provenance hashes; the source actually proved is
the sources field, which is fully included.

The supplied restore_snapshot.py reconstructs one source/ tree and its
manifest from this ZIP in a new directory, verifying every source hash.
Proof runner, freeze runner and guard are archived separately with exact
receipt hashes. The r110 runner was recovered by removing later scope entries
and then checking that its bytes match the recorded SHA256 exactly.

Final scope: 13 minimum routines, 284 info checks, no warnings. Twelve
unchanged minima use r114 receipts; Offset_Transpose has a fresh r115 receipt.
The scope audit verifies the same public spec and identical body outside
Offset_Transpose/Build_Transpose. This aggregate includes ghost model bounds
and does not establish whole-solver Gold.

Both full Build_Transpose attempts reached the 240-second watchdog without
a completed scoped report. Global stable mapping remains unproved. The
r115 Factor_Values attempt reports 46 info checks, 8 open obligations and
2 warnings at 1 second per prover. All negative receipts are preserved.

The current SPARK boundary assumes an initialized in-out Pattern. Caller
flow for a partially initialized constructor is not proved; native runtime
tests do not establish that claim. No proof assumptions, new trusted bodies,
suppressions or narrower public input domain were added.

See index/ for summaries and exact scope boundaries. External member-manifest
and archive metadata are intentionally outside this ZIP so the archive and
every member can be independently hashed without self-reference.
