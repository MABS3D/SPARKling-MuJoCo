Runtime verification and diagnostic evidence for r120.
The final-engine manifest identifies final runtime/proof source inputs.
profile-r111 is an earlier instrumented source revision, before Factor_Values row caching.
c-wheel-counts was executed with an unchanged C 3.15 wheel and per-step equality checks.
c-counter-drivers also includes a PREPARED ONLY separate recompiled-C private-counter experiment: prepare.py/build.py/run.py were not executed. Do not treat those scripts as measured evidence.
Build objects and proof caches are excluded. Published r109 baseline evidence remains in its earlier repository archive.
