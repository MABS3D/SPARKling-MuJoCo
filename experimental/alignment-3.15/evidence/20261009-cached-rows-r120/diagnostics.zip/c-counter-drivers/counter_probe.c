#include <mujoco/mujoco.h>
#include "engine/sparkling_counts.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
static void number(double* x) { if (scanf("%lf",x)!=1) {fputs("input error\n",stderr);exit(2);} }
static void counts(const uint64_t* x) { putchar('[');for(int i=0;i<SPARK_COUNTER_COUNT;++i)printf("%s%" PRIu64,i?",":"",x[i]);putchar(']'); }
static void state(const mjModel* m,const mjData* d) {
 putchar('[');int comma=0;
 for(int i=0;i<m->nq;++i){printf("%s%.17g",comma?",":"",(double)d->qpos[i]);comma=1;}
 for(int i=0;i<m->nv;++i)printf(",%.17g",(double)d->qvel[i]);
 printf(",%.17g",(double)d->time);
 for(int i=0;i<m->na;++i)printf(",%.17g",(double)d->act[i]);putchar(']');
}
int main(int argc,char** argv) {
 if(argc!=7)return 2;int sample=atoi(argv[2]),steps=atoi(argv[3]),endpoints=atoi(argv[4]),batches=atoi(argv[5]),warmup=atoi(argv[6]);
 if(sample<0||steps<1||batches<1||warmup<0||(endpoints!=0&&endpoints!=2))return 2;
 if(mj_version()!=3015000)return 2;
 mjModel* m=mj_loadModel(argv[1],NULL);if(!m)return 3;
 mjData* d=mj_makeData(m);if(!d||d->threadpool)return 3;
 int cases,input_steps;if(scanf("%d%d",&cases,&input_steps)!=2||sample>=cases)return 2;
 int stride=1+m->nq+2*m->nv+m->nu+m->na;
 double* x=calloc((size_t)stride,sizeof(double));if(!x)return 3;
 for(int c=0;c<=sample;++c)for(int j=0;j<stride;++j)number(x+j);
 if(x[0]!=0)return 2;
 printf("{\"batches\":%d,\"warmup\":%d,\"trajectories\":[",batches,warmup);
 for(int batch=0;batch<batches+warmup;++batch){
 if(batch)putchar(',');
 mj_resetData(m,d);int k=1;
 for(int i=0;i<m->nq;++i)d->qpos[i]=x[k++];
 for(int i=0;i<m->nv;++i)d->qvel[i]=x[k++];
 for(int i=0;i<m->nv;++i)d->qfrc_applied[i]=x[k++];
 for(int i=0;i<m->nu;++i)d->ctrl[i]=x[k++];
 for(int i=0;i<m->na;++i)d->act[i]=x[k++];
 uint64_t endpoint[SPARK_COUNTER_COUNT],total[SPARK_COUNTER_COUNT]={0},part[SPARK_COUNTER_COUNT];
 sparkling_count_reset();for(int i=0;i<endpoints;++i)mj_forward(m,d);sparkling_count_read(endpoint);
 printf("{\"version\":\"%s\",\"sample\":%d,\"steps\":%d,\"endpoint_forwards\":%d,\"nv\":%d,\"endpoint_counts\":",mj_versionString(),sample,steps,endpoints,m->nv);counts(endpoint);
 sparkling_count_reset();
 printf(",\"per_step\":[");
 for(int step=0;step<steps;++step){
  mj_step(m,d);sparkling_count_read(part);
  for(int j=0;j<SPARK_COUNTER_COUNT;++j){uint64_t before=total[j];total[j]=part[j];part[j]-=before;}
  printf("%s{\"counts\":",step?",":"");counts(part);
  printf(",\"ncon\":%d,\"nefc\":%d,\"solver_niter\":[",d->ncon,d->nefc);
  for(int j=0;j<mjNISLAND;++j)printf("%s%d",j?",":"",d->solver_niter[j]);
  printf("],\"state\":");state(m,d);putchar('}');
 }
 printf("],\"step_counts\":");counts(total);printf(",\"state\":");state(m,d);printf("}");
 }
 printf("]}\n");
 free(x);mj_deleteData(d);mj_deleteModel(m);return 0;
}
