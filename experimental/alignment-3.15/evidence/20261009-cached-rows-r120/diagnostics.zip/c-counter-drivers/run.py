#!/usr/bin/env python3
"""Count exact frozen benchmark inputs and compare to unchanged wheel, separate process."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--cases',type=pathlib.Path,required=True);p.add_argument('--results',type=pathlib.Path,required=True);p.add_argument('--sample',type=int,default=1);p.add_argument('--steps',type=int,default=100);p.add_argument('--batches',type=int,default=16);p.add_argument('--warmup',type=int,default=1);p.add_argument('--cpu',type=int,default=0);p.add_argument('--guard',type=pathlib.Path,default=pathlib.Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tools/guarded.py'));p.add_argument('--endpoints',type=int,nargs='+',default=[0,2]);p.add_argument('--models',nargs='+',default=['membrane_Newton_3','free','element_2_sphere','element_mixed_pyramidal_3','element_elastic_cross_elliptic_6','element_elastic_self_bvh_pyramidal_3']);a=p.parse_args()
assert a.batches>=1 and a.warmup>=0 and a.steps>0
os.sched_setaffinity(0,{a.cpu});a.results.mkdir(parents=True,exist_ok=False)
manifest=json.loads((a.out/'manifest.json').read_text());build=json.loads((a.out/'build-result.json').read_text());names=manifest['counter_names']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(pathlib.Path(build['library']))==build['library_sha256'] and sha(a.out/'counter_probe')==build['probe_sha256']
report=dict(complete=False,scope='Diagnostic counts only, identical frozen input sample; instrumented source build compared to unmodified normal-SIMD wheel. No timing/gain claim.',source_commit=manifest['commit'],sample=a.sample,steps=a.steps,batches=a.batches,warmup=a.warmup,rows=[])
def save():(a.results/'results.json').write_text(json.dumps(report,indent=2)+'\n')
save()
def run(command,output,stdin_path=None):
 wrapped=[sys.executable,str(a.guard),'--cap-mb','2500','--timeout','240','--',sys.executable,str(a.out/'capture.py'),str(output),str(output.with_suffix('.stderr')),str(stdin_path) if stdin_path else '-',*command]
 with output.with_suffix('.guard.log').open('w') as log:subprocess.run(wrapped,stdout=log,stderr=subprocess.STDOUT,check=True)

for name in a.models:
 model=a.cases/(name+'.mjb');input_path=a.cases/(name+'.input')
 for ep in a.endpoints:
  stem=name+'-endpoints-'+str(ep);cpath=a.results/(stem+'-instrumented.json');wpath=a.results/(stem+'-wheel.json')
  args=[str(a.sample),str(a.steps),str(ep),str(a.batches),str(a.warmup)]
  run([str(a.out/'counter_probe'),str(model),*args],cpath,input_path)
  run([sys.executable,str(a.out/'wheel_reference.py'),str(model),str(input_path),*args],wpath)
  c=json.loads(cpath.read_text());w=json.loads(wpath.read_text());assert len(c['trajectories'])==len(w['trajectories'])==a.batches+a.warmup
  counters=np.zeros(len(names),dtype=np.uint64);endpoint=np.zeros(len(names),dtype=np.uint64);max_abs=0.;all_states=True;stats_same=True;repeat_counts=[]
  for batch,(ct,wt) in enumerate(zip(c['trajectories'],w['trajectories'])):
   assert len(ct['per_step'])==len(wt['per_step'])==a.steps
   for cs,ws in zip(ct['per_step'],wt['per_step']):
    ca=np.array(cs['state']);wa=np.array(ws['state']);assert ca.shape==wa.shape
    max_abs=max(max_abs,float(np.max(np.abs(ca-wa))))
    all_states=all_states and bool(np.allclose(ca,wa,atol=2e-9,rtol=2e-9))
    stats_same=stats_same and all(cs[k]==ws[k] for k in ['solver_niter','ncon','nefc'])
   if batch>=a.warmup:
    counters+=np.array(ct['step_counts'],dtype=np.uint64);endpoint+=np.array(ct['endpoint_counts'],dtype=np.uint64);repeat_counts.append(ct['step_counts'])
  row=dict(model=name,endpoint_forwards=ep,scope='exact C benchmark step scope' if ep==0 else 'supplemental two-forward endpoint scope; not the C timed benchmark setup',model_sha256=sha(model),input_sha256=sha(input_path),state_max_abs=max_abs,state_matches=all_states,solver_iterations_contacts_rows_match_wheel=stats_same,wheel_library_sha256=w['library_sha256'],instrumented_library_sha256=build['library_sha256'],step_counts={n:int(v) for n,v in zip(names,counters)},endpoint_counts={n:int(v) for n,v in zip(names,endpoint)},repeated_trajectory_counts_identical=all(x==repeat_counts[0] for x in repeat_counts),integration_steps=a.batches*a.steps,warmup_excluded=True)
  row['validated_for_call_comparison']=all_states and stats_same
  report['rows'].append(row);save()
  if not row['validated_for_call_comparison']:raise RuntimeError('Numerics/solver path differ from wheel: '+stem+'; do not attribute benchmark counts from this source build.')
report['complete']=True;save();print(a.results/'results.json')
