#define _GNU_SOURCE
#include <mujoco/mujoco.h>
#include <dlfcn.h>
#include <pthread.h>
#include <stdint.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef SPARK_WHEEL_PATH
#error SPARK_WHEEL_PATH must name the exact unchanged reference wheel library
#endif
static _Atomic uint64_t calls[2];
static pthread_once_t once=PTHREAD_ONCE_INIT;
typedef int (*factor_fn)(mjtNum*,int,mjtNum,const int*,const int*,const int*,const int*,const int*,const int*,const int*,const mjtNum*,const int*,const int*,const int*,mjtNum*);
typedef void (*gram_fn)(mjtNum*,int,const int*,const int*,const int*,const int*,const mjtNum*,const int*,const int*,const int*,const mjtNum*,const int*,const int*,const int*,const int*,const mjtNum*,mjData*);
static factor_fn real_factor;
static gram_fn real_gram;
static const char* resolved_name;
static void init(void){
 void* handle=dlopen(SPARK_WHEEL_PATH,RTLD_NOW|RTLD_NOLOAD);
 if(!handle){fprintf(stderr,"counter: reference wheel not already loaded: %s\n",dlerror());abort();}
 *(void**)(&real_factor)=dlsym(handle,"mju_cholFactorNumeric");
 *(void**)(&real_gram)=dlsym(handle,"mju_sqrMatTDSparseNumeric");
 Dl_info info;if(!real_factor||!real_gram||!dladdr((void*)real_factor,&info)){fputs("counter: original symbol resolution failed\n",stderr);abort();}
 resolved_name=info.dli_fname;
}
void spark_wheel_count_reset(void){for(int i=0;i<2;++i)atomic_store_explicit(calls+i,0,memory_order_relaxed);}
void spark_wheel_count_read(uint64_t* out){for(int i=0;i<2;++i)out[i]=atomic_load_explicit(calls+i,memory_order_relaxed);}
const char* spark_wheel_resolved_library(void){pthread_once(&once,init);return resolved_name;}
int mju_cholFactorNumeric(mjtNum* L,int n,mjtNum min,const int* ln,const int* la,const int* lc,const int* tn,const int* ta,const int* tc,const int* map,const mjtNum* h,const int* hn,const int* ha,const int* hc,mjtNum* scratch){
 pthread_once(&once,init);atomic_fetch_add_explicit(calls,1,memory_order_relaxed);
 return real_factor(L,n,min,ln,la,lc,tn,ta,tc,map,h,hn,ha,hc,scratch);
}
void mju_sqrMatTDSparseNumeric(mjtNum* res,int nc,const int* rn,const int* ra,const int* rc,const int* rd,const mjtNum* mat,const int* mn,const int* ma,const int* mc,const mjtNum* mt,const int* tn,const int* ta,const int* tc,const int* ts,const mjtNum* diag,mjData* d){
 pthread_once(&once,init);atomic_fetch_add_explicit(calls+1,1,memory_order_relaxed);
 real_gram(res,nc,rn,ra,rc,rd,mat,mn,ma,mc,mt,tn,ta,tc,ts,diag,d);
}
