#!/usr/bin/env python3
"""Explicit build phase. Configure/build serially under memory/time guards."""
import argparse,hashlib,json,pathlib,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--guard',type=pathlib.Path,default=pathlib.Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tools/guarded.py'));a=p.parse_args()
out=a.out.resolve();source=out/'source';build=out/'build';manifest=json.loads((out/'manifest.json').read_text())
for name,digest in manifest['modified_hashes'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
commands=[]
def run(command,name,cap=3000,timeout=600):
 wrapped=[sys.executable,str(a.guard),'--cap-mb',str(cap),'--timeout',str(timeout),'--',*command]
 commands.append(wrapped);(out/'build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (out/name).open('w') as log:subprocess.run(wrapped,stdout=log,stderr=subprocess.STDOUT,check=True)
run(['cmake','-S',str(source),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DMUJOCO_BUILD_TESTS=OFF','-DMUJOCO_BUILD_EXAMPLES=OFF','-DMUJOCO_BUILD_SIMULATE=OFF','-DMUJOCO_BUILD_STUDIO=OFF','-DMUJOCO_TEST_PYTHON_UTIL=OFF','-DMUJOCO_WITH_USD=OFF','-DMUJOCO_USE_FILAMENT=OFF','-DMUJOCO_ENABLE_AVX=ON','-DMUJOCO_ENABLE_AVX_INTRINSICS=ON','-DMUJOCO_ENABLE_LTO=OFF','-DCMAKE_C_FLAGS=-march=native -ffp-contract=off','-DCMAKE_CXX_FLAGS=-march=native -ffp-contract=off','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],'configure.log')
run(['cmake','--build',str(build),'--target','mujoco','--parallel','1'],'build.log')
library=build/'lib/libmujoco.so.3.15.0';assert library.is_file()
run(['cc','-std=c11','-O3','-march=native','-ffp-contract=off','-I'+str(source/'include'),'-I'+str(source/'src'),str(out/'counter_probe.c'),str(library),'-Wl,-rpath,'+str(library.parent),'-o',str(out/'counter_probe')],'probe-build.log',cap=1000,timeout=120)
(out/'linkage.txt').write_text(subprocess.check_output(['ldd',str(out/'counter_probe')],text=True))
receipt=dict(complete=True,library=str(library),library_sha256=hashlib.sha256(library.read_bytes()).hexdigest(),probe_sha256=hashlib.sha256((out/'counter_probe').read_bytes()).hexdigest(),scope='Counters only; normal AVX intrinsics enabled; LTO disabled to keep diagnostics bounded/inspectable; no timing claims.')
(out/'build-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(out/'build-result.json')
