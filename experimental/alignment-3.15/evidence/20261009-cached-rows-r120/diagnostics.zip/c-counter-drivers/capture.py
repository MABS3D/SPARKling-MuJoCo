#!/usr/bin/env python3
"""Redirect child output while watchdog diagnostics retain their own log."""
import contextlib,pathlib,subprocess,sys
out,err,inp,*cmd=sys.argv[1:]
with pathlib.Path(out).open('w') as stdout,pathlib.Path(err).open('w') as stderr,contextlib.ExitStack() as stack:
 stdin=stack.enter_context(pathlib.Path(inp).open()) if inp!='-' else None
 result=subprocess.run(cmd,stdin=stdin,stdout=stdout,stderr=stderr)
sys.exit(result.returncode)
