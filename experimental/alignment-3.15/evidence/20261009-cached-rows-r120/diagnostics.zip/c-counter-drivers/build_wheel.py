#!/usr/bin/env python3
"""Small explicit guarded build of preload counters. Never changes wheel/source."""
import argparse,hashlib,json,pathlib,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--wheel',type=pathlib.Path,default=pathlib.Path('/var/tmp/sparkling-movement315-env/lib/python3.12/site-packages/mujoco/libmujoco.so.3.15.0'));p.add_argument('--guard',default='/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tools/guarded.py');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
here=pathlib.Path(__file__).resolve().parent;source=here/'wheel_counts.c'
cmd=['cc','-std=c11','-O2','-shared','-fPIC','-pthread','-I'+str(a.wheel.parent/'include'),'-DSPARK_WHEEL_PATH='+json.dumps(str(a.wheel.resolve())),str(source),'-ldl','-o',str(a.out/'wheel_counts.so')]
wrapped=[sys.executable,a.guard,'--cap-mb','1000','--timeout','120','--',*cmd]
with (a.out/'build.log').open('w') as log:subprocess.run(wrapped,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(complete=True,command=wrapped,wheel=str(a.wheel.resolve()),wheel_sha256=sha(a.wheel),source_sha256=sha(source),wrapper_sha256=sha(a.out/'wheel_counts.so'),scope='Exact reference wheel numeric functions intercepted through PLT; no runtime verification performed by this build phase; no timing claims.')
(a.out/'build-result.json').write_text(json.dumps(r,indent=2)+'\n');print(a.out/'build-result.json')
