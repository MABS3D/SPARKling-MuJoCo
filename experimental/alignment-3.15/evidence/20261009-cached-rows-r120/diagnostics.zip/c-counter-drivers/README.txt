C 3.15 call-count diagnostic, prepared 2026-10-09; NOT BUILT OR RUN

Start with the exact-wheel diagnostic. All outputs/builds stay in fresh /var/tmp
folders. No repository, upstream checkout, existing library or evidence changes.
Do not launch while another agent owns the heavy build/proof slot.

1. Exact unchanged wheel, exported numeric functions only

/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-call-diagnostic-plan-20261009/build_wheel.py --out /var/tmp/sparkling-c315-wheel-counters-20261009

/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-call-diagnostic-plan-20261009/run_wheel.py --build /var/tmp/sparkling-c315-wheel-counters-20261009 --cases /var/tmp/sparkling-alignment-315-scatter-release-r111-20261009/constrained --out /var/tmp/sparkling-c315-wheel-count-results-20261009 --sample 1 --steps 100 --batches 16 --warmup 1

The small cc build is guarded at 1000 MiB /120 s. Each run is guarded at
2500 MiB /240 s. Each program runs serially on CPU0. No duration is measured.
LD_PRELOAD is applied only to guarded diagnostic children. The original function
pointers are resolved through dlopen(exact-wheel-path, NOLOAD)/dlsym(handle),
not a potentially unresolved RTLD_NEXT search over Python's local loader groups.
The driver requires original-library identity and unchanged wheel SHA; each step
must match untouched-wheel state BITWISE and contact/row/solver-iteration stats
exactly. The sparse elliptic model must produce positive counts for both hooks.
Failure of these checks means interception/algorithm identity is unverified.

Counters: mju_cholFactorNumeric and mju_sqrMatTDSparseNumeric, all internal C callers.
Private helper calls are NOT inferred from these totals. Source inspection found
actual call instructions through PLT and exported dynamic symbols. MakeHessian,
HessianIncremental/HessianCone* and mj_solNewton are not dynamically exported.
Static helpers cannot be counted reliably by preload alone.

2. Private-path attribution: isolated source-instrumented 3.15 build

/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-call-diagnostic-plan-20261009/prepare.py --out /var/tmp/sparkling-c315-source-counters-20261009

/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-20261009/build.py --out /var/tmp/sparkling-c315-source-counters-20261009

/var/tmp/sparkling-movement315-env/bin/python /var/tmp/sparkling-c315-source-counters-20261009/run.py --out /var/tmp/sparkling-c315-source-counters-20261009 --cases /var/tmp/sparkling-alignment-315-scatter-release-r111-20261009/constrained --results /var/tmp/sparkling-c315-source-count-results-20261009 --sample 1 --steps 100 --batches 16 --warmup 1

prepare.py archives existing local Git commit
9ea3cdfcae93bf2cc4dc0e1a1627c5a39a1e06e5 into a fresh Linux directory. It checks the
three source files against the frozen 3.15 foundation, creates an exact patch,
adds atomic entry/branch counters and records hashes. No git checkout/fetch/reset.
Full CMake configure and build are separate guarded 3000 MiB /600 s commands;
cmake --build --target mujoco --parallel 1. Normal AVX/intrinsics stay enabled;
-march=native -ffp-contract=off, LTO OFF only in this diagnostic build. No fast-math
or numerical-expression changes. Dependency downloads use the isolated build.
The preexisting CMake engines found are 3.14/3.14.1, so are not reused. Their
source caches may be used later only after checking pinned identities and patch
state. This conservative driver lets pinned CMake fetch its own dependencies.
After a terminal guarded build timeout, the same build.py can resume the existing
build; do not restart while a prior job is live.

Counters additionally include MakeHessian, FactorizeHessian/recompute,
HessianIncremental, HessianConeFolded, HessianConeUpdate, Newton/CG entries and
certificate exits, gate fold/update decisions, Gram single/batched result rows,
and mju_cholUpdateSparse. Atomic instrumentation survives inlining. No worker
thread pool is bound; the runner rejects a nonzero data threadpool pointer.
Compiled backend state must match unchanged wheel within the established
2e-9 atol/rtol at EVERY step and solver/contact/row stats must match exactly.
Because this is a new compiler build, it is source-algorithm evidence, not an
identity guarantee with the measured wheel. Exact-wheel counts take precedence
if path counters differ; do not attribute a mismatch to the Ada port.

Scope and comparison rules

- Both diagnostics default to the same six models, corpus sample1,100 steps,
  16 measured batches and one excluded warmup used in an individual paired
  benchmark block. Every measured trajectory is counted; no extrapolated totals.
- For each trajectory: load/reset/set state and inputs OUTSIDE the counted step
  loop, then reset counters immediately before the mj_step loop. Reads/deltas
  give per-step and total counts. No timing claim; instrumentation and output
  affect elapsed time.
- endpoint0 is the PRIMARY exact C benchmark initialization (no mj_forward).
- endpoint2 is a SEPARATE supplemental run from reset, executing two mj_forward
  calls then the step loop. Endpoint counts are recorded separately and excluded
  from step totals. This helps compare the Ada full-process profile; it is not
  silently substituted for the actual benchmark's setup.
- r111 Ada gprof:2000*100 integration steps plus4000 extra Evaluate calls,
  204000 solves and778000 Gram/factors. Do not equate 778000/204000 with a timed
  per-step count, and do not compare it directly to C endpoint0 totals.
- To reproduce the repetition count of the profile, use --batches 2000 --warmup 0;
  per-step state output will be large. The original profile sampled only the
  elliptic model; specify --models element_elastic_cross_elliptic_6 if appropriate.
- To reproduce all repetitions of a 24-block benchmark, run24 explicit diagnostic
  blocks with fresh result directories. One repeated deterministic block suffices
  to inspect algorithm call patterns but is not all24 blocks.
- Private gate counts are cache DECISIONS, not number of fold invocations.
- Numeric utility counters include every C caller, not only Newton. Use source
  helper counters to establish attribution; do not subtract unrelated totals
  without evidence.

Preparation validation only: Python AST parse and exact C insertion-anchor
checks. No C compilation, library loading or trajectory run has been done.
