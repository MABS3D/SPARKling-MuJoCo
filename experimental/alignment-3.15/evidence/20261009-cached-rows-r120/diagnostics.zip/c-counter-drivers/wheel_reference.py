#!/usr/bin/env python3
import argparse,ctypes,hashlib,json,os,pathlib
import mujoco,numpy as np
p=argparse.ArgumentParser();p.add_argument('model');p.add_argument('input');p.add_argument('sample',type=int);p.add_argument('steps',type=int);p.add_argument('endpoints',type=int);p.add_argument('batches',type=int);p.add_argument('warmup',type=int);a=p.parse_args()
if a.batches < 1 or a.steps < 1 or a.sample < 0 or a.warmup < 0 or a.endpoints not in (0,2):
 p.error('Invalid trajectory arguments')
assert mujoco.__version__=='3.15.0'
hooks=None
if os.environ.get('SPARK_WHEEL_COUNTER_SO'):
 hooks=ctypes.CDLL(os.environ['SPARK_WHEEL_COUNTER_SO'])
 hooks.spark_wheel_count_read.argtypes=[ctypes.POINTER(ctypes.c_uint64)]
 hooks.spark_wheel_resolved_library.restype=ctypes.c_char_p
 def counters():
  x=(ctypes.c_uint64*2)();hooks.spark_wheel_count_read(x);return list(x)

m=mujoco.MjModel.from_binary_path(a.model);d=mujoco.MjData(m)
header,body=pathlib.Path(a.input).read_text().split('\n',1);count,_=map(int,header.split());stride=1+m.nq+2*m.nv+m.nu+m.na
x=np.fromstring(body,sep=' ');assert x.size==count*stride
assert a.sample<count,'Sample index outside corpus'
x=x.reshape(count,stride)[a.sample];assert x[0]==0
trajectories=[]
for batch in range(a.batches+a.warmup):
 mujoco.mj_resetData(m,d);k=1
 for array in [d.qpos,d.qvel,d.qfrc_applied,d.ctrl,d.act]:array[:]=x[k:k+len(array)];k+=len(array)
 if hooks:hooks.spark_wheel_count_reset()
 for _ in range(a.endpoints):mujoco.mj_forward(m,d)
 endpoint_counts=counters() if hooks else None
 if hooks:hooks.spark_wheel_count_reset()
 previous=[0,0]

 rows=[]
 for _ in range(a.steps):
  mujoco.mj_step(m,d)
  row=dict(state=np.r_[d.qpos,d.qvel,d.time,d.act].tolist(),ncon=int(d.ncon),nefc=int(d.nefc),solver_niter=d.solver_niter.tolist())
  if hooks:
   current=counters();row['counts']=[a-b for a,b in zip(current,previous)];previous=current
  rows.append(row)
 trajectories.append(dict(per_step=rows,state=rows[-1]['state'],step_counts=previous if hooks else None,endpoint_counts=endpoint_counts))

lib=pathlib.Path(mujoco.__file__).parent/'libmujoco.so.3.15.0'
print(json.dumps(dict(library=str(lib),library_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),resolved_original_library=hooks.spark_wheel_resolved_library().decode() if hooks else None,trajectories=trajectories)))
