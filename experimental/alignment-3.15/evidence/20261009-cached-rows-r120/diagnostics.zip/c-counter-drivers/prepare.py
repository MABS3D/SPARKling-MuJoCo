#!/usr/bin/env python3
"""Prepare isolated C counters at the exact 3.15 commit. Does not configure/build/run."""
import argparse,difflib,hashlib,json,pathlib,re,shutil,subprocess,tarfile
COMMIT='9ea3cdfcae93bf2cc4dc0e1a1627c5a39a1e06e5'
NAMES=['MakeHessian','HessianIncremental','HessianConeFolded','HessianConeUpdate','FactorizeHessian','FactorizeRecompute','cholFactorNumeric','sqrMatTDSparseNumeric','NewtonEntry','CGEntry','NewtonCertificate','CGCertificate','GateFold','GateUpdate','GramSingleRows','GramBatchedRows','cholUpdateSparse']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inject(text,name,body):
 pattern=r'(?m)^(?:static )?(?:void|int) '+re.escape(name)+r'\([^;{]*\)\s*\{'
 matches=list(re.finditer(pattern,text));assert len(matches)==1,(name,len(matches))
 m=matches[0];return text[:m.end()]+'\n  '+body+'\n'+text[m.end():]
def main():
 p=argparse.ArgumentParser();p.add_argument('--git',type=pathlib.Path,default=pathlib.Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/mujoco'));p.add_argument('--foundation',type=pathlib.Path,default=pathlib.Path('/var/tmp/sparkling-alignment-315-foundation-r6-20261007/source/mujoco'));p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
 a.out.mkdir(parents=True,exist_ok=False);source=a.out/'source';source.mkdir()
 cmd=['git','-C',str(a.git),'archive','--format=tar',COMMIT]
 with subprocess.Popen(cmd,stdout=subprocess.PIPE) as proc:
  with tarfile.open(fileobj=proc.stdout,mode='r|') as archive:archive.extractall(source,filter='data')
  assert proc.wait()==0
 files=['src/engine/engine_solver.c','src/engine/engine_util_solve.c','src/engine/engine_util_sparse.c']
 original={name:(source/name).read_text() for name in files};hashes={name:sha(source/name) for name in files}
 for name in files:assert hashes[name]==sha(a.foundation/name),(name,'foundation/reference mismatch')
 for name in files:
  text=original[name];position=text.index('#include ');text=text[:position]+'#include "engine/sparkling_counts.h"\n'+text[position:]
  if name.endswith('engine_solver.c'):
   for f in NAMES[:5]:text=inject(text,f,'sparkling_count_add(SPARK_'+f+', 1);'+(' if (flg_recompute) sparkling_count_add(SPARK_FactorizeRecompute, 1);' if f=='FactorizeHessian' else ''))
   text=inject(text,'mj_solPrimal','sparkling_count_add(flg_Newton ? SPARK_NewtonEntry : SPARK_CGEntry, 1);')
   old='  int flg_certificate = flg_gap && (!flg_Newton || flg_gradient);';assert text.count(old)==1
   text=text.replace(old,old+'\n  if (flg_certificate) sparkling_count_add(flg_Newton ? SPARK_NewtonCertificate : SPARK_CGCertificate, 1);')
   old='  return 10*U > 3*(ctx->Lflops + 2*S);';assert text.count(old)==1
   text=text.replace(old,'  int fold = 10*U > 3*(ctx->Lflops + 2*S);\n  sparkling_count_add(fold ? SPARK_GateFold : SPARK_GateUpdate, 1);\n  return fold;')
  elif name.endswith('engine_util_solve.c'):
   text=inject(text,'mju_cholFactorNumeric','sparkling_count_add(SPARK_cholFactorNumeric, 1);')
   text=inject(text,'mju_cholUpdateSparse','sparkling_count_add(SPARK_cholUpdateSparse, 1);')
  else:
   text=inject(text,'mju_sqrMatTDSparseNumeric','sparkling_count_add(SPARK_sqrMatTDSparseNumeric, 1);')
   marker='    // single row\n    if (ns == 1) {';assert text.count(marker)==1
   text=text.replace(marker,'    sparkling_count_add(ns == 1 ? SPARK_GramSingleRows : SPARK_GramBatchedRows, (uint64_t)ns);\n'+marker)
  (source/name).write_text(text)
 header='''#ifndef SPARKLING_COUNTS_H\n#define SPARKLING_COUNTS_H\n#include <stdint.h>\n#ifdef __cplusplus\nextern "C" {\n#endif\n#define SPARK_EXPORT __attribute__((visibility("default")))\nenum sparkling_counter {\n'''+''.join('  SPARK_'+n+',\n' for n in NAMES)+'''  SPARK_COUNTER_COUNT\n};\nSPARK_EXPORT void sparkling_count_reset(void);\nSPARK_EXPORT void sparkling_count_read(uint64_t* out);\nvoid sparkling_count_add(enum sparkling_counter which, uint64_t amount);\n#ifdef __cplusplus\n}\n#endif\n#endif\n'''
 (source/'src/engine/sparkling_counts.h').write_text(header)
 (source/'src/engine/sparkling_counts.c').write_text('''#include "engine/sparkling_counts.h"\n#include <stdatomic.h>\nstatic _Atomic uint64_t counters[SPARK_COUNTER_COUNT];\nvoid sparkling_count_add(enum sparkling_counter which, uint64_t amount) {\n  atomic_fetch_add_explicit(counters+which, amount, memory_order_relaxed);\n}\nvoid sparkling_count_reset(void) {\n  for (int i=0; i<SPARK_COUNTER_COUNT; ++i) atomic_store_explicit(counters+i, 0, memory_order_relaxed);\n}\nvoid sparkling_count_read(uint64_t* out) {\n  for (int i=0; i<SPARK_COUNTER_COUNT; ++i) out[i]=atomic_load_explicit(counters+i, memory_order_relaxed);\n}\n''')
 cmake=source/'CMakeLists.txt';old=cmake.read_text();cmake.write_text(old+'\n# Isolated diagnostic counters; no timing claims.\ntarget_sources(mujoco PRIVATE src/engine/sparkling_counts.c)\n')
 changes={name:(source/name).read_text() for name in files};changes['CMakeLists.txt']=cmake.read_text();original['CMakeLists.txt']=old
 for name in ['src/engine/sparkling_counts.c','src/engine/sparkling_counts.h']:original[name]='';changes[name]=(source/name).read_text()
 patch=''.join(''.join(difflib.unified_diff(original[n].splitlines(True),changes[n].splitlines(True),fromfile='a/'+n,tofile='b/'+n)) for n in changes)
 (a.out/'instrumentation.patch').write_text(patch)
 here=pathlib.Path(__file__).resolve().parent
 for name in ['counter_probe.c','wheel_reference.py','build.py','run.py','capture.py']:
  shutil.copyfile(here/name,a.out/name)
 metadata=dict(commit=COMMIT,reference='3.15.0',archive_command=cmd,original_hashes=hashes,modified_hashes={n:sha(source/n) for n in changes},counter_names=NAMES,patch_sha256=sha(a.out/'instrumentation.patch'),scope='Entry/branch counts only. Atomic instrumentation changes cost; no timing claims. No thread pool is bound by probe.')
 (a.out/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n');print(a.out)
if __name__=='__main__':main()
