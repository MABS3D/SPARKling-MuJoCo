#!/usr/bin/env python3
"""First diagnostic: intercept actual unchanged wheel; states must remain bitwise equal."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--build',type=pathlib.Path,required=True);p.add_argument('--cases',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--sample',type=int,default=1);p.add_argument('--steps',type=int,default=100);p.add_argument('--batches',type=int,default=16);p.add_argument('--warmup',type=int,default=1);p.add_argument('--cpu',type=int,default=0);p.add_argument('--endpoints',type=int,nargs='+',default=[0,2]);p.add_argument('--models',nargs='+',default=['membrane_Newton_3','free','element_2_sphere','element_mixed_pyramidal_3','element_elastic_cross_elliptic_6','element_elastic_self_bvh_pyramidal_3']);p.add_argument('--guard',default='/mnt/c/Users/Chello/Desktop/Sparkling Mujoco/tools/guarded.py');a=p.parse_args()
if a.batches < 1 or a.steps < 1 or a.sample < 0 or a.warmup < 0 or any(ep not in (0,2) for ep in a.endpoints):
 p.error('Positive batches/steps, nonnegative sample/warmup and endpoints in {0,2} required')
here=pathlib.Path(__file__).resolve().parent;build=json.loads((a.build/'build-result.json').read_text());wrapper=(a.build/'wheel_counts.so').resolve();wheel=pathlib.Path(build['wheel'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(wheel)==build['wheel_sha256'] and sha(wrapper)==build['wrapper_sha256']
a.out.mkdir(parents=True,exist_ok=False);os.sched_setaffinity(0,{a.cpu})
report=dict(complete=False,scope='Exact unchanged reference wheel exported numeric call counts; no timings; primary endpoint0 follows benchmark initialization.',sample=a.sample,steps=a.steps,batches=a.batches,warmup=a.warmup,counter_names=['cholFactorNumeric','sqrMatTDSparseNumeric'],wheel_sha256=sha(wheel),wrapper_sha256=sha(wrapper),driver_hashes={name:sha(here/name) for name in ['run_wheel.py','wheel_reference.py','capture.py']},guard_sha256=sha(pathlib.Path(a.guard)),commands=[],rows=[])
def save():(a.out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for name in a.models:
 for ep in a.endpoints:
  model=a.cases/(name+'.mjb');data=a.cases/(name+'.input');prefix=name+'-ep'+str(ep);outputs={}
  for hooked in [False,True]:
   label='hooked' if hooked else 'untouched';path=a.out/(prefix+'-'+label+'.json')
   env=os.environ.copy();env.pop('LD_PRELOAD',None);env.pop('SPARK_WHEEL_COUNTER_SO',None)
   if hooked:env['LD_PRELOAD']=str(wrapper);env['SPARK_WHEEL_COUNTER_SO']=str(wrapper)
   cmd=[sys.executable,str(here/'wheel_reference.py'),str(model),str(data),str(a.sample),str(a.steps),str(ep),str(a.batches),str(a.warmup)]
   guard=[sys.executable,a.guard,'--cap-mb','2500','--timeout','240','--',sys.executable,str(here/'capture.py'),str(path),str(path.with_suffix('.stderr')),'-',*cmd]
   report['commands'].append(dict(model=name,endpoint_forwards=ep,hooked=hooked,command=guard,diagnostic_environment={key:env[key] for key in ['LD_PRELOAD','SPARK_WHEEL_COUNTER_SO'] if key in env}));save()
   with path.with_suffix('.guard.log').open('w') as log:subprocess.run(guard,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
   outputs[label]=json.loads(path.read_text())
  base=outputs['untouched'];inst=outputs['hooked'];assert base['library_sha256']==inst['library_sha256']==build['wheel_sha256']
  assert pathlib.Path(inst['resolved_original_library']).resolve()==wheel.resolve()
  assert len(base['trajectories'])==len(inst['trajectories'])==a.batches+a.warmup
  equal=True;stats=True;total=np.zeros(2,dtype=np.uint64);endpoint=np.zeros(2,dtype=np.uint64);repeats=[]
  for batch,(bt,it) in enumerate(zip(base['trajectories'],inst['trajectories'])):
   assert len(bt['per_step'])==len(it['per_step'])==a.steps,'Per-step frame count mismatch'
   for b,i in zip(bt['per_step'],it['per_step']):
    equal=equal and np.array(b['state'],dtype=np.float64).tobytes()==np.array(i['state'],dtype=np.float64).tobytes()
    stats=stats and all(b[k]==i[k] for k in ['solver_niter','ncon','nefc'])
   if batch>=a.warmup:
    total+=np.array(it['step_counts'],dtype=np.uint64);endpoint+=np.array(it['endpoint_counts'],dtype=np.uint64);repeats.append(it['step_counts'])
  row=dict(model=name,endpoint_forwards=ep,model_sha256=sha(model),input_sha256=sha(data),state_bitwise_equal=bool(equal),solver_path_stats_equal=bool(stats),step_counts=dict(zip(report['counter_names'],map(int,total))),endpoint_counts=dict(zip(report['counter_names'],map(int,endpoint))),integration_steps=a.batches*a.steps,warmups_excluded=True,repeated_counts_identical=all(x==repeats[0] for x in repeats))
  report['rows'].append(row);save()
  assert equal and stats,'Instrumentation changed results/path: '+prefix
  if name=='element_elastic_cross_elliptic_6':assert all(total>0),'Positive interception check failed for known sparse elliptic workload'
assert sha(wheel)==build['wheel_sha256']
report['complete']=True;save();print(a.out/'results.json')
