import bisect, collections, hashlib, json, pathlib, struct, subprocess
root=pathlib.Path('/var/tmp/sparkling-alignment-315-scatter-profile-r111-20261009')
binary=root/'build/release/bin/flex_constrained_probe'
syms=[]
for line in subprocess.check_output(['nm','-S','--defined-only',str(binary)],text=True).splitlines():
    p=line.split()
    if len(p)==4 and p[2] in ('t','T','w','W') and int(p[1],16)>0:
        syms.append((int(p[0],16),int(p[1],16),p[3]))
syms.sort(); starts=[s[0] for s in syms]
def lookup(pc,end=None):
    i=bisect.bisect_right(starts,pc)-1
    if i>=0:
        start,size,name=syms[i]
        if pc<start+size and (end is None or end<=start+size):return name
    return '<unmapped_or_boundary>'
data=(root/'gmon.out').read_bytes()
assert data[:4]==b'gmon' and struct.unpack_from('<I',data,4)[0]==1
p=20; samples=collections.Counter(); incoming=collections.Counter(); arcs=collections.Counter(); histograms=[]
while p<len(data):
    tag=data[p];p+=1
    if tag==0:
        low,high,n,rate,dimension,abbrev=struct.unpack_from('<QQII15sc',data,p);p+=40
        h=struct.unpack_from('<'+'H'*n,data,p);p+=2*n
        assert (high-low)%n==0
        width=(high-low)//n
        histograms.append(dict(low=low,high=high,bins=n,rate=rate,width=width,samples=sum(h)))
        for k,count in enumerate(h):
            if count:samples[lookup(low+k*width,low+(k+1)*width)]+=count
    elif tag==1:
        caller,callee,count=struct.unpack_from('<QQI',data,p);p+=20
        cn=lookup(callee);pn=lookup(caller)
        incoming[cn]+=count;arcs[pn,cn]+=count
    else:raise ValueError((tag,p))
total=sum(samples.values())
rows=[dict(name=name,samples=count,percent=100*count/total,calls=incoming.get(name)) for name,count in samples.most_common()]
selected={name:dict(samples=samples[name],percent=100*samples[name]/total,calls=count) for name,count in incoming.items() if any(key in name for key in ['run_primal','count_symbolic','fill_symbolic','build_transpose','build_gram','factor_values','prepare_gram_layout','solve_with_force','backsolve_flat','evaluate_block'])}
for row in rows:
    if row['calls'] is None:
        row['call_count_status']='No incoming mcount arc recorded; count unavailable, not zero.'
    if any(key in row['name'] for key in ['run_primal','prepare_gram_layout']):
        selected[row['name']]={k:v for k,v in row.items() if k!='name'}
result=dict(scope='Raw GNU gmon histogram and arcs mapped into sized nm text symbols; full-process instrumented attribution, not release timing.',binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),gmon_sha256=hashlib.sha256(data).hexdigest(),histograms=histograms,total_samples=total,top=rows[:40],selected=selected,selected_arcs=[dict(caller=a,callee=b,count=c) for (a,b),c in arcs.items() if any(key in b for key in ['run_primal','build_gram','factor_values','prepare_gram_layout'])])
(root/'sized-profile.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
