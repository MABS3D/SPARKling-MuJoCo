import collections, contextlib, io, json, pathlib, subprocess, runpy
with contextlib.redirect_stdout(io.StringIO()):g=runpy.run_path('/var/tmp/sparkling-r111-sized-profile.py')
selected={}
for stem in ['factor_values','build_gram']:
    pcs=[(g['low']+k*g['width'],count) for k,count in enumerate(g['h']) if count and g['lookup'](g['low']+k*g['width'],g['low']+(k+1)*g['width']).endswith(stem)]
    addresses=[hex(pc) for pc,c in pcs]
    lines=subprocess.check_output(['addr2line','-e',str(g['binary']),*addresses],text=True).splitlines()
    assert len(lines)==len(pcs)
    agg=collections.Counter()
    for (pc,c),line in zip(pcs,lines):agg[line]+=c
    selected[stem]=[dict(location=loc,samples=c,process_percent=100*c/g['total']) for loc,c in agg.most_common()]
p=g['root']/'sized-lines.json';p.write_text(json.dumps(selected,indent=2)+'\n')
print(json.dumps({name:rows[:12] for name,rows in selected.items()},indent=2))
