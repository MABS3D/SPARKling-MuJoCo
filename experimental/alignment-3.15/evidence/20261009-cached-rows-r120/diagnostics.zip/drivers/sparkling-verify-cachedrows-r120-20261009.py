from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
py315 = '/var/tmp/sparkling-movement315-env/bin/python'
py314 = '/var/tmp/sparkling-movement-env/bin/python'
engine = '/var/tmp/sparkling-alignment-315-cachedrows-engine-r120-20261009'
receipts = Path('/var/tmp/sparkling-verify-cachedrows-r120-20261009.json')
assert not receipts.exists()
commands = []
stages = [
    ('freeze', [py315, str(root/'experimental/alignment-3.15/tests/build_flex.py'),
        '--foundation', '/var/tmp/sparkling-alignment-315-foundation-r6-20261007',
        '--out', engine, '--python', py315, '--mode', 'release', '--freeze-only']),
    ('native', [py315, str(root/'experimental/alignment-3.15/tests/build_rowgram.py'),
        '--engine', engine, '--out', '/var/tmp/sparkling-alignment-315-cachedrows-native-r120-20261009',
        '--python', py315, '--reference', '/var/tmp/sparkling-alignment-315-foundation-r6-20261007/source/mujoco']),
    ('release', [py315, str(root/'experimental/alignment-3.15/tests/build_flex.py'),
        '--foundation', '/var/tmp/sparkling-alignment-315-foundation-r6-20261007',
        '--out', '/var/tmp/sparkling-alignment-315-cachedrows-release-r120-20261009',
        '--python', py315, '--mode', 'release']),
    ('production', [py314, str(root/'experimental/alignment-3.15/tests/build_flex.py'),
        '--foundation', '/var/tmp/sparkling-alignment-314-foundation-r2-20261007',
        '--out', '/var/tmp/sparkling-alignment-314-cachedrows-release-r120-20261009',
        '--python', py314, '--mode', 'release', '--production-regression']),
]
for label, command in stages:
    start = time.monotonic()
    run = subprocess.run(command, cwd=root)
    commands.append(dict(label=label, command=command, exit=run.returncode,
        seconds=time.monotonic()-start,
        runner_sha256=hashlib.sha256(Path(command[1]).read_bytes()).hexdigest()))
    receipts.write_text(json.dumps(commands, indent=2)+'\n')
    print(label, run.returncode, flush=True)
    if run.returncode:
        raise SystemExit(run.returncode)
manifest = json.loads((Path(engine)/'manifest.json').read_text())
changed = [name for name, digest in manifest['original_sources'].items()
    if hashlib.sha256((root/name).read_bytes()).hexdigest() != digest]
assert not changed, changed
print('Final worktree still matches frozen original inputs', flush=True)
