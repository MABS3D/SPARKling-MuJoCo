from pathlib import Path
import json
import os
import subprocess
import time

root = Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
py = '/var/tmp/sparkling-movement315-env/bin/python'
prefix = Path('/var/tmp/sparkling-cachedrows-time-r120-vs-r109-20261009')
watch = Path(str(prefix)+'-watch.json')
assert not prefix.exists() and not watch.exists()
command = [py, str(root/'tools/guarded.py'), '--cap-mb', '2500', '--timeout', '600', '--',
    py, '/var/tmp/sparkling-alignment-315-flat-time-r67-quiet-20261008/benchmark_constrained.py',
    '--binary', '/var/tmp/sparkling-alignment-315-cachedrows-release-r120-20261009/force-build/release/bin/flex_constrained_probe',
    '--baseline', '/var/tmp/sparkling-alignment-315-rowgram-release-r109-20261008/force-build/release/bin/flex_constrained_probe',
    '--cases', '/var/tmp/sparkling-alignment-315-cachedrows-release-r120-20261009/constrained',
    '--out', str(prefix), '--blocks', '24', '--batches', '16', '--steps', '100',
    '--cpu', '0', '--quiet-window', '--reference', '3.15.0', '--models',
    'membrane_Newton_3', 'free', 'element_2_sphere', 'element_mixed_pyramidal_3',
    'element_elastic_cross_elliptic_6', 'element_elastic_self_bvh_pyramidal_3']
receipt = dict(command=command, started=False, complete=False, quiet_verified=False,
    scope='Coordinated own jobs idle; poll observed WSL processes every two seconds. Does not establish absence of all native Windows background work.',
    observations=[])

def save():
    watch.write_text(json.dumps(receipt, indent=2)+'\n')

def other_jobs():
    rows = []
    for line in subprocess.check_output(['ps', '-eo', 'pid=,ppid=,comm=,args='], text=True).splitlines():
        p, parent, name, args = line.split(None, 3)
        rows.append((int(p), int(parent), name, args))
    owned = {os.getpid()}
    while True:
        new = owned | {p for p, parent, _, _ in rows if parent in owned}
        if new == owned:
            break
        owned = new
    heavy = {'gnatprove', 'gnat1', 'gnat2why', 'gprbuild', 'why3server', 'cvc5', 'z3',
             'alt-ergo', 'cc1', 'cc1plus', 'gcc', 'g++', 'clang', 'cmake', 'ninja', 'rustc', 'cargo'}
    found = []
    for p, _, name, args in rows:
        if p in owned:
            continue
        if name in heavy or name == 'python.exe' or (name.startswith('python') and
                any(word in args.lower() for word in ('benchmark', 'profile_', 'pytest', 'run_checks', 'run_acceptance', 'build_', 'prove_'))):
            found.append(dict(pid=p, name=name, command=args))
    return found

start = time.monotonic()
quiet = 0
while quiet < 3:
    jobs = other_jobs()
    receipt['observations'].append(dict(phase='preflight', seconds=time.monotonic()-start, jobs=jobs))
    save()
    quiet = 0 if jobs else quiet+1
    if time.monotonic()-start > 600:
        raise SystemExit('No quiet interval within ten minutes; benchmark not started')
    time.sleep(2)
receipt['started'] = True
save()
print('Quiet interval verified; benchmark starting', flush=True)
contaminated = False
with Path(str(prefix)+'.log').open('w') as stream:
    process = subprocess.Popen(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    while process.poll() is None:
        jobs = other_jobs()
        contaminated = contaminated or bool(jobs)
        receipt['observations'].append(dict(phase='measurement', seconds=time.monotonic()-start, jobs=jobs))
        save()
        time.sleep(2)
receipt.update(exit=process.returncode, complete=process.returncode == 0,
               quiet_verified=not contaminated)
save()
print(json.dumps({k:receipt[k] for k in ('complete','quiet_verified','exit')}), flush=True)
raise SystemExit(process.returncode or (2 if contaminated else 0))
