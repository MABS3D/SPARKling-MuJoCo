with MJ.Constraint_Solvers.Dense_Cholesky;

--  MuJoCo 3.14 symbolic/numeric reverse Cholesky, H = L' L.
--  Structural zero entries are retained: their order affects sparse dots.
package MJ.Constraint_Solvers.Sparse_Cholesky with SPARK_Mode is
   package Dense renames MJ.Constraint_Solvers.Dense_Cholesky;
   subtype Operand is Dense.Operand;
   subtype Pivot is Dense.Pivot;
   type Status is (Success, Invalid_Pattern, Numeric_Limit);
   subtype Mask is Structural_Matrix;
   type Counts is array (Positive range <>) of Natural;
   type Indices is array (Positive range <>, Positive range <>) of Natural;
   type Pattern (N : Positive) is record
      Length, Transpose_Length : Counts (1 .. N);
      Column, Transpose_Row, Transpose_Position : Indices (1 .. N, 1 .. N);
   end record;

   function Valid (P : Pattern) return Boolean is
     (P.N <= Max_Dofs
      and then (for all R in 1 .. P.N =>
        P.Length (R) in 1 .. R and then P.Transpose_Length (R) in 1 .. P.N-R+1
        and then P.Column (R, P.Length (R)) = R
        and then P.Transpose_Row (R, 1) = R
        and then P.Transpose_Position (R, 1) = P.Length (R)
        and then (for all I in 1 .. P.Length (R) =>
          P.Column (R, I) in 1 .. R
          and then (if I > 1 then P.Column (R, I-1) < P.Column (R, I)))
        and then (for all K in 2 .. P.Transpose_Length (R) =>
          P.Transpose_Row (R, K) in R+1 .. P.N
          and then P.Transpose_Position (R, K) in 1 .. Natural'Min (P.N, P.Length (P.Transpose_Row (R, K)))
          and then P.Column (P.Transpose_Row (R, K), P.Transpose_Position (R, K)) = R)));

   --  Read the upper triangle. The two symbolic traversals retain C's CSC
   --  update order, which need not be sorted by row number.
   procedure Symbolic (H : Mask; P : out Pattern; Result : out Status) with
     Global => null,
     Pre => P.N <= Max_Dofs and then H'First (1) = 1 and then H'First (2) = 1
       and then H'Length (1) = P.N and then H'Length (2) = P.N,
     Post => (if Result = Success then Valid (P));

   --  Add the mass after the constraint contribution, preserving its
   --  floating-point order on every entry consumed by sparse Factor.
   procedure Add_Mass_Row (H : in out Matrix; M : Matrix; P : Pattern; R : Positive)
     with Global => null, Inline_Always,
     Pre => (Static => Valid (P) and then Dense.Square (H) and then Dense.Square (M)
       and then H'Length (1) = P.N and then M'Length (1) = P.N and then R <= P.N
       and then (for all I in H'Range (1) => (for all J in H'Range (2) =>
         H (I, J) in -2.0e100 .. 2.0e100 and then M (I, J) in -1.0e100 .. 1.0e100))
       and then (for all J in H'Range (2) => H (R, J) in -1.0e100 .. 1.0e100)),
     Post => (Static =>
       (for all I in H'Range (1) => (for all J in H'Range (2) =>
         H (I, J) in -2.0e100 .. 2.0e100 and then H (I, J) =
           (if I = R and then (for some K in 1 .. P.Length (R) => P.Column (R, K) = J)
            then H'Old (I, J)+M (I, J) else H'Old (I, J)))));

   procedure Add_Mass (H : in out Matrix; M : Matrix; P : Pattern)
     with Global => null, Inline_Always,
     Pre => (Static => Valid (P) and then Dense.Square (H) and then Dense.Square (M)
       and then H'Length (1) = P.N and then M'Length (1) = P.N
       and then (for all I in H'Range (1) => (for all J in H'Range (2) =>
         H (I, J) in -1.0e100 .. 1.0e100 and then M (I, J) in -1.0e100 .. 1.0e100))),
     Post => (Static =>
       (for all I in H'Range (1) => (for all J in H'Range (2) =>
         H (I, J) in -2.0e100 .. 2.0e100 and then H (I, J) =
           (if (for some K in 1 .. P.Length (I) => P.Column (I, K) = J)
            then H'Old (I, J)+M (I, J) else H'Old (I, J)))));

   subtype Residual is Real range -1.0e245 .. 1.0e245;
   function Update (Value, A, B : Real) return Real is (Value - A * B) with
     Global => null, Inline_Always,
     Pre => (Static => Value in Residual and then A in Operand and then B in Operand),
     Post => Update'Result = Value - A * B and then abs Update'Result <= 2.0e245;
   function Scale (Value, Inverse : Real) return Real is (Value * Inverse) with
     Global => null, Inline_Always,
     Pre => (Static => Value in Residual and then Inverse in 0.0 .. 1.0e15),
     Post => Scale'Result = Value * Inverse and then abs Scale'Result <= 1.0e260;

   --  A power-of-two envelope has exact scaling for these small integer
   --  counts. It budgets every possible CSC row update, including patterns
   --  whose fill closure has not yet been proved; public inputs stay unchanged.
   Max_Updates : constant Natural := Max_Dofs*Max_Dofs+1;
   Update_Step : constant Real := 2.0**799;
   function Scratch_Bound (Count : Natural) return Real is (Real (Count)*Update_Step)
     with Ghost => Static, Global => null,
     Pre => Count <= Max_Updates,
     Post => Scratch_Bound'Result = Real (Count)*Update_Step
       and then Scratch_Bound'Result in 0.0 .. Residual'Last;
   function Headroom_Term (Value, Term : Real; Count : Natural) return Real is
     (Value-Term)
     with Ghost => Static, Global => null,
     Pre => Count < Max_Updates and then abs Value <= Scratch_Bound (Count)
       and then abs Term <= 2.0e240,
     Post => Headroom_Term'Result in Residual
       and then Headroom_Term'Result = Value-Term
       and then abs Headroom_Term'Result <= Scratch_Bound (Count+1);
   function Headroom_Update (Value, A, B : Real; Count : Natural) return Real is
     (Headroom_Term (Value, A*B, Count))
     with Ghost => Static, Global => null,
     Pre => Count < Max_Updates and then abs Value <= Scratch_Bound (Count)
       and then A in Operand and then B in Operand,
     Post => Headroom_Update'Result in Residual
       and then Headroom_Update'Result = Update (Value, A, B)
       and then abs Headroom_Update'Result <= Scratch_Bound (Count+1);

   procedure Factor (H : Matrix; P : Pattern; L : out Matrix;
                     Rank : out Natural; Result : out Status; Floor : Pivot := 1.0e-15) with
     Global => null,
     Pre => Valid (P) and then Dense.Square (H) and then Dense.Bounded (H)
       and then H'Length (1) = P.N and then L'First (1) = 1 and then L'First (2) = 1
       and then L'Length (1) = P.N and then L'Length (2) = P.N,
     Post => Rank <= P.N and then (if Result = Success then
       Dense.Bounded (L) and then Dense.Positive_Diagonal (L));

   procedure Backsolve (L : Matrix; P : Pattern; B : Vector; X : out Vector;
                        Result : out Status) with
     Global => null,
     Pre => Valid (P) and then Dense.Square (L) and then Dense.Bounded (L)
       and then Dense.Positive_Diagonal (L) and then L'Length (1) = P.N
       and then B'First = 1 and then B'Length = P.N
       and then X'First = 1 and then X'Length = P.N
       and then (for all V of B => V in Operand),
     Post => (if Result = Success then (for all V of X => V in Operand));
end MJ.Constraint_Solvers.Sparse_Cholesky;
