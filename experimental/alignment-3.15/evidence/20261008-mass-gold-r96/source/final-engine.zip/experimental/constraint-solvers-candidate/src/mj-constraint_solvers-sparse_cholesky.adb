with MJ.Quaternion_Math;
package body MJ.Constraint_Solvers.Sparse_Cholesky with SPARK_Mode is
   procedure Symbolic (H : Mask; P : out Pattern; Result : out Status) is
      N : constant Positive := P.N;
      Parent, Flag : Counts (1 .. N);
      Cursor : Counts (1 .. N) := (others => 0);
      Written : Counts (1 .. N) := (others => 1);
      I, Pos : Natural;
   begin
      Result := Invalid_Pattern;
      P.Length := (others => 1); P.Transpose_Length := (others => 1);
      P.Column := (others => (others => 0));
      P.Transpose_Row := (others => (others => 0));
      P.Transpose_Position := (others => (others => 0));
      for Phase in 1 .. 2 loop
         Parent := (others => 0); Flag := (others => 0);
         if Phase = 2 then
            for R in 1 .. P.N loop
               if P.Length (R) not in 1 .. P.N then return; end if;
               Cursor (R) := P.Length (R)-1;
            end loop;
         end if;
         for R in reverse 1 .. P.N loop
            Parent (R) := 0; Flag (R) := R;
            if Phase = 2 then
               if P.Length (R) not in 1 .. P.N or else Written (R) not in 1 .. P.N then return; end if;
               P.Column (R, P.Length (R)) := R;
               P.Transpose_Row (R, Written (R)) := R;
               P.Transpose_Position (R, Written (R)) := P.Length (R);
               Written (R) := Written (R)+1;
            end if;
            for C in R+1 .. P.N loop
               if H (R, C) then
                  I := C;
                  while I in 1 .. P.N and then Flag (I) /= R loop
                     if I <= R then return; end if;
                     if Parent (I) = 0 then Parent (I) := R; end if;
                     if Phase = 1 then
                        if P.Length (I) >= P.N or else P.Transpose_Length (R) >= P.N then return; end if;
                        P.Length (I) := P.Length (I)+1;
                        P.Transpose_Length (R) := P.Transpose_Length (R)+1;
                     else
                        Pos := Cursor (I);
                        if Pos not in 1 .. P.N or else Written (R) not in 1 .. P.N then return; end if;
                        P.Column (I, Pos) := R;
                        Cursor (I) := Pos-1;
                        P.Transpose_Row (R, Written (R)) := I;
                        P.Transpose_Position (R, Written (R)) := Pos;
                        Written (R) := Written (R)+1;
                     end if;
                     if Parent (I) not in 1 .. I-1 then return; end if;
                     Flag (I) := R; I := Parent (I);
                     pragma Loop_Variant (Decreases => I);
                  end loop;
                  if I not in 1 .. P.N then return; end if;
               end if;
            end loop;
         end loop;
      end loop;
      if not Valid (P) then return; end if;
      Result := Success;
   end Symbolic;

   procedure Columns_Ordered (P : Pattern; R, First, Last : Positive)
     with Ghost => Static, Global => null,
     Pre => Valid (P) and then R <= P.N
       and then First <= Last and then Last <= P.Length (R),
     Post => P.Column (R, First) <= P.Column (R, Last)
       and then (if First < Last then P.Column (R, First) < P.Column (R, Last)),
     Subprogram_Variant => (Decreases => Last)
   is
   begin
      if First < Last then Columns_Ordered (P, R, First, Last-1); end if;
   end Columns_Ordered;

   procedure Separate_Column (P : Pattern; R, Position : Positive)
     with Ghost => Static, Global => null,
     Pre => Valid (P) and then R <= P.N and then Position <= P.Length (R),
     Post => (for all K in 1 .. P.Length (R) =>
       (if K /= Position then P.Column (R, K) /= P.Column (R, Position)))
   is
   begin
      for K in 1 .. P.Length (R) loop
         if K < Position then Columns_Ordered (P, R, K, Position);
         elsif K > Position then Columns_Ordered (P, R, Position, K);
         end if;
         pragma Loop_Invariant (for all Q in 1 .. K =>
           (if Q /= Position then P.Column (R, Q) /= P.Column (R, Position)));
      end loop;
   end Separate_Column;

   procedure Bound_Monotone (Smaller, Larger : Natural)
     with Ghost => Static, Global => null,
     Pre => Smaller <= Larger and then Larger <= Max_Updates,
     Post => Scratch_Bound (Smaller) <= Scratch_Bound (Larger)
   is
   begin
      pragma Assert (Real (Smaller) <= Real (Larger));
   end Bound_Monotone;

   procedure Row_Headroom
     (Before, After : Vector; L : Matrix; P : Pattern;
      C, Position : Positive; Budget : Natural)
     with Ghost => Static, Global => null,
     Pre => Valid (P) and then Dense.Square (L) and then Dense.Bounded (L)
       and then L'Length (1) = P.N and then C <= P.N
       and then Position <= P.Length (C) and then Budget < Max_Updates
       and then Before'First = 1 and then Before'Length = P.N
       and then After'First = 1 and then After'Length = P.N
       and then (for all V of Before => abs V <= Scratch_Bound (Budget))
       and then (for all K in 1 .. Position => After (P.Column (C, K)) =
         Update (Before (P.Column (C, K)),
           L (C, P.Column (C, Position)), L (C, P.Column (C, K))))
       and then (for all J in After'Range =>
         (if (for all K in 1 .. Position => P.Column (C, K) /= J)
          then After (J) = Before (J))),
     Post => (for all V of After => abs V <= Scratch_Bound (Budget+1))
   is
   begin
      Bound_Monotone (Budget, Budget+1);
      for J in After'Range loop
         for K in 1 .. Position loop
            if P.Column (C, K) = J then
               pragma Assert (After (J) = Headroom_Update
                 (Before (J), L (C, P.Column (C, Position)), L (C, J), Budget));
               pragma Assert (abs After (J) <= Scratch_Bound (Budget+1));
            end if;
            pragma Loop_Invariant
              (if (for some Q in 1 .. K => P.Column (C, Q) = J)
               then abs After (J) <= Scratch_Bound (Budget+1));
         end loop;
         pragma Assert (abs After (J) <= Scratch_Bound (Budget+1));
         pragma Loop_Invariant (for all I in After'First .. J =>
           abs After (I) <= Scratch_Bound (Budget+1));
      end loop;
   end Row_Headroom;

   --  One CSC contribution, with a component relation and a frame property.
   --  The strictly ordered row indices ensure each target is visited once.
   procedure Update_Row
     (L : Matrix; P : Pattern; C, Position : Positive;
      Scratch : in out Vector; Result : out Status; Step : Positive)
     with Global => null, Inline_Always,
     Pre => (Static => Valid (P) and then Dense.Square (L) and then Dense.Bounded (L)
       and then L'Length (1) = P.N and then C <= P.N
       and then Position <= P.Length (C)
       and then Scratch'First = 1 and then Scratch'Length = P.N
       and then (for all V of Scratch => V in Residual)
       and then Step in 2 .. Max_Dofs+1
       and then (for all V of Scratch => abs V <=
         Scratch_Bound ((P.N-P.Column (C, Position))*Max_Dofs+Step-1))),
     Post => (Static => (for all V of Scratch => V in Residual)
       and then Result = Success
       and then (for all V of Scratch => abs V <=
         Scratch_Bound ((P.N-P.Column (C, Position))*Max_Dofs+Step))
       and then (if Result = Success then
         (for all K in 1 .. Position => Scratch (P.Column (C, K)) =
           Update (Scratch'Old (P.Column (C, K)),
             L (C, P.Column (C, Position)), L (C, P.Column (C, K))))
         and then (for all J in Scratch'Range =>
           (if (for all K in 1 .. Position => P.Column (C, K) /= J)
            then Scratch (J) = Scratch'Old (J)))))
   is
      Before : constant Vector := Scratch with Ghost => Static;
      R : constant Positive := P.Column (C, Position);
      Multiplier : constant Real := L (C, R);
      Budget : constant Natural := (P.N-R)*Max_Dofs+Step-1 with Ghost => Static;
      J : Natural;
      Value : Real;
   begin
      Result := Numeric_Limit;
      for Q in 1 .. Position loop
         Separate_Column (P, C, Q);
         J := P.Column (C, Q);
         Value := Update (Scratch (J), Multiplier, L (C, J));
         pragma Assert (Static => Value =
           Headroom_Update (Before (J), Multiplier, L (C, J), Budget));
         pragma Assert (Static => Value in Residual);
         Scratch (J) := Value;
         pragma Loop_Invariant (for all V of Scratch => V in Residual);
         pragma Loop_Invariant (Static => (for all K in 1 .. Q =>
           Scratch (P.Column (C, K)) =
             Update (Before (P.Column (C, K)), L (C, R), L (C, P.Column (C, K)))));
         pragma Loop_Invariant (Static => (for all K in Q+1 .. Position =>
           Scratch (P.Column (C, K)) = Before (P.Column (C, K))));
         pragma Loop_Invariant (Static => (for all I in Scratch'Range =>
           (if (for all K in 1 .. Q => P.Column (C, K) /= I)
            then Scratch (I) = Before (I))));
      end loop;
      Row_Headroom (Before, Scratch, L, P, C, Position, Budget);
      Result := Success;
   end Update_Row;

   --  Assemble one numeric row. Each CSC update is specified and proved in
   --  Update_Row; the global symbolic/fill relation remains a separate goal.
   procedure Prepare_Row
     (H, L : Matrix; P : Pattern; R : Positive;
      Scratch : in out Vector; Result : out Status)
     with Global => null, Inline_Always,
     Pre => (Static => Valid (P) and then R <= P.N
       and then Dense.Square (H) and then Dense.Bounded (H)
       and then Dense.Square (L) and then Dense.Bounded (L)
       and then H'Length (1) = P.N and then L'Length (1) = P.N
       and then Scratch'First = 1 and then Scratch'Length = P.N
       and then (for all V of Scratch => V in Residual)
       and then (for all V of Scratch =>
         abs V <= Scratch_Bound ((P.N-R)*Max_Dofs+1))),
     Post => (Static => (for all V of Scratch => V in Residual)
       and then (for all V of Scratch =>
         abs V <= Scratch_Bound ((P.N-R+1)*Max_Dofs+1)))
   is
      J, C, Pos : Natural;
   begin
      for K in 1 .. P.Length (R) loop
         J := P.Column (R, K); Scratch (J) := H (R, J);
         pragma Loop_Invariant (for all V of Scratch => V in Residual);
         pragma Loop_Invariant (Static => (for all V of Scratch =>
           abs V <= Scratch_Bound ((P.N-R)*Max_Dofs+1)));
      end loop;
      for K in 2 .. P.Transpose_Length (R) loop
         C := P.Transpose_Row (R, K); Pos := P.Transpose_Position (R, K);
         Update_Row (L, P, C, Pos, Scratch, Result, K);
         if Result /= Success then return; end if;
         pragma Loop_Invariant (for all V of Scratch => V in Residual);
         pragma Loop_Invariant (Static => (for all V of Scratch =>
           abs V <= Scratch_Bound ((P.N-R)*Max_Dofs+K)));
      end loop;
      Bound_Monotone ((P.N-R)*Max_Dofs+P.Transpose_Length (R),
                      (P.N-R+1)*Max_Dofs+1);
      Result := Success;
   end Prepare_Row;

   procedure Store_Element (L : in out Matrix; R, C : Positive; Value : Operand)
     with Global => null, Inline_Always,
     Pre => Dense.Square (L) and then Dense.Bounded (L)
       and then R <= L'Last (1) and then C <= L'Last (2),
     Post => (Static => Dense.Bounded (L) and then L (R, C) = Value
       and then (for all J in L'Range (2) =>
         (if J /= C then L (R, J) = L'Old (R, J)))
       and then (for all I in L'Range (1) =>
         (if I /= R then (for all J in L'Range (2) => L (I, J) = L'Old (I, J)))))
   is
   begin
      L (R, C) := Value;
   end Store_Element;

   procedure Row_Frame_Transitive (Original, Before, After : Matrix; R : Positive)
     with Ghost => Static, Global => null,
     Pre => Dense.Square (Original) and then Dense.Square (Before)
       and then Dense.Square (After)
       and then Original'Length (1) = Before'Length (1)
       and then Original'Length (1) = After'Length (1) and then R <= Original'Length (1)
       and then (for all I in Before'Range (1) =>
         (if I /= R then (for all J in Before'Range (2) => Before (I, J) = Original (I, J))))
       and then (for all I in After'Range (1) =>
         (if I /= R then (for all J in After'Range (2) => After (I, J) = Before (I, J)))),
     Post => (for all I in After'Range (1) =>
       (if I /= R then (for all J in After'Range (2) => After (I, J) = Original (I, J))))
   is
   begin
      for I in After'Range (1) loop
         if I /= R then
            for J in After'Range (2) loop
               pragma Assert (After (I, J) = Original (I, J));
               pragma Loop_Invariant (for all C in After'First (2) .. J =>
                 After (I, C) = Original (I, C));
            end loop;
         end if;
         pragma Loop_Invariant (for all Q in After'First (1) .. I =>
           (if Q /= R then (for all J in After'Range (2) => After (Q, J) = Original (Q, J))));
      end loop;
   end Row_Frame_Transitive;

   procedure Add_Mass_Row (H : in out Matrix; M : Matrix; P : Pattern; R : Positive) is
      Before : constant Matrix := H with Ghost => Static;
   begin
      for Slot in 1 .. P.Length (R) loop
         Separate_Column (P, R, Slot);
         declare C : constant Positive := P.Column (R, Slot); begin
            H (R, C) := H (R, C)+M (R, C);
         end;
         pragma Loop_Invariant (Static =>
           (for all I in H'Range (1) => (for all J in H'Range (2) =>
             H (I, J) in -2.0e100 .. 2.0e100 and then H (I, J) =
               (if I = R and then (for some K in 1 .. Slot => P.Column (R, K) = J)
                then Before (I, J)+M (I, J) else Before (I, J)))));
      end loop;
   end Add_Mass_Row;

   procedure Add_Mass (H : in out Matrix; M : Matrix; P : Pattern) is
      Before : constant Matrix := H with Ghost => Static;
   begin
      for R in 1 .. P.N loop
         Add_Mass_Row (H, M, P, R);
         pragma Loop_Invariant (Static =>
           (for all I in H'Range (1) => (for all J in H'Range (2) =>
             H (I, J) in -2.0e100 .. 2.0e100 and then H (I, J) =
               (if I <= R and then (for some K in 1 .. P.Length (I) => P.Column (I, K) = J)
                then Before (I, J)+M (I, J) else Before (I, J)))));
      end loop;
   end Add_Mass;

   --  Scale and publish only the off-diagonal row. Its multiplier is an
   --  input, keeping root/division expressions outside this loop minimum.
   procedure Store_Offdiagonal
     (Scratch : Vector; P : Pattern; R : Positive; Inverse : Real;
      Deficient : Boolean; L : in out Matrix; Result : out Status)
     with Global => null, Inline_Always,
     Pre => (Static => Valid (P) and then R <= P.N
       and then Dense.Square (L) and then Dense.Bounded (L)
       and then L'Length (1) = P.N
       and then Scratch'First = 1 and then Scratch'Length = P.N
       and then (for all V of Scratch => V in Residual)
       and then Inverse in 0.0 .. 1.0e15),
     Post => (Static => Dense.Bounded (L)
       and then (for all I in L'Range (1) =>
         (if I /= R then (for all J in L'Range (2) => L (I, J) = L'Old (I, J))))
       and then (if Result = Success then
         (for all K in 1 .. P.Length (R)-1 =>
           L (R, P.Column (R, K)) = (if Deficient then 0.0 else
             Scale (Scratch (P.Column (R, K)), Inverse)))))
   is
      Before : constant Matrix := L with Ghost => Static;
      Prior : Matrix := L with Ghost => Static;
      Value : Real;
      J : Natural;
   begin
      Result := Numeric_Limit;
      if P.Length (R) > 1 then
         for K in 1 .. P.Length (R)-1 loop
            Separate_Column (P, R, K);
            J := P.Column (R, K);
            Value := (if Deficient then 0.0 else Scale (Scratch (J), Inverse));
            if Value not in Operand then return; end if;
            Prior := L;
            Store_Element (L, R, J, Value);
            Row_Frame_Transitive (Before, Prior, L, R);
            pragma Loop_Invariant (Dense.Bounded (L));
            pragma Loop_Invariant (Static => (for all Q in 1 .. K =>
              L (R, P.Column (R, Q)) = (if Deficient then 0.0 else
                Scale (Scratch (P.Column (R, Q)), Inverse))));
            pragma Loop_Invariant (Static => (for all I in L'Range (1) =>
              (if I /= R then (for all C in L'Range (2) => L (I, C) = Before (I, C)))));
         end loop;
      end if;
      Result := Success;
   end Store_Offdiagonal;

   procedure Store_Row
     (Scratch : Vector; P : Pattern; R : Positive; Floor : Pivot;
      L : in out Matrix; Deficient : out Boolean; Result : out Status)
     with Global => null, Inline_Always,
     Pre => Valid (P) and then R <= P.N
       and then Dense.Square (L) and then Dense.Bounded (L)
       and then L'Length (1) = P.N
       and then Scratch'First = 1 and then Scratch'Length = P.N
       and then (for all V of Scratch => V in Residual),
     Post => (Static => Dense.Bounded (L)
       and then Deficient = (Scratch (R) < Floor)
       and then (for all I in L'Range (1) =>
         (if I /= R then (for all J in L'Range (2) => L (I, J) = L'Old (I, J))))
       and then (if Result = Success then L (R, R) in Pivot
         and then L (R, R) = MJ.Quaternion_Math.Sqrt
           (if Deficient then Floor else Scratch (R))
         and then (for all K in 1 .. P.Length (R)-1 =>
           L (R, P.Column (R, K)) = (if Deficient then 0.0 else
             Scale (Scratch (P.Column (R, K)), Dense.Inverse_Pivot (L (R, R)))))))
   is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Dense.Bounded);
      Before : constant Matrix := L with Ghost => Static;
      Prior : Matrix := L with Ghost => Static;
      Value, Root, Inverse : Real;
   begin
      Result := Numeric_Limit;
      Deficient := Scratch (R) < Floor;
      Value := (if Deficient then Floor else Scratch (R));
      Root := MJ.Quaternion_Math.Sqrt (Value);
      if Root not in Pivot then return; end if;
      Inverse := Dense.Inverse_Pivot (Root);
      Store_Offdiagonal (Scratch, P, R, Inverse, Deficient, L, Result);
      if Result /= Success then return; end if;
      Separate_Column (P, R, P.Length (R));
      Prior := L;
      Store_Element (L, R, R, Root);
      Row_Frame_Transitive (Before, Prior, L, R);
      Result := Success;
   end Store_Row;

   procedure Clear_Row (P : Pattern; R : Positive; Scratch : in out Vector)
     with Global => null, Inline_Always,
     Pre => (Static => Valid (P) and then R <= P.N
       and then Scratch'First = 1 and then Scratch'Length = P.N
       and then (for all V of Scratch => V in Residual)
       and then (for all V of Scratch =>
         abs V <= Scratch_Bound ((P.N-R+1)*Max_Dofs+1))),
     Post => (Static => (for all V of Scratch => V in Residual)
       and then (for all V of Scratch =>
         abs V <= Scratch_Bound ((P.N-R+1)*Max_Dofs+1))
       and then (for all K in 1 .. P.Length (R) => Scratch (P.Column (R, K)) = 0.0)
       and then (for all I in Scratch'Range =>
         (if (for all K in 1 .. P.Length (R) => P.Column (R, K) /= I)
          then Scratch (I) = Scratch'Old (I))))
   is
      Budget : constant Natural := (P.N-R+1)*Max_Dofs+1 with Ghost => Static;
   begin
      for K in 1 .. P.Length (R) loop
         Scratch (P.Column (R, K)) := 0.0;
         pragma Loop_Invariant (for all V of Scratch => V in Residual);
         pragma Loop_Invariant (Static =>
           (for all V of Scratch => abs V <= Scratch_Bound (Budget)));
         pragma Loop_Invariant (Static => (for all Q in 1 .. K =>
           Scratch (P.Column (R, Q)) = 0.0));
         pragma Loop_Invariant (Static => (for all I in Scratch'Range =>
           (if (for all Q in 1 .. K => P.Column (R, Q) /= I)
            then Scratch (I) = Scratch'Loop_Entry (I))));
      end loop;
   end Clear_Row;

   procedure Diagonal_Progress (Before, After : Matrix; R : Positive)
     with Ghost => Static, Global => null,
     Pre => Dense.Square (Before) and then Dense.Square (After)
       and then Before'Length (1) = After'Length (1) and then R <= After'Length (1)
       and then After (R, R) in Pivot
       and then (for all I in R+1 .. Before'Last (1) => Before (I, I) in Pivot)
       and then (for all I in R+1 .. After'Last (1) => After (I, I) = Before (I, I)),
     Post => (for all I in R .. After'Last (1) => After (I, I) in Pivot)
   is
   begin
      for I in R .. After'Last (1) loop
         if I > R then pragma Assert (After (I, I) = Before (I, I)); end if;
         pragma Assert (After (I, I) in Pivot);
         pragma Loop_Invariant (for all Q in R .. I => After (Q, Q) in Pivot);
      end loop;
   end Diagonal_Progress;

   procedure Factor (H : Matrix; P : Pattern; L : out Matrix;
                     Rank : out Natural; Result : out Status; Floor : Pivot := 1.0e-15) is
      Scratch : Vector (1 .. P.N) := (others => 0.0);
      Before : Matrix (L'Range (1), L'Range (2)) with Ghost => Static;
      Deficient : Boolean;
      Row_Status : Status;
   begin
      Result := Numeric_Limit; Rank := P.N;
      L := (others => (others => 0.0));
      for R in reverse 1 .. P.N loop
         Prepare_Row (H, L, P, R, Scratch, Row_Status);
         if Row_Status /= Success then return; end if;
         Before := L;
         Store_Row (Scratch, P, R, Floor, L, Deficient, Row_Status);
         --  Keep the original rank accounting even when the numeric row fails.
         if Deficient then Rank := Rank-1; end if;
         if Row_Status /= Success then return; end if;
         Diagonal_Progress (Before, L, R);
         Clear_Row (P, R, Scratch);
         pragma Loop_Invariant (Dense.Bounded (L));
         pragma Loop_Invariant (for all V of Scratch => V in Residual);
         pragma Loop_Invariant (Static => (for all V of Scratch =>
           abs V <= Scratch_Bound ((P.N-R+1)*Max_Dofs+1)));
         pragma Loop_Invariant (for all I in R .. P.N => L (I, I) in Pivot);
         pragma Loop_Invariant (Rank in R-1 .. P.N);
      end loop;
      Result := Success;
   end Factor;

   --  The ordered off-diagonal prefix takes an already normalized scalar.
   --  Keeping division outside this minimum avoids coupling its loop proof
   --  to the diagonal's nonlinear expression.
   procedure Scatter_Prefix (L : Matrix; P : Pattern; X : in out Vector;
                             I : Positive; Multiplier : Real; Result : out Status)
     with Global => null, Inline_Always,
     Pre => (Static => Valid (P) and then Dense.Square (L) and then Dense.Bounded (L)
       and then L'Length (1) = P.N and then I <= P.N
       and then X'First = 1 and then X'Length = P.N
       and then (for all V of X => V in Operand) and then Multiplier in Operand),
     Post => (Static => (for all V of X => V in Operand)
       and then (for all J in X'Range =>
         (if (for all K in 1 .. P.Length (I)-1 => P.Column (I, K) /= J)
          then X (J) = X'Old (J)))
       and then (if Result = Success then
         (for all K in 1 .. P.Length (I)-1 =>
           X (P.Column (I, K)) = Update
             (X'Old (P.Column (I, K)), L (I, P.Column (I, K)), Multiplier))))
   is
      Before : constant Vector := X with Ghost => Static;
      Value : Real;
      J : Natural;
   begin
      Result := Numeric_Limit;
      for K in 1 .. P.Length (I)-1 loop
         Separate_Column (P, I, K);
         J := P.Column (I, K);
         Value := Update (X (J), L (I, J), Multiplier);
         if Value not in Operand then return; end if;
         X (J) := Value;
         pragma Loop_Invariant (for all V of X => V in Operand);
         pragma Loop_Invariant (Static => (for all V of Before => V in Operand));
         pragma Loop_Invariant (Static => (for all Q in 1 .. K =>
           X (P.Column (I, Q)) = Update
             (Before (P.Column (I, Q)), L (I, P.Column (I, Q)), Multiplier)));
         pragma Loop_Invariant (Static => (for all Q in K+1 .. P.Length (I)-1 =>
           X (P.Column (I, Q)) = Before (P.Column (I, Q))));
         pragma Loop_Invariant (Static => (for all J in X'Range =>
           (if (for all Q in 1 .. K => P.Column (I, Q) /= J)
            then X (J) = Before (J))));
      end loop;
      Result := Success;
   end Scatter_Prefix;

   --  One ordered L^-T scatter from mju_cholSolveSparse. Bounds on the
   --  stored factors and RHS justify the static Update precondition.
   procedure Scatter_Row (L : Matrix; P : Pattern; X : in out Vector;
                          I : Positive; Result : out Status)
     with Global => null, Inline_Always,
     Pre => Valid (P) and then Dense.Square (L) and then Dense.Bounded (L)
       and then Dense.Positive_Diagonal (L) and then L'Length (1) = P.N
       and then X'First = 1 and then X'Length = P.N and then I <= P.N
       and then (for all V of X => V in Operand),
     Post => (Static => (for all V of X => V in Operand)
       and then (for all J in X'Range =>
         (if J /= I and then (for all K in 1 .. P.Length (I)-1 => P.Column (I, K) /= J)
          then X (J) = X'Old (J)))
       and then (if Result = Success then
         (if X'Old (I) = 0.0 then X = X'Old else
           X (I) = X'Old (I) / L (I, I)
           and then (for all K in 1 .. P.Length (I)-1 =>
             X (P.Column (I, K)) = Update
               (X'Old (P.Column (I, K)), L (I, P.Column (I, K)), X (I))))))
   is
      Value : Real;
   begin
      Result := Success;
      if X (I) = 0.0 then return; end if;
      Result := Numeric_Limit;
      Value := X (I) / L (I, I);
      if Value not in Operand then return; end if;
      Separate_Column (P, I, P.Length (I));
      X (I) := Value;
      Scatter_Prefix (L, P, X, I, Value, Result);
   end Scatter_Row;

   procedure Backsolve (L : Matrix; P : Pattern; B : Vector; X : out Vector;
                        Result : out Status) is
      Value, S, S0, S1, S2, S3 : Real;
      J, Offset, Count : Natural;
      Row_Status : Status;
   begin
      X := B; Result := Numeric_Limit;
      for I in reverse 1 .. P.N loop
         Scatter_Row (L, P, X, I, Row_Status);
         if Row_Status /= Success then return; end if;
         pragma Loop_Invariant (for all V of X => V in Operand);
      end loop;
      for I in 1 .. P.N loop
         Count := P.Length (I)-1;
         if Count > 0 then
            S0 := 0.0; S1 := 0.0; S2 := 0.0; S3 := 0.0; Offset := 0;
            --  mju_dotSparse has a sequential scalar tail, unlike mju_dot.
            while Offset+4 <= Count loop
               J := P.Column (I, Offset+1); S0 := S0 + L (I, J)*X (J);
               J := P.Column (I, Offset+2); S1 := S1 + L (I, J)*X (J);
               J := P.Column (I, Offset+3); S2 := S2 + L (I, J)*X (J);
               J := P.Column (I, Offset+4); S3 := S3 + L (I, J)*X (J);
               Offset := Offset+4;
               pragma Loop_Variant (Increases => Offset);
            end loop;
            S := (S0+S2)+(S1+S3);
            for K in Offset+1 .. Count loop
               J := P.Column (I, K); S := S + L (I, J)*X (J);
            end loop;
            Value := X (I)-S;
         else Value := X (I);
         end if;
         Value := Value/L (I, I);
         if Value not in Operand then return; end if;
         X (I) := Value;
      end loop;
      Result := Success;
   end Backsolve;
end MJ.Constraint_Solvers.Sparse_Cholesky;
