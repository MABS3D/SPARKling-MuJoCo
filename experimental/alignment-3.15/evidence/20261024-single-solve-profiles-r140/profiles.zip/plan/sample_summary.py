#!/usr/bin/env python3
"""Raw gmon main-image samples; diagnostic self cost, distinct from entry counts."""
from pathlib import Path
import argparse,bisect,collections,hashlib,json,struct,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--binary',type=Path,required=True);p.add_argument('--gmon',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
a=p.parse_args();syms=[]
for line in subprocess.check_output(['nm','-S','--defined-only',str(a.binary)],text=True).splitlines():
 parts=line.split()
 if len(parts)==4 and parts[2] in ('t','T','w','W') and int(parts[1],16)>0:syms.append((int(parts[0],16),int(parts[1],16),parts[3]))
syms.sort();starts=[s[0] for s in syms]
def locate(pc,end=None):
 i=bisect.bisect_right(starts,pc)-1
 if i>=0 and pc<starts[i]+syms[i][1] and (end is None or end<=starts[i]+syms[i][1]):return syms[i][2]
 return '<unmapped_or_boundary>'
data=a.gmon.read_bytes();assert data[:4]==b'gmon' and struct.unpack_from('<I',data,4)[0]==1
pos=20;samples=collections.Counter();incoming=collections.Counter();histograms=[]
while pos<len(data):
 tag=data[pos];pos+=1
 if tag==0:
  low,high,n,rate,dimension,abbrev=struct.unpack_from('<QQII15sc',data,pos);pos+=40
  bins=struct.unpack_from('<'+'H'*n,data,pos);pos+=2*n
  assert (high-low)%n==0 and rate>0;span=(high-low)//n
  histograms.append(dict(low=hex(low),high=hex(high),bins=n,rate_hz=rate,bin_bytes=span,samples=sum(bins),saturated_bins=sum(x==65535 for x in bins)))
  for k,count in enumerate(bins):
   if count:samples[locate(low+k*span,low+(k+1)*span)]+=count
 elif tag==1:
  caller,callee,count=struct.unpack_from('<QQI',data,pos);pos+=20;incoming[locate(callee)]+=count
 else:raise ValueError(('Unsupported gmon record',tag,pos))
assert pos==len(data);total=sum(samples.values());assert total>0
rates={h['rate_hz'] for h in histograms};assert len(rates)==1;rate=next(iter(rates))
rows=[dict(symbol=name,samples=count,percent_of_main_image_samples=100*count/total,
 sampled_self_seconds=count/rate,incoming_recorded_entries=incoming.get(name)) for name,count in samples.most_common()]
result=dict(scope='Instrumented full process: parsing, preparation, two extra Evaluate calls per trajectory, stepping and output. Histogram covers main executable address range; shared-library time can be absent. Not release timing, not timed-loop-only, no measured Ada/C cost ratio.',
 method='GNU gmon histogram bins mapped only when entirely inside sized ELF text symbols. Boundary/unmapped bins retained. Entry arcs and sample counts are distinct observations. Instrumentation changes costs and code generation.',
 binary_sha256=hashlib.sha256(a.binary.read_bytes()).hexdigest(),gmon_sha256=hashlib.sha256(data).hexdigest(),analysis_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 histograms=histograms,total_samples=total,sampled_main_image_seconds=total/rate,unmapped_or_boundary_samples=samples['<unmapped_or_boundary>'],
 sampling_resolution_note='Each sample is1/rate seconds. Percentages are diagnostic and have sampling variation; no statistical confidence claim or inclusive callgraph-time allocation.',
 low_sample_warning=total<1000,top_self=rows[:60],all_sampled_symbols=rows)
a.out.write_text(json.dumps(result,indent=2)+chr(10));print(json.dumps(dict(gmon=str(a.gmon),total_samples=total,top=rows[:8])),flush=True)
