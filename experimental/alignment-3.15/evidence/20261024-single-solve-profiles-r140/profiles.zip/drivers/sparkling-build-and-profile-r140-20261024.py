from pathlib import Path
import os,subprocess,hashlib,json,time,sys
plan=Path('/tmp/sparkling-r140-profile-plan-20261024-v1');engine=Path('/var/tmp/sparkling-single-solve-r140-315-release-20261024');root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');build=Path('/var/tmp/sparkling-r140-instrumented-build-20261024-v1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not build.exists();build.mkdir()
manifest=json.loads((engine/'manifest.json').read_text())
def matches():return all(sha(engine/'source'/name)==value for name,value in manifest['sources'].items())
assert matches()
env=os.environ.copy();tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env['PATH']=':'.join(str(p) for name in ['gnat','gprbuild'] for p in (tc/name).glob('*/bin'))+':'+env['PATH'];env.update(FLEX_BUILD_ROOT=str(build),FLEX_MODE='release')
command=['gprbuild','-P',str(engine/'source/experimental/flex-elasticity-integration/flex_constrained.gpr'),'-j1','-cargs:Ada','-pg','-g','-largs','-pg']
log=build/'build.log';started=time.monotonic();print('START one instrumented build',flush=True)
with log.open('w') as f:run=subprocess.run(['python3',str(root/'tools/guarded.py'),'--cap-mb','3000','--timeout','600','--',*command],cwd=engine/'source',env=env,stdout=f,stderr=subprocess.STDOUT)
lineage=dict(command=command,exit=run.returncode,seconds=time.monotonic()-started,build_root=str(build),log_sha256=sha(log),engine_manifest_sha256=sha(engine/'manifest.json'),source_hashes_unchanged=matches(),scope='One -pg/-g build from the exact measured r140 sources; not release timing.')
(build/'results.json').write_text(json.dumps(lineage,indent=2)+'\n');assert run.returncode==0 and lineage['source_hashes_unchanged']
binary=build/'release/bin/flex_constrained_probe';target=plan/'frozen/instrumented';target.mkdir(parents=True,exist_ok=False)
import shutil
shutil.copyfile(binary,target/'flex_constrained_probe');shutil.copymode(binary,target/'flex_constrained_probe');shutil.copyfile(log,target/'build.log')
lineage.update(source_binary_sha256=sha(binary));(target/'lineage.json').write_text(json.dumps(lineage,indent=2)+'\n')
files={str(p.relative_to(plan)):sha(p) for p in plan.rglob('*') if p.is_file() and p.name!='plan-hashes.json'}
(plan/'plan-hashes.json').write_text(json.dumps(files,indent=2)+'\n')
print('END build; one frozen ELF',lineage['source_binary_sha256'],flush=True)
import mujoco,numpy as np
for name in ['free','element_elastic_cross_elliptic_6']:
 m=mujoco.MjModel.from_binary_path(str(plan/'cases'/f'{name}.mjb'));assert not np.any(m.dof_damping),name
print('START six count cases and two longer profiles',flush=True)
sys.exit(subprocess.run([sys.executable,str(plan/'run.py'),'--execute'],cwd=plan).returncode)
