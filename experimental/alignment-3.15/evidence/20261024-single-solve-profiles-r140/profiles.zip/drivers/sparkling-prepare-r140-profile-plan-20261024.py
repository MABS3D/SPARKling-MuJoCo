from pathlib import Path
import ast,hashlib,json,shutil
old=Path('/tmp/sparkling-r122-profile-plan-20261024-v2');plan=Path('/tmp/sparkling-r140-profile-plan-20261024-v1');plan.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=json.loads((old/'plan-hashes.json').read_text())
for name,value in original.items():
 assert sha(old/name)==value,name
 if name=='run.py' or name.startswith('frozen/instrumented/'):continue
 target=plan/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/name,target)
engine=Path('/var/tmp/sparkling-single-solve-r140-315-release-20261024');out=Path('/var/tmp/sparkling-r140-profiles-20261024-v1')
s=(old/'run.py').read_text();s=s.replace("ENGINE=Path('/var/tmp/sparkling-alignment-315-reuse-release-r122-20261009')",f'ENGINE=Path({str(engine)!r})').replace("OUT=Path('/var/tmp/sparkling-r122-profiles-20261024-v2')",f'OUT=Path({str(out)!r})')
s=s.replace("EXPECTED_MANIFEST='cdc29de6b5b5076568a99f5e196c8861d6d162dab687f7f9d0e605cae2b4cdc4'",'EXPECTED_MANIFEST='+repr(sha(engine/'manifest.json')))
s=s.replace("EXPECTED_RELEASE_BINARY='637cbe2ea3d5788b2d9a16e1cb25e22a4147a88625612cc9e013c86756d00df9'",'EXPECTED_RELEASE_BINARY='+repr(sha(engine/'force-build/release/bin/flex_constrained_probe')))
s=s.replace('Immutable r122 only.','Immutable r140 only.').replace("working_tree_note='HEAD context570128a; live worktree is changing for3.17 and ghost proofs. No equality to current worktree is required; only frozen r122 source manifest is authoritative.'", "working_tree_note='Frozen measured r140; current tree has only separate proof refinements. The immutable r140 manifest identifies the profiled runtime.'")
s=s.replace("original_head='570128a07e176eeefc27a161ffe7cc659d0d1221'","original_head='368ab2109fb4f6c170cd39bde629532c58659c54'")
needle="counts=collector.arc_counts(shared,modeldir/'gmon.out');assert counts['Solve_With_Force']['calls']==204000";assert s.count(needle)==1
s=s.replace(needle,needle+"\n  assert counts['Solve_Compatible_Buffers']['calls']==204000, (name, 'Unexpected extra base/Euler solve; both long fixtures have zero joint damping')",1)
ast.parse(s);(plan/'run.py').write_text(s)
p=plan/'collect.py';s=p.read_text();needle="TARGETS={'Factor_Values':";assert s.count(needle)==1
s=s.replace(needle,"TARGETS={'Solve_Compatible_Buffers':'mj__data__inertia_phase__solve_compatible_buffers','Factor_Values':",1);ast.parse(s);p.write_text(s)
(plan/'README.txt').write_text('Frozen r140 diagnostics after the quiet release measurement. One separately built -pg binary is reused across all cases. Exact incoming-entry counts and main-image sampling are diagnostic; instrumented durations are not release timings. C3.15 endpoint2 receipts and byte-identical inputs are preserved from the validated reference run. No latest-C3.17 or full-port claim.\n')
print(plan)
