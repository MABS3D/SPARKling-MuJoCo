#!/usr/bin/env python3
"""Freeze inputs, build profiles, diagnose minimal subprograms, prove whole units."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
UNITS = ['mj-constraint_solvers-native_inertia', 'mj-constraint_solvers-cholesky_updates', 'mj-constraint_solvers-jacobian_transpose', 'mj-constraint_solvers-jacobians', 'mj-constraint_solvers-sparse_cholesky', 'mj-constraint_solvers-dense_cholesky', 'mj-constraint_solvers-reduction_models', 'mj-constraint_solvers-reductions',
         'mj-constraint_scalar', 'mj-constraint_order',
         'mj-constraint_solvers-sparse_kernels',
         'mj-constraint_solvers-cholesky', 'mj-constraint_solvers']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sources():
    return [ROOT/'src/mj.ads', ROOT/'src/mj-types.ads', ROOT/'src/mj-quaternion_math.ads',
            *sorted((HERE/'src').glob('*.ad?')), HERE/'tests/solvers_probe.adb',
            HERE/'tests/cholesky_edges.adb', HERE/'tests/reductions_probe.adb',
            HERE/'tests/dense_cholesky_probe.adb', HERE/'tests/sparse_cholesky_probe.adb',
            HERE/'tests/jacobians_probe.adb', HERE/'tests/transpose_probe.adb',
            HERE/'tests/cholesky_updates_probe.adb', HERE/'tests/native_inertia_probe.adb']

def environment():
    env = os.environ.copy()
    tc = Path('/var/tmp/sparkling-matrix-recovery/toolchains')
    env['PATH'] = os.pathsep.join(str(next((tc/n).glob('*/bin')))
        for n in ['gnat', 'gprbuild', 'gnatprove']) + os.pathsep + env['PATH']
    return env

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--phase', choices=['build', 'small', 'whole'], required=True)
    ap.add_argument('--mode', choices=['validation', 'release'], default='validation')
    ap.add_argument('--unit', choices=UNITS)
    ap.add_argument('--only', help='minimal subprogram name, not a whole-unit filter')
    ap.add_argument('--timeout', type=int, default=10)
    ap.add_argument('--proof', choices=['per_check', 'per_path', 'progressive'], default='per_check')
    ap.add_argument('--no-inlining', action='store_true', help='diagnose explicit subprogram boundaries')
    ap.add_argument('--wall-timeout', type=int, default=600)
    args = ap.parse_args()
    if args.only and args.phase != 'small':
        ap.error('--only is allowed only for small-subprogram diagnostics')
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    (out/'src').mkdir()
    hashes = {str(p.relative_to(ROOT)): digest(p) for p in sources()}
    for p in sources():
        shutil.copyfile(p, out/'src'/p.name)
    project = (HERE/'solvers.gpr').read_text().replace(
        'for Source_Dirs use ("src", "../../src", "tests");',
        'for Source_Dirs use ("src");')
    (out/'solvers.gpr').write_text(project)
    (out/'sources.json').write_text(json.dumps(hashes, indent=2)+'\n')
    def frozen_unchanged():
        return hashes == {rel: digest(out/'src'/Path(rel).name) for rel in hashes}
    def checkout_matches():
        return hashes == {str(p.relative_to(ROOT)): digest(p) for p in sources()}
    assert frozen_unchanged(), 'input changed during source capture'
    (out/'runner-inputs.json').write_text(json.dumps({
        str(Path(__file__).resolve()): digest(Path(__file__)),
        str(HERE/'solvers.gpr'): digest(HERE/'solvers.gpr'),
        str(ROOT/'tools/guarded.py'): digest(ROOT/'tools/guarded.py'),
        'frozen_project_sha256': digest(out/'solvers.gpr')}, indent=2)+'\n')
    env = environment()
    env['SOLVERS_BUILD_ROOT'] = str(out/'build')
    env['SOLVERS_MODE'] = args.mode
    versions = {name: subprocess.check_output([name, '--version'], env=env, text=True).splitlines()[0] for name in ['gprbuild', 'gnatprove']}
    (out/'tools.json').write_text(json.dumps(versions, indent=2)+'\n')
    records = []
    def run(command, label):
        command = [sys.executable, str(ROOT/'tools/guarded.py'),
                   '--cap-mb', '3800', '--min-free-mb', '12000', '--timeout', str(args.wall_timeout), '--', *command]
        start = time.monotonic()
        p = subprocess.run(command, env=env, text=True, capture_output=True)
        (out/(label+'.log')).write_text(p.stdout+p.stderr)
        return p, dict(label=label, command=command, code=p.returncode,
                      seconds=time.monotonic()-start)
    if args.phase == 'build':
        p, rec = run(['gprbuild', '-P', str(out/'solvers.gpr'), '-j1'], 'build')
        binary = out/'build'/args.mode/'bin/solvers_probe'
        if p.returncode:
            print((p.stdout+p.stderr)[-5000:])
            raise SystemExit(p.returncode)
        rec.update(binary=str(binary), binary_sha256=digest(binary), mode=args.mode)
        edge_binary = binary.with_name('cholesky_edges')
        edge, edge_record = run([str(edge_binary)], 'cholesky-edges')
        edge_record.update(binary_sha256=digest(edge_binary), output=edge.stdout.strip())
        rec['cholesky_edges'] = edge_record
        if edge.returncode:
            print(edge.stdout+edge.stderr)
            raise SystemExit(edge.returncode)
        assert frozen_unchanged(), 'frozen build inputs changed'
        rec.update(snapshot_hashes_unchanged=True, checkout_matches_snapshot=checkout_matches())
        (out/'binary.json').write_text(json.dumps(rec, indent=2)+'\n')
        print(binary)
        return
    targets = []
    for unit in ([args.unit] if args.unit else UNITS):
        if args.phase == 'whole':
            targets.append((unit, None, unit))
        else:
            # Definitions in the spec, separately implemented bodies in .adb.
            body = (HERE/'src'/f'{unit}.adb').read_text()
            for suffix in ['ads', 'adb']:
                for n, line in enumerate((HERE/'src'/f'{unit}.{suffix}').read_text().splitlines(), 1):
                    m = re.match(r'\s*(function|procedure) (\w+)\b', line)
                    if not m or (args.only and m[2] != args.only):
                        continue
                    if suffix == 'ads' and re.search(r'\b(?:function|procedure) '+m[2]+r'\b', body):
                        continue
                    targets.append((unit, f'{unit}.{suffix}:{n}', m[2]))
    ok = True
    if not targets:
        ap.error('no subprogram matched the requested unit/name')
    for unit, limit, label in targets:
        directory = out/'build'/args.mode/'obj/gnatprove'
        for report in directory.glob('*.spark'):
            report.unlink()
        command = ['gnatprove', '-f', '-P', str(out/'solvers.gpr'), '-u', unit+'.ads',
            '--prover=cvc5,z3,altergo', f'--timeout={args.timeout}', '--memlimit=800',
            '--steps=0', '--proof='+args.proof, '-j1', '--checks-as-errors=on',
            '--warnings=continue', '--report=all', '--counterexamples=off']
        if args.no_inlining:
            command.append('--no-inlining')
        if limit:
            command.append('--limit-subp='+limit)
        label = args.phase+'-'+label
        p, rec = run(command, label)
        rec.update(unit=unit, limit=limit)
        report = directory/(unit+'.spark')
        if report.exists():
            d = json.loads(report.read_text())
            shutil.copyfile(report, out/(label+'.spark.json'))
            diagnostics = [x for s in ['proof', 'flow', 'warn_error'] for x in d.get(s, [])]
            rec.update(checks=sum(x.get('severity') == 'info'
                for s in ['proof', 'flow'] for x in d.get(s, [])),
                open=[x for x in diagnostics if x.get('severity') not in ['info', 'warning']],
                warnings=[x for x in diagnostics if x.get('severity') == 'warning'])
            if not limit:
                rec['complete_coverage'] = (
                    not d['skip_proof'] and not d['skip_flow_proof'] and not d['pragma_assume']
                    and all(v == 'all' for v in d['spark'].values())
                    and d['progress'] == 'PROGRESS_PROOF'
                    and d['stop_reason'] == 'STOP_REASON_NONE')
                rec['entities'] = sorted(d['entities'][k]['name']
                    for k, v in d['spark'].items() if v == 'all')
                expected = {m.lower() for suffix in ['ads', 'adb']
                    for m in re.findall(r'\b(?:function|procedure)\s+(\w+)',
                        (out/'src'/f'{unit}.{suffix}').read_text())}
                proved = {name.split('.')[-1].lower() for name in rec['entities']}
                rec['missing_entities'] = sorted(expected-proved)
                rec['complete_coverage'] = rec['complete_coverage'] and not rec['missing_entities']
        # Retain these diagnostics in the evidence. They describe the existing
        # Ada runtime sqrt boundary and controlled unfolding of terminating
        # ghost recurrences; neither is an assumed application theorem.
        reviewed = []
        for warning in rec.get('warnings', []):
            # Both diagnostics say that recursive bodies/contracts may be
            # unavailable to the prover, reducing usable hypotheses. They
            # do not assume a result. Keep them in the receipt and require
            # proof of the recursive body, termination and unfolding lemma.
            if (warning.get('file') in ('mj-constraint_solvers-reduction_models.ads',
                                       'mj-constraint_solvers-dense_cholesky.ads',
                                       'mj-constraint_solvers-jacobians.ads',
                                       'mj-constraint_solvers-jacobian_transpose.ads')
                    and warning.get('rule') in ('numeric-variant', 'contracts-recursive')):
                reviewed.append(warning)
            if unit in ('mj-constraint_solvers-cholesky', 'mj-constraint_solvers-dense_cholesky', 'mj-constraint_solvers-cholesky_updates',
                        'mj-constraint_solvers-sparse_cholesky') and (
                warning.get('rule') == 'numeric-variant'
                or (warning.get('rule') == 'imprecise-call'
                    and warning.get('message', {}).get('arguments') == ['Sqrt'])
            ):
                reviewed.append(warning)
        rec['reviewed_warnings'] = reviewed
        rec['unreviewed_warnings'] = [w for w in rec.get('warnings', []) if w not in reviewed]
        passed = (p.returncode == 0 and 'open' in rec and not rec['open']
                  and not rec['unreviewed_warnings'] and (limit or rec.get('complete_coverage')))
        rec['passed'] = bool(passed)
        ok = bool(passed) and ok
        records.append(rec)
        (out/'results.json').write_text(json.dumps(records, indent=2)+'\n')
        print(label, 'passed' if passed else 'OPEN', rec.get('checks'), flush=True)
        if not passed:
            print('\n'.join(x for x in (p.stdout+p.stderr).splitlines()
                            if re.search(r'error:|medium:|high:|low:', x))[-3500:], flush=True)
            if 'open' not in rec:
                raise SystemExit(p.returncode or 1)
    assert frozen_unchanged(), 'frozen proof inputs changed'
    (out/'acceptance.json').write_text(json.dumps(dict(passed=ok, phase=args.phase,
        snapshot_hashes_unchanged=True, checkout_matches_snapshot=checkout_matches()), indent=2)+'\n')
    raise SystemExit(0 if ok else 1)

if __name__ == '__main__':
    main()
