from pathlib import Path
import subprocess,json,time,hashlib
root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');out=Path('/var/tmp/sparkling-support-publish-r143-solvers-20261024')
py='/var/tmp/sparkling-movement315-env/bin/python'; tests=root/'experimental/constraint-solvers-candidate/tests';binary=out/'build/validation/bin/solvers_probe'
jobs=[('dense',[py,str(tests/'differential.py'),'--binary',str(binary),'--out',str(out/'dense.json'),'--reference-version','3.15.0']),('sparse',[py,str(tests/'differential.py'),'--binary',str(binary),'--out',str(out/'sparse.json'),'--reference-version','3.15.0','--jacobian','sparse']),('native',[py,str(tests/'differential.py'),'--binary',str(binary),'--out',str(out/'native.json'),'--reference-version','3.15.0','--jacobian','sparse','--native-jacobian']),('robustness',[py,str(tests/'robustness.py'),'--binary',str(binary),'--out',str(out/'robustness.json')]),('cholesky-edges',[str(binary.with_name('cholesky_edges'))])]
records=[]
for name,cmd in jobs:
 guarded=[py,str(root/'tools/guarded.py'),'--cap-mb','3000','--timeout','600','--',*cmd];start=time.monotonic()
 with (out/(name+'.log')).open('w') as f: r=subprocess.run(guarded,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=guarded,exit=r.returncode,seconds=time.monotonic()-start));(out/'regression-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:print((out/(name+'.log')).read_text()[-5000:]);raise SystemExit(r.returncode)
print('all regressions passed',flush=True)
