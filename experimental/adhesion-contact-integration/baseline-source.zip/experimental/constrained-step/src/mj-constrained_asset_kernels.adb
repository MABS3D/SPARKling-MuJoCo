package body MJ.Constrained_Asset_Kernels with SPARK_Mode is
   function Promote (X : Float) return Real is (Real (X));
   function Vertex_Index (First, Local, Length : Natural) return Natural is
     (First + Local);
   function Graph_Span (Vertices, Faces : Natural) return Natural is
     (2 + 3 * Vertices + 6 * Faces);
end MJ.Constrained_Asset_Kernels;
