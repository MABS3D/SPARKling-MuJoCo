--  Publish only already admitted buffers. All failure paths stay before this
--  boundary, so position, velocity, activation and time advance together.
package MJ.Data.Step_Publication with SPARK_Mode is
   procedure Publish
     (Qpos, Qvel : in out Real_Array; Activation : in out State_Vector;
      Clock : in out Nonneg_Tier0;
      Next_Qpos, Next_Qvel : Real_Array; Next_Activation : State_Vector;
      Next_Time : Nonneg_Tier0)
     with Global => null,
       Pre => Qpos'First = Next_Qpos'First and then Qpos'Last = Next_Qpos'Last
         and then Qvel'First = Next_Qvel'First and then Qvel'Last = Next_Qvel'Last
         and then Activation'First = Next_Activation'First
         and then Activation'Last = Next_Activation'Last;
   pragma Postcondition
     (Static => Qpos = Next_Qpos and then Qvel = Next_Qvel
       and then Activation = Next_Activation and then Clock = Next_Time);
   pragma Inline_Always (Publish);
end MJ.Data.Step_Publication;
