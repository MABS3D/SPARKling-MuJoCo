package body MJ.Data.Step_Publication with SPARK_Mode is
   procedure Publish
     (Qpos, Qvel : in out Real_Array; Activation : in out State_Vector;
      Clock : in out Nonneg_Tier0;
      Next_Qpos, Next_Qvel : Real_Array; Next_Activation : State_Vector;
      Next_Time : Nonneg_Tier0)
   is
   begin
      Qpos := Next_Qpos;
      Qvel := Next_Qvel;
      Activation := Next_Activation;
      Clock := Next_Time;
   end Publish;
end MJ.Data.Step_Publication;
