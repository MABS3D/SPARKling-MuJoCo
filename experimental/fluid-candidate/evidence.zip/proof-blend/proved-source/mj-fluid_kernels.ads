with MJ.Types; use MJ.Types;
with MJ.Smooth_Math; use MJ.Smooth_Math;
with Ada.Numerics;
with MJ.Fluid_Box;
with MJ.Spatial_Kernels;
package MJ.Fluid_Kernels with SPARK_Mode is
   type Motion_Array is array (Natural range <>) of MJ.Spatial_Kernels.Motion;
   No_Motions : constant Motion_Array := [1 .. 0 => [others => 0.0]];
   Pi : constant Real := Ada.Numerics.Pi;
   subtype Dimension is Real range 0.0 .. 1.0e14;
   subtype Rate is Real range -1.0e12 .. 1.0e12;
   subtype Fluid_Value is Real range -1.0e110 .. 1.0e110;
   subtype Wrench is MJ.Fluid_Box.Wrench;
   use type MJ.Fluid_Box.Wrench;
   subtype Box_Coefficients is MJ.Fluid_Box.Coefficients;
   type Ellipsoid_Cache is record
      Volume, Dmax, Amax, Lin_Visc, Ang_Visc : Real := 0.0;
      Surface, Angular_Moment : Vector := Zero;
   end record;
   type Ellipsoid_Parameters is record
      Size : Vector := Zero;
      Interaction, Blunt, Slender, Angular, Kutta, Magnus : Nonneg_Tier0 := 0.0;
      Virtual_Mass, Virtual_Inertia : Vector := Zero;
   end record;
   function Fourth (X : Dimension) return Real is ((X*X)*(X*X))
     with Global => null, Post => Fourth'Result in 0.0 .. 2.0e56;
   function Prepare_Box (Box : Vector; Density, Viscosity : Nonneg_Tier0) return Box_Coefficients
     renames MJ.Fluid_Box.Prepare;
   function Apply_Box (C : Box_Coefficients; Linear, Angular : Vector) return Wrench
     renames MJ.Fluid_Box.Evaluate;
   function Prepare_Ellipsoid (P : Ellipsoid_Parameters) return Ellipsoid_Cache
     with Global => null;
   subtype Blend_Value is Real range -1.0e250 .. 1.0e250;
   subtype Blend_Input is Real range -1.0e100 .. 1.0e100;
   function Blend_Force (Added, Magnus, Kutta, Drag : Blend_Input;
                         Speed : Rate; Interaction : Nonneg_Tier0) return Blend_Value
     with Global => null,
     Post => Blend_Force'Result = (Added + (Magnus+Kutta-Drag*Speed))*Interaction;
   function Blend_Torque (Added, Drag : Blend_Input; Speed : Rate;
                          Interaction : Nonneg_Tier0) return Blend_Value
     with Global => null,
     Post => Blend_Torque'Result = (Added-Drag*Speed)*Interaction;
   function Ellipsoid (P : Ellipsoid_Parameters; Cache : Ellipsoid_Cache; Density, Viscosity : Nonneg_Tier0;
                        Linear, Angular : Vector) return Wrench
     with Global => null,
     Pre => Bounded (Linear, 1.0e12) and then Bounded (Angular, 1.0e12)
       and then (for all X of P.Size => X in Nonneg_Tier0)
       and then Bounded (P.Virtual_Mass, Max_Val) and then Bounded (P.Virtual_Inertia, Max_Val);
   --  Metadata is frozen at Create, so geometric quantities are computed once.
   type Element is record
      Body_Id : Natural := 0;
      Position : Vector := Zero;
      Rotation : Matrix := Identity;
      Is_Ellipsoid : Boolean := False;
      Box : Vector := Zero;
      Parameters : Ellipsoid_Parameters;
      Box_Data : Box_Coefficients;
      Ellipsoid_Data : Ellipsoid_Cache;
   end record;
   type Element_Array is array (Natural range <>) of Element;
   type Element_Access is access Element_Array;
end MJ.Fluid_Kernels;
