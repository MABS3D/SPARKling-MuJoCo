# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-bep45hcm/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Momentum` | `mj-fluid_added_mass.adb:2` | [completed_no_unproved](logs/mj-fluid_added_mass__momentum__adb_2.log) | 6 | 0 | 0 | 12.6 |
| `Cross_Term` | `mj-fluid_added_mass.adb:6` | [completed_no_unproved](logs/mj-fluid_added_mass__cross_term__adb_6.log) | 8 | 0 | 0 | 8.5 |
| `Evaluate` | `mj-fluid_added_mass.adb:10` | [proof_timeout](logs/mj-fluid_added_mass__evaluate__adb_10.log) | 0 | 0 | 0 | 120.2 |

## Diagnostics

