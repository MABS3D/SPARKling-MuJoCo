# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-xcfsbx79/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Viscous_Linear` | `mj-fluid_box.adb:2` | [completed_no_unproved](logs/mj-fluid_box__viscous_linear__adb_2.log) | 6 | 0 | 0 | 6.9 |
| `Viscous_Angular` | `mj-fluid_box.adb:6` | [completed_no_unproved](logs/mj-fluid_box__viscous_angular__adb_6.log) | 10 | 0 | 0 | 11.9 |
| `Drag_Linear` | `mj-fluid_box.adb:10` | [completed_no_unproved](logs/mj-fluid_box__drag_linear__adb_10.log) | 8 | 0 | 0 | 5.2 |
| `Drag_Angular` | `mj-fluid_box.adb:14` | [completed_no_unproved](logs/mj-fluid_box__drag_angular__adb_14.log) | 22 | 0 | 0 | 6.2 |
| `Component` | `mj-fluid_box.adb:21` | [completed_no_unproved](logs/mj-fluid_box__component__adb_21.log) | 18 | 0 | 0 | 6.9 |
| `Prepare` | `mj-fluid_box.adb:28` | [completed_no_unproved](logs/mj-fluid_box__prepare__adb_28.log) | 50 | 0 | 0 | 66.6 |
| `Evaluate` | `mj-fluid_box.adb:36` | [completed_no_unproved](logs/mj-fluid_box__evaluate__adb_36.log) | 17 | 0 | 0 | 31.9 |

## Diagnostics

