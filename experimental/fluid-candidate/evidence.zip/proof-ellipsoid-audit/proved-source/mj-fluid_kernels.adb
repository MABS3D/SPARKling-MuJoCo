with Ada.Numerics.Long_Elementary_Functions;
package body MJ.Fluid_Kernels with SPARK_Mode is
   function Linear_Viscous (Diameter : Dimension; Viscosity : Nonneg_Tier0; V : Rate) return Viscous_Value is
   begin
      return (-3.0*Pi*Diameter*Viscosity)*V;
   end Linear_Viscous;
   function Angular_Viscous (Diameter : Dimension; Viscosity : Nonneg_Tier0; V : Rate) return Viscous_Value is
   begin
      return (-Pi*Diameter*Diameter*Diameter*Viscosity)*V;
   end Angular_Viscous;
   function Linear_Drag (Side1, Side2 : Dimension; Density : Nonneg_Tier0; V : Rate) return Drag_Value is
      subtype Area_Coefficient is Real range 0.0 .. 1.0e40;
      subtype Once_Velocity is Real range 0.0 .. 1.0e53;
      A : constant Area_Coefficient := 0.5*Density*Side1*Side2;
      B : constant Once_Velocity := A*abs(V);
   begin
      return B*V;
   end Linear_Drag;
   function Angular_Drag (Side0, Side1, Side2 : Dimension; Density : Nonneg_Tier0; V : Rate) return Drag_Value is
      subtype Fourth_Value is Real range 0.0 .. 2.0e56;
      subtype Sum_Value is Real range 0.0 .. 5.0e56;
      subtype Coefficient is Real range 0.0 .. 1.0e82;
      subtype Once_Velocity is Real range 0.0 .. 2.0e94;
      A1 : constant Fourth_Value := Side1*Side1*Side1*Side1;
      A2 : constant Fourth_Value := Side2*Side2*Side2*Side2;
      A : constant Sum_Value := A1+A2;
      B : constant Coefficient := Density*Side0*A;
      C : constant Once_Velocity := B*abs(V);
   begin
      return C*V/64.0;
   end Angular_Drag;
   function Box_Linear (Diameter, Side1, Side2 : Dimension;
                        Density, Viscosity : Nonneg_Tier0; V : Rate) return Fluid_Value is
      F : constant Viscous_Value := (if Viscosity > 0.0 then Linear_Viscous(Diameter,Viscosity,V) else 0.0);
      Q : constant Drag_Value := (if Density > 0.0 then Linear_Drag(Side1,Side2,Density,V) else 0.0);
   begin
      return F-Q;
   end Box_Linear;
   function Box_Angular (Diameter, Side0, Side1, Side2 : Dimension;
                         Density, Viscosity : Nonneg_Tier0; V : Rate) return Fluid_Value is
      F : constant Viscous_Value := (if Viscosity > 0.0 then Angular_Viscous(Diameter,Viscosity,V) else 0.0);
      Q : constant Drag_Value := (if Density > 0.0 then Angular_Drag(Side0,Side1,Side2,Density,V) else 0.0);
   begin
      return F-Q;
   end Box_Angular;
   function Inertia_Box (Box : Vector; Density, Viscosity : Nonneg_Tier0;
                         Linear, Angular : Vector) return Wrench is
      Diameter : constant Dimension := (Box(0)+Box(1)+Box(2))/3.0;
   begin
      return (Force => [Box_Linear(Diameter,Box(1),Box(2),Density,Viscosity,Linear(0)),
                        Box_Linear(Diameter,Box(0),Box(2),Density,Viscosity,Linear(1)),
                        Box_Linear(Diameter,Box(0),Box(1),Density,Viscosity,Linear(2))],
              Torque => [Box_Angular(Diameter,Box(0),Box(1),Box(2),Density,Viscosity,Angular(0)),
                         Box_Angular(Diameter,Box(1),Box(0),Box(2),Density,Viscosity,Angular(1)),
                         Box_Angular(Diameter,Box(2),Box(0),Box(1),Density,Viscosity,Angular(2))]);
   end Inertia_Box;

   function Ellipsoid (P : Ellipsoid_Parameters; Density, Viscosity : Nonneg_Tier0;
                        Linear, Angular : Vector) return Wrench is
      use Ada.Numerics.Long_Elementary_Functions;
      S : Vector renames P.Size;
      Volume : constant Real := 4.0/3.0*Pi*S(0)*S(1)*S(2);
      Dmax : constant Real := Real'Max (Real'Max(S(0),S(1)),S(2));
      Dmin : constant Real := Real'Min (Real'Min(S(0),S(1)),S(2));
      Dmid : constant Real := S(0)+S(1)+S(2)-Dmax-Dmin;
      Amax : constant Real := Pi*Dmax*Dmid;
      Speed : constant Real := Sqrt (Dot (Linear, Linear));
      Inv_Speed : constant Real := (if Speed > Min_Val then 1.0/Speed else 0.0);
      Inv_Dmax : constant Real := (if Dmax > Min_Val then 1.0/Dmax else 0.0);
      V : constant Vector := Inv_Speed * Linear;
      SN : constant Vector := Inv_Dmax * S;
      Araw : constant Real := (SN(1)*SN(2))*(SN(1)*SN(2));
      Braw : constant Real := (SN(2)*SN(0))*(SN(2)*SN(0));
      Craw : constant Real := (SN(0)*SN(1))*(SN(0)*SN(1));
      PN : constant Real := Araw*V(0)*V(0) + Braw*V(1)*V(1) + Craw*V(2)*V(2);
      Inv_PN : constant Real := (if PN > Min_Val then 1.0/PN else 0.0);
      A : constant Real := Araw*Inv_PN;
      B : constant Real := Braw*Inv_PN;
      C : constant Real := Craw*Inv_PN;
      PD : constant Real := A*A*V(0)*V(0) + B*B*V(1)*V(1) + C*C*V(2)*V(2);
      Aproj : constant Real := Pi*Dmax*Dmax*Sqrt (PN*PD);
      Normal : constant Vector := [A*V(0),B*V(1),C*V(2)];
      Cos_Alpha : constant Real := (if PD > Min_Val then 1.0/PD else 0.0);
      Magnus : constant Vector := (P.Magnus*Density*Volume) * Cross (Angular, Linear);
      Circulation : constant Vector := (P.Kutta*Density*Cos_Alpha*Aproj) * Cross (Normal, Linear);
      Kutta : constant Vector := Cross (Circulation, Linear);
      Diameter : constant Real := 2.0/3.0*(S(0)+S(1)+S(2));
      Lin_Visc : constant Real := 3.0*Pi*Diameter;
      Ang_Visc : constant Real := Pi*Diameter*Diameter*Diameter;
      Imax : constant Real := 8.0/15.0*Pi*Dmid*Fourth(Dmax);
      Mom, LM, AM : Vector;
      R : Wrench;
      Drag_Lin : constant Real := Viscosity*Lin_Visc + Density*Speed*
        (Aproj*P.Blunt + P.Slender*(Amax-Aproj));
      Drag_Ang : Real;
   begin
      for I in Axis loop
         declare
            II : constant Real := 8.0/15.0*Pi*S(I)*Fourth(Real'Max(S((I+1) mod 3),S((I+2) mod 3)));
         begin
            Mom(I) := Angular(I)*(P.Angular*II + P.Slender*(Imax-II));
            LM(I) := Density*P.Virtual_Mass(I)*Linear(I);
            AM(I) := Density*P.Virtual_Inertia(I)*Angular(I);
         end;
      end loop;
      Drag_Ang := Viscosity*Ang_Visc + Density*Sqrt (Dot (Mom,Mom));
      R.Force := Cross (LM, Angular);
      R.Torque := Cross (LM, Linear) + Cross (AM, Angular);
      for I in Axis loop
         R.Torque(I) := (R.Torque(I) - Drag_Ang*Angular(I))*P.Interaction;
         R.Force(I) := (R.Force(I) + (Magnus(I)+Kutta(I)-Drag_Lin*Linear(I)))*P.Interaction;
      end loop;
      return R;
   end Ellipsoid;
end MJ.Fluid_Kernels;
