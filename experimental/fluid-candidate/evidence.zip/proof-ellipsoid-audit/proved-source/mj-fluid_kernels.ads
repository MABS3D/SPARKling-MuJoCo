with MJ.Types; use MJ.Types;
with MJ.Smooth_Math; use MJ.Smooth_Math;
with Ada.Numerics;
package MJ.Fluid_Kernels with SPARK_Mode is
   Pi : constant Real := Ada.Numerics.Pi;
   subtype Dimension is Real range 0.0 .. 1.0e14;
   subtype Rate is Real range -1.0e12 .. 1.0e12;
   subtype Fluid_Value is Real range -1.0e110 .. 1.0e110;
   type Wrench is record
      Force, Torque : Vector := Zero;
   end record;
   type Ellipsoid_Parameters is record
      Size : Vector := Zero;
      Interaction, Blunt, Slender, Angular, Kutta, Magnus : Nonneg_Tier0 := 0.0;
      Virtual_Mass, Virtual_Inertia : Vector := Zero;
   end record;
   function Fourth (X : Dimension) return Real is ((X*X)*(X*X))
     with Global => null, Post => Fourth'Result in 0.0 .. 2.0e56;
   subtype Viscous_Value is Real range -1.0e67 .. 1.0e67;
   subtype Drag_Value is Real range -1.0e108 .. 1.0e108;
   function Linear_Viscous (Diameter : Dimension; Viscosity : Nonneg_Tier0; V : Rate) return Viscous_Value
     with Global => null, Post => Linear_Viscous'Result = (-3.0*Pi*Diameter*Viscosity)*V;
   function Angular_Viscous (Diameter : Dimension; Viscosity : Nonneg_Tier0; V : Rate) return Viscous_Value
     with Global => null, Post => Angular_Viscous'Result = (-Pi*Diameter*Diameter*Diameter*Viscosity)*V;
   function Linear_Drag (Side1, Side2 : Dimension; Density : Nonneg_Tier0; V : Rate) return Drag_Value
     with Global => null, Post => Linear_Drag'Result = 0.5*Density*Side1*Side2*abs(V)*V;
   function Angular_Drag (Side0, Side1, Side2 : Dimension; Density : Nonneg_Tier0; V : Rate) return Drag_Value
     with Global => null, Post => Angular_Drag'Result = Density*Side0*
       (Side1*Side1*Side1*Side1 + Side2*Side2*Side2*Side2)*abs(V)*V/64.0;
   function Box_Linear (Diameter, Side1, Side2 : Dimension;
                        Density, Viscosity : Nonneg_Tier0; V : Rate) return Fluid_Value
     with Global => null,
     Post => Box_Linear'Result =
       (if Viscosity > 0.0 then Linear_Viscous (Diameter,Viscosity,V) else 0.0)
       - (if Density > 0.0 then Linear_Drag (Side1,Side2,Density,V) else 0.0);
   function Box_Angular (Diameter, Side0, Side1, Side2 : Dimension;
                         Density, Viscosity : Nonneg_Tier0; V : Rate) return Fluid_Value
     with Global => null,
     Post => Box_Angular'Result =
       (if Viscosity > 0.0 then Angular_Viscous (Diameter,Viscosity,V) else 0.0)
       - (if Density > 0.0 then Angular_Drag (Side0,Side1,Side2,Density,V) else 0.0);
   function Box_Model (Box : Vector; Density, Viscosity : Nonneg_Tier0;
                       Linear, Angular : Vector) return Wrench is
     (Force => [Box_Linear ((Box(0)+Box(1)+Box(2))/3.0,Box(1),Box(2),Density,Viscosity,Linear(0)),
                Box_Linear ((Box(0)+Box(1)+Box(2))/3.0,Box(0),Box(2),Density,Viscosity,Linear(1)),
                Box_Linear ((Box(0)+Box(1)+Box(2))/3.0,Box(0),Box(1),Density,Viscosity,Linear(2))],
      Torque => [Box_Angular ((Box(0)+Box(1)+Box(2))/3.0,Box(0),Box(1),Box(2),Density,Viscosity,Angular(0)),
                 Box_Angular ((Box(0)+Box(1)+Box(2))/3.0,Box(1),Box(0),Box(2),Density,Viscosity,Angular(1)),
                 Box_Angular ((Box(0)+Box(1)+Box(2))/3.0,Box(2),Box(0),Box(1),Density,Viscosity,Angular(2))])
     with Ghost => Static, Global => null,
     Pre => (for all X of Box => X in Dimension) and then
       (Box(0)+Box(1)+Box(2))/3.0 in Dimension
       and then Bounded (Linear, 1.0e12) and then Bounded (Angular, 1.0e12);
   function Inertia_Box (Box : Vector; Density, Viscosity : Nonneg_Tier0;
                         Linear, Angular : Vector) return Wrench
     with Global => null,
     Pre => (for all X of Box => X in Dimension) and then
       (Box(0)+Box(1)+Box(2))/3.0 in Dimension
       and then Bounded (Linear, 1.0e12) and then Bounded (Angular, 1.0e12),
     Post => (Static => Inertia_Box'Result = Box_Model (Box,Density,Viscosity,Linear,Angular));
   function Ellipsoid (P : Ellipsoid_Parameters; Density, Viscosity : Nonneg_Tier0;
                        Linear, Angular : Vector) return Wrench
     with Global => null,
     Pre => Bounded (Linear, 1.0e12) and then Bounded (Angular, 1.0e12)
       and then (for all X of P.Size => X in Nonneg_Tier0)
       and then Bounded (P.Virtual_Mass, Max_Val) and then Bounded (P.Virtual_Inertia, Max_Val);
   --  Metadata is frozen at Create, so geometric quantities are computed once.
   type Element is record
      Body_Id : Natural := 0;
      Position : Vector := Zero;
      Rotation : Matrix := Identity;
      Is_Ellipsoid : Boolean := False;
      Box : Vector := Zero;
      Parameters : Ellipsoid_Parameters;
   end record;
   type Element_Array is array (Natural range <>) of Element;
   type Element_Access is access Element_Array;
end MJ.Fluid_Kernels;
