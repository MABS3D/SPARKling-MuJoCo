
// Extracts: Copyright 2021 DeepMind Technologies Limited.
// Licensed under the Apache License, Version 2.0.
// See https://www.apache.org/licenses/LICENSE-2.0
// Distributed without warranties or conditions of any kind.
#include <cmath>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <mujoco/mujoco.h>
#include "engine/engine_macro.h"
#include "engine/engine_inline.h"
#include "engine/engine_util_blas.h"
#include "engine/engine_util_errmem.h"
#include "engine/engine_util_spatial.h"
#include "user/user_util.h"
struct Stencil2D {
  static constexpr int kNumEdges          = 3;
  static constexpr int kNumVerts          = 3;
  static constexpr int kNumFaces          = 2;
  static constexpr int edge[kNumEdges][2] = {
      {1, 2},
      {2, 0},
      {0, 1}
  };
  static constexpr int face[kNumVerts][2] = {
      {1, 2},
      {2, 0},
      {0, 1}
  };
  static constexpr int edge2face[kNumEdges][2] = {
      {1, 2},
      {2, 0},
      {0, 1}
  };
  int vertices[kNumVerts];
  int edges[kNumEdges];
};

struct Stencil3D {
  static constexpr int kNumEdges          = 6;
  static constexpr int kNumVerts          = 4;
  static constexpr int kNumFaces          = 3;
  static constexpr int edge[kNumEdges][2] = {
      {0, 1},
      {1, 2},
      {2, 0},
      {2, 3},
      {0, 3},
      {1, 3}
  };
  static constexpr int face[kNumVerts][3] = {
      {2, 1, 0},
      {0, 1, 3},
      {1, 2, 3},
      {2, 0, 3}
  };
  static constexpr int edge2face[kNumEdges][2] = {
      {2, 3},
      {1, 3},
      {2, 1},
      {1, 0},
      {0, 2},
      {0, 3}
  };
  int vertices[kNumVerts];
  int edges[kNumEdges];
};

double mjuu_dot3(const double* a, const double* b) {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

double mjuu_normvec(double* vec, const int n) {
  double nrm = 0;

  for (int i = 0; i < n; i++) { nrm += vec[i] * vec[i]; }
  if (nrm < mjEPS) { return 0; }

  nrm = sqrt(nrm);

  // don't normalize if nrm is within mjEPS of 1
  if (std::abs(nrm - 1) > mjEPS) {
    for (int i = 0; i < n; i++) { vec[i] /= nrm; }
  }

  return nrm;
}

void mjuu_crossvec(double* a, const double* b, const double* c) {
  a[0] = b[1]*c[2] - b[2]*c[1];
  a[1] = b[2]*c[0] - b[0]*c[2];
  a[2] = b[0]*c[1] - b[1]*c[0];
}

template <typename T> inline double ComputeVolume(const double* x, const int* v);

template <>
inline double ComputeVolume<Stencil2D>(const double* x, const int v[Stencil2D::kNumVerts]) {
  double        normal[3];
  const double* x0       = x + 3 * v[0];
  const double* x1       = x + 3 * v[1];
  const double* x2       = x + 3 * v[2];
  double        edge1[3] = {x1[0] - x0[0], x1[1] - x0[1], x1[2] - x0[2]};
  double        edge2[3] = {x2[0] - x0[0], x2[1] - x0[1], x2[2] - x0[2]};
  mjuu_crossvec(normal, edge1, edge2);
  return mjuu_normvec(normal, 3) / 2;
}

template <>
inline double ComputeVolume<Stencil3D>(const double* x, const int v[Stencil3D::kNumVerts]) {
  double        normal[3];
  const double* x0       = x + 3 * v[0];
  const double* x1       = x + 3 * v[1];
  const double* x2       = x + 3 * v[2];
  const double* x3       = x + 3 * v[3];
  double        edge1[3] = {x1[0] - x0[0], x1[1] - x0[1], x1[2] - x0[2]};
  double        edge2[3] = {x2[0] - x0[0], x2[1] - x0[1], x2[2] - x0[2]};
  double        edge3[3] = {x3[0] - x0[0], x3[1] - x0[1], x3[2] - x0[2]};
  mjuu_crossvec(normal, edge1, edge2);
  return mjuu_dot3(normal, edge3) / 6;
}

template <typename T> void ComputeBasis(double* b, const double* x, const int* v, const int* fl, const int* fr, double volume);

template <>
void inline ComputeBasis<Stencil2D>(double        basis[9],
                                    const double* x,
                                    const int     v[Stencil2D::kNumVerts],
                                    const int     faceL[Stencil2D::kNumFaces],
                                    const int     faceR[Stencil2D::kNumFaces],
                                    double        volume) {
  double basisL[3], basisR[3];
  double normal[3];

  const double* xL0       = x + 3 * v[faceL[0]];
  const double* xL1       = x + 3 * v[faceL[1]];
  const double* xR0       = x + 3 * v[faceR[0]];
  const double* xR1       = x + 3 * v[faceR[1]];
  double        edgesL[3] = {xL0[0] - xL1[0], xL0[1] - xL1[1], xL0[2] - xL1[2]};
  double        edgesR[3] = {xR1[0] - xR0[0], xR1[1] - xR0[1], xR1[2] - xR0[2]};

  mjuu_crossvec(normal, edgesR, edgesL);
  mjuu_normvec(normal, 3);
  mjuu_crossvec(basisL, normal, edgesL);
  mjuu_crossvec(basisR, edgesR, normal);

  // we use as basis the symmetrized tensor products of the edge normals of the
  // other two edges; this is shown in Weischedel "A discrete geometric view on
  // shear-deformable shell models" in the remark at the end of section 4.1;
  // equivalent to linear finite elements but in a coordinate-free formulation.

  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      basis[3 * i + j] = (basisL[i] * basisR[j] + basisR[i] * basisL[j]) / (8 * volume * volume);
    }
  }
}

template <>
void inline ComputeBasis<Stencil3D>(double        basis[9],
                                    const double* x,
                                    const int     v[Stencil3D::kNumVerts],
                                    const int     faceL[Stencil3D::kNumFaces],
                                    const int     faceR[Stencil3D::kNumFaces],
                                    double        volume) {
  const double* xL0       = x + 3 * v[faceL[0]];
  const double* xL1       = x + 3 * v[faceL[1]];
  const double* xL2       = x + 3 * v[faceL[2]];
  const double* xR0       = x + 3 * v[faceR[0]];
  const double* xR1       = x + 3 * v[faceR[1]];
  const double* xR2       = x + 3 * v[faceR[2]];
  double        edgesL[6] = {xL1[0] - xL0[0],
                             xL1[1] - xL0[1],
                             xL1[2] - xL0[2],
                             xL2[0] - xL0[0],
                             xL2[1] - xL0[1],
                             xL2[2] - xL0[2]};
  double        edgesR[6] = {xR1[0] - xR0[0],
                             xR1[1] - xR0[1],
                             xR1[2] - xR0[2],
                             xR2[0] - xR0[0],
                             xR2[1] - xR0[1],
                             xR2[2] - xR0[2]};

  double normalL[3], normalR[3];
  mjuu_crossvec(normalL, edgesL, edgesL + 3);
  mjuu_crossvec(normalR, edgesR, edgesR + 3);

  // we use as basis the symmetrized tensor products of the area normals of the
  // two faces not adjacent to the edge; this is the 3D equivalent to the basis
  // proposed in Weischedel "A discrete geometric view on shear-deformable shell
  // models" in the remark at the end of section 4.1. This is also equivalent to
  // linear finite elements but in a coordinate-free formulation.

  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      basis[3 * i + j] =
          (normalL[i] * normalR[j] + normalR[i] * normalL[j]) / (36 * 2 * volume * volume);
    }
  }
}

template <typename T>
void inline MetricTensor(
    double* metric, int idx, double mu, double la, const double basis[T::kNumEdges][9]) {
  double trE[T::kNumEdges]                 = {0};
  double trEE[T::kNumEdges * T::kNumEdges] = {0};
  double k[T::kNumEdges * T::kNumEdges];

  // compute first invariant i.e. trace(strain)
  for (int e = 0; e < T::kNumEdges; e++) {
    for (int i = 0; i < 3; i++) { trE[e] += basis[e][4 * i]; }
  }

  // compute second invariant i.e. trace(strain^2)
  for (int ed1 = 0; ed1 < T::kNumEdges; ed1++) {
    for (int ed2 = 0; ed2 < T::kNumEdges; ed2++) {
      for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
          trEE[T::kNumEdges * ed1 + ed2] += basis[ed1][3 * i + j] * basis[ed2][3 * j + i];
        }
      }
    }
  }

  // assembly of strain metric tensor
  for (int ed1 = 0; ed1 < T::kNumEdges; ed1++) {
    for (int ed2 = 0; ed2 < T::kNumEdges; ed2++) {
      k[T::kNumEdges * ed1 + ed2] = mu * trEE[T::kNumEdges * ed1 + ed2] + la * trE[ed2] * trE[ed1];
    }
  }

  // copy to triangular representation
  int id = 0;
  for (int ed1 = 0; ed1 < T::kNumEdges; ed1++) {
    for (int ed2 = ed1; ed2 < T::kNumEdges; ed2++) {
      metric[21 * idx + id++] = k[T::kNumEdges * ed1 + ed2];
    }
  }

  if (id != T::kNumEdges * (T::kNumEdges + 1) / 2) { mju_error("incorrect stiffness matrix size"); }
}

void mj_assignFriction(const mjModel* m, mjtNum* target, const mjtNum* source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    for (int i=0; i < 5; i++) {
      target[i] = mju_max(mjMINMU, m->opt.o_friction[i]);
    }
  } else {
    for (int i=0; i < 5; i++) {
      target[i] = mju_max(mjMINMU, source[i]);
    }
  }
}

void mj_assignRef(const mjModel* m, mjtNum* target, const mjtNum* source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    mju_copy(target, m->opt.o_solref, mjNREF);
  } else {
    mju_copy(target, source, mjNREF);
  }
}

void mj_assignImp(const mjModel* m, mjtNum* target, const mjtNum* source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    mju_copy(target, m->opt.o_solimp, mjNIMP);
  } else {
    mju_copy(target, source, mjNIMP);
  }
}

mjtNum mj_assignMargin(const mjModel* m, mjtNum source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    return m->opt.o_margin;
  } else {
    return source;
  }
}

void mju_makeFrame(mjtNum frame[9]) {
  mjtNum tmp[3];

  // normalize xaxis
  if (mju_normalize3(frame) < 0.5) {
    mjERROR("xaxis of contact frame undefined");
  }

  // if yaxis undefined, set yaxis to (0,1,0) if possible, otherwise (0,0,1)
  if (mju_dot3(frame+3, frame+3) < 0.25) {
    mju_zero3(frame+3);

    if (frame[1] < 0.5 && frame[1] > -0.5) {
      frame[4] = 1;
    } else {
      frame[5] = 1;
    }
  }

  // make yaxis orthogonal to xaxis
  mji_scl3(tmp, frame, mju_dot3(frame, frame+3));
  mji_subFrom3(frame+3, tmp);
  mju_normalize3(frame+3);

  // zaxis = cross(xaxis, yaxis)
  mji_cross(frame+6, frame, frame+3);
}

static void mj_contactParam(const mjModel* m, int* condim,
                            mjtNum* solref, mjtNum* solimp, mjtNum* friction,
                            mjtNum* adhesion, int g1, int g2, int f1, int f2) {
  mjtNum fri[3];

  // get parameters from geom1 or flex1
  int priority1 =           (f1 < 0) ? m->geom_priority[g1]     : m->flex_priority[f1];
  int condim1 =             (f1 < 0) ? m->geom_condim[g1]       : m->flex_condim[f1];
  mjtNum solmix1 =          (f1 < 0) ? m->geom_solmix[g1]       : m->flex_solmix[f1];
  const mjtNum* solref1 =   (f1 < 0) ? m->geom_solref+g1*mjNREF : m->flex_solref+f1*mjNREF;
  const mjtNum* solimp1 =   (f1 < 0) ? m->geom_solimp+g1*mjNIMP : m->flex_solimp+f1*mjNIMP;
  const mjtNum* friction1 = (f1 < 0) ? m->geom_friction+g1*3    : m->flex_friction+f1*3;
  mjtNum adhesion1 =        (f1 < 0) ? m->geom_adhesion[g1]     : 0;

  // get parameters from geom2 or flex2
  int priority2 =           (f2 < 0) ? m->geom_priority[g2]     : m->flex_priority[f2];
  int condim2 =             (f2 < 0) ? m->geom_condim[g2]       : m->flex_condim[f2];
  mjtNum solmix2 =          (f2 < 0) ? m->geom_solmix[g2]       : m->flex_solmix[f2];
  const mjtNum* solref2 =   (f2 < 0) ? m->geom_solref+g2*mjNREF : m->flex_solref+f2*mjNREF;
  const mjtNum* solimp2 =   (f2 < 0) ? m->geom_solimp+g2*mjNIMP : m->flex_solimp+f2*mjNIMP;
  const mjtNum* friction2 = (f2 < 0) ? m->geom_friction+g2*3    : m->flex_friction+f2*3;
  mjtNum adhesion2 =        (f2 < 0) ? m->geom_adhesion[g2]     : 0;

  // adhesion: each surface contributes its own attraction
  *adhesion = adhesion1 + adhesion2;

  // different priority: copy from item with higher priority
  if (priority1 > priority2) {
    *condim = condim1;
    mju_copy(solref, solref1, mjNREF);
    mju_copy(solimp, solimp1, mjNIMP);
    mju_copy(fri, friction1, 3);
    *adhesion = adhesion1;
  }
  else if (priority1 < priority2) {
    *condim = condim2;
    mju_copy(solref, solref2, mjNREF);
    mju_copy(solimp, solimp2, mjNIMP);
    mju_copy(fri, friction2, 3);
    *adhesion = adhesion2;
  }

  // same priority
  else {
    // condim: max
    *condim = mjMAX(condim1, condim2);

    // compute solver mix factor
    mjtNum mix;
    if (solmix1 >= mjMINVAL && solmix2 >= mjMINVAL) {
      mix = solmix1 / (solmix1 + solmix2);
    } else if (solmix1 < mjMINVAL && solmix2 < mjMINVAL) {
      mix = 0.5;
    } else if (solmix1 < mjMINVAL) {
      mix = 0.0;
    } else {
      mix = 1.0;
    }

    // reference standard: mix
    if (solref1[0] > 0 && solref2[0] > 0) {
      for (int i=0; i < mjNREF; i++) {
        solref[i] = mix*solref1[i] + (1-mix)*solref2[i];
      }
    }

    // reference direct: min
    else {
      for (int i=0; i < mjNREF; i++) {
        solref[i] = mju_min(solref1[i], solref2[i]);
      }
    }

    // impedance: mix
    for (int i=0; i < mjNIMP; i++) {
      solimp[i] = mix*solimp1[i] + (1-mix)*solimp2[i];
    }

    // friction: max
    for (int i=0; i < 3; i++) {
      fri[i] = mju_max(friction1[i], friction2[i]);
    }
  }

  // unpack 5D friction
  friction[0] = fri[0];
  friction[1] = fri[0];
  friction[2] = fri[1];
  friction[3] = fri[2];
  friction[4] = fri[2];

  // SHOULD NOT OCCUR
  if (*condim > 6 || *condim < 1) {
    mjERROR("Invalid condim value: %d", *condim);
  }
}

static void mj_setContact(const mjModel* m, mjContact* con,
                          int condim, mjtNum includemargin,
                          const mjtNum* solref, const mjtNum* solreffriction,
                          const mjtNum* solimp, const mjtNum* friction,
                          mjtNum adhesion) {
  // set parameters
  con->dim = condim;
  con->includemargin = includemargin;
  con->adhesion = adhesion;
  mj_assignRef(m, con->solref, solref);
  mj_assignRef(m, con->solreffriction, solreffriction);
  mj_assignImp(m, con->solimp, solimp);
  mj_assignFriction(m, con->friction, friction);

  // exclude in gap; adhesive contacts remain active in the gap, producing
  // rows with positive violation whose reference acceleration pulls (tether)
  con->exclude = (con->dist >= includemargin) && !adhesion;

  // in-gap adhesive contacts have no surface contact and therefore no
  // friction: reduce to normal-only rows (with tangential rows present, fast
  // slip would recruit normal force and brake tangential motion at a distance)
  if (adhesion && con->dist >= includemargin) {
    con->dim = 1;
  }

  // complete frame
  mju_makeFrame(con->frame);

  // clear fields that are computed later
  con->efc_address = -1;
  con->mu = 0;
  mju_zero(con->H, 36);

  // set deprecated fields
  con->geom1 = con->geom[0];
  con->geom2 = con->geom[1];
}
void put(double x) { std::cout << x << ' '; }
void params(int dim,const double* sr,const double* sfr,const double* si,const double* fr,double adhesion) {
  put(dim); for(int i=0;i<2;i++)put(sr[i]); for(int i=0;i<2;i++)put(sfr[i]);
  for(int i=0;i<5;i++)put(si[i]);for(int i=0;i<5;i++)put(fr[i]);put(adhesion);
}
template<class T> void geometry(const double* pos) {
  int v[4]={0,1,2,3}; double volume=ComputeVolume<T>(pos,v),basis[6][9]={};put(volume);
  for(int e=0;e<T::kNumEdges;e++) ComputeBasis<T>(basis[e],pos,v,T::face[T::edge2face[e][0]],T::face[T::edge2face[e][1]],volume);
  for(int e=0;e<6;e++)for(int j=0;j<9;j++)put(basis[e][j]);
}
int main(){
 std::cout << std::setprecision(17) << std::scientific;
 std::string line;
 while(std::getline(std::cin,line)) {
  std::istringstream in(line);int op;in>>op;
  if(op==1){
   int kind,damp,spring;double E,nu,thickness,rayleigh,volume,h,len,rest,velocity,basis[6][9],metric[21]={};
   in>>kind>>E>>nu>>thickness>>rayleigh>>volume>>h>>len>>rest>>velocity>>damp>>spring;
   for(int e=0;e<6;e++)for(int j=0;j<9;j++)in>>basis[e][j];
   double mu_base=E/(2*(1+nu));
   double la_base=E*nu/((1+nu)*(1-2*nu));
   double                             la_linear = E * nu / (1 + nu) / (1 - 2 * nu);
   double la_plane = E * nu / (1.0 - nu * nu);
   double young=E,poisson=nu;
   double D_bend = young * thickness * thickness * thickness / (12.0 * (1.0 - poisson * poisson));
   if(kind==1)thickness=4;
   double mu = E / (2 * (1 + nu)) * std::abs(volume) / 4 * thickness;
double la = E * nu / ((1 + nu) * (1 - 2 * nu)) * std::abs(volume) / 4 * thickness;
   double kD = damp && h > 0 ? rayleigh / h : 0; double dL = velocity * h;
   put(mu_base);put(la_base);put(la_linear);put(la_plane);put(D_bend);put(mu);put(la);put(kD);
   put(spring?len*len - rest*rest:0);put(kD?dL*(2*len - dL) * kD:0);
   if(kind==0)MetricTensor<Stencil2D>(metric,0,mu,la,basis);
   else MetricTensor<Stencil3D>(metric,0,mu,la,basis);
   for(int i=0;i<21;i++)put(metric[i]);
  }else if(op==3){
   int kind;double pos[12];in>>kind;for(double&x:pos)in>>x;
   if(kind==0)geometry<Stencil2D>(pos);else geometry<Stencil3D>(pos);
  }else if(op==2){
   mjModel m{};int kind[2],priority[2],dim[2];double mix[2],sr[4],si[10],fr[6],adh[2],margin[2],gap[2];
   for(int i=0;i<2;i++){
    in>>kind[i]>>priority[i]>>dim[i]>>mix[i];for(int j=0;j<2;j++)in>>sr[2*i+j];
    for(int j=0;j<5;j++)in>>si[5*i+j];for(int j=0;j<3;j++)in>>fr[3*i+j];in>>adh[i]>>margin[i]>>gap[i];
   }
   m.geom_priority=m.flex_priority=priority;m.geom_condim=m.flex_condim=dim;
   m.geom_solmix=m.flex_solmix=mix;m.geom_solref=m.flex_solref=sr;m.geom_solimp=m.flex_solimp=si;
   m.geom_friction=m.flex_friction=fr;m.geom_adhesion=adh;
   int pd,pe;double psr[2],psfr[2],psi[5],pfr[5],pa,pm,pg;
   in>>pe>>pd;for(double&x:psr)in>>x;for(double&x:psfr)in>>x;for(double&x:psi)in>>x;for(double&x:pfr)in>>x;in>>pa>>pm>>pg;
   int over;in>>over;for(double&x:m.opt.o_solref)in>>x;for(double&x:m.opt.o_solimp)in>>x;
   for(double&x:m.opt.o_friction)in>>x;in>>m.opt.o_margin;
   double distance;int self;in>>distance>>self;
   int cd;double csr[2],csi[5],cfr[5],ca,csfr[2]={};
   mj_contactParam(&m,&cd,csr,csi,cfr,&ca,kind[0]?-1:0,kind[1]?-1:1,kind[0]?0:-1,kind[1]?1:-1);
   params(cd,csr,csfr,csi,cfr,ca);
   double cm=margin[0]+margin[1],cg=gap[0]+gap[1];
   if(pe){cd=pd;for(int j=0;j<2;j++)csr[j]=psr[j];for(int j=0;j<5;j++){csi[j]=psi[j];cfr[j]=pfr[j];}ca=pa;cm=pm;cg=pg;
     if(psfr[0]||psfr[1])for(int j=0;j<2;j++)csfr[j]=psfr[j];}
   if(over)m.opt.enableflags|=mjENBL_OVERRIDE;
   cm=self?0:mj_assignMargin(&m,cm);
   mjContact con{};con.dist=distance;con.frame[2]=1;con.frame[3]=1;
   mj_setContact(&m,&con,cd,cm,csr,csfr,csi,cfr,ca);
   params(con.dim,con.solref,con.solreffriction,con.solimp,con.friction,con.adhesion);
   put(con.includemargin);put(cg);put(con.exclude);
  }else return 2;
  std::cout << '\n';
 }
}
