__attribute__((noipa)) void benchmark_barrier(void* input,void* output){__asm__ __volatile__("" : : "r"(input),"r"(output) : "memory");}
