from pathlib import Path
import argparse,hashlib,json,os,subprocess
import numpy as np
OUT=Path(__file__).parent; BASE=Path('/var/tmp/sparkling-materials-performance-20261001')
p=argparse.ArgumentParser();p.add_argument('build');p.add_argument('result');p.add_argument('--quick',action='store_true');a=p.parse_args()
dest=OUT/a.result;dest.mkdir(exist_ok=False)
BINS={'before':BASE/'bin/materials_benchmark','after':OUT/a.build/'bin/materials_benchmark','c':BASE/'c16-closed-benchmark'}
CASES=[('triangle','metric'),('tetrahedron','metric'),('laws','laws')]+[('contact-'+n,'contact') for n in ['equal','priority','direct','pair','override','flex','mixed']]
if a.quick:CASES=[x for x in CASES if x[0] in ['triangle','tetrahedron','contact-mixed']]
REPS=7 if a.quick else 21;TARGET=.035 if a.quick else .10;N=64;cpu=5
assert cpu in os.sched_getaffinity(0)
records=[];results=[];rng=np.random.default_rng(3141002)
def run(lang,case,mode,loops,label):
 command=['taskset','-c',str(cpu),str(BINS[lang]),mode,str(loops)]
 p=subprocess.run(command,input=(BASE/'fixtures'/f'{case}.txt').read_text(),capture_output=True,text=True,check=True,timeout=30)
 lines=p.stdout.splitlines();assert len(lines)==65
 seconds=float(lines[0]);values=np.array([np.fromstring(l,sep=' ') for l in lines[1:]])
 records.append(dict(case=case,lang=lang,label=label,command=command,loops=loops,calls=N*loops,seconds=seconds,ns=seconds*1e9/(loops*N)))
 if label=='correctness':(dest/f'{case}-{lang}.txt').write_text(p.stdout)
 return seconds,values
for case,mode in CASES:
 expected={lang:run(lang,case,mode,32,'correctness')[1] for lang in BINS}
 for lang in ['before','after']:assert np.array_equal(expected[lang].view(np.uint64),expected['c'].view(np.uint64)),(case,lang,'mismatch')
 times=[run(lang,case,mode,4096,'calibrate')[0] for lang in BINS]
 loops=max(4096,min(2000000,int(4096*TARGET/min(times))))
 samples={lang:[] for lang in BINS}
 for rep in range(REPS):
  order=['before','after','c'];order=order[rep%3:]+order[:rep%3]
  if rep%2:order.reverse()
  for lang in order:
   elapsed,values=run(lang,case,mode,loops,str(rep));assert np.array_equal(values.view(np.uint64),expected[lang].view(np.uint64))
   samples[lang].append(elapsed*1e9/(N*loops))
 arrays={k:np.array(v) for k,v in samples.items()}
 stats={k:dict(median_ns=float(np.median(v)),p05_ns=float(np.quantile(v,.05)),p95_ns=float(np.quantile(v,.95)),mad_ns=float(np.median(np.abs(v-np.median(v))))) for k,v in arrays.items()}
 ratios={}
 for label,den in [('after_before','before'),('after_c','c')]:
  r=arrays['after']/arrays[den];boot=[float(np.median(rng.choice(r,len(r),replace=True))) for _ in range(3000)]
  ratios[label]=dict(median=float(np.median(r)),ci95=np.quantile(boot,[.025,.975]).tolist())
 item=dict(case=case,loops=loops,repetitions=REPS,bit_identical=True,stats=stats,ratios=ratios);results.append(item)
 (dest/'raw.json').write_text(json.dumps(records,indent=2)+'\n');(dest/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print('%s before %.2f after %.2f C %.2f ns; after/C %.3f, after/before %.3f'%(case,stats['before']['median_ns'],stats['after']['median_ns'],stats['c']['median_ns'],ratios['after_c']['median'],ratios['after_before']['median']),flush=True)
summary=dict(passed=True,quick=a.quick,cpu=cpu,build=a.build,results=results,binaries={k:dict(path=str(v),sha256=hashlib.sha256(v.read_bytes()).hexdigest()) for k,v in BINS.items()},sources=json.loads((OUT/a.build/'sources.json').read_text()),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
