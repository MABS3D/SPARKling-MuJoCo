
// Extracts: Copyright 2021 DeepMind Technologies Limited.
// Licensed under the Apache License, Version 2.0.
// See https://www.apache.org/licenses/LICENSE-2.0
// Distributed without warranties or conditions of any kind.
#include <cmath>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <mujoco/mujoco.h>
#include "engine/engine_macro.h"
#include "engine/engine_inline.h"
#include "engine/engine_util_blas.h"
#include "engine/engine_util_errmem.h"
#include "engine/engine_util_spatial.h"
#include "user/user_util.h"
#include <cstring>
void mju_copy(mjtNum* res, const mjtNum* vec, int n) {
  memcpy(res, vec, n*sizeof(mjtNum));
}
mjtNum mju_min(mjtNum a, mjtNum b) {
  return a <= b ? a : b;
}
mjtNum mju_max(mjtNum a, mjtNum b) {
  return a >= b ? a : b;
}
struct Stencil2D {
  static constexpr int kNumEdges          = 3;
  static constexpr int kNumVerts          = 3;
  static constexpr int kNumFaces          = 2;
  static constexpr int edge[kNumEdges][2] = {
      {1, 2},
      {2, 0},
      {0, 1}
  };
  static constexpr int face[kNumVerts][2] = {
      {1, 2},
      {2, 0},
      {0, 1}
  };
  static constexpr int edge2face[kNumEdges][2] = {
      {1, 2},
      {2, 0},
      {0, 1}
  };
  int vertices[kNumVerts];
  int edges[kNumEdges];
};

struct Stencil3D {
  static constexpr int kNumEdges          = 6;
  static constexpr int kNumVerts          = 4;
  static constexpr int kNumFaces          = 3;
  static constexpr int edge[kNumEdges][2] = {
      {0, 1},
      {1, 2},
      {2, 0},
      {2, 3},
      {0, 3},
      {1, 3}
  };
  static constexpr int face[kNumVerts][3] = {
      {2, 1, 0},
      {0, 1, 3},
      {1, 2, 3},
      {2, 0, 3}
  };
  static constexpr int edge2face[kNumEdges][2] = {
      {2, 3},
      {1, 3},
      {2, 1},
      {1, 0},
      {0, 2},
      {0, 3}
  };
  int vertices[kNumVerts];
  int edges[kNumEdges];
};

double mjuu_dot3(const double* a, const double* b) {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

double mjuu_normvec(double* vec, const int n) {
  double nrm = 0;

  for (int i = 0; i < n; i++) { nrm += vec[i] * vec[i]; }
  if (nrm < mjEPS) { return 0; }

  nrm = sqrt(nrm);

  // don't normalize if nrm is within mjEPS of 1
  if (std::abs(nrm - 1) > mjEPS) {
    for (int i = 0; i < n; i++) { vec[i] /= nrm; }
  }

  return nrm;
}

void mjuu_crossvec(double* a, const double* b, const double* c) {
  a[0] = b[1]*c[2] - b[2]*c[1];
  a[1] = b[2]*c[0] - b[0]*c[2];
  a[2] = b[0]*c[1] - b[1]*c[0];
}

template <typename T> inline double ComputeVolume(const double* x, const int* v);

template <>
inline double ComputeVolume<Stencil2D>(const double* x, const int v[Stencil2D::kNumVerts]) {
  double        normal[3];
  const double* x0       = x + 3 * v[0];
  const double* x1       = x + 3 * v[1];
  const double* x2       = x + 3 * v[2];
  double        edge1[3] = {x1[0] - x0[0], x1[1] - x0[1], x1[2] - x0[2]};
  double        edge2[3] = {x2[0] - x0[0], x2[1] - x0[1], x2[2] - x0[2]};
  mjuu_crossvec(normal, edge1, edge2);
  return mjuu_normvec(normal, 3) / 2;
}

template <>
inline double ComputeVolume<Stencil3D>(const double* x, const int v[Stencil3D::kNumVerts]) {
  double        normal[3];
  const double* x0       = x + 3 * v[0];
  const double* x1       = x + 3 * v[1];
  const double* x2       = x + 3 * v[2];
  const double* x3       = x + 3 * v[3];
  double        edge1[3] = {x1[0] - x0[0], x1[1] - x0[1], x1[2] - x0[2]};
  double        edge2[3] = {x2[0] - x0[0], x2[1] - x0[1], x2[2] - x0[2]};
  double        edge3[3] = {x3[0] - x0[0], x3[1] - x0[1], x3[2] - x0[2]};
  mjuu_crossvec(normal, edge1, edge2);
  return mjuu_dot3(normal, edge3) / 6;
}

template <typename T> void ComputeBasis(double* b, const double* x, const int* v, const int* fl, const int* fr, double volume);

template <>
void inline ComputeBasis<Stencil2D>(double        basis[9],
                                    const double* x,
                                    const int     v[Stencil2D::kNumVerts],
                                    const int     faceL[Stencil2D::kNumFaces],
                                    const int     faceR[Stencil2D::kNumFaces],
                                    double        volume) {
  double basisL[3], basisR[3];
  double normal[3];

  const double* xL0       = x + 3 * v[faceL[0]];
  const double* xL1       = x + 3 * v[faceL[1]];
  const double* xR0       = x + 3 * v[faceR[0]];
  const double* xR1       = x + 3 * v[faceR[1]];
  double        edgesL[3] = {xL0[0] - xL1[0], xL0[1] - xL1[1], xL0[2] - xL1[2]};
  double        edgesR[3] = {xR1[0] - xR0[0], xR1[1] - xR0[1], xR1[2] - xR0[2]};

  mjuu_crossvec(normal, edgesR, edgesL);
  mjuu_normvec(normal, 3);
  mjuu_crossvec(basisL, normal, edgesL);
  mjuu_crossvec(basisR, edgesR, normal);

  // we use as basis the symmetrized tensor products of the edge normals of the
  // other two edges; this is shown in Weischedel "A discrete geometric view on
  // shear-deformable shell models" in the remark at the end of section 4.1;
  // equivalent to linear finite elements but in a coordinate-free formulation.

  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      basis[3 * i + j] = (basisL[i] * basisR[j] + basisR[i] * basisL[j]) / (8 * volume * volume);
    }
  }
}

template <>
void inline ComputeBasis<Stencil3D>(double        basis[9],
                                    const double* x,
                                    const int     v[Stencil3D::kNumVerts],
                                    const int     faceL[Stencil3D::kNumFaces],
                                    const int     faceR[Stencil3D::kNumFaces],
                                    double        volume) {
  const double* xL0       = x + 3 * v[faceL[0]];
  const double* xL1       = x + 3 * v[faceL[1]];
  const double* xL2       = x + 3 * v[faceL[2]];
  const double* xR0       = x + 3 * v[faceR[0]];
  const double* xR1       = x + 3 * v[faceR[1]];
  const double* xR2       = x + 3 * v[faceR[2]];
  double        edgesL[6] = {xL1[0] - xL0[0],
                             xL1[1] - xL0[1],
                             xL1[2] - xL0[2],
                             xL2[0] - xL0[0],
                             xL2[1] - xL0[1],
                             xL2[2] - xL0[2]};
  double        edgesR[6] = {xR1[0] - xR0[0],
                             xR1[1] - xR0[1],
                             xR1[2] - xR0[2],
                             xR2[0] - xR0[0],
                             xR2[1] - xR0[1],
                             xR2[2] - xR0[2]};

  double normalL[3], normalR[3];
  mjuu_crossvec(normalL, edgesL, edgesL + 3);
  mjuu_crossvec(normalR, edgesR, edgesR + 3);

  // we use as basis the symmetrized tensor products of the area normals of the
  // two faces not adjacent to the edge; this is the 3D equivalent to the basis
  // proposed in Weischedel "A discrete geometric view on shear-deformable shell
  // models" in the remark at the end of section 4.1. This is also equivalent to
  // linear finite elements but in a coordinate-free formulation.

  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      basis[3 * i + j] =
          (normalL[i] * normalR[j] + normalR[i] * normalL[j]) / (36 * 2 * volume * volume);
    }
  }
}

template <typename T>
void inline MetricTensor(
    double* metric, int idx, double mu, double la, const double basis[T::kNumEdges][9]) {
  double trE[T::kNumEdges]                 = {0};
  double trEE[T::kNumEdges * T::kNumEdges] = {0};
  double k[T::kNumEdges * T::kNumEdges];

  // compute first invariant i.e. trace(strain)
  for (int e = 0; e < T::kNumEdges; e++) {
    for (int i = 0; i < 3; i++) { trE[e] += basis[e][4 * i]; }
  }

  // compute second invariant i.e. trace(strain^2)
  for (int ed1 = 0; ed1 < T::kNumEdges; ed1++) {
    for (int ed2 = 0; ed2 < T::kNumEdges; ed2++) {
      for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
          trEE[T::kNumEdges * ed1 + ed2] += basis[ed1][3 * i + j] * basis[ed2][3 * j + i];
        }
      }
    }
  }

  // assembly of strain metric tensor
  for (int ed1 = 0; ed1 < T::kNumEdges; ed1++) {
    for (int ed2 = 0; ed2 < T::kNumEdges; ed2++) {
      k[T::kNumEdges * ed1 + ed2] = mu * trEE[T::kNumEdges * ed1 + ed2] + la * trE[ed2] * trE[ed1];
    }
  }

  // copy to triangular representation
  int id = 0;
  for (int ed1 = 0; ed1 < T::kNumEdges; ed1++) {
    for (int ed2 = ed1; ed2 < T::kNumEdges; ed2++) {
      metric[21 * idx + id++] = k[T::kNumEdges * ed1 + ed2];
    }
  }

  if (id != T::kNumEdges * (T::kNumEdges + 1) / 2) { mju_error("incorrect stiffness matrix size"); }
}

void mj_assignFriction(const mjModel* m, mjtNum* target, const mjtNum* source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    for (int i=0; i < 5; i++) {
      target[i] = mju_max(mjMINMU, m->opt.o_friction[i]);
    }
  } else {
    for (int i=0; i < 5; i++) {
      target[i] = mju_max(mjMINMU, source[i]);
    }
  }
}

void mj_assignRef(const mjModel* m, mjtNum* target, const mjtNum* source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    mju_copy(target, m->opt.o_solref, mjNREF);
  } else {
    mju_copy(target, source, mjNREF);
  }
}

void mj_assignImp(const mjModel* m, mjtNum* target, const mjtNum* source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    mju_copy(target, m->opt.o_solimp, mjNIMP);
  } else {
    mju_copy(target, source, mjNIMP);
  }
}

mjtNum mj_assignMargin(const mjModel* m, mjtNum source) {
  if (mjENABLED(mjENBL_OVERRIDE)) {
    return m->opt.o_margin;
  } else {
    return source;
  }
}

void mju_makeFrame(mjtNum frame[9]) {
  mjtNum tmp[3];

  // normalize xaxis
  if (mju_normalize3(frame) < 0.5) {
    mjERROR("xaxis of contact frame undefined");
  }

  // if yaxis undefined, set yaxis to (0,1,0) if possible, otherwise (0,0,1)
  if (mju_dot3(frame+3, frame+3) < 0.25) {
    mju_zero3(frame+3);

    if (frame[1] < 0.5 && frame[1] > -0.5) {
      frame[4] = 1;
    } else {
      frame[5] = 1;
    }
  }

  // make yaxis orthogonal to xaxis
  mji_scl3(tmp, frame, mju_dot3(frame, frame+3));
  mji_subFrom3(frame+3, tmp);
  mju_normalize3(frame+3);

  // zaxis = cross(xaxis, yaxis)
  mji_cross(frame+6, frame, frame+3);
}

static void mj_contactParam(const mjModel* m, int* condim,
                            mjtNum* solref, mjtNum* solimp, mjtNum* friction,
                            mjtNum* adhesion, int g1, int g2, int f1, int f2) {
  mjtNum fri[3];

  // get parameters from geom1 or flex1
  int priority1 =           (f1 < 0) ? m->geom_priority[g1]     : m->flex_priority[f1];
  int condim1 =             (f1 < 0) ? m->geom_condim[g1]       : m->flex_condim[f1];
  mjtNum solmix1 =          (f1 < 0) ? m->geom_solmix[g1]       : m->flex_solmix[f1];
  const mjtNum* solref1 =   (f1 < 0) ? m->geom_solref+g1*mjNREF : m->flex_solref+f1*mjNREF;
  const mjtNum* solimp1 =   (f1 < 0) ? m->geom_solimp+g1*mjNIMP : m->flex_solimp+f1*mjNIMP;
  const mjtNum* friction1 = (f1 < 0) ? m->geom_friction+g1*3    : m->flex_friction+f1*3;
  mjtNum adhesion1 =        (f1 < 0) ? m->geom_adhesion[g1]     : 0;

  // get parameters from geom2 or flex2
  int priority2 =           (f2 < 0) ? m->geom_priority[g2]     : m->flex_priority[f2];
  int condim2 =             (f2 < 0) ? m->geom_condim[g2]       : m->flex_condim[f2];
  mjtNum solmix2 =          (f2 < 0) ? m->geom_solmix[g2]       : m->flex_solmix[f2];
  const mjtNum* solref2 =   (f2 < 0) ? m->geom_solref+g2*mjNREF : m->flex_solref+f2*mjNREF;
  const mjtNum* solimp2 =   (f2 < 0) ? m->geom_solimp+g2*mjNIMP : m->flex_solimp+f2*mjNIMP;
  const mjtNum* friction2 = (f2 < 0) ? m->geom_friction+g2*3    : m->flex_friction+f2*3;
  mjtNum adhesion2 =        (f2 < 0) ? m->geom_adhesion[g2]     : 0;

  // adhesion: each surface contributes its own attraction
  *adhesion = adhesion1 + adhesion2;

  // different priority: copy from item with higher priority
  if (priority1 > priority2) {
    *condim = condim1;
    mju_copy(solref, solref1, mjNREF);
    mju_copy(solimp, solimp1, mjNIMP);
    mju_copy(fri, friction1, 3);
    *adhesion = adhesion1;
  }
  else if (priority1 < priority2) {
    *condim = condim2;
    mju_copy(solref, solref2, mjNREF);
    mju_copy(solimp, solimp2, mjNIMP);
    mju_copy(fri, friction2, 3);
    *adhesion = adhesion2;
  }

  // same priority
  else {
    // condim: max
    *condim = mjMAX(condim1, condim2);

    // compute solver mix factor
    mjtNum mix;
    if (solmix1 >= mjMINVAL && solmix2 >= mjMINVAL) {
      mix = solmix1 / (solmix1 + solmix2);
    } else if (solmix1 < mjMINVAL && solmix2 < mjMINVAL) {
      mix = 0.5;
    } else if (solmix1 < mjMINVAL) {
      mix = 0.0;
    } else {
      mix = 1.0;
    }

    // reference standard: mix
    if (solref1[0] > 0 && solref2[0] > 0) {
      for (int i=0; i < mjNREF; i++) {
        solref[i] = mix*solref1[i] + (1-mix)*solref2[i];
      }
    }

    // reference direct: min
    else {
      for (int i=0; i < mjNREF; i++) {
        solref[i] = mju_min(solref1[i], solref2[i]);
      }
    }

    // impedance: mix
    for (int i=0; i < mjNIMP; i++) {
      solimp[i] = mix*solimp1[i] + (1-mix)*solimp2[i];
    }

    // friction: max
    for (int i=0; i < 3; i++) {
      fri[i] = mju_max(friction1[i], friction2[i]);
    }
  }

  // unpack 5D friction
  friction[0] = fri[0];
  friction[1] = fri[0];
  friction[2] = fri[1];
  friction[3] = fri[2];
  friction[4] = fri[2];

  // SHOULD NOT OCCUR
  if (*condim > 6 || *condim < 1) {
    mjERROR("Invalid condim value: %d", *condim);
  }
}

static void mj_setContact(const mjModel* m, mjContact* con,
                          int condim, mjtNum includemargin,
                          const mjtNum* solref, const mjtNum* solreffriction,
                          const mjtNum* solimp, const mjtNum* friction,
                          mjtNum adhesion) {
  // set parameters
  con->dim = condim;
  con->includemargin = includemargin;
  con->adhesion = adhesion;
  mj_assignRef(m, con->solref, solref);
  mj_assignRef(m, con->solreffriction, solreffriction);
  mj_assignImp(m, con->solimp, solimp);
  mj_assignFriction(m, con->friction, friction);

  // exclude in gap; adhesive contacts remain active in the gap, producing
  // rows with positive violation whose reference acceleration pulls (tether)
  con->exclude = (con->dist >= includemargin) && !adhesion;

  // in-gap adhesive contacts have no surface contact and therefore no
  // friction: reduce to normal-only rows (with tangential rows present, fast
  // slip would recruit normal force and brake tangential motion at a distance)
  if (adhesion && con->dist >= includemargin) {
    con->dim = 1;
  }

  // complete frame
  mju_makeFrame(con->frame);

  // clear fields that are computed later
  con->efc_address = -1;
  con->mu = 0;
  mju_zero(con->H, 36);

  // set deprecated fields
  con->geom1 = con->geom[0];
  con->geom2 = con->geom[1];
}

#include <chrono>
#include <array>
#include <cstdlib>
extern "C" void benchmark_barrier(void*,void*);
constexpr int N=64;
struct ElasticInput {int kind;double E,nu,thickness,rayleigh,measure,h,len,rest,velocity;int damp,spring;double basis[6][9];};
struct ElasticOutput {double metric[21];};
struct ContactInput {int kind[2],priority[2],dim[2]; double mix[2],sr[4],si[10],fr[6],adh[2],margin[2],gap[2];
int pe,pd;double psr[2],psfr[2],psi[5],pfr[5],pa,pm,pg;int over;double osr[2],osi[5],ofr[5],om,distance;int self;};
struct ContactOutput {int dim;double solref[2],solreffriction[2],solimp[5],friction[5],adhesion,margin,gap;bool excluded;};
std::array<ElasticInput,N> ei;std::array<ElasticOutput,N> eo;std::array<std::array<double,10>,N> lo;
std::array<ContactInput,N> ci;std::array<ContactOutput,N> co;
int priority[2*N],dim[2*N];double mix[2*N],sr[4*N],si[10*N],fr[6*N],adh[2*N];mjModel model{};
static __attribute__((always_inline)) inline void assign_contact(const mjModel*m,ContactOutput*out,double distance,int condim,double includemargin,
 const double*solref,const double*solreffriction,const double*solimp,const double*friction,double adhesion){

  // set parameters
  out->dim = condim;
  out->margin = includemargin;
  out->adhesion = adhesion;
  mj_assignRef(m, out->solref, solref);
  mj_assignRef(m, out->solreffriction, solreffriction);
  mj_assignImp(m, out->solimp, solimp);
  mj_assignFriction(m, out->friction, friction);

  // exclude in gap; adhesive contacts remain active in the gap, producing
  // rows with positive violation whose reference acceleration pulls (tether)
  out->excluded = (distance >= includemargin) && !adhesion;

  // in-gap adhesive contacts have no surface contact and therefore no
  // friction: reduce to normal-only rows (with tangential rows present, fast
  // slip would recruit normal force and brake tangential motion at a distance)
  if (adhesion && distance >= includemargin) {
    out->dim = 1;
  }


}
static __attribute__((always_inline)) inline void prepare_contact(const mjModel*m,int i,const ContactInput&in,ContactOutput&out){
 int cd;double csr[2],csfr[2]={},csi[5],cfr[5],ca;
 double cm=in.margin[0]+in.margin[1],cg=in.gap[0]+in.gap[1];
 if(in.pe){cd=in.pd;for(int j=0;j<2;j++)csr[j]=in.psr[j];for(int j=0;j<5;j++){csi[j]=in.psi[j];cfr[j]=in.pfr[j];}
 ca=in.pa;cm=in.pm;cg=in.pg;if(in.psfr[0]||in.psfr[1])for(int j=0;j<2;j++)csfr[j]=in.psfr[j];}
 else mj_contactParam(m,&cd,csr,csi,cfr,&ca,in.kind[0]?-1:2*i,in.kind[1]?-1:2*i+1,in.kind[0]?2*i:-1,in.kind[1]?2*i+1:-1);
 cm=in.self?0:mj_assignMargin(m,cm);
 assign_contact(m,&out,in.distance,cd,cm,csr,csfr,csi,cfr,ca);out.gap=cg;
}
static __attribute__((always_inline)) inline void metric(const ElasticInput&in,ElasticOutput&out){
 double mu=in.E/(2*(1+in.nu)),la=in.E*in.nu/((1+in.nu)*(1-2*in.nu));
 double t=in.kind==0?in.thickness:4;
 mu=mu*std::abs(in.measure)/4*t;la=la*std::abs(in.measure)/4*t;
 if(in.kind==0){MetricTensor<Stencil2D>(out.metric,0,mu,la,in.basis);for(int j=6;j<21;j++)out.metric[j]=0;}
 else MetricTensor<Stencil3D>(out.metric,0,mu,la,in.basis);
}
static __attribute__((always_inline)) inline void laws(const ElasticInput&in,std::array<double,10>&out){
 double E=in.E,nu=in.nu,t=in.thickness;
 out[0]=E/(2*(1+nu));out[1]=E*nu/((1+nu)*(1-2*nu));out[2]=(E*nu/(1+nu))/(1-2*nu);
 out[3]=E*nu/(1-nu*nu);out[4]=E*t*t*t/(12*(1-nu*nu));
 out[5]=out[0]*std::abs(in.measure)/4*(in.kind==0?t:4);
 out[6]=out[1]*std::abs(in.measure)/4*(in.kind==0?t:4);
 double kd=in.damp&&in.h>0?in.rayleigh/in.h:0,dl=in.velocity*in.h;
 out[7]=kd;out[8]=in.spring?in.len*in.len-in.rest*in.rest:0;out[9]=kd?dl*(2*in.len-dl)*kd:0;
}
int main(int argc,char**argv){
 std::string mode=argv[1];int loops=std::atoi(argv[2]);std::cout<<std::setprecision(17)<<std::scientific;
 bool elastic=mode!="contact";
 for(int i=0;i<N;i++){
 int op;std::cin>>op;
 if(elastic){auto&in=ei[i];std::cin>>in.kind>>in.E>>in.nu>>in.thickness>>in.rayleigh>>in.measure>>in.h>>in.len>>in.rest>>in.velocity>>in.damp>>in.spring;
 for(int e=0;e<6;e++)for(int j=0;j<9;j++)std::cin>>in.basis[e][j];}
 else{auto&in=ci[i];for(int k=0;k<2;k++){std::cin>>in.kind[k]>>in.priority[k]>>in.dim[k]>>in.mix[k];for(int j=0;j<2;j++)std::cin>>in.sr[2*k+j];
 for(int j=0;j<5;j++)std::cin>>in.si[5*k+j];for(int j=0;j<3;j++)std::cin>>in.fr[3*k+j];std::cin>>in.adh[k]>>in.margin[k]>>in.gap[k];}
 std::cin>>in.pe>>in.pd;for(double&x:in.psr)std::cin>>x;for(double&x:in.psfr)std::cin>>x;for(double&x:in.psi)std::cin>>x;for(double&x:in.pfr)std::cin>>x;
 std::cin>>in.pa>>in.pm>>in.pg>>in.over;for(double&x:in.osr)std::cin>>x;for(double&x:in.osi)std::cin>>x;for(double&x:in.ofr)std::cin>>x;std::cin>>in.om>>in.distance>>in.self;
 for(int k=0;k<2;k++){int idx=2*i+k;priority[idx]=in.priority[k];dim[idx]=in.dim[k];mix[idx]=in.mix[k];adh[idx]=in.adh[k];
 for(int j=0;j<2;j++)sr[2*idx+j]=in.sr[2*k+j];for(int j=0;j<5;j++)si[5*idx+j]=in.si[5*k+j];for(int j=0;j<3;j++)fr[3*idx+j]=in.fr[3*k+j];}}
 }
 if(!elastic){model.geom_priority=model.flex_priority=priority;model.geom_condim=model.flex_condim=dim;model.geom_solmix=model.flex_solmix=mix;
 model.geom_solref=model.flex_solref=sr;model.geom_solimp=model.flex_solimp=si;model.geom_friction=model.flex_friction=fr;model.geom_adhesion=adh;
 if(ci[0].over)model.opt.enableflags|=mjENBL_OVERRIDE;for(int j=0;j<2;j++)model.opt.o_solref[j]=ci[0].osr[j];
 for(int j=0;j<5;j++){model.opt.o_solimp[j]=ci[0].osi[j];model.opt.o_friction[j]=ci[0].ofr[j];}model.opt.o_margin=ci[0].om;}
 if(!std::cin)return 2;
 auto execute=[&](int rounds){
 if(mode=="metric"){for(int r=0;r<rounds;r++){for(int i=0;i<N;i++)metric(ei[i],eo[i]);benchmark_barrier(ei.data(),eo.data());}}
 else if(mode=="laws"){for(int r=0;r<rounds;r++){for(int i=0;i<N;i++)laws(ei[i],lo[i]);benchmark_barrier(ei.data(),lo.data());}}
 else {for(int r=0;r<rounds;r++){for(int i=0;i<N;i++)prepare_contact(&model,i,ci[i],co[i]);benchmark_barrier(&model,co.data());benchmark_barrier(ci.data(),co.data());}}
 };
 execute(1024);auto begin=std::chrono::steady_clock::now();execute(loops);auto end=std::chrono::steady_clock::now();
 std::cout<<std::chrono::duration<double>(end-begin).count()<<'\n';
 for(int i=0;i<N;i++){
 if(mode=="metric"){for(double x:eo[i].metric)std::cout<<x<<' ';}
 else if(mode=="laws"){for(double x:lo[i])std::cout<<x<<' ';}
 else{auto&c=co[i];std::cout<<c.dim<<' ';for(double x:c.solref)std::cout<<x<<' ';for(double x:c.solreffriction)std::cout<<x<<' ';
 for(double x:c.solimp)std::cout<<x<<' ';for(double x:c.friction)std::cout<<x<<' ';std::cout<<c.adhesion<<' '<<c.margin<<' '<<c.gap<<' '<<c.excluded;}
 std::cout<<'\n';}
}
