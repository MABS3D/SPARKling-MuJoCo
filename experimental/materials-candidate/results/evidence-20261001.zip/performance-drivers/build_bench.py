from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
ROOT=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');BASE=Path('/var/tmp/sparkling-materials-performance-20261001');OUT=Path(__file__).parent/sys.argv[1]
OUT.mkdir(exist_ok=False);(OUT/'src').mkdir()
paths=[ROOT/'src/mj.ads',ROOT/'src/mj-types.ads',*sorted((ROOT/'experimental/materials-candidate/src').glob('*.ad?'))]
for p in paths:shutil.copyfile(p,OUT/'src'/p.name)
shutil.copyfile(BASE/'src/materials_benchmark.adb',OUT/'src/materials_benchmark.adb')
(OUT/'benchmark.gpr').write_text((BASE/'benchmark.gpr').read_text())
tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env=os.environ.copy();env['PATH']=':'.join(str(next((tc/n).glob('*/bin'))) for n in ['gnat','gprbuild'])+':'+env['PATH']
cmd=['gprbuild','-P',str(OUT/'benchmark.gpr'),'-j2'];p=subprocess.run(cmd,env=env,capture_output=True,text=True);(OUT/'build.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stdout+p.stderr
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};(OUT/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'build.json').write_text(json.dumps(dict(command=cmd,binary_sha256=hashlib.sha256((OUT/'bin/materials_benchmark').read_bytes()).hexdigest(),harness_sha256=hashlib.sha256((OUT/'src/materials_benchmark.adb').read_bytes()).hexdigest()),indent=2)+'\n')
print(OUT/'bin/materials_benchmark')
