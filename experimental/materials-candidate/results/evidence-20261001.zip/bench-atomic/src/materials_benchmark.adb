
with Ada.Text_IO; use Ada.Text_IO;
with Ada.Command_Line;
with Ada.Real_Time;
with System;
with MJ.Types; use MJ.Types;
with MJ.Elastic_Materials;
with MJ.Contact_Materials;
procedure Materials_Benchmark is
 package IO is new Ada.Text_IO.Float_IO(Real);
 package E renames MJ.Elastic_Materials;
 package C renames MJ.Contact_Materials;
 use type Ada.Real_Time.Time;
 N : constant := 64;
 Mode : constant String := Ada.Command_Line.Argument(1);
 Loops : constant Positive := Positive'Value(Ada.Command_Line.Argument(2));
 procedure Barrier(Input, Output : System.Address) with Import, Convention => C, External_Name => "benchmark_barrier";
 type Elastic_Input is record
  Kind : E.Element_Kind; M : E.Material; Measure : E.Measure_Value; H : E.Step_Value;
  Length, Rest : Nonneg_Tier0; Velocity : Tier0_Real; Damp, Spring : Boolean; Basis : E.Element_Basis;
 end record;
 type Contact_Input is record
  A,B : C.Surface; Pair : C.Explicit_Pair; Override : C.Override_Options;
  Distance : C.Wide_Value; Self : Boolean;
 end record;
 type Elastic_Table is array(0..N-1) of Elastic_Input;
 type Contact_Table is array(0..N-1) of Contact_Input;
 type Metric_Table is array(0..N-1) of E.Element_Metric;
 type Law_Output is array(0..9) of Real;
 type Law_Table is array(0..N-1) of Law_Output;
 type Output_Table is array(0..N-1) of C.Prepared_Contact;
 EI : Elastic_Table; CI : Contact_Table; EO : Metric_Table; LO : Law_Table; CO : Output_Table;
 procedure Execute(Rounds : Positive) is
 begin
  if Mode="metric" then
   for R in 1..Rounds loop
    for I in EI'Range loop
     E.Compile_Metric(EI(I).M,EI(I).Kind,EI(I).Measure,EI(I).Basis,EO(I));
    end loop;
    Barrier(EI'Address,EO'Address);
   end loop;
  elsif Mode="laws" then
   for R in 1..Rounds loop
    for I in EI'Range loop
     declare X : Elastic_Input renames EI(I); begin
      LO(I):=[E.Shear(X.M),E.Lame_Simplex(X.M),E.Lame_Interpolated(X.M),E.Lame_Plane_Stress(X.M),E.Bending_Modulus(X.M),
       E.Weighted_Shear(X.M,X.Kind,X.Measure),E.Weighted_Lame(X.M,X.Kind,X.Measure),E.Damping_Scale(X.M,X.H,X.Damp),
       E.Spring_Elongation(X.Length,X.Rest,X.Spring),E.Damper_Elongation(X.M,X.Length,X.Velocity,X.H,X.Damp)];
     end;
    end loop;
    Barrier(EI'Address,LO'Address);
   end loop;
  else
   for R in 1..Rounds loop
    for I in CI'Range loop
     declare X : Contact_Input renames CI(I); begin
      CO(I):=C.Prepare(X.A,X.B,X.Pair,X.Override,X.Distance,X.Self);
     end;
    end loop;
    Barrier(CI'Address,CO'Address);Barrier(CI'Address,CO'Address);
   end loop;
  end if;
 end Execute;
 procedure Put_Real(X : Real) is begin IO.Put(X,Fore=>1,Aft=>17,Exp=>3);Put(' ');end;
 procedure Put_Parameters(P : C.Parameters) is begin
  Put_Real(Real(P.Condim));for X of P.Solref loop Put_Real(X);end loop;
  for X of P.Solref_Friction loop Put_Real(X);end loop;for X of P.Solimp loop Put_Real(X);end loop;
  for X of P.Friction loop Put_Real(X);end loop;Put_Real(P.Adhesion);
 end;
 Start, Finish : Ada.Real_Time.Time;
begin
 for I in 0..N-1 loop
  declare
   Line : constant String := Get_Line;
   Pos : Positive := Line'First;
   function Read return Real is V : Real; Last : Positive;
   begin IO.Get(Line(Pos..Line'Last),V,Last);Pos:=Last+1;return V;end;
   function Read_Surface return C.Surface is S : C.Surface;
   begin
    S.Kind:=C.Surface_Kind'Val(Integer(Read));S.Priority:=Integer(Read);S.Condim:=Integer(Read);S.Solmix:=Read;
    for X of S.Solref loop X:=Read;end loop;for X of S.Solimp loop X:=Read;end loop;
    for X of S.Friction loop X:=Read;end loop;S.Adhesion:=Read;S.Margin:=Read;S.Gap:=Read;return S;
   end;
   Op : constant Integer := Integer(Read);
  begin
   if Op=1 then
    declare X : Elastic_Input renames EI(I);begin
     X.Kind:=E.Element_Kind'Val(Integer(Read));X.M.Young:=Read;X.M.Poisson:=Read;X.M.Thickness:=Read;X.M.Rayleigh_Damping:=Read;
     X.Measure:=Read;X.H:=Read;X.Length:=Read;X.Rest:=Read;X.Velocity:=Read;X.Damp:=Read/=0.0;X.Spring:=Read/=0.0;
     for B of X.Basis loop for V of B loop V:=Read;end loop;end loop;
    end;
   else
    declare X : Contact_Input renames CI(I);begin
     X.A:=Read_Surface;X.B:=Read_Surface;X.Pair.Enabled:=Read/=0.0;X.Pair.Condim:=Integer(Read);
     for V of X.Pair.Solref loop V:=Read;end loop;for V of X.Pair.Solref_Friction loop V:=Read;end loop;
     for V of X.Pair.Solimp loop V:=Read;end loop;for V of X.Pair.Friction loop V:=Read;end loop;
     X.Pair.Adhesion:=Read;X.Pair.Margin:=Read;X.Pair.Gap:=Read;X.Override.Enabled:=Read/=0.0;
     for V of X.Override.Solref loop V:=Read;end loop;for V of X.Override.Solimp loop V:=Read;end loop;
     for V of X.Override.Friction loop V:=Read;end loop;X.Override.Margin:=Read;X.Distance:=Read;X.Self:=Read/=0.0;
    end;
   end if;
  end;
 end loop;
 Execute(1024);Start:=Ada.Real_Time.Clock;Execute(Loops);Finish:=Ada.Real_Time.Clock;
 Put_Real(Real(Ada.Real_Time.To_Duration(Finish-Start)));New_Line;
 for I in 0..N-1 loop
  if Mode="metric" then for X of EO(I) loop Put_Real(X);end loop;
  elsif Mode="laws" then for X of LO(I) loop Put_Real(X);end loop;
  else Put_Parameters(CO(I).Values);Put_Real(CO(I).Include_Margin);Put_Real(CO(I).Detection_Gap);Put_Real(Real(Boolean'Pos(CO(I).Excluded)));
  end if;
  New_Line;
 end loop;
end Materials_Benchmark;
