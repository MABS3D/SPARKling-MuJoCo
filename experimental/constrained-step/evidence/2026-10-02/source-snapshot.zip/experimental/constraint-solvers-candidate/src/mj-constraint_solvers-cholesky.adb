package body MJ.Constraint_Solvers.Cholesky with SPARK_Mode is
   package Math renames MJ.Quaternion_Math;

   function Start (Value : Real) return Sum_Result is
   begin
      if Value not in Accumulator then return (0.0, False); end if;
      return (Value, True);
   end Start;

   function Subtract (S : Accumulator; A, B : Operand) return Sum_Result is
      Value : constant Real := S - A * B;
   begin
      return Start (Value);
   end Subtract;

   function Entry_Correct (M, L : Matrix; I, K : Positive; Floor : Pivot)
     return Boolean is
      S : constant Sum_Result := Factor_Sum (M, L, I, K, K - 1);
   begin
      return S.OK and then
        (if I = K then S.Value >= Floor and then
            L (I, K) = Math.Sqrt (S.Value)
         else L (K, K) in Pivot and then L (I, K) = S.Value / L (K, K));
   end Entry_Correct;

   procedure Unfold_Factor_Sum
     (M, L : Matrix; I, K : Positive; Count : Natural)
     with Ghost => Static, Global => null,
     Pre => Square (M) and then Square (L)
       and then M'Length (1) = L'Length (1) and then Bounded (L)
       and then I in M'Range (1) and then K in 1 .. I and then Count < K,
     Post => Factor_Sum (M, L, I, K, Count) =
       (if Count = 0 then Start (M (I, K)) else
        Extend (Factor_Sum (M, L, I, K, Count - 1), L (I, Count), L (K, Count)))
   is
      pragma Annotate (GNATprove, Unhide_Info, "Expression_Function_Body", Factor_Sum);
   begin
      null;
   end Unfold_Factor_Sum;

   procedure Factor_Cell
     (M : Matrix; L : in out Matrix; I, K : Positive; Floor : Pivot;
      Result : out Status)
     with Global => null,
     Pre => (Static => Square (M) and then Square (L)
       and then M'Length (1) = L'Length (1) and then Bounded (L)
       and then Triangular (L) and then I in M'Range (1) and then K in 1 .. I
       and then (for all P in 1 .. I - 1 => L (P, P) in Pivot)),
     Post => (Static => Bounded (L) and then Triangular (L)
       and then (for all P in 1 .. I - 1 => L (P, P) in Pivot)
       and then (for all P in L'Range (1) => (for all Q in L'Range (2) =>
          (if P /= I or else Q /= K then L (P, Q) = L'Old (P, Q))))
       and then (if Result /= Success then L = L'Old)
       and then (if Result = Success then
         Factor_Sum (M, L'Old, I, K, K - 1).OK and then
         (if I = K then L (I, K) in Pivot
           and then Factor_Sum (M, L'Old, I, K, K - 1).Value >= Floor
           and then L (I, K) = Math.Sqrt (Factor_Sum (M, L'Old, I, K, K - 1).Value)
          else L (I, K) = Divide (Factor_Sum (M, L'Old, I, K, K - 1).Value,
                                 L'Old (K, K)))))
   is
      S : Sum_Result := Start (M (I, K));
      Root : Real;
      Value : Operand;
   begin
      Result := Numeric_Limit;
      Unfold_Factor_Sum (M, L, I, K, 0);
      if not S.OK then return; end if;
      for T in 1 .. K - 1 loop
         pragma Loop_Invariant (Static => S.OK and then
           S = Factor_Sum (M, L, I, K, T - 1));
         S := Subtract (S.Value, L (I, T), L (K, T));
         if not S.OK then return; end if;
         Unfold_Factor_Sum (M, L, I, K, T);
         pragma Assert (Static => S = Factor_Sum (M, L, I, K, T));
      end loop;
      pragma Assert (Static => S = Factor_Sum (M, L, I, K, K - 1));
      if I = K then
         if S.Value < Floor then Result := Not_Positive_Definite; return; end if;
         Root := Math.Sqrt (S.Value);
         --  Keep the existing runtime sqrt boundary explicit. Its contract
         --  does not provide an upper bound; no accuracy axiom is added.
         if Root not in Pivot then return; end if;
         Value := Root;
      else
         Value := Divide (S.Value, L (K, K));
      end if;
      L (I, K) := Value;
      pragma Assert (Static => Bounded (L));
      pragma Assert (Static => Triangular (L));
      pragma Assert (Static => (for all P in 1 .. I - 1 => L (P, P) in Pivot));
      Result := Success;
   end Factor_Cell;

   procedure Factor (M : Matrix; L : out Matrix; Result : out Status;
                     Floor : Pivot := 1.0e-15) is
   begin
      L := (others => (others => 0.0));
      for I in M'Range (1) loop
         for K in 1 .. I loop
            declare
            begin
            Factor_Cell (M, L, I, K, Floor, Result);
            pragma Assert_And_Cut (Static => Bounded (L) and then Triangular (L)
              and then (for all P in 1 .. I - 1 => L (P, P) in Pivot)
              and then (if Result = Success and then K = I then L (I, I) in Pivot));
            if Result /= Success then return; end if;
            end;
            pragma Loop_Invariant (Static => Bounded (L) and then Triangular (L));
            pragma Loop_Invariant (Static => (for all P in 1 .. I - 1 => L (P, P) in Pivot));
            pragma Loop_Invariant (Static => (if K = I then L (I, I) in Pivot));
         end loop;
         pragma Loop_Invariant (Static => Bounded (L) and then Triangular (L));
         pragma Loop_Invariant (Static => (for all P in 1 .. I => L (P, P) in Pivot));
      end loop;
      pragma Assert (Static => Bounded (L));
      pragma Assert (Static => Triangular (L));
      pragma Assert (Static => Positive_Diagonal (L));
      Result := Success;
   end Factor;

   procedure Backsolve (L : Matrix; B : Vector; X : out Vector;
                        Result : out Status) is
      S : Sum_Result;
   begin
      X := (others => 0.0);
      Result := Numeric_Limit;
      for I in B'Range loop
         pragma Loop_Invariant (Static => (for all V of X => V in Operand));
         pragma Loop_Invariant
           (Static => (if (for all V of B => V = 0.0) then (for all V of X => V = 0.0)));
         S := Start (B (I));
         if not S.OK then return; end if;
         for K in 1 .. I - 1 loop
            pragma Loop_Invariant
              (Static => (if (for all V of B => V = 0.0) then S.OK and then S.Value = 0.0));
            S := Subtract (S.Value, L (I, K), X (K));
            if not S.OK then return; end if;
         end loop;
         X (I) := Divide (S.Value, L (I, I));
      end loop;
      for I in reverse B'Range loop
         pragma Loop_Invariant (Static => (for all V of X => V in Operand));
         pragma Loop_Invariant
           (Static => (if (for all V of B => V = 0.0) then (for all V of X => V = 0.0)));
         S := Start (X (I));
         if not S.OK then return; end if;
         for K in I + 1 .. B'Last loop
            pragma Loop_Invariant
              (Static => (if (for all V of B => V = 0.0) then S.OK and then S.Value = 0.0));
            S := Subtract (S.Value, L (K, I), X (K));
            if not S.OK then return; end if;
         end loop;
         X (I) := Divide (S.Value, L (I, I));
      end loop;
      Result := Success;
   end Backsolve;
end MJ.Constraint_Solvers.Cholesky;
