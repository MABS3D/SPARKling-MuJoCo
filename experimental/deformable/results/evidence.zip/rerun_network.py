import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
sys.path.insert(0,str(repo/'experimental/smooth/tools'))
from prove_fragments import diagnostic_messages,save_report
root=Path('/var/tmp/sparkling-deformable-20260927')
old=json.loads((root/'network-final/results.json').read_text())
manifest={k:v for k,v in old.items() if k not in ('results','counts')}
out=root/'network-accepted';(out/'logs').mkdir(parents=True,exist_ok=True)
snapshot=Path(manifest['snapshot']);project=Path(manifest['projects']['mj-elastic_network']['path'])
# Keep the previous source revision alongside its historical report. Only our
# isolated snapshot is refreshed; GNATprove invalidates affected cached tasks.
for name in ('mj-elastic_kernels.ads','mj-elastic_kernels.adb'):
 rel=Path('experimental/smooth/src')/name
 backup=root/'network-final/previous-dependencies'/name;backup.parent.mkdir(exist_ok=True)
 shutil.copy2(snapshot/rel,backup);shutil.copy2(repo/rel,snapshot/rel)
 manifest['source_sha256'][str(rel)]=hashlib.sha256((snapshot/rel).read_bytes()).hexdigest()
for name in ('mj-elastic_kernels.ads','mj-elastic_kernels.adb','mj-elastic_network.ads','mj-elastic_network.adb'):
 rel=Path('experimental/smooth/src')/name
 assert (repo/rel).read_bytes()==(snapshot/rel).read_bytes()
manifest['arguments']['report_dir']=str(out)
manifest['incremental_from']=str(root/'network-final')
manifest['incremental_note']='Normal GNATprove dependency invalidation and proof cache reuse; full unit requested, no limits or suppressions.'
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
obj=project.parent/(project.stem+'-obj')
for p in obj.rglob('*.spark'):p.unlink()
summary=obj/'gnatprove/gnatprove.out'
if summary.exists():summary.unlink()
env=os.environ.copy();base=Path('/var/tmp/sparkling-matrix-recovery/toolchains')
env['PATH']=os.pathsep.join(str(p) for name in ('gnat','gprbuild','gnatprove') for p in base.glob(name+'/*/bin'))+os.pathsep+env['PATH']
row=old['results'][0];cmd=row['command'];start=time.monotonic()
r=subprocess.run(cmd,cwd=snapshot,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
elapsed=time.monotonic()-start
log=out/row['log'];log.write_text(r.stdout)
structured={p.name:json.loads(p.read_text()) for p in obj.rglob('*.spark')}
(out/'logs/mj-elastic_network__whole_unit.spark.json').write_text(json.dumps(structured,indent=2))
if summary.exists():shutil.copy2(summary,out/'logs/mj-elastic_network__whole_unit.summary.txt')
messages=diagnostic_messages(r.stdout,structured)
unproved=sum(m['severity'] in ('low','medium','high') for m in messages)
errors=sum(m['severity']=='error' for m in messages)
checks=sum(len(i.get('proof',[])) for i in structured.values())
flow=sum(len(i.get('flow',[])) for i in structured.values())
passed=r.returncode==0 and not unproved and not errors and checks>0 and not any(m['severity']=='warning' for m in messages)
row.update(status='completed_no_unproved' if passed else 'unproved_checks',exit_code=r.returncode,seconds=round(elapsed,2),unproved=unproved,errors=errors,proof_checks=checks,flow_checks=flow,messages=messages)
save_report(out,manifest,[row]);print(row['status'],checks,unproved,errors,round(elapsed,2),flush=True)
sys.exit(0 if passed else 1)
