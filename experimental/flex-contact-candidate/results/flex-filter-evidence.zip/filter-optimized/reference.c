// Copyright 2021 DeepMind Technologies Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <stdlib.h>
#include <string.h>
typedef double mjtNum;
typedef unsigned char mjtByte;
typedef struct { double dist, pos[3]; int id; } mjContact;
typedef struct { int ncon; mjContact* contact; } mjData;
#define mjMAXCONPAIR 50
#define mjMAXVAL 1e10
#define mjSTACKALLOC(d,n,T) ((T*)__builtin_alloca((n)*sizeof(T)))
#define mj_markStack(d) ((void)0)
#define mj_freeStack(d) ((void)0)
#define resetArena(d) ((void)0)
static void filterFlexContacts(mjData* d, int ncon_before) {
  int n = d->ncon - ncon_before;
  if (n <= mjMAXCONPAIR) {
    return;
  }

  mjContact* contacts = d->contact + ncon_before;

  mj_markStack(d);
  mjtByte* selected = mjSTACKALLOC(d, n, mjtByte);
  mjtNum* min_dist = mjSTACKALLOC(d, n, mjtNum);
  memset(selected, 0, n);

  for (int i = 0; i < n; i++) {
    min_dist[i] = mjMAXVAL;
  }

  // start with the deepest penetrating contact
  int nselected = 0;
  int best = 0;
  mjtNum bestdist = -contacts[0].dist;
  for (int i = 1; i < n; i++) {
    if (-contacts[i].dist > bestdist) {
      bestdist = -contacts[i].dist;
      best = i;
    }
  }

  while (nselected < mjMAXCONPAIR && best >= 0) {
    selected[best] = 1;
    mjtNum* bestpos = contacts[best].pos;

    int nextbest = -1;
    mjtNum nextbestdist = -1;
    for (int i = 0; i < n; i++) {
      if (selected[i]) continue;

      mjtNum dx = contacts[i].pos[0] - bestpos[0];
      mjtNum dy = contacts[i].pos[1] - bestpos[1];
      mjtNum dz = contacts[i].pos[2] - bestpos[2];
      mjtNum d2 = dx*dx + dy*dy + dz*dz;
      if (d2 < min_dist[i]) {
        min_dist[i] = d2;
      }
      if (min_dist[i] > nextbestdist) {
        nextbestdist = min_dist[i];
        nextbest = i;
      }
    }

    if (nselected < mjMAXCONPAIR - 1) {
      mjContact temp = contacts[nselected];
      contacts[nselected] = contacts[best];
      contacts[best] = temp;

      if (nextbest == nselected) {
        nextbest = best;
      }
    }

    nselected++;
    best = nextbest;
  }

  mj_freeStack(d);

  d->ncon = ncon_before + nselected;
  resetArena(d);
}
int reference_filter(int n, const double* dist, const double* pos, int* ids) {
  mjContact* contacts = calloc(n+3, sizeof(mjContact));
  if (!contacts) return -1;
  for (int i=0; i<3; ++i) contacts[i].id = -100-i;
  for (int i=0; i<n; ++i) {
    contacts[i+3].id=i+1; contacts[i+3].dist=dist[i];
    memcpy(contacts[i+3].pos, pos+3*i, 3*sizeof(double));
  }
  mjData data = {n+3, contacts};
  filterFlexContacts(&data, 3);
  int count=data.ncon-3;
  for (int i=0; i<count; ++i) ids[i]=contacts[i+3].id;
  for (int i=0; i<3; ++i) if(contacts[i].id != -100-i) count=-2;
  free(contacts); return count;
}
