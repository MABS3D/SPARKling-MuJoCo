package body MJ.Flex_Contact_Network with SPARK_Mode is
   procedure Relate_Forces (C : Configuration; P : Particle; F, Expected : Edge_Force;
     Applied, Gravity : Input_Vector; H : Time_Step; Selected_Rank : Contact_Rank; Info : Evaluation)
     with Ghost => Static, Global => null,
     Pre => Bounded (F.Spring, 1.0e80) and then Bounded (F.Damper, 1.0e80)
       and then Bounded (Expected.Spring, 1.0e80) and then Bounded (Expected.Damper, 1.0e80)
       and then F = Expected and then Matches (C, P, F, Applied, Gravity, H, Selected_Rank, Info),
     Post => Matches (C, P, Expected, Applied, Gravity, H, Selected_Rank, Info);
   procedure Relate_Forces (C : Configuration; P : Particle; F, Expected : Edge_Force;
     Applied, Gravity : Input_Vector; H : Time_Step; Selected_Rank : Contact_Rank; Info : Evaluation) is
      pragma Annotate (GNATprove, Unhide_Info, "Expression_Function_Body", Matches);
      pragma Annotate (GNATprove, Unhide_Info, "Expression_Function_Body", Free_Acceleration);
   begin
      for K in Axis loop
         pragma Assert (Info.Free (K) = Free_Acceleration
           (P.Mass, F.Spring (K), F.Damper (K), Applied (K), Gravity (K)));
         pragma Assert (F.Spring (K) = Expected.Spring (K) and then F.Damper (K) = Expected.Damper (K));
         pragma Assert (Info.Free (K) = Free_Acceleration
           (P.Mass, Expected.Spring (K), Expected.Damper (K), Applied (K), Gravity (K)));
         pragma Loop_Invariant (for all J in Axis'First .. K => Info.Free (J) = Free_Acceleration
           (P.Mass, Expected.Spring (J), Expected.Damper (J), Applied (J), Gravity (J)));
      end loop;
   end Relate_Forces;

   procedure Evaluate (C : Configuration; P : Particle_Array; E : Edge_Array;
     Applied : Input_Array; Gravity : Input_Vector; H : Time_Step;
     Info : out Evaluation_Array; Result : out Status) is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", MJ.Elastic_Network.Component);
      F : Force_Array (P'Range);
      Force_Status : MJ.Elastic_Network.Status;
      Ranks : MJ.Flex_Contact_Filter.Rank_Array (P'Range);
   begin
      Info := [others => (False, False, False, 0, 0.0, 0.0, [others => 0.0], [others => 0.0])];
      Result := Numeric_Limit;
      Forces (P, E, F, Force_Status);
      if Force_Status /= MJ.Elastic_Network.Success then return; end if;
      MJ.Flex_Contact_Filter.Select_Contacts (C, P, Ranks);
      Result := Success;
      for V in P'Range loop
         pragma Assert (Static => F (V) = Model_Force (P, E, V));
         MJ.Flex_Contact_Kernels.Evaluate (C, P (V), F (V), Applied (V), Gravity, H, Ranks (V), Info (V));
         Relate_Forces (C, P (V), F (V), Model_Force (P, E, V), Applied (V), Gravity, H, Ranks (V), Info (V));
         if not Info (V).Accepted then Result := Numeric_Limit; return; end if;
         pragma Loop_Invariant (Static => (for all W in 1 .. V => Info (W).Accepted and then
           Info (W).Retained_Rank = Ranks (W) and then
           Matches (C, P (W), Model_Force (P, E, W), Applied (W), Gravity, H, Ranks (W), Info (W))));
      end loop;
   end Evaluate;

   procedure Step (C : Configuration; P : in out Particle_Array; E : Edge_Array;
     Applied : Input_Array; Gravity : Input_Vector; H : Time_Step;
     Info : out Evaluation_Array; Result : out Status) is
      pragma Annotate (GNATprove, Hide_Info, "Expression_Function_Body", Model_Force);
      Candidate : Particle_Array (P'Range) := P;
      Next : Particle;
      Accepted : Boolean;
   begin
      Evaluate (C, P, E, Applied, Gravity, H, Info, Result);
      if Result /= Success then return; end if;
      for V in P'Range loop
         Next := P (V);
         Integrate (Next, Info (V).Acceleration, H, Accepted);
         if not Accepted then Result := Numeric_Limit; return; end if;
         pragma Assert (if not P (V).Pinned then Next.Velocity (0) =
           Velocity_After (P (V).Velocity (0), Info (V).Acceleration (0), H));
         pragma Assert (if not P (V).Pinned then Next.Velocity (1) =
           Velocity_After (P (V).Velocity (1), Info (V).Acceleration (1), H));
         pragma Assert (if not P (V).Pinned then Next.Velocity (2) =
           Velocity_After (P (V).Velocity (2), Info (V).Acceleration (2), H));
         Candidate (V) := Next;
         pragma Loop_Invariant (for all W in P'Range =>
           Candidate (W).Mass = P (W).Mass and then Candidate (W).Pinned = P (W).Pinned
           and then (if P (W).Pinned then Candidate (W) = P (W)));
         pragma Loop_Invariant (for all W in V + 1 .. P'Last => Candidate (W) = P (W));
         pragma Loop_Invariant (for all W in 1 .. V => (if not P (W).Pinned then
           Candidate (W).Velocity (0) = Velocity_After (P (W).Velocity (0), Info (W).Acceleration (0), H)));
         pragma Loop_Invariant (for all W in 1 .. V => (if not P (W).Pinned then
           Candidate (W).Position (0) = P (W).Position (0) + H * Candidate (W).Velocity (0)));
         pragma Loop_Invariant (for all W in 1 .. V => (if not P (W).Pinned then
           Candidate (W).Velocity (1) = Velocity_After (P (W).Velocity (1), Info (W).Acceleration (1), H)));
         pragma Loop_Invariant (for all W in 1 .. V => (if not P (W).Pinned then
           Candidate (W).Position (1) = P (W).Position (1) + H * Candidate (W).Velocity (1)));
         pragma Loop_Invariant (for all W in 1 .. V => (if not P (W).Pinned then
           Candidate (W).Velocity (2) = Velocity_After (P (W).Velocity (2), Info (W).Acceleration (2), H)));
         pragma Loop_Invariant (for all W in 1 .. V => (if not P (W).Pinned then
           Candidate (W).Position (2) = P (W).Position (2) + H * Candidate (W).Velocity (2)));
      end loop;
      P := Candidate;
   end Step;
end MJ.Flex_Contact_Network;
