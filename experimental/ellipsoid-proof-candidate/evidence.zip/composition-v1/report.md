# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-zjoacfgn/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prepare_Ellipsoid` | `mj-fluid_kernels.adb:5` | [unproved_checks](logs/mj-fluid_kernels__prepare_ellipsoid__adb_5.log) | 72 | 15 | 0 | 148.9 |
| `Blend_Force` | `mj-fluid_kernels.adb:26` | [completed_no_unproved](logs/mj-fluid_kernels__blend_force__adb_26.log) | 12 | 0 | 0 | 3.3 |
| `Blend_Torque` | `mj-fluid_kernels.adb:31` | [completed_no_unproved](logs/mj-fluid_kernels__blend_torque__adb_31.log) | 8 | 0 | 0 | 2.8 |
| `Ellipsoid` | `mj-fluid_kernels.adb:37` | [proof_timeout](logs/mj-fluid_kernels__ellipsoid__adb_37.log) | 0 | 0 | 0 | 160.2 |

## Diagnostics

### mj-fluid_kernels__prepare_ellipsoid__adb_5

- `mj-fluid_kernels.adb:21` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time and memory limit before completing the proof]
- `mj-fluid_kernels.adb:21` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time and memory limit before completing the proof]
- `mj-fluid_kernels.adb:22` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.ads:46` (medium): precondition might fail [provers reached time and memory limit before completing the proof]
- `mj-fluid_kernels.ads:46` (medium): precondition might fail [provers reached time and memory limit before completing the proof]
- `mj-fluid_kernels.ads:47` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time and memory limit before completing the proof]
- `mj-fluid_kernels.ads:47` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time and memory limit before completing the proof]
- `mj-fluid_kernels.ads:48` (medium): precondition might fail [provers reached time and memory limit before completing the proof]
- 7 more diagnostics in the individual log.

