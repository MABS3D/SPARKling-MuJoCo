# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-d8e858_y/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Normal_Cross` | `mj-fluid_lift.adb:2` | [completed_no_unproved](logs/mj-fluid_lift__normal_cross__adb_2.log) | 8 | 0 | 0 | 3.6 |
| `Magnus_Component` | `mj-fluid_lift.adb:6` | [unproved_checks](logs/mj-fluid_lift__magnus_component__adb_6.log) | 14 | 1 | 0 | 9.2 |
| `Circulation_Component` | `mj-fluid_lift.adb:10` | [unproved_checks](logs/mj-fluid_lift__circulation_component__adb_10.log) | 10 | 1 | 0 | 8.9 |
| `Kutta_Component` | `mj-fluid_lift.adb:14` | [completed_no_unproved](logs/mj-fluid_lift__kutta_component__adb_14.log) | 8 | 0 | 0 | 3.0 |
| `Magnus` | `mj-fluid_lift.adb:18` | [completed_no_unproved](logs/mj-fluid_lift__magnus__adb_18.log) | 28 | 0 | 0 | 17.3 |
| `Circulation` | `mj-fluid_lift.adb:24` | [completed_no_unproved](logs/mj-fluid_lift__circulation__adb_24.log) | 28 | 0 | 0 | 20.0 |
| `Kutta` | `mj-fluid_lift.adb:30` | [completed_no_unproved](logs/mj-fluid_lift__kutta__adb_30.log) | 28 | 0 | 0 | 10.9 |

## Diagnostics

### mj-fluid_lift__magnus_component__adb_6

- `mj-fluid_lift.ads:16` (medium): postcondition might fail [provers reached time limit before completing the proof]

### mj-fluid_lift__circulation_component__adb_10

- `mj-fluid_lift.ads:18` (medium): postcondition might fail [provers reached time limit before completing the proof]

