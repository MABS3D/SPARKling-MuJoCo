# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-u_eojc8q/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-fluid_geometry.adb:1` | [completed_no_unproved](logs/mj-fluid_geometry__whole_unit.log) | 84 | 0 | 0 | 15.0 |
| `whole unit` | `mj-fluid_lift.adb:1` | [completed_no_unproved](logs/mj-fluid_lift__whole_unit.log) | 130 | 0 | 0 | 51.0 |

## Diagnostics

