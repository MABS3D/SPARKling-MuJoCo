# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-1cj3urcq/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Normalize_Axis` | `mj-fluid_geometry.adb:14` | [unproved_checks](logs/mj-fluid_geometry__normalize_axis__adb_14.log) | 10 | 1 | 0 | 26.2 |
| `Angular_Moment` | `mj-fluid_geometry.adb:45` | [completed_no_unproved](logs/mj-fluid_geometry__angular_moment__adb_45.log) | 10 | 0 | 0 | 3.3 |
| `Moment` | `mj-fluid_geometry.adb:41` | [completed_no_unproved](logs/mj-fluid_geometry__moment__adb_41.log) | 12 | 0 | 0 | 3.6 |

## Diagnostics

### mj-fluid_geometry__normalize_axis__adb_14

- `mj-fluid_geometry.adb:19` (medium): assertion might fail [provers reached time limit before completing the proof]

