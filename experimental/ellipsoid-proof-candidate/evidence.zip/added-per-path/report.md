# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-m93nfj5i/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-fluid_added_mass.adb:1` | [unproved_checks](logs/mj-fluid_added_mass__whole_unit.log) | 111 | 1 | 0 | 117.6 |

## Diagnostics

### mj-fluid_added_mass__whole_unit

- `mj-fluid_added_mass.ads:17` (medium): postcondition might fail [provers reached time and memory limit before completing the proof]

