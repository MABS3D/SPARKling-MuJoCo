# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-cfvyxrbk/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Ellipsoid` | `mj-fluid_kernels.adb:35` | [unproved_checks](logs/mj-fluid_kernels__ellipsoid__adb_35.log) | 67 | 41 | 0 | 28.4 |

## Diagnostics

### mj-fluid_kernels__ellipsoid__adb_35

- `mj-fluid_kernels.adb:48` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.adb:50` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.adb:51` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.adb:52` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.adb:53` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.adb:53` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.adb:53` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- `mj-fluid_kernels.adb:54` (medium): range check might fail [reason for check: input value must fit in parameter type] [provers reached time limit before completing the proof]
- 33 more diagnostics in the individual log.

