# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-el4dn2_b/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Prepare_Ellipsoid` | `mj-fluid_kernels.adb:6` | [completed_no_unproved](logs/mj-fluid_kernels__prepare_ellipsoid__adb_6.log) | 72 | 0 | 0 | 23.6 |
| `Blend_Force` | `mj-fluid_kernels.adb:24` | [completed_no_unproved](logs/mj-fluid_kernels__blend_force__adb_24.log) | 12 | 0 | 0 | 3.3 |
| `Blend_Torque` | `mj-fluid_kernels.adb:29` | [completed_no_unproved](logs/mj-fluid_kernels__blend_torque__adb_29.log) | 8 | 0 | 0 | 3.0 |
| `Fourth` | `mj-fluid_kernels.ads:26` | [completed_no_unproved](logs/mj-fluid_kernels__fourth__ads_26.log) | 4 | 0 | 0 | 3.1 |

## Diagnostics

