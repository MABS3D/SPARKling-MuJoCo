# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-u9kzqiih/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Magnus_Factor` | `mj-fluid_lift.adb:2` | [completed_no_unproved](logs/mj-fluid_lift__magnus_factor__adb_2.log) | 6 | 0 | 0 | 3.6 |
| `Rate_Cross` | `mj-fluid_lift.adb:6` | [completed_no_unproved](logs/mj-fluid_lift__rate_cross__adb_6.log) | 8 | 0 | 0 | 3.4 |
| `Circulation_Factor` | `mj-fluid_lift.adb:10` | [completed_no_unproved](logs/mj-fluid_lift__circulation_factor__adb_10.log) | 8 | 0 | 0 | 3.3 |
| `Magnus_Component` | `mj-fluid_lift.adb:18` | [unproved_checks](logs/mj-fluid_lift__magnus_component__adb_18.log) | 4 | 1 | 0 | 12.9 |
| `Circulation_Component` | `mj-fluid_lift.adb:22` | [completed_no_unproved](logs/mj-fluid_lift__circulation_component__adb_22.log) | 4 | 0 | 0 | 3.8 |

## Diagnostics

### mj-fluid_lift__magnus_component__adb_18

- `mj-fluid_lift.adb:20` (medium): range check might fail [reason for check: returned value must fit in the result type of the function] [possible fix: subprogram at mj-fluid_lift.ads:24 should mention Coefficient and Density and V1 and V2 and Volume and W1 and W2 in a precondition] [provers reached time limit before completing the proof]

