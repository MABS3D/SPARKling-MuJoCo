# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-fdxe1ek5/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Torque_Sum` | `mj-fluid_added_mass.adb:10` | [completed_no_unproved](logs/mj-fluid_added_mass__torque_sum__adb_10.log) | 4 | 0 | 0 | 3.1 |
| `Evaluate` | `mj-fluid_added_mass.adb:14` | [completed_no_unproved](logs/mj-fluid_added_mass__evaluate__adb_14.log) | 92 | 0 | 0 | 161.8 |

## Diagnostics

