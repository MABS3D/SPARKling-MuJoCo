# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-m1_bk7g5/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Inverse` | `mj-fluid_projection.adb:2` | [unproved_checks](logs/mj-fluid_projection__inverse__adb_2.log) | 6 | 1 | 0 | 13.7 |
| `Normalize` | `mj-fluid_projection.adb:6` | [completed_no_unproved](logs/mj-fluid_projection__normalize__adb_6.log) | 4 | 0 | 0 | 3.1 |
| `Numerator_Part` | `mj-fluid_projection.adb:10` | [completed_no_unproved](logs/mj-fluid_projection__numerator_part__adb_10.log) | 6 | 0 | 0 | 4.3 |
| `Numerator` | `mj-fluid_projection.adb:14` | [completed_no_unproved](logs/mj-fluid_projection__numerator__adb_14.log) | 6 | 0 | 0 | 3.8 |
| `Coefficient` | `mj-fluid_projection.adb:18` | [completed_no_unproved](logs/mj-fluid_projection__coefficient__adb_18.log) | 4 | 0 | 0 | 2.0 |
| `Denominator_Part` | `mj-fluid_projection.adb:22` | [completed_no_unproved](logs/mj-fluid_projection__denominator_part__adb_22.log) | 8 | 0 | 0 | 4.3 |
| `Denominator` | `mj-fluid_projection.adb:26` | [completed_no_unproved](logs/mj-fluid_projection__denominator__adb_26.log) | 6 | 0 | 0 | 4.3 |
| `Normal` | `mj-fluid_projection.adb:30` | [completed_no_unproved](logs/mj-fluid_projection__normal__adb_30.log) | 4 | 0 | 0 | 2.6 |
| `Norm_Squared` | `mj-fluid_projection.adb:34` | [completed_no_unproved](logs/mj-fluid_projection__norm_squared__adb_34.log) | 12 | 0 | 0 | 5.7 |
| `Projected_Area` | `mj-fluid_projection.adb:38` | [completed_no_unproved](logs/mj-fluid_projection__projected_area__adb_38.log) | 8 | 0 | 0 | 3.3 |
| `Linear_Drag` | `mj-fluid_projection.adb:42` | [completed_no_unproved](logs/mj-fluid_projection__linear_drag__adb_42.log) | 18 | 0 | 0 | 4.4 |
| `Moment` | `mj-fluid_projection.adb:46` | [completed_no_unproved](logs/mj-fluid_projection__moment__adb_46.log) | 4 | 0 | 0 | 3.4 |
| `Angular_Drag` | `mj-fluid_projection.adb:50` | [completed_no_unproved](logs/mj-fluid_projection__angular_drag__adb_50.log) | 8 | 0 | 0 | 3.3 |
| `Norm` | `mj-fluid_projection.adb:54` | [completed_no_unproved](logs/mj-fluid_projection__norm__adb_54.log) | 3 | 0 | 0 | 3.8 |

## Diagnostics

### mj-fluid_projection__inverse__adb_2

- `mj-fluid_projection.adb:4` (medium): range check might fail [reason for check: result of division must fit in the type of the qualification] [possible fix: subprogram at mj-fluid_projection.ads:24 should mention X in a precondition] [provers reached time limit before completing the proof]

