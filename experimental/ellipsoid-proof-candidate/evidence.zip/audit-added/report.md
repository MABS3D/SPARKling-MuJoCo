# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-n8hd7n4w/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Evaluate` | `mj-fluid_added_mass.adb:10` | [unproved_checks](logs/mj-fluid_added_mass__evaluate__adb_10.log) | 97 | 2 | 0 | 93.7 |

## Diagnostics

### mj-fluid_added_mass__evaluate__adb_10

- `mj-fluid_added_mass.ads:17` (medium): postcondition might fail, cannot prove V (0) in -Limit .. Limit [provers reached time and memory limit before completing the proof]
- `mj-fluid_added_mass.ads:17` (medium): in inlined expression function body at mj-smooth_math.ads:19

