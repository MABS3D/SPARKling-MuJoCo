# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-_r__31mh/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Surface_From_Size` | `mj-fluid_geometry.adb:49` | [unproved_checks](logs/mj-fluid_geometry__surface_from_size__adb_49.log) | 8 | 1 | 0 | 13.5 |
| `Moment_From_Size` | `mj-fluid_geometry.adb:56` | [completed_no_unproved](logs/mj-fluid_geometry__moment_from_size__adb_56.log) | 3 | 0 | 0 | 4.1 |
| `Prepare_Ellipsoid` | `mj-fluid_kernels.adb:6` | [completed_no_unproved](logs/mj-fluid_kernels__prepare_ellipsoid__adb_6.log) | 72 | 0 | 0 | 25.6 |

## Diagnostics

### mj-fluid_geometry__surface_from_size__adb_49

- `mj-fluid_geometry.ads:50` (medium): precondition might fail [provers reached time limit before completing the proof]

