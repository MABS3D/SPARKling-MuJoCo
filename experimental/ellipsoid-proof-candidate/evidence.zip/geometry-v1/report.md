# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-rl9zmxz4/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Volume` | `mj-fluid_geometry.adb:2` | [completed_no_unproved](logs/mj-fluid_geometry__volume__adb_2.log) | 8 | 0 | 0 | 3.3 |
| `Middle` | `mj-fluid_geometry.adb:6` | [completed_no_unproved](logs/mj-fluid_geometry__middle__adb_6.log) | 10 | 0 | 0 | 3.6 |
| `Area` | `mj-fluid_geometry.adb:10` | [completed_no_unproved](logs/mj-fluid_geometry__area__adb_10.log) | 6 | 0 | 0 | 2.8 |
| `Normalize_Axis` | `mj-fluid_geometry.adb:14` | [unproved_checks](logs/mj-fluid_geometry__normalize_axis__adb_14.log) | 8 | 1 | 0 | 9.7 |
| `Surface` | `mj-fluid_geometry.adb:18` | [completed_no_unproved](logs/mj-fluid_geometry__surface__adb_18.log) | 8 | 0 | 0 | 2.8 |
| `Diameter` | `mj-fluid_geometry.adb:22` | [completed_no_unproved](logs/mj-fluid_geometry__diameter__adb_22.log) | 8 | 0 | 0 | 2.8 |
| `Linear_Viscosity` | `mj-fluid_geometry.adb:26` | [completed_no_unproved](logs/mj-fluid_geometry__linear_viscosity__adb_26.log) | 4 | 0 | 0 | 2.5 |
| `Angular_Viscosity` | `mj-fluid_geometry.adb:30` | [completed_no_unproved](logs/mj-fluid_geometry__angular_viscosity__adb_30.log) | 8 | 0 | 0 | 3.0 |
| `Moment` | `mj-fluid_geometry.adb:34` | [completed_no_unproved](logs/mj-fluid_geometry__moment__adb_34.log) | 12 | 0 | 0 | 3.0 |
| `Angular_Moment` | `mj-fluid_geometry.adb:38` | [unproved_checks](logs/mj-fluid_geometry__angular_moment__adb_38.log) | 10 | 1 | 0 | 8.7 |

## Diagnostics

### mj-fluid_geometry__normalize_axis__adb_14

- `mj-fluid_geometry.adb:16` (medium): range check might fail [reason for check: result of multiplication must fit in the type of the qualification] [provers reached time limit before completing the proof]

### mj-fluid_geometry__angular_moment__adb_38

- `mj-fluid_geometry.adb:40` (medium): range check might fail [reason for check: returned value must fit in the result type of the function] [possible fix: subprogram at mj-fluid_geometry.ads:44 should mention Angular and II and Imax and Slender in a precondition] [provers reached time limit before completing the proof]

