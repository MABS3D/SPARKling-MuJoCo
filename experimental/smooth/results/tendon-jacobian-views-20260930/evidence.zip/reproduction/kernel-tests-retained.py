import hashlib,json,sys
from pathlib import Path
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');base=Path('/var/tmp/sparkling-tendon-views-20260930');sys.path.insert(0,str(repo/'experimental/spatial-tendon-candidate/tests'))
import common
common.SCRATCH=base/'kernels-retained';common.SCRATCH.mkdir(exist_ok=True)
import test_spatial as tests
records=[]
for mode in ('validation','release'):
 exe=common.build(mode)
 result={'mode':mode,'geometry':tests.geometry_test(exe),'paths':tests.path_tests(exe),'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()};records.append(result);print(json.dumps(result),flush=True)
(base/'kernel-tests-retained.json').write_text(json.dumps(records,indent=2)+'\n')
