import hashlib,json,os,re,shutil,subprocess
from pathlib import Path
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');base=Path('/var/tmp/sparkling-tendon-views-20260930/proof');base.mkdir(exist_ok=False);snap=base/'source';snap.mkdir()
paths=list((repo/'experimental/spatial-tendon-candidate/src').glob('*.ad?'))+[repo/'src'/n for n in ('mj.ads','mj-types.ads','mj-quaternion_math.ads')]
hashes={}
for p in paths:shutil.copyfile(p,snap/p.name);hashes[str(p.relative_to(repo))]=hashlib.sha256(p.read_bytes()).hexdigest()
project=base/'proof.gpr';project.write_text('project Proof is\n for Source_Dirs use ("source");\n for Object_Dir use "obj";\n for Create_Missing_Dirs use "True";\n package Compiler is\n for Default_Switches ("Ada") use ("-gnat2022");\n end Compiler;\nend Proof;\n')
env=os.environ.copy();tc=Path('/var/tmp/sparkling-matrix-recovery/toolchains');env['PATH']=':'.join(str(p) for name in ('gnat','gprbuild','gnatprove') for p in (tc/name).glob('*/bin'))+':'+env['PATH'];results=[]
for filename,selected in [('mj-spatial_tendons.adb',{'Flat_Column','Evaluate','Evaluate_Flat'}),('mj-spatial_tendons.ads',{'Valid_Flat_Kinematics'})]:
 for line,txt in enumerate((snap/filename).read_text().splitlines(),1):
  m=re.match(r'   (?:function|procedure) (\w+)',txt)
  if not m or m[1] not in selected:continue
  name=m[1];log=base/(name+'.log');command=['python3',str(repo/'tools/guarded.py'),'--cap-mb','3000','--min-free-mb','2048','--timeout','150','--','gnatprove','-P',str(project),f'--limit-subp={filename}:{line}','--prover=cvc5,z3,altergo','--timeout=10','--memlimit=1000','-j2','--report=all','--warnings=continue','--checks-as-errors=on','--counterexamples=off']
  with log.open('w') as f:r=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
  reports=list((base/'obj').rglob('mj-spatial_tendons.spark'));records=[]
  if reports:
   shutil.copyfile(reports[0],base/(name+'.spark.json'));d=json.loads(reports[0].read_text());records=d.get('proof',[])
  data={'name':name,'returncode':r.returncode,'command':command,'proved':sum(x.get('severity')=='info' for x in records),'open':sum(x.get('severity')!='info' for x in records)};results.append(data);print(json.dumps(data),flush=True)
(base/'manifest.json').write_text(json.dumps({'source_sha256':hashes,'results':results},indent=2)+'\n')
