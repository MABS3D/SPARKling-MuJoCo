import importlib.util,json,sys
from pathlib import Path
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco')
base=Path('/var/tmp/sparkling-tendon-views-20260930')
sys.path.insert(0,str(repo/'experimental/spatial-tendon-candidate/tests'))
spec=importlib.util.spec_from_file_location('bench',repo/'experimental/spatial-tendon-candidate/tests/benchmark_integration.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mod.OUT=base/sys.argv[1];mod.MANIFEST=mod.OUT/'build.json';mod.SCRATCH=base
info=mod.build();print(json.dumps({'profile':sys.argv[1],'ada':info['ada'],'c':info['c']}))
