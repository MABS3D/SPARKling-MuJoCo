import importlib.util,itertools,json,os,statistics,subprocess,sys,time
from pathlib import Path
import numpy as np
import mujoco as mj
repo=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');base=Path('/var/tmp/sparkling-tendon-views-20260930');profile=sys.argv[1] if len(sys.argv)>1 else 'optimized';out=base/('performance-'+profile);out.mkdir(exist_ok=False)
sys.path.insert(0,str(repo/'experimental/spatial-tendon-candidate/tests'))
spec=importlib.util.spec_from_file_location('bench',repo/'experimental/spatial-tendon-candidate/tests/benchmark_integration.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
before=json.loads((base/'baseline/build.json').read_text());after=json.loads((base/profile/'build.json').read_text());exes={'baseline':before['ada'],'current':after['ada'],'c':after['c']}
cpu=sorted(os.sched_getaffinity(0))[-1];os.sched_setaffinity(0,{cpu});batches=1024;orders=list(itertools.permutations(exes))*2;results=[]
for arms in [1,4,8,32]:
 xml=mod.model(arms);m=mj.MjModel.from_xml_string(xml);model=out/f'arms-{arms}.mjb';mj.mj_saveModel(m,str(model));(out/f'arms-{arms}.xml').write_text(xml);records=[]
 for block,order in enumerate([tuple(exes),*orders]):
  sample={};sums={}
  for side in order:
   p=subprocess.run([exes[side],str(model),str(batches)],capture_output=True,text=True,check=True,timeout=120);(out/f'{arms}-{block}-{side}.txt').write_text(p.stdout);values=np.array([float(x) for x in p.stdout.split()]);assert len(values)==1+2*batches
   sums[side]=values[0];wall=values[1:1+batches]*1e6/64;cpu_times=values[1+batches:]*1e6/64
   sample[side]={'wall_us':float(wall.mean()),'cpu_us':float(cpu_times.mean()),'p95_us':float(np.percentile(wall,95)),'checksum':float(values[0])}
  for side in ['baseline','current']:np.testing.assert_allclose(sums[side],sums['c'],rtol=2e-11,atol=2e-11)
  if block:records.append({'order':order,'samples':sample})
 ratios={};rng=np.random.default_rng(20260930)
 for numerator,denominator in [('current','baseline'),('current','c')]:
  xs=np.array([row['samples'][numerator]['wall_us']/row['samples'][denominator]['wall_us'] for row in records]);boot=np.median(rng.choice(xs,size=(10000,len(xs)),replace=True),axis=1)
  ratios[f'{numerator}_over_{denominator}']={'paired_median':float(np.median(xs)),'bootstrap_95':np.quantile(boot,[.025,.975]).tolist()}
 summary={'dofs':m.nv,'bodies':m.nbody,'tendons':m.ntendon,'batches':batches,'steps':64,'blocks':12,'warmup_blocks':1,'median_wall_us':{side:statistics.median(row['samples'][side]['wall_us'] for row in records) for side in exes},'ratios':ratios,'eliminated_jacobian_temporary_bytes':48*m.nbody*m.nv,'records':records};results.append(summary);print(json.dumps({k:v for k,v in summary.items() if k!='records'}),flush=True)
(out/'results.json').write_text(json.dumps({'reference':mj.__version__,'logical_cpu':cpu,'workloads':results,'scope':'Full 64-step Euler; baseline/current/C, all six orders repeated twice; shared host; numerical checksums verified; inputs/reset/getters outside timing','load_average':os.getloadavg(),'binaries':exes},indent=2)+'\n')
