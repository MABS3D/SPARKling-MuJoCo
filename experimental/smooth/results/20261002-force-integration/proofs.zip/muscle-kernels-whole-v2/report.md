# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-l2_fn4cx/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-muscle_kernels.adb:1` | [unproved_checks](logs/mj-muscle_kernels__whole_unit.log) | 301 | 2 | 0 | 197.0 |

## Diagnostics

### mj-muscle_kernels__whole_unit

- `mj-muscle_kernels.adb:55` (medium): range check might fail [reason for check: returned value must fit in the result type of the function] [possible fix: subprogram at mj-muscle_kernels.ads:136 should mention P and R in a precondition] [provers reached time limit before completing the proof]
- `mj-muscle_kernels.ads:156` (medium): postcondition might fail [provers reached time limit before completing the proof]

