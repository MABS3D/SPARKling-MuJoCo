# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-fqrr9rzd/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Derivative` | `mj-activation.ads:14` | [completed_no_unproved](logs/mj-activation__derivative__ads_14.log) | 4 | 0 | 0 | 3.1 |
| `Raw_Next` | `mj-activation.ads:17` | [completed_no_unproved](logs/mj-activation__raw_next__ads_17.log) | 7 | 0 | 0 | 2.9 |
| `Next_Value` | `mj-activation.adb:20` | [completed_no_unproved](logs/mj-activation__next_value__adb_20.log) | 2 | 0 | 0 | 6.2 |
| `Prepare` | `mj-activation.adb:28` | [completed_no_unproved](logs/mj-activation__prepare__adb_28.log) | 5 | 0 | 0 | 3.9 |

## Diagnostics

