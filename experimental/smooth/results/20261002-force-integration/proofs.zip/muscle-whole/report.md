# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-9kyr9efo/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-muscle_kernels.adb:1` | [proof_timeout](logs/mj-muscle_kernels__whole_unit.log) | 0 | 0 | 0 | 120.2 |
| `whole unit` | `mj-muscle_actuation.adb:1` | [completed_no_unproved](logs/mj-muscle_actuation__whole_unit.log) | 24 | 0 | 0 | 8.3 |

## Diagnostics

