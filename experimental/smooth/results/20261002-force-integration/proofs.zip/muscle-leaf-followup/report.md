# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-oehfzbrj/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Optimal_Length` | `mj-muscle_kernels.adb:52` | [completed_no_unproved](logs/mj-muscle_kernels__optimal_length__adb_52.log) | 6 | 0 | 0 | 12.2 |
| `Bias` | `mj-muscle_kernels.adb:110` | [completed_no_unproved](logs/mj-muscle_kernels__bias__adb_110.log) | 21 | 0 | 0 | 12.4 |

## Diagnostics

