# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-bp8ywby8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Fixed_Kinematics` | `mj-tendon_kernels.adb:139` | [completed_no_unproved](logs/mj-tendon_kernels__fixed_kinematics__adb_139.log) | 10 | 0 | 0 | 3.1 |
| `Sparse_Dot` | `mj-tendon_kernels.adb:111` | [unproved_checks](logs/mj-tendon_kernels__sparse_dot__adb_111.log) | 56 | 1 | 0 | 25.2 |
| `Dot` | `mj-tendon_kernels.adb:54` | [completed_no_unproved](logs/mj-tendon_kernels__dot__adb_54.log) | 25 | 0 | 0 | 7.8 |

## Diagnostics

### mj-tendon_kernels__sparse_dot__adb_111

- `mj-tendon_kernels.adb:128` (medium): assertion might fail [provers reached time limit before completing the proof]

