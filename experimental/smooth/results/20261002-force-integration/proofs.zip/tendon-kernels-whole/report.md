# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-apcgy457/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `whole unit` | `mj-tendon_kernels.adb:1` | [unproved_checks](logs/mj-tendon_kernels__whole_unit.log) | 397 | 2 | 0 | 109.1 |

## Diagnostics

### mj-tendon_kernels__whole_unit

- `mj-tendon_kernels.adb:128` (medium): assertion might fail [provers reached time limit before completing the proof]
- `mj-tendon_kernels.ads:68` (medium): postcondition might fail, cannot prove Spring = Spring_Model (C, Length, Spring_Enabled) [provers reached time limit before completing the proof]

