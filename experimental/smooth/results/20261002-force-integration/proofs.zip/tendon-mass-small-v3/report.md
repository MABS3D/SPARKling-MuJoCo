# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-o9in2wgj/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Store_Mass_Pair` | `mj-spatial_tendon_models.adb:249` | [completed_no_unproved](logs/mj-spatial_tendon_models__store_mass_pair__adb_249.log) | 33 | 0 | 0 | 21.3 |
| `Add_Mass` | `mj-spatial_tendon_models.adb:260` | [completed_no_unproved](logs/mj-spatial_tendon_models__add_mass__adb_260.log) | 22 | 0 | 0 | 19.4 |

## Diagnostics

