# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-gjm3ylwe/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Sparse_Dot` | `mj-tendon_kernels.adb:111` | [unproved_checks](logs/mj-tendon_kernels__sparse_dot__adb_111.log) | 56 | 1 | 0 | 56.4 |
| `Spring_Damper` | `mj-tendon_kernels.adb:20` | [completed_no_unproved](logs/mj-tendon_kernels__spring_damper__adb_20.log) | 7 | 0 | 0 | 16.5 |

## Diagnostics

### mj-tendon_kernels__sparse_dot__adb_111

- `mj-tendon_kernels.adb:128` (medium): assertion might fail [provers reached time limit before completing the proof]

