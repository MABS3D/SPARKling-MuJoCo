with MJ.External_Forces;
--  Review draft. Semi-implicit Euler, including optional implicit linear
--  damping as in mj_Euler. A returned failure leaves qpos/qvel/time unchanged;
--  derived buffers and scratch may have been recomputed.
package MJ.Data.Euler with SPARK_Mode is
   --  These total value queries are safe to snapshot unconditionally on entry.
   pragma Unevaluated_Use_Of_Old (Allow);
   --  External: world-frame force/torque at each body COM for this call.
   --  Empty means no loads; a nonempty array must cover 0 .. Body_Count - 1.
   procedure Step
     (D : in out Simulation; Result : out Status;
      External : MJ.External_Forces.Wrench_Array := MJ.External_Forces.No_Loads) with Global => null, Pre => Valid_State (D),
     Post => Is_Empty (D) = Is_Empty (D)'Old;
   pragma Postcondition (Is_Ready (D) = Is_Ready (D)'Old);
   pragma Postcondition (Shape (D) = Shape (D)'Old);
   pragma Postcondition (Input_Values (D) = Input_Values (D)'Old);
   pragma Postcondition (if Result = Success then Is_Ready (D));
   pragma Postcondition (if Result = Success then Time (D) = Time (D)'Old + Step_Size (D)'Old);
   pragma Postcondition (if Result = Success then not Positions_Current (D) and then not Forces_Current (D));
   pragma Postcondition (if Result /= Success then State_Values (D) = State_Values (D)'Old
     and then Activation_Values (D) = Activation_Values (D)'Old);
   pragma Postcondition (Static => Configuration (D) = Configuration (D)'Old);

   pragma Postcondition (Static => (if Result = Success then
     Euler_State_Update (D, Position_Values (D)'Old, Velocity_Values (D)'Old,
       Step_Rates (D), Position_Values (D), Velocity_Values (D), Step_Size (D)'Old)));
private
   procedure Integrate (D : in out Simulation; Result : out Status) with Global => null, Pre => Is_Ready (D),
     Post => Is_Empty (D) = Is_Empty (D)'Old;
   pragma Postcondition (Is_Ready (D));
   pragma Postcondition (Shape (D) = Shape (D)'Old);
   pragma Postcondition (Input_Values (D) = Input_Values (D)'Old);
   pragma Postcondition (if Result = Success then Is_Ready (D));
   pragma Postcondition (if Result = Success then Time (D) = Time (D)'Old + Step_Size (D)'Old);
   pragma Postcondition (if Result = Success then not Positions_Current (D) and then not Forces_Current (D));
   pragma Postcondition (if Result /= Success then State_Values (D) = State_Values (D)'Old
     and then Activation_Values (D) = Activation_Values (D)'Old);
   pragma Postcondition (Static => Configuration (D) = Configuration (D)'Old);

   pragma Postcondition (Static => (if Result = Success then
     Euler_State_Update (D, Position_Values (D)'Old, Velocity_Values (D)'Old,
       Step_Rates (D), Position_Values (D), Velocity_Values (D), Step_Size (D)'Old)));
end MJ.Data.Euler;
