--  Checked executable boundary for the C/Spark differential suite.
with Ada.Command_Line;
with Ada.Exceptions;
with Ada.Text_IO; use Ada.Text_IO;
with Ada.Integer_Text_IO;
with MJ.Types; use MJ.Types;
with MJ.Fields;
with MJ.Models;
with MJ.MJB;
with MJ.Data; use MJ.Data;
with MJ.Data.Forward;
with MJ.Data.Forces;
with MJ.Data.Actuation;
with MJ.Data.Euler;
with MJ.Smooth_Math;
with MJ.External_Forces;

procedure Smooth_Probe is
   package Numbers is new Ada.Text_IO.Float_IO (Real);
   M : MJ.Models.Model;
   D : Simulation;
   Loaded : MJ.Fields.Load_Result;
   Result : Status;
   Cases, Steps : Integer;
   Input_Time : Real;
   Selected_Policy : Inertia_Policy := Compatible;
   With_External : constant Boolean := Ada.Command_Line.Argument_Count >= 3
     and then Ada.Command_Line.Argument (3) = "external";

   procedure Check (Expected : Status := Success) is
   begin
      if Result /= Expected then
         raise Program_Error with "expected " & Expected'Image & ", got " & Result'Image;
      end if;
   end Check;

   procedure Emit (Name : String; A : Real_Array) is
   begin
      Put (Name);
      for X of A loop
         Put (' ');
         Numbers.Put (X, Fore => 1, Aft => 17, Exp => 3);
      end loop;
      New_Line;
   end Emit;

   procedure Read_State (A : out State_Vector) is
      X : Real;
   begin
      for I in A'Range loop
         Numbers.Get (X);
         A (I) := X;
      end loop;
   end Read_State;

   procedure Check_Normalization is
      package Math renames MJ.Smooth_Math;
      use type Math.Vector;
      use type Math.Quaternion;
      V : Math.Vector;
      Q : Math.Quaternion;
      Accepted : Boolean;
   begin
      V := Math.Zero;
      Math.Normalize (V, Accepted);
      if Accepted or else V /= Math.Zero then
         raise Program_Error with "zero vector normalization";
      end if;
      V := [1.0e-300, -1.0e-300, 0.0];
      Math.Normalize (V, Accepted);
      if not Accepted or else not Math.Unit_Vector (V) or else V (0) /= -V (1) then
         raise Program_Error with "tiny vector normalization";
      end if;
      V := [Math.Work_Limit, -Math.Work_Limit, 0.0];
      Math.Normalize (V, Accepted);
      if not Accepted or else not Math.Unit_Vector (V) or else V (0) /= -V (1) then
         raise Program_Error with "large vector normalization";
      end if;
      V := [2.0 * Math.Work_Limit, 0.0, 0.0];
      Math.Normalize (V, Accepted);
      if Accepted or else V /= [2.0 * Math.Work_Limit, 0.0, 0.0] then
         raise Program_Error with "rejected vector changed";
      end if;
      Q := [others => 0.0];
      Math.Normalize (Q, Accepted);
      if Accepted or else Q /= [0.0, 0.0, 0.0, 0.0] then
         raise Program_Error with "zero quaternion normalization";
      end if;
      Q := [1.0e-100, 0.0, 0.0, 0.0];
      Math.Normalize (Q, Accepted);
      if Accepted or else Q /= [1.0e-100, 0.0, 0.0, 0.0] then
         raise Program_Error with "tiny quaternion changed";
      end if;
      Q := [Math.Work_Limit, Math.Work_Limit, -Math.Work_Limit, Math.Work_Limit];
      Math.Normalize (Q, Accepted);
      if not Accepted or else Q /= [0.5, 0.5, -0.5, 0.5] then
         raise Program_Error with "large quaternion normalization";
      end if;
   end Check_Normalization;
begin
   Check_Normalization;
   MJ.MJB.Load (Ada.Command_Line.Argument (1), (Contact_Cap => 0), M, Loaded);
   if Loaded.Status /= OK then
      raise Program_Error with "load: " & Loaded.Status'Image;
   end if;
   if Ada.Command_Line.Argument_Count > 1 then
      Selected_Policy := Inertia_Policy'Value (Ada.Command_Line.Argument (2));
   end if;
   Create (M, D, Result, Selected_Policy);
   if Result = Success and then Policy (D) /= Selected_Policy then
      raise Program_Error with "solver policy selection";
   end if;
   Put_Line ("create " & Result'Image);
   if Result /= Success then
      if not Is_Empty (D) then raise Program_Error with "rejected creation retained storage"; end if;
      MJ.Models.Free (M);
      return;
   end if;
   Create (M, D, Result);
   Check (Already_Allocated);
   if Policy (D) /= Selected_Policy then raise Program_Error with "allocated policy changed"; end if;
   MJ.Models.Free (M);  --  Exercise ownership: the snapshot must survive.
   declare
      N : constant Natural := Velocity_Count (D);
      U : constant Natural := Control_Count (D);
      Nq : constant Natural := Position_Count (D);
      Q : State_Vector (3 .. Nq + 2);
      V : State_Vector (3 .. N + 2);  --  Nonzero lower bound is intentional.
      Controls : State_Vector (0 .. Integer (U) - 1);
      Applied : State_Vector (0 .. Integer (N) - 1);
      Qout : Real_Array (0 .. Integer (Nq) - 1);
      Vout, Acc, G, B, P, A : Real_Array (0 .. Integer (N) - 1);
      Mass : Real_Array (0 .. Integer (N * N) - 1);
      Len, Vel, Force : Real_Array (0 .. Integer (U) - 1);
      TLen, TVel, TForce : Real_Array (0 .. Integer (Tendon_Count (D)) - 1);
      Empty : State_Vector (1 .. 0);
      Bad : State_Vector (0 .. Integer (N)) := [others => 0.0];
      Loads : MJ.External_Forces.Wrench_Array
        (0 .. (if With_External then Integer (Body_Count (D)) - 1 else -1));
      Bad_Loads : MJ.External_Forces.Wrench_Array (0 .. Body_Count (D));
      Shifted_Loads : MJ.External_Forces.Wrench_Array (1 .. Body_Count (D));
      Act : State_Vector (0 .. Integer (Activation_Count (D)) - 1) := [others => 0.0];
      T : Real;
      Pos : MJ.Smooth_Math.Vector;
      Quat : MJ.Smooth_Math.Quaternion;
   begin
      --  Explicit lifecycle/error checks; no assertions depend on optimization.
      Get_Acceleration (D, Acc, Result); Check (Stale_Results);
      Get_Tendon_Outputs (D, TLen, TVel, TForce, Result); Check (Stale_Results);
      Get_Mass_Matrix (D, Mass, Result); Check (Stale_Results);
      Set_State (D, Bad, Empty, 0.0, Result); Check (Invalid_Size);
      Set_Control (D, U, 0.0, Result); Check (Invalid_Index);
      Set_Applied_Force (D, N, 0.0, Result); Check (Invalid_Index);
      if N > 0 then
         declare
            Edge_Q : State_Vector (Natural'Last - Nq + 1 .. Natural'Last) := [others => 0.25];
            Edge_V : State_Vector (Natural'Last - N + 1 .. Natural'Last) := [others => -0.5];
            Edge_Qout : Real_Array (Edge_Q'Range);
            Edge_Vout : Real_Array (Edge_V'Range);
         begin
            Set_State (D, Edge_Q, Edge_V, 0.125, Result); Check;
            Get_State (D, Edge_Qout, Edge_Vout, T, Result); Check;
            if (for some X of Edge_Qout => X /= 0.25)
              or else (for some X of Edge_Vout => X /= -0.5) or else T /= 0.125
            then
               raise Program_Error with "state access at high array bounds";
            end if;
         end;
      end if;
      if Activation_Count (D) > 0 then
         declare
            Edge : State_Vector (Natural'Last - Activation_Count (D) + 1 .. Natural'Last) := [others => 0.25];
         begin
            Set_Activation (D, Edge, Result); Check;
            if (for some X of Activation_Values (D) => X /= 0.25) then
               raise Program_Error with "activation high array bounds";
            end if;
         end;
      end if;
      Ada.Integer_Text_IO.Get (Cases);
      for C in 1 .. Cases loop
         Reset (D, Result); Check;
         Get_State (D, Qout, Vout, T, Result); Check;
         if Policy (D) /= Selected_Policy then raise Program_Error with "reset changed policy"; end if;
         if Clamped_Dof (D) /= -1 then raise Program_Error with "warning reset"; end if;
         Emit ("reset_qpos", Qout);
         Emit ("reset_qvel", Vout);
         Read_State (Q); Read_State (V); Read_State (Controls); Read_State (Applied);
         Read_State (Act);
         if (for some X of Activation_Values (D) => X /= 0.0) then
            raise Program_Error with "activation reset";
         end if;
         declare
            Bad : State_Vector (0 .. Activation_Count (D)) := [others => 0.0];
            Before : constant Real_Array := Complete_State_Values (D);
         begin
            Set_Activation (D, Bad, Result); Check (Invalid_Size);
            if Complete_State_Values (D) /= Before then raise Program_Error with "activation invalid size"; end if;
         end;
         Set_Activation (D, Act, Result); Check;
         for W of Loads loop
            for X of W.Force loop Numbers.Get (Input_Time); X := Input_Time; end loop;
            for X of W.Torque loop Numbers.Get (Input_Time); X := Input_Time; end loop;
         end loop;
         Numbers.Get (Input_Time);
         Ada.Integer_Text_IO.Get (Steps);
         Set_State (D, Q, V, Input_Time, Result); Check;
         declare
            Before : constant Real_Array := Complete_State_Values (D);
         begin
            Set_State (D, Bad, Empty, 0.0, Result); Check (Invalid_Size);
            if Complete_State_Values (D) /= Before then
               raise Program_Error with "invalid Set_State changed state";
            end if;
         end;
         for I in Controls'Range loop
            Set_Control (D, I, Controls (I), Result); Check;
         end loop;
         for I in Applied'Range loop
            Set_Applied_Force (D, I, Applied (I), Result); Check;
         end loop;
         declare
            Before : constant Real_Array := Complete_State_Values (D);
            Inputs : constant Real_Array := Input_Values (D);
         begin
            MJ.Data.Forward.Evaluate (D, Result, Bad_Loads); Check (Invalid_Size);
            MJ.Data.Euler.Step (D, Result, Bad_Loads); Check (Invalid_Size);
            MJ.Data.Forward.Evaluate (D, Result, Shifted_Loads); Check (Invalid_Size);
            MJ.Data.Euler.Step (D, Result, Shifted_Loads); Check (Invalid_Size);
            if Complete_State_Values (D) /= Before or else Input_Values (D) /= Inputs then
               raise Program_Error with "invalid external loads changed inputs/state";
            end if;
         end;
         MJ.Data.Forward.Evaluate (D, Result, Loads);
         Put_Line ("forward " & Result'Image);
         Emit ("forward_clamped", [Real (Clamped_Dof (D))]);
         if Result = Success then
            Get_Acceleration (D, Acc, Result); Check; Emit ("qacc", Acc);
            Emit ("act_dot", Activation_Rates (D));
            MJ.Data.Actuation.Compute (D, Result); Check;
            MJ.Data.Forward.Evaluate (D, Result, Loads); Check;
            if Activation_Values (D) /= As_Reals (Act) then
               raise Program_Error with "Forward advanced activation";
            end if;
            if With_External then
               declare
                  Expected : constant Real_Array := Acc;
               begin
                  MJ.Data.Forward.Evaluate (D, Result); Check;
                  Get_Acceleration (D, Acc, Result); Check; Emit ("removed_qacc", Acc);
                  MJ.Data.Forward.Evaluate (D, Result, Loads); Check;
                  Get_Acceleration (D, Acc, Result); Check;
                  if Acc /= Expected then
                     raise Program_Error with "external load replacement accumulated or reused stale force";
                  end if;
               end;
            end if;
            Get_Mass_Matrix (D, Mass, Result); Check; Emit ("mass", Mass);
            --  Exercise the dense API independently of private storage,
            --  including caller arrays ending at Integer'Last.
            declare
               High : Real_Array ((if N = 0 then 1 else Integer'Last - N * N + 1) .. (if N = 0 then 0 else Integer'Last));
               Wrong : Real_Array (7 .. 7);
            begin
               if N > 0 then
                  Get_Mass_Matrix (D, High, Result); Check;
                  if High /= Mass then raise Program_Error with "mass at high array bounds"; end if;
               end if;
               if N /= 1 then
                  Get_Mass_Matrix (D, Wrong, Result); Check (Invalid_Size);
                  if Wrong (7) /= 0.0 then raise Program_Error with "invalid mass output"; end if;
               end if;
               Get_Mass_Matrix (D, Mass, Result); Check;
            end;
            Get_Forces (D, G, B, P, A, Result); Check;
            Emit ("gravity", G); Emit ("bias", B); Emit ("passive", P); Emit ("actuation", A);
            Get_Tendon_Outputs (D, TLen, TVel, TForce, Result); Check;
            declare
               WL, WV, WF : Real_Array (0 .. Tendon_Count (D));
            begin
               Get_Tendon_Outputs (D, WL, WV, WF, Result); Check (Invalid_Size);
               if (for some X of WL => X /= 0.0) or else (for some X of WV => X /= 0.0)
                 or else (for some X of WF => X /= 0.0) then
                  raise Program_Error with "invalid tendon output retained data";
               end if;
            end;
            Emit ("tendon_length", TLen); Emit ("tendon_velocity", TVel); Emit ("tendon_force", TForce);
            if Tendon_Count (D) > 0 then
               declare
                  Before : constant Real_Array := P;
               begin
                  MJ.Data.Forces.Compute (D, Result); Check;
                  MJ.Data.Forces.Compute (D, Result); Check;
                  MJ.Data.Forward.Evaluate (D, Result, Loads); Check;
                  Get_Forces (D, G, B, P, A, Result); Check;
                  if Before /= P then raise Program_Error with "tendon force accumulated twice"; end if;
               end;
            end if;
            Get_Actuator_Outputs (D, Len, Vel, Force, Result); Check;
            Emit ("length", Len); Emit ("velocity", Vel); Emit ("force", Force);
            for Body_Id in 0 .. Body_Count (D) - 1 loop
               Get_Body_Pose (D, Body_Id, Pos, Quat, Result); Check;
               Emit ("position", Real_Array (Pos));
               Emit ("quaternion", Real_Array (Quat));
            end loop;
            Get_State (D, Qout, Vout, T, Result); Check;
            Emit ("unchanged_qpos", Qout); Emit ("unchanged_qvel", Vout);
            Emit ("unchanged_time", [T]);
            --  Failed setters must also preserve already-current caches.
            Set_Control (D, U, 0.0, Result); Check (Invalid_Index);
            Set_Applied_Force (D, N, 0.0, Result); Check (Invalid_Index);
            Set_State (D, Bad, Empty, 0.0, Result); Check (Invalid_Size);
            if not Positions_Current (D) or else not Forces_Current (D) then
               raise Program_Error with "rejected setter invalidated current results";
            end if;
         end if;
         for S in 1 .. Steps loop
            declare
               Before : constant Real_Array := Complete_State_Values (D);
            begin
               MJ.Data.Euler.Step (D, Result, Loads);
               if Result /= Success and then Complete_State_Values (D) /= Before then
                  raise Program_Error with "failed Step changed state";
               end if;
            end;
            exit when Result /= Success;
         end loop;
         Emit ("act", Activation_Values (D));
         Put_Line ("step " & Result'Image);
         Emit ("step_clamped", [Real (Clamped_Dof (D))]);
         Get_State (D, Qout, Vout, T, Result); Check;
         Emit ("qpos", Qout); Emit ("qvel", Vout); Emit ("time", [T]);
         if Steps > 0 and then not Forces_Current (D) then
            Get_Acceleration (D, Acc, Result); Check (Stale_Results);
            --  A rejected acceleration can leave an assembled mass current;
            --  a successful state update invalidates both independently.
            Get_Mass_Matrix (D, Mass, Result);
            Check (if Mass_Current (D) then Success else Stale_Results);
         end if;
      end loop;
   end;
   Free (D); Free (D);
   Reset (D, Result); Check (Not_Allocated);
   Put_Line ("lifecycle PASS");
exception
   when E : others =>
      Put_Line (Standard_Error, Ada.Exceptions.Exception_Information (E));
      Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
end Smooth_Probe;
