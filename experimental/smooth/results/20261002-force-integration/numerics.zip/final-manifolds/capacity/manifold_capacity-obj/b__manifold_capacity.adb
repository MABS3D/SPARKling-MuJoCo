pragma Warnings (Off);
pragma Ada_95;
pragma Source_File_Name (ada_main, Spec_File_Name => "b__manifold_capacity.ads");
pragma Source_File_Name (ada_main, Body_File_Name => "b__manifold_capacity.adb");
pragma Suppress (Overflow_Check);
with Ada.Exceptions;

package body ada_main is

   E074 : Short_Integer; pragma Import (Ada, E074, "system__os_lib_E");
   E011 : Short_Integer; pragma Import (Ada, E011, "ada__exceptions_E");
   E015 : Short_Integer; pragma Import (Ada, E015, "system__soft_links_E");
   E024 : Short_Integer; pragma Import (Ada, E024, "system__exception_table_E");
   E037 : Short_Integer; pragma Import (Ada, E037, "ada__containers_E");
   E069 : Short_Integer; pragma Import (Ada, E069, "ada__io_exceptions_E");
   E053 : Short_Integer; pragma Import (Ada, E053, "ada__strings_E");
   E055 : Short_Integer; pragma Import (Ada, E055, "ada__strings__maps_E");
   E059 : Short_Integer; pragma Import (Ada, E059, "ada__strings__maps__constants_E");
   E042 : Short_Integer; pragma Import (Ada, E042, "interfaces__c_E");
   E025 : Short_Integer; pragma Import (Ada, E025, "system__exceptions_E");
   E087 : Short_Integer; pragma Import (Ada, E087, "system__object_reader_E");
   E048 : Short_Integer; pragma Import (Ada, E048, "system__dwarf_lines_E");
   E017 : Short_Integer; pragma Import (Ada, E017, "system__soft_links__initialize_E");
   E036 : Short_Integer; pragma Import (Ada, E036, "system__traceback__symbolic_E");
   E158 : Short_Integer; pragma Import (Ada, E158, "ada__assertions_E");
   E143 : Short_Integer; pragma Import (Ada, E143, "ada__numerics_E");
   E105 : Short_Integer; pragma Import (Ada, E105, "ada__strings__utf_encoding_E");
   E113 : Short_Integer; pragma Import (Ada, E113, "ada__tags_E");
   E103 : Short_Integer; pragma Import (Ada, E103, "ada__strings__text_buffers_E");
   E121 : Short_Integer; pragma Import (Ada, E121, "ada__streams_E");
   E137 : Short_Integer; pragma Import (Ada, E137, "system__file_control_block_E");
   E132 : Short_Integer; pragma Import (Ada, E132, "system__finalization_root_E");
   E130 : Short_Integer; pragma Import (Ada, E130, "ada__finalization_E");
   E129 : Short_Integer; pragma Import (Ada, E129, "system__file_io_E");
   E266 : Short_Integer; pragma Import (Ada, E266, "ada__streams__stream_io_E");
   E119 : Short_Integer; pragma Import (Ada, E119, "ada__text_io_E");
   E198 : Short_Integer; pragma Import (Ada, E198, "mj__activation_E");
   E202 : Short_Integer; pragma Import (Ada, E202, "mj__bounds_kernels_E");
   E259 : Short_Integer; pragma Import (Ada, E259, "mj__bytes_E");
   E264 : Short_Integer; pragma Import (Ada, E264, "mj__file_io_E");
   E185 : Short_Integer; pragma Import (Ada, E185, "mj__fluid_metadata_E");
   E191 : Short_Integer; pragma Import (Ada, E191, "mj__models_E");
   E208 : Short_Integer; pragma Import (Ada, E208, "mj__muscle_kernels_E");
   E206 : Short_Integer; pragma Import (Ada, E206, "mj__muscle_actuation_E");
   E164 : Short_Integer; pragma Import (Ada, E164, "mj__smooth_math_E");
   E175 : Short_Integer; pragma Import (Ada, E175, "mj__fluid_box_E");
   E173 : Short_Integer; pragma Import (Ada, E173, "mj__fluid_added_mass_E");
   E181 : Short_Integer; pragma Import (Ada, E181, "mj__fluid_geometry_E");
   E177 : Short_Integer; pragma Import (Ada, E177, "mj__fluid_lift_E");
   E179 : Short_Integer; pragma Import (Ada, E179, "mj__fluid_projection_E");
   E162 : Short_Integer; pragma Import (Ada, E162, "mj__fluid_transport_E");
   E196 : Short_Integer; pragma Import (Ada, E196, "mj__simple_kernels_E");
   E169 : Short_Integer; pragma Import (Ada, E169, "mj__smooth_kernels_E");
   E204 : Short_Integer; pragma Import (Ada, E204, "mj__smooth_actuation_E");
   E167 : Short_Integer; pragma Import (Ada, E167, "mj__smooth_dynamics_E");
   E200 : Short_Integer; pragma Import (Ada, E200, "mj__ancestor_rows_E");
   E230 : Short_Integer; pragma Import (Ada, E230, "mj__external_forces_E");
   E250 : Short_Integer; pragma Import (Ada, E250, "mj__pose_arithmetic_E");
   E210 : Short_Integer; pragma Import (Ada, E210, "mj__smooth_topology_E");
   E252 : Short_Integer; pragma Import (Ada, E252, "mj__solver_kernels_E");
   E254 : Short_Integer; pragma Import (Ada, E254, "mj__solver_reductions_E");
   E183 : Short_Integer; pragma Import (Ada, E183, "mj__spatial_kernels_E");
   E171 : Short_Integer; pragma Import (Ada, E171, "mj__fluid_kernels_E");
   E189 : Short_Integer; pragma Import (Ada, E189, "mj__spatial_dynamics_E");
   E248 : Short_Integer; pragma Import (Ada, E248, "mj__fused_rne_E");
   E187 : Short_Integer; pragma Import (Ada, E187, "mj__manifold_math_E");
   E244 : Short_Integer; pragma Import (Ada, E244, "mj__spatial_storage_E");
   E220 : Short_Integer; pragma Import (Ada, E220, "mj__tendon_kernels_E");
   E216 : Short_Integer; pragma Import (Ada, E216, "mj__tendon_vectors_E");
   E214 : Short_Integer; pragma Import (Ada, E214, "mj__tendon_geometry_E");
   E218 : Short_Integer; pragma Import (Ada, E218, "mj__spatial_tendons_E");
   E212 : Short_Integer; pragma Import (Ada, E212, "mj__spatial_tendon_models_E");
   E140 : Short_Integer; pragma Import (Ada, E140, "mj__data_E");
   E142 : Short_Integer; pragma Import (Ada, E142, "mj__data__fluid_phase_E");
   E160 : Short_Integer; pragma Import (Ada, E160, "mj__data__jacobians_E");
   E154 : Short_Integer; pragma Import (Ada, E154, "mj__data__fluid_tree_E");
   E224 : Short_Integer; pragma Import (Ada, E224, "mj__data__boundary_E");
   E228 : Short_Integer; pragma Import (Ada, E228, "mj__data__external_loads_E");
   E238 : Short_Integer; pragma Import (Ada, E238, "mj__data__manifold_actuation_E");
   E236 : Short_Integer; pragma Import (Ada, E236, "mj__data__actuation_phase_E");
   E232 : Short_Integer; pragma Import (Ada, E232, "mj__data__mass_publication_E");
   E242 : Short_Integer; pragma Import (Ada, E242, "mj__data__spatial_E");
   E240 : Short_Integer; pragma Import (Ada, E240, "mj__data__forces_phase_E");
   E226 : Short_Integer; pragma Import (Ada, E226, "mj__data__inertia_phase_E");
   E234 : Short_Integer; pragma Import (Ada, E234, "mj__data__pipeline_E");
   E246 : Short_Integer; pragma Import (Ada, E246, "mj__data__spatial_tendon_phase_E");
   E222 : Short_Integer; pragma Import (Ada, E222, "mj__data__euler_E");
   E270 : Short_Integer; pragma Import (Ada, E270, "mj__validation_E");
   E257 : Short_Integer; pragma Import (Ada, E257, "mj__mjb_E");
   E262 : Short_Integer; pragma Import (Ada, E262, "mj__mjb__readers_E");

   Sec_Default_Sized_Stacks : array (1 .. 1) of aliased System.Secondary_Stack.SS_Stack (System.Parameters.Runtime_Default_Sec_Stack_Size);

   Local_Priority_Specific_Dispatching : constant String := "";
   Local_Interrupt_States : constant String := "";

   Is_Elaborated : Boolean := False;

   procedure finalize_library is
   begin
      E119 := E119 - 1;
      declare
         procedure F1;
         pragma Import (Ada, F1, "ada__text_io__finalize_spec");
      begin
         F1;
      end;
      E266 := E266 - 1;
      declare
         procedure F2;
         pragma Import (Ada, F2, "ada__streams__stream_io__finalize_spec");
      begin
         F2;
      end;
      declare
         procedure F3;
         pragma Import (Ada, F3, "system__file_io__finalize_body");
      begin
         E129 := E129 - 1;
         F3;
      end;
      declare
         procedure Reraise_Library_Exception_If_Any;
            pragma Import (Ada, Reraise_Library_Exception_If_Any, "__gnat_reraise_library_exception_if_any");
      begin
         Reraise_Library_Exception_If_Any;
      end;
   end finalize_library;

   procedure adafinal is
      procedure s_stalib_adafinal;
      pragma Import (Ada, s_stalib_adafinal, "system__standard_library__adafinal");

      procedure Runtime_Finalize;
      pragma Import (C, Runtime_Finalize, "__gnat_runtime_finalize");

   begin
      if not Is_Elaborated then
         return;
      end if;
      Is_Elaborated := False;
      Runtime_Finalize;
      s_stalib_adafinal;
   end adafinal;

   type No_Param_Proc is access procedure;
   pragma Favor_Top_Level (No_Param_Proc);

   procedure adainit is
      Main_Priority : Integer;
      pragma Import (C, Main_Priority, "__gl_main_priority");
      Time_Slice_Value : Integer;
      pragma Import (C, Time_Slice_Value, "__gl_time_slice_val");
      WC_Encoding : Character;
      pragma Import (C, WC_Encoding, "__gl_wc_encoding");
      Locking_Policy : Character;
      pragma Import (C, Locking_Policy, "__gl_locking_policy");
      Queuing_Policy : Character;
      pragma Import (C, Queuing_Policy, "__gl_queuing_policy");
      Task_Dispatching_Policy : Character;
      pragma Import (C, Task_Dispatching_Policy, "__gl_task_dispatching_policy");
      Priority_Specific_Dispatching : System.Address;
      pragma Import (C, Priority_Specific_Dispatching, "__gl_priority_specific_dispatching");
      Num_Specific_Dispatching : Integer;
      pragma Import (C, Num_Specific_Dispatching, "__gl_num_specific_dispatching");
      Main_CPU : Integer;
      pragma Import (C, Main_CPU, "__gl_main_cpu");
      Interrupt_States : System.Address;
      pragma Import (C, Interrupt_States, "__gl_interrupt_states");
      Num_Interrupt_States : Integer;
      pragma Import (C, Num_Interrupt_States, "__gl_num_interrupt_states");
      Unreserve_All_Interrupts : Integer;
      pragma Import (C, Unreserve_All_Interrupts, "__gl_unreserve_all_interrupts");
      Detect_Blocking : Integer;
      pragma Import (C, Detect_Blocking, "__gl_detect_blocking");
      Default_Stack_Size : Integer;
      pragma Import (C, Default_Stack_Size, "__gl_default_stack_size");
      Default_Secondary_Stack_Size : System.Parameters.Size_Type;
      pragma Import (C, Default_Secondary_Stack_Size, "__gnat_default_ss_size");
      Bind_Env_Addr : System.Address;
      pragma Import (C, Bind_Env_Addr, "__gl_bind_env_addr");
      Interrupts_Default_To_System : Integer;
      pragma Import (C, Interrupts_Default_To_System, "__gl_interrupts_default_to_system");

      procedure Runtime_Initialize (Install_Handler : Integer);
      pragma Import (C, Runtime_Initialize, "__gnat_runtime_initialize");

      Finalize_Library_Objects : No_Param_Proc;
      pragma Import (C, Finalize_Library_Objects, "__gnat_finalize_library_objects");
      Binder_Sec_Stacks_Count : Natural;
      pragma Import (Ada, Binder_Sec_Stacks_Count, "__gnat_binder_ss_count");
      Default_Sized_SS_Pool : System.Address;
      pragma Import (Ada, Default_Sized_SS_Pool, "__gnat_default_ss_pool");

   begin
      if Is_Elaborated then
         return;
      end if;
      Is_Elaborated := True;
      Main_Priority := -1;
      Time_Slice_Value := -1;
      WC_Encoding := 'b';
      Locking_Policy := ' ';
      Queuing_Policy := ' ';
      Task_Dispatching_Policy := ' ';
      Priority_Specific_Dispatching :=
        Local_Priority_Specific_Dispatching'Address;
      Num_Specific_Dispatching := 0;
      Main_CPU := -1;
      Interrupt_States := Local_Interrupt_States'Address;
      Num_Interrupt_States := 0;
      Unreserve_All_Interrupts := 0;
      Detect_Blocking := 0;
      Default_Stack_Size := -1;

      ada_main'Elab_Body;
      Default_Secondary_Stack_Size := System.Parameters.Runtime_Default_Sec_Stack_Size;
      Binder_Sec_Stacks_Count := 1;
      Default_Sized_SS_Pool := Sec_Default_Sized_Stacks'Address;

      Runtime_Initialize (1);

      Finalize_Library_Objects := finalize_library'access;

      Ada.Exceptions'Elab_Spec;
      System.Soft_Links'Elab_Spec;
      System.Exception_Table'Elab_Body;
      E024 := E024 + 1;
      Ada.Containers'Elab_Spec;
      E037 := E037 + 1;
      Ada.Io_Exceptions'Elab_Spec;
      E069 := E069 + 1;
      Ada.Strings'Elab_Spec;
      E053 := E053 + 1;
      Ada.Strings.Maps'Elab_Spec;
      E055 := E055 + 1;
      Ada.Strings.Maps.Constants'Elab_Spec;
      E059 := E059 + 1;
      Interfaces.C'Elab_Spec;
      E042 := E042 + 1;
      System.Exceptions'Elab_Spec;
      E025 := E025 + 1;
      System.Object_Reader'Elab_Spec;
      E087 := E087 + 1;
      System.Dwarf_Lines'Elab_Spec;
      E048 := E048 + 1;
      System.Os_Lib'Elab_Body;
      E074 := E074 + 1;
      System.Soft_Links.Initialize'Elab_Body;
      E017 := E017 + 1;
      E015 := E015 + 1;
      System.Traceback.Symbolic'Elab_Body;
      E036 := E036 + 1;
      E011 := E011 + 1;
      Ada.Assertions'Elab_Spec;
      E158 := E158 + 1;
      Ada.Numerics'Elab_Spec;
      E143 := E143 + 1;
      Ada.Strings.Utf_Encoding'Elab_Spec;
      E105 := E105 + 1;
      Ada.Tags'Elab_Spec;
      Ada.Tags'Elab_Body;
      E113 := E113 + 1;
      Ada.Strings.Text_Buffers'Elab_Spec;
      E103 := E103 + 1;
      Ada.Streams'Elab_Spec;
      E121 := E121 + 1;
      System.File_Control_Block'Elab_Spec;
      E137 := E137 + 1;
      System.Finalization_Root'Elab_Spec;
      E132 := E132 + 1;
      Ada.Finalization'Elab_Spec;
      E130 := E130 + 1;
      System.File_Io'Elab_Body;
      E129 := E129 + 1;
      Ada.Streams.Stream_Io'Elab_Spec;
      E266 := E266 + 1;
      Ada.Text_Io'Elab_Spec;
      Ada.Text_Io'Elab_Body;
      E119 := E119 + 1;
      E198 := E198 + 1;
      E202 := E202 + 1;
      E259 := E259 + 1;
      E264 := E264 + 1;
      E185 := E185 + 1;
      E191 := E191 + 1;
      E208 := E208 + 1;
      E206 := E206 + 1;
      E164 := E164 + 1;
      E175 := E175 + 1;
      E173 := E173 + 1;
      E181 := E181 + 1;
      E177 := E177 + 1;
      E179 := E179 + 1;
      E162 := E162 + 1;
      E196 := E196 + 1;
      E169 := E169 + 1;
      E204 := E204 + 1;
      E167 := E167 + 1;
      E200 := E200 + 1;
      E230 := E230 + 1;
      E250 := E250 + 1;
      E210 := E210 + 1;
      E252 := E252 + 1;
      E254 := E254 + 1;
      E183 := E183 + 1;
      E171 := E171 + 1;
      E189 := E189 + 1;
      E248 := E248 + 1;
      E187 := E187 + 1;
      E244 := E244 + 1;
      E220 := E220 + 1;
      E216 := E216 + 1;
      E214 := E214 + 1;
      E218 := E218 + 1;
      E212 := E212 + 1;
      E140 := E140 + 1;
      E160 := E160 + 1;
      E154 := E154 + 1;
      E142 := E142 + 1;
      E224 := E224 + 1;
      E228 := E228 + 1;
      E238 := E238 + 1;
      E236 := E236 + 1;
      E232 := E232 + 1;
      E242 := E242 + 1;
      E234 := E234 + 1;
      E226 := E226 + 1;
      E246 := E246 + 1;
      E240 := E240 + 1;
      E222 := E222 + 1;
      E270 := E270 + 1;
      E262 := E262 + 1;
      E257 := E257 + 1;
   end adainit;

   procedure Ada_Main_Program;
   pragma Import (Ada, Ada_Main_Program, "_ada_manifold_capacity");

   function main
     (argc : Integer;
      argv : System.Address;
      envp : System.Address)
      return Integer
   is
      procedure Initialize (Addr : System.Address);
      pragma Import (C, Initialize, "__gnat_initialize");

      procedure Finalize;
      pragma Import (C, Finalize, "__gnat_finalize");
      SEH : aliased array (1 .. 2) of Integer;

      Ensure_Reference : aliased System.Address := Ada_Main_Program_Name'Address;
      pragma Volatile (Ensure_Reference);

   begin
      if gnat_argc = 0 then
         gnat_argc := argc;
         gnat_argv := argv;
      end if;
      gnat_envp := envp;

      Initialize (SEH'Address);
      adainit;
      Ada_Main_Program;
      adafinal;
      Finalize;
      return (gnat_exit_status);
   end;

--  BEGIN Object file/option list
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-types.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-activation.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-bounds_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-bytes.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fields.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-file_io.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fixed.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_metadata.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-models.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-models-gen_clauses.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-models-validity.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-muscle_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-muscle_actuation.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-smooth_math.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_box.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_added_mass.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_geometry.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_lift.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_projection.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_transport.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-simple_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-smooth_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-smooth_actuation.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-smooth_dynamics.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-ancestor_rows.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-external_forces.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-pose_arithmetic.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-smooth_topology.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-solver_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-solver_reductions.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-spatial_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fluid_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-spatial_dynamics.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-fused_rne.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-manifold_math.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-spatial_storage.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-tendon_kernels.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-tendon_vectors.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-tendon_geometry.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-spatial_tendons.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-spatial_tendon_models.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-jacobians.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-fluid_tree.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-fluid_phase.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-boundary.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-external_loads.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-manifold_actuation.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-actuation_phase.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-mass_publication.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-spatial.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-pipeline.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-inertia_phase.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-spatial_tendon_phase.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-forces_phase.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-data-euler.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-validation.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-mjb-readers.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/mj-mjb.o
   --   /var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/manifold_capacity.o
   --   -L/var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/
   --   -L/var/tmp/sparkling-force-integration-20261002/final-manifolds/capacity/manifold_capacity-obj/
   --   -L/var/tmp/sparkling-matrix-recovery/toolchains/gnat/gnat-x86_64-linux-16.1.0-1/lib/gcc/x86_64-pc-linux-gnu/16.1.0/adalib/
   --   -static
   --   -lgnat
   --   -lm
   --   -ldl
--  END Object file/option list   

end ada_main;
