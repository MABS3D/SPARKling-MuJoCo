package body MJ.Nonlinear_Passive with SPARK_Mode is
   function Polynomial (Linear : Nonneg_Tier0; Quadratic, Cubic : Tier0_Real;
                        X : Displacement) return Coefficient is
   begin
      return (Linear + Quadratic * X) + Cubic * (X * X);
   end Polynomial;

   function Damping_Derivative
     (Linear : Nonneg_Tier0; Quadratic, Cubic, Velocity : Tier0_Real)
      return Coefficient is
      X : constant Tier0_Real := abs Velocity;
   begin
      return (Linear + (2.0 * Quadratic) * X) + (3.0 * Cubic) * (X * X);
   end Damping_Derivative;

   function Passive_Force
     (Qpos, Reference, Velocity : Tier0_Real; Stiffness, Damping : Nonneg_Tier0;
      Stiffness_Quadratic, Stiffness_Cubic, Damping_Quadratic, Damping_Cubic : Tier0_Real;
      Spring_Enabled, Damper_Enabled : Boolean) return Force is
      Spring, Damper : Force := 0.0;
   begin
      if Spring_Enabled then
         Spring := -(Qpos - Reference) * Polynomial
           (Stiffness, Stiffness_Quadratic, Stiffness_Cubic, Qpos - Reference);
      end if;
      if Damper_Enabled then
         Damper := -Velocity * Polynomial
           (Damping, Damping_Quadratic, Damping_Cubic, abs Velocity);
      end if;
      return Spring + Damper;
   end Passive_Force;
end MJ.Nonlinear_Passive;
