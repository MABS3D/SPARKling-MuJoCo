--  MuJoCo 3.14 scalar joint polynomial laws (mjNPOLY = 2).
--  Preserve C power accumulation and addition order, including the derivative.
with MJ.Types; use MJ.Types;
package MJ.Nonlinear_Passive with SPARK_Mode is
   subtype Displacement is Real range -2.0e10 .. 2.0e10;
   subtype Coefficient is Real range -1.0e32 .. 1.0e32;
   subtype Force is Real range -1.0e43 .. 1.0e43;
   function Polynomial (Linear : Nonneg_Tier0; Quadratic, Cubic : Tier0_Real;
                        X : Displacement) return Coefficient with
     Global => null,
     Post => Polynomial'Result = (Linear + Quadratic * X) + Cubic * (X * X);
   pragma Inline_Always (Polynomial);
   function Damping_Derivative
     (Linear : Nonneg_Tier0; Quadratic, Cubic, Velocity : Tier0_Real)
      return Coefficient with Global => null,
     Post => Damping_Derivative'Result =
       (Linear + (2.0 * Quadratic) * abs Velocity)
         + (3.0 * Cubic) * (abs Velocity * abs Velocity);
   pragma Inline_Always (Damping_Derivative);
   function Passive_Force
     (Qpos, Reference, Velocity : Tier0_Real; Stiffness, Damping : Nonneg_Tier0;
      Stiffness_Quadratic, Stiffness_Cubic, Damping_Quadratic, Damping_Cubic : Tier0_Real;
      Spring_Enabled, Damper_Enabled : Boolean) return Force with Global => null,
     Post => Passive_Force'Result =
       (if Spring_Enabled then -(Qpos - Reference) * Polynomial
          (Stiffness, Stiffness_Quadratic, Stiffness_Cubic, Qpos - Reference) else 0.0)
       + (if Damper_Enabled then -Velocity * Polynomial
          (Damping, Damping_Quadratic, Damping_Cubic, abs Velocity) else 0.0);
   pragma Inline_Always (Passive_Force);
end MJ.Nonlinear_Passive;
