# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-whtn0ve5/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Solve_Strict_Buffers` | `mj-data-inertia_phase.adb:1602` | [unproved_checks](logs/mj-data-inertia_phase__solve_strict_buffers__adb_1602.log) | 51 | 1 | 0 | 158.3 |

## Diagnostics

### mj-data-inertia_phase__solve_strict_buffers__adb_1602

- `mj-data-inertia_phase.adb:1659` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove abs Factor (Off (N, K, K)) <= Matrix_Norm [provers reached time limit before completing the proof]

