# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-upa557fk/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Polynomial` | `mj-nonlinear_passive.adb:2` | [completed_no_unproved](logs/mj-nonlinear_passive__polynomial__adb_2.log) | 12 | 0 | 0 | 23.0 |
| `Damping_Derivative` | `mj-nonlinear_passive.adb:8` | [unproved_checks](logs/mj-nonlinear_passive__damping_derivative__adb_8.log) | 17 | 1 | 0 | 41.4 |
| `Passive_Force` | `mj-nonlinear_passive.adb:16` | [unproved_checks](logs/mj-nonlinear_passive__passive_force__adb_16.log) | 18 | 1 | 0 | 36.7 |

## Diagnostics

### mj-nonlinear_passive__damping_derivative__adb_8

- `mj-nonlinear_passive.ads:18` (medium): float overflow check might fail [reason for check: result of floating-point addition must be bounded] [possible fix: subprogram at line 13 should mention Cubic and Linear and Quadratic and Velocity in a precondition] [provers reached time limit before completing the proof]

### mj-nonlinear_passive__passive_force__adb_16

- `mj-nonlinear_passive.ads:24` (medium): postcondition might fail [provers reached time limit before completing the proof]

