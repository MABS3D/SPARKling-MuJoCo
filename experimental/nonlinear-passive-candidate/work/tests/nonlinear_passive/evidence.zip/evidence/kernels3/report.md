# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-83d7z5nq/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Polynomial` | `mj-nonlinear_passive.adb:2` | [completed_no_unproved](logs/mj-nonlinear_passive__polynomial__adb_2.log) | 12 | 0 | 0 | 11.0 |
| `Damping_Derivative` | `mj-nonlinear_passive.adb:8` | [completed_no_unproved](logs/mj-nonlinear_passive__damping_derivative__adb_8.log) | 11 | 0 | 0 | 7.8 |
| `Force_Component` | `mj-nonlinear_passive.adb:16` | [completed_no_unproved](logs/mj-nonlinear_passive__force_component__adb_16.log) | 4 | 0 | 0 | 4.9 |
| `Damper_Component` | `mj-nonlinear_passive.adb:22` | [completed_no_unproved](logs/mj-nonlinear_passive__damper_component__adb_22.log) | 6 | 0 | 0 | 7.5 |
| `Passive_Force` | `mj-nonlinear_passive.adb:28` | [completed_no_unproved](logs/mj-nonlinear_passive__passive_force__adb_28.log) | 8 | 0 | 0 | 14.1 |

## Diagnostics

