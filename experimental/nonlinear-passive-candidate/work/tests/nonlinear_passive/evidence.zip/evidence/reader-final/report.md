# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-lnawpvrq/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Read_Joint_Config` | `mj-data.adb:539` | [unproved_checks](logs/mj-data__read_joint_config__adb_539.log) | 79 | 2 | 0 | 164.0 |

## Diagnostics

### mj-data__read_joint_config__adb_539

- `mj-data.adb:546` (medium): postcondition might fail [provers reached time and memory limit before completing the proof]
- `mj-data.adb:570` (medium): pointer dereference check might fail [provers reached time and memory limit before completing the proof]

