# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-jdamn589/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Solve_Strict_Buffers` | `mj-data-inertia_phase.adb:1602` | [proof_timeout](logs/mj-data-inertia_phase__solve_strict_buffers__adb_1602.log) | 0 | 0 | 0 | 180.4 |
| `Solve` | `mj-data-inertia_phase.adb:1923` | [completed_no_unproved](logs/mj-data-inertia_phase__solve__adb_1923.log) | 19 | 0 | 0 | 132.9 |
| `Solve` | `mj-data-inertia_phase.adb:1943` | [completed_no_unproved](logs/mj-data-inertia_phase__solve__adb_1943.log) | 19 | 0 | 0 | 7.9 |

## Diagnostics

