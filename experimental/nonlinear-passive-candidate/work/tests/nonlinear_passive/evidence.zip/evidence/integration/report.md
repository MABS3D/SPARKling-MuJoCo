# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-z_diw6ap/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Joint_Element` | `mj-data.adb:105` | [completed_no_unproved](logs/mj-data__joint_element__adb_105.log) | 31 | 0 | 0 | 52.6 |
| `Dof_Element` | `mj-data.adb:148` | [completed_no_unproved](logs/mj-data__dof_element__adb_148.log) | 23 | 0 | 0 | 17.8 |
| `Read_Joint_Config` | `mj-data.adb:539` | [unproved_checks](logs/mj-data__read_joint_config__adb_539.log) | 79 | 1 | 0 | 65.3 |
| `Passive_Buffers` | `mj-data-forces_phase.adb:371` | [completed_no_unproved](logs/mj-data-forces_phase__passive_buffers__adb_371.log) | 39 | 0 | 0 | 50.1 |
| `Damping_Present` | `mj-data-inertia_phase.adb:2157` | [completed_no_unproved](logs/mj-data-inertia_phase__damping_present__adb_2157.log) | 21 | 0 | 0 | 45.7 |
| `Load_Ancestor_Buffers` | `mj-data-inertia_phase.adb:1839` | [completed_no_unproved](logs/mj-data-inertia_phase__load_ancestor_buffers__adb_1839.log) | 17 | 0 | 0 | 15.4 |
| `Solve_Strict_Buffers` | `mj-data-inertia_phase.adb:1602` | [unproved_checks](logs/mj-data-inertia_phase__solve_strict_buffers__adb_1602.log) | 49 | 3 | 0 | 110.3 |
| `Solve_Workspace` | `mj-data-inertia_phase.adb:1887` | [completed_no_unproved](logs/mj-data-inertia_phase__solve_workspace__adb_1887.log) | 4 | 0 | 0 | 5.9 |
| `Solve` | `mj-data-inertia_phase.adb:1922` | [unproved_checks](logs/mj-data-inertia_phase__solve__adb_1922.log) | 16 | 1 | 0 | 65.9 |
| `Solve` | `mj-data-inertia_phase.adb:1942` | [unproved_checks](logs/mj-data-inertia_phase__solve__adb_1942.log) | 16 | 1 | 0 | 10.9 |

## Diagnostics

### mj-data__read_joint_config__adb_539

- `mj-data.adb:546` (medium): postcondition might fail [provers reached time and memory limit before completing the proof]

### mj-data-inertia_phase__solve_strict_buffers__adb_1602

- `mj-data-inertia_phase.adb:1656` (medium): loop invariant might not be preserved by an arbitrary iteration, cannot prove abs Factor (Off (N, K, K)) <= Matrix_Norm [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:1657` (medium): range check might fail [reason for check: slice bounds must fit in the underlying array] [provers reached time limit before completing the proof]
- `mj-data-inertia_phase.adb:1669` (medium): loop invariant might fail in first iteration, cannot prove abs Factor (Off (N, K, K)) <= Matrix_Norm [provers reached time limit before completing the proof]

### mj-data-inertia_phase__solve__adb_1922

- `mj-data-inertia_phase.adb:1926` (medium): postcondition might fail [provers reached time limit before completing the proof]

### mj-data-inertia_phase__solve__adb_1942

- `mj-data-inertia_phase.adb:1926` (medium): postcondition might fail [provers reached time limit before completing the proof]

