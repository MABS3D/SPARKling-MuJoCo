static int HessianConeFoldFaster(const mjPrimalContext* ctx) {
  int nefc = ctx->nefc;

  // U: update flops, S: J'*D*J flops
  mjtSize U = 0, S = 0;
  for (int i=0; i < nefc; i++) {
    int nnz = ctx->J_rownnz[i];
    if (ctx->efc_state[i] == mjCNSTRSTATE_QUADRATIC) {
      S += (mjtSize)nnz * nnz;
    } else if (ctx->efc_state[i] == mjCNSTRSTATE_CONE) {
      int dim = ctx->contact[ctx->efc_id[i]].dim;
      int lastcol = ctx->J_colind[ctx->J_rowadr[i] + nnz - 1];
      U += (mjtSize)dim * ctx->pathcost[lastcol];
      S += (mjtSize)dim * nnz * nnz;
      i += dim - 1;
    }
  }

  return 10*U > 3*(ctx->Lflops + 2*S);
}
