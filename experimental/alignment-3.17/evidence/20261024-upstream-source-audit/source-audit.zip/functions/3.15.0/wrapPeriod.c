static mjtNum wrapPeriod(const mjModel* m, int i) {
  // servo shape: fixed gain, affine bias, matching kp, setpoint input
  mjtDyn dyntype = m->actuator_dyntype[i];
  int servo = m->actuator_gaintype[i] == mjGAIN_FIXED  &&
              m->actuator_biastype[i] == mjBIAS_AFFINE &&
              m->actuator_gainprm[mjNGAIN*i] == -m->actuator_biasprm[mjNBIAS*i+1] &&
              (dyntype == mjDYN_NONE || dyntype == mjDYN_INTEGRATOR);

  // PID shape: kp and kv are single-sourced in the affine bias
  int pid = m->actuator_gaintype[i] == mjGAIN_PID;

  if (!servo && !pid) {
    return 0;
  }

  const mjtNum* gear = m->actuator_gear+6*m->actuator_outadr[i];
  mjtTrn trntype = m->actuator_trntype[i];

  // site transmission with refsite and purely rotational gear
  if (trntype == mjTRN_SITE && m->actuator_trnid[2*i+1] >= 0 &&
      !gear[0] && !gear[1] && !gear[2]) {
    return 2*mjPI * mju_norm3(gear+3);
  }

  // joint transmission on a ball joint
  if ((trntype == mjTRN_JOINT || trntype == mjTRN_JOINTINPARENT) &&
      m->jnt_type[m->actuator_trnid[2*i]] == mjJNT_BALL) {
    return 2*mjPI * mju_norm3(gear);
  }

  return 0;
}
