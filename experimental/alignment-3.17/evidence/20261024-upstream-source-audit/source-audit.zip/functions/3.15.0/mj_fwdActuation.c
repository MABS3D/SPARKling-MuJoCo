void mj_fwdActuation(const mjModel* m, mjData* d) {
  TM_START;
  int nv = m->nv, nu = m->nu, nactuator = m->nactuator, nout = m->nout, ntendon = m->ntendon;
  mjtNum gain, bias, tau;
  mjtNum *force = d->actuator_force;

  // clear actuator_force
  mju_zero(force, nout);

  int sleep_filter = mjENABLED(mjENBL_SLEEP);

  // disabled or no actuation: return
  if (nactuator == 0 || mjDISABLED(mjDSBL_ACTUATION)) {
    mju_zero(d->qfrc_actuator, nv);
    TM_END(mjTIMER_ACTUATION);
    return;
  }

  // any tendon transmission targets with force limits
  int tendon_frclimited = 0;

  // local copy of ctrl
  mj_markStack(d);
  mjtNum *ctrl = mjSTACKALLOC(d, nu, mjtNum);

  // copy controls, overwrite delayed actuators from history buffer
  mju_copy(ctrl, d->ctrl, nu);
  for (int i = 0; i < nactuator; i++) {
    if (m->actuator_delay[i]) {
      int adr = m->actuator_ctrladr[i];
      const mjtNum* ptr = mj_readCtrl(m, d, i, d->time, ctrl + adr, -1);
      if (ptr) mju_copy(ctrl + adr, ptr, m->actuator_ctrlnum[i]);
    }
  }

  // clamp local copy
  if (!mjDISABLED(mjDSBL_CLAMPCTRL)) {
    clampVec(ctrl, m->actuator_ctrlrange, m->actuator_ctrllimited, nu, NULL);
  }

  // check controls, set all to 0 if any are bad
  for (int i=0; i < nu; i++) {
    if (mju_isBad(ctrl[i])) {
      mj_warning(d, mjWARN_BADCTRL, i);
      mju_zero(ctrl, nu);
      break;
    }
  }

  // act_dot for stateful actuators
  for (int i=0; i < nactuator; i++) {
    if (sleep_filter && mj_sleepState(m, d, mjOBJ_ACTUATOR, i) == mjS_ASLEEP) {
      continue;
    }

    int act_first = m->actuator_actadr[i];
    if (act_first < 0) {
      continue;
    }

    // addresses of the actuator's input and output blocks
    int uadr = m->actuator_ctrladr[i];
    int oadr = m->actuator_outadr[i];

    // zero act_dot for actuator plugins
    int actnum = m->actuator_actnum[i];
    if (actnum) {
      mju_zero(d->act_dot + act_first, actnum);
    }

    // extract info
    const mjtNum* dynprm = m->actuator_dynprm + i*mjNDYN;
    mjtDyn dyntype = m->actuator_dyntype[i];

    // index into the last element in act. For most actuators it's also the
    // first element, but actuator plugins might store their own state in act
    int act_last = act_first + actnum - 1;

    // compute act_dot according to dynamics type
    switch (dyntype) {
    case mjDYN_INTEGRATOR: {        // simple integrator, one per control
      int num = m->actuator_ctrlnum[i];
      for (int j=0; j < num; j++) {
        d->act_dot[act_last-num+1+j] = ctrl[uadr+j];
      }
      break;
    }

    case mjDYN_FILTER:              // linear filter: dynprm = tau
    case mjDYN_FILTEREXACT:
      tau = mju_max(mjMINVAL, dynprm[0]);
      d->act_dot[act_last] = (ctrl[uadr] - d->act[act_last]) / tau;
      break;

    case mjDYN_MUSCLE:              // muscle model: dynprm = (tau_act, tau_deact)
      d->act_dot[act_last] = mju_muscleDynamics(ctrl[uadr], d->act[act_last], dynprm);
      break;

    case mjDYN_PID: {               // PID controller states, slot order: slew, integral
      int adr = act_first;
      mjtNum period = wrapPeriod(m, i);

      // slew rate limiting of the position setpoint
      mjtNum slew_s = dynprm[1];
      if (slew_s > 0) {
        ctrl[uadr] = slewLimit(ctrl[uadr], d->act[adr], slew_s, m->opt.timestep,
                               period, d->act_dot + adr);
        adr++;
      }

      // integral of the position error
      if (m->actuator_gainprm[mjNGAIN*i] > 0) {
        mjtNum err = ctrl[uadr] - d->actuator_length[oadr];

        // rotational transmission: error on the circle
        if (period > 0) {
          err -= period*mju_round(err/period);
        }

        // anti-windup: stop accumulating beyond imax
        mjtNum imax = dynprm[0];
        if (imax > 0) {
          mjtNum z = d->act[adr];
          if (z >= imax) {
            err = mju_min(err, 0);
          } else if (z <= -imax) {
            err = mju_max(err, 0);
          }
        }
        d->act_dot[adr] = err;
      }
      break;
    }

    case mjDYN_DCMOTOR: {           // DC motor: up to 5 optional states
      const mjtNum* gainprm = m->actuator_gainprm + mjNGAIN*i;

      // verify allocated state size matches parameters; SHOULD NOT OCCUR
      if (mj_dcmotorSlots(dynprm, gainprm).num_slots != actnum) {
        mjERROR("inconsistent state array dimension in DC motor (actuator %d)", i);
      }

      int adr = act_first;
      mjtNum velocity = d->actuator_velocity[oadr];
      mjtNum R = gainprm[0];   // resistance
      mjtNum K = gainprm[1];   // motor constant
      mjtNum ki = gainprm[5];  // integral gain
      mjtNum te = dynprm[0];   // electrical time constant

      // slot order: slew, integral, temperature, bristle, current

      // controller state: slew rate limiting
      mjtNum slew_s = dynprm[7];  // slew rate limit
      if (slew_s > 0) {
        ctrl[uadr] = slewLimit(ctrl[uadr], d->act[adr], slew_s, m->opt.timestep,
                               0, d->act_dot + adr);
        adr++;
      }

      // controller state: integral of the position error (setpoint mode only)
      mjtNum x_I = 0;
      if (ki > 0) {
        x_I = d->act[adr];
        mjtNum Imax = dynprm[8];   // integral clamp
        mjtNum act_dot = ctrl[uadr] - d->actuator_length[oadr];

        // clamp act_dot based on integral state
        if (Imax > 0) {
          if (x_I >= Imax) {
            act_dot = mju_min(act_dot, 0);
          } else if (x_I <= -Imax) {
            act_dot = mju_max(act_dot, 0);
          }
        }
        d->act_dot[adr] = act_dot;
        adr++;
      }

      // compute physical voltage to feed into current and temperature equations
      mjtNum V = dcmotorVoltage(ctrl + uadr, m->actuator_ctrlspec[i],
                                d->actuator_length[oadr], velocity, x_I, gainprm);

      // temperature: dT/dt = (R*i^2 - T/RT) / C, where T = delta above ambient
      mjtNum RT = dynprm[2];  // thermal resistance
      if (RT > 0) {
        mjtNum C = dynprm[3];       // thermal capacitance
        mjtNum Ta = dynprm[4];      // ambient temperature
        mjtNum alpha = gainprm[2];  // temperature coefficient
        mjtNum T0 = gainprm[3];     // reference temperature
        mjtNum T = d->act[adr];     // temperature rise above ambient
        R *= 1 + alpha * (T + Ta - T0);

        // get current: from act_last if stateful, from (V - K*omega)/R if stateless
        mjtNum current = (te > 0) ? d->act[act_last] : (V - K * velocity) / R;
        d->act_dot[adr] = (R*current*current - T / RT) / C;
        adr++;
      }

      // LuGre bristle state: dz/dt = v - sigma0 * |v| / g(v) * z
      mjtNum sigma0 = dynprm[5];  // bristle stiffness
      if (sigma0 > 0) {
        const mjtNum* biasprm = m->actuator_biasprm + mjNBIAS*i;
        mjtNum F_C = biasprm[3];  // Coulomb friction
        mjtNum F_S = biasprm[4];  // static friction
        mjtNum v_S = biasprm[5];  // Stribeck velocity
        mjtNum z = d->act[adr];   // bristle state
        mjtNum g = mj_lugreStribeck(velocity, F_C, F_S, v_S);
        mjtNum a = -sigma0 * mju_abs(velocity) / mju_max(mjMINVAL, g);
        d->act_dot[adr] = a * z + velocity;
        adr++;
      }

      // current state: di/dt = (V/R - K/R*omega - i) / te
      if (te > 0) {
        mjtNum dimax = dynprm[1];  // current rate limit (di/dt)_max
        mjtNum i_dot = (V/R - K/R*velocity - d->act[act_last]) / te;
        if (dimax > 0) {
          i_dot = mju_clip(i_dot, -dimax, dimax);
        }
        d->act_dot[act_last] = i_dot;
      }
      break;
    }

    default:                        // user dynamics
      if (mjcb_act_dyn) {
        if (actnum == 1) {
          // scalar activation dynamics, get act_dot
          d->act_dot[act_last] = mjcb_act_dyn(m, d, i);
        } else {
          // higher-order dynamics, mjcb_act_dyn writes into act_dot directly
          mjcb_act_dyn(m, d, i);
        }
      }
    }
  }

  // get act_dot from actuator plugins
  if (m->nplugin) {
    const int nslot = mjp_pluginCount();
    for (int i=0; i < m->nplugin; i++) {
      const int slot = m->plugin[i];
      const mjpPlugin* plugin = mjp_getPluginAtSlotUnsafe(slot, nslot);
      if (!plugin) {
        mjERROR("invalid plugin slot: %d", slot);
      }
      if (plugin->capabilityflags & mjPLUGIN_ACTUATOR) {
        if (plugin->actuator_act_dot) {
          plugin->actuator_act_dot(m, d, i);
        }
      }
    }
  }

  // force = gain .* [ctrl/act] + bias
  for (int i=0; i < nactuator; i++) {
    // skip if sleeping
    if (sleep_filter && mj_sleepState(m, d, mjOBJ_ACTUATOR, i) == mjS_ASLEEP) {
      continue;
    }

    // skip if disabled
    if (mj_actuatorDisabled(m, i)) {
      continue;
    }

    // skip actuator plugins -- these are handled after builtin actuator types
    if (m->actuator_plugin[i] >= 0) {
      continue;
    }

    // addresses of the actuator's input and output blocks
    int uadr = m->actuator_ctrladr[i];
    int oadr = m->actuator_outadr[i];

    // SO(3) geodesic servo: 3 or 4 inputs and 3 outputs on an SO3 transmission
    if (m->actuator_gaintype[i] == mjGAIN_SO3) {
      mjtNum q_tgt[4];

      // quat input: normalize ctrl directly (zero maps to the identity)
      if (m->actuator_ctrlspec[i] == mjCHART_QUAT) {
        mju_copy4(q_tgt, ctrl + uadr);
        mju_normalize4(q_tgt);
      }

      // expmap input: ctrl block (position) or act block (integrator)
      else {
        mjtNum u[3];
        if (m->actuator_dyntype[i] == mjDYN_NONE) {
          mju_copy3(u, ctrl + uadr);
        } else {
          int act_adr = m->actuator_actadr[i];
          if (m->actuator_actearly[i]) {
            for (int k=0; k < 3; k++) {
              u[k] = mj_nextActivation(m, d, i, act_adr+k, d->act_dot[act_adr+k]);
            }
          } else {
            mju_copy3(u, d->act + act_adr);
          }
        }
        expmap2Quat(q_tgt, u);
      }

      // error rotation from current to target: e = log(q_cur^-1 * q_tgt), in the local frame
      // of the transmission, matching the frame of the moment rows and of actuator_velocity
      // note: the force is invariant to the setpoint representative (exp is ray-periodic),
      // so no wrapping is required; act is re-anchored at integration time in mj_advance
      mjtNum q_cur[4], e[3];
      expmap2Quat(q_cur, d->actuator_length + oadr);
      mji_subQuat(e, q_tgt, q_cur);

      // output force: kp * error + constant - kv * velocity
      mjtNum kp = m->actuator_gainprm[mjNGAIN*i];
      const mjtNum* prm = m->actuator_biasprm + mjNBIAS*i;
      for (int k=0; k < 3; k++) {
        force[oadr+k] = kp*e[k] + prm[0] + prm[2]*d->actuator_velocity[oadr+k];
      }
      continue;
    }

    // check for tendon transmission with force limits
    if (ntendon && !tendon_frclimited && m->actuator_trntype[i] == mjTRN_TENDON) {
      tendon_frclimited = m->tendon_actfrclimited[m->actuator_trnid[2*i]];
    }

    // extract info
    const mjtNum* dynprm = m->actuator_dynprm + mjNDYN*i;
    const mjtNum* gainprm = m->actuator_gainprm + mjNGAIN*i;
    mjtGain gaintype = m->actuator_gaintype[i];
    int actnum = m->actuator_actnum[i];

    // handle SISO actuators according to gain type
    switch (gaintype) {
    case mjGAIN_FIXED:              // fixed gain: prm = gain
      gain = gainprm[0];
      break;

    case mjGAIN_PID:                // PID servo: input side handled below, state side in bias
      gain = 0;
      break;

    case mjGAIN_AFFINE:             // affine: prm = [const, kp, kv]
      gain = gainprm[0] + gainprm[1]*d->actuator_length[oadr] +
             gainprm[2]*d->actuator_velocity[oadr];
      break;

    case mjGAIN_MUSCLE:             // muscle gain
      gain = mju_muscleGain(d->actuator_length[oadr],
                            d->actuator_velocity[oadr],
                            m->actuator_lengthrange+2*oadr,
                            m->actuator_acc0[oadr],
                            gainprm);
      break;

    case mjGAIN_DCMOTOR: {          // DC motor: gain = K or K/R
      mjtNum R = mj_dcmotorResistance(m, d, i);  // motor resistance
      mjtNum K = gainprm[1];                     // motor constant
      mjDCMotorSlots slots = mj_dcmotorSlots(dynprm, gainprm);

      // verify allocated state size matches parameters; SHOULD NOT OCCUR
      if (slots.num_slots != actnum) {
        mjERROR("inconsistent state array dimension in DC motor (actuator %d)", i);
      }

      // stateful current: gain = K, force = K * act[last] (generic path)
      // stateless: gain = K/R, force = K/R * ctrl (condition below)
      gain = (dynprm[0] > 0) ? K : K / R;

      // controller: compute voltage, override ctrl[uadr] for force computation
      // (pure raw-voltage motor reads ctrl directly; empty block reads as 0 below)
      if (m->actuator_ctrlspec[i] != mjINPUT_VOLTAGE && m->actuator_ctrlnum[i] > 0) {
        mjtNum x_I = (slots.integral >= 0) ? d->act[m->actuator_actadr[i]+slots.integral] : 0;
        ctrl[uadr] = dcmotorVoltage(ctrl + uadr, m->actuator_ctrlspec[i],
                                    d->actuator_length[oadr],
                                    d->actuator_velocity[oadr], x_I, gainprm);
      }
      break;
    }

    case mjGAIN_SO3:                // handled above via early continue
      mjERROR("mjGAIN_SO3 reached SISO switch (actuator %d)", i);
      break;

    default:                        // user gain
      if (mjcb_act_gain) {
        gain = mjcb_act_gain(m, d, i);
      } else {
        gain = 1;
      }
    }

    // set force = gain .* [ctrl/act]

    // DC motor without current state: use ctrl even if other activations exist
    int dcmotor_no_current = (gaintype == mjGAIN_DCMOTOR && dynprm[0] <= 0);

    // PID servo: force = kp*(qref - l) + kv*(vref - l_dot) [+ ff] [+ ki*z]
    // input-side terms computed here; state-side terms added by the affine bias below
    if (gaintype == mjGAIN_PID) {
      const mjtNum* prm = m->actuator_biasprm + mjNBIAS*i;

      // unpack present inputs in canonical order [pos, vel, ff]; absent input: setpoint 0
      mjtNum u4[4];
      unpackServoInputs(ctrl + uadr, m->actuator_ctrlspec[i], u4);
      mjtNum qref = u4[0], vref = u4[1], ff = u4[2];

      // position setpoint: representative nearest the length on rotational transmissions
      mjtNum period = wrapPeriod(m, i);
      if (period > 0) {
        qref = wrapSetpoint(qref, d->actuator_length[oadr], period);
      }

      // kp and kv are single-sourced in the affine bias parameters
      force[oadr] = -prm[1]*qref - prm[2]*vref + ff;

      // integral state (last slot): force += ki * z
      if (actnum && gainprm[0] > 0) {
        int act_adr = m->actuator_actadr[i] + actnum - 1;
        mjtNum z = m->actuator_actearly[i]
                       ? mj_nextActivation(m, d, i, act_adr, d->act_dot[act_adr])
                       : d->act[act_adr];
        force[oadr] += gainprm[0]*z;
      }
    }
    else if (actnum == 0 || dcmotor_no_current) {
      // empty input block (passive dcmotor): input is 0
      mjtNum input = m->actuator_ctrlnum[i] ? ctrl[uadr] : 0;

      // rotational setpoint: use representative nearest the length (local, no state change)
      mjtNum period = wrapPeriod(m, i);
      if (period > 0) {
        input = wrapSetpoint(input, d->actuator_length[oadr], period);
      }
      force[oadr] = gain * input;
    } else {
      // use last activation variable associated with actuator i
      int act_adr = m->actuator_actadr[i] + actnum - 1;

      mjtNum act;
      if (m->actuator_actearly[i]) {
        act = mj_nextActivation(m, d, i, act_adr, d->act_dot[act_adr]);
      } else {
        act = d->act[act_adr];
      }

      // rotational setpoint: use representative nearest the length (local, no state change)
      mjtNum period = wrapPeriod(m, i);
      if (period > 0) {
        act = wrapSetpoint(act, d->actuator_length[oadr], period);
      }
      force[oadr] = gain * act;
    }

    // extract bias info
    const mjtNum* biasprm = m->actuator_biasprm + mjNBIAS*i;
    mjtBias biastype = m->actuator_biastype[i];

    // handle according to bias type
    switch (biastype) {
    case mjBIAS_NONE:               // none
      bias = 0.0;
      break;

    case mjBIAS_AFFINE:             // affine: biasprm = [const, kp, kv]
      bias = biasprm[0] + biasprm[1]*d->actuator_length[oadr] +
             biasprm[2]*d->actuator_velocity[oadr];
      break;

    case mjBIAS_MUSCLE:             // muscle passive force
      bias =  mju_muscleBias(d->actuator_length[oadr],
                             m->actuator_lengthrange+2*oadr,
                             m->actuator_acc0[oadr],
                             biasprm);
      break;

    case mjBIAS_DCMOTOR: {          // DC motor: back-EMF only (current-limited)
      bias = 0;

      // back-EMF (stateless only; for stateful current it's in the ODE)
      mjtNum te = m->actuator_dynprm[mjNDYN*i];  // electrical time constant
      if (te <= 0) {
        mjtNum K = gainprm[1];   // motor constant
        bias -= gain * K * d->actuator_velocity[oadr];
      }
      break;
    }

    default:                        // user bias
      if (mjcb_act_bias) {
        bias = mjcb_act_bias(m, d, i);
      } else {
        bias = 0;
      }
    }

    // add bias
    force[oadr] += bias;
  }

  // handle actuator plugins
  if (m->nplugin) {
    const int nslot = mjp_pluginCount();
    for (int i=0; i < m->nplugin; i++) {
      const int slot = m->plugin[i];
      const mjpPlugin* plugin = mjp_getPluginAtSlotUnsafe(slot, nslot);
      if (!plugin) {
        mjERROR("invalid plugin slot: %d", slot);
      }
      if (plugin->capabilityflags & mjPLUGIN_ACTUATOR) {
        if (!plugin->compute) {
          mjERROR("`compute` is a null function pointer for plugin at slot %d", slot);
        }
        plugin->compute(m, d, i, mjPLUGIN_ACTUATOR);
      }
    }
  }

  // clamp tendon total actuator force
  if (tendon_frclimited) {
    // compute total force for each tendon
    mjtNum* tendon_total_force = mjSTACKALLOC(d, ntendon, mjtNum);
    mju_zero(tendon_total_force, ntendon);
    for (int i=0; i < nactuator; i++) {
      if (m->actuator_trntype[i] == mjTRN_TENDON) {
        int tendon_id = m->actuator_trnid[2*i];
        if (m->tendon_actfrclimited[tendon_id]) {
          tendon_total_force[tendon_id] += force[m->actuator_outadr[i]];
        }
      }
    }

    // scale tendon actuator forces if limited and outside range
    for (int i=0; i < nactuator; i++) {
      if (m->actuator_trntype[i] != mjTRN_TENDON) {
        continue;
      }
      int tendon_id = m->actuator_trnid[2*i];
      mjtNum tendon_force = tendon_total_force[tendon_id];
      if (m->tendon_actfrclimited[tendon_id] && tendon_force) {
        const mjtNum* range = m->tendon_actfrcrange + 2 * tendon_id;
        if (tendon_force < range[0]) {
          force[m->actuator_outadr[i]] *= range[0] / tendon_force;
        } else if (tendon_force > range[1]) {
          force[m->actuator_outadr[i]] *= range[1] / tendon_force;
        }
      }
    }
  }

  // clamp actuator_force
  for (int i=0; i < nactuator; i++) {
    if (!m->actuator_forcelimited[i]) {
      continue;
    }
    const mjtNum* range = m->actuator_forcerange + 2*i;
    mjtNum* f = force + m->actuator_outadr[i];

    // SO3: clamp the norm of the output torque, preserving its direction
    if (m->actuator_gaintype[i] == mjGAIN_SO3) {
      mjtNum norm = mju_norm3(f);
      if (norm > range[1]) {
        mju_scl3(f, f, range[1]/norm);
      }
    }

    // otherwise: clamp each output
    else {
      int outnum = m->actuator_outnum[i];
      for (int j=0; j < outnum; j++) {
        f[j] = mju_clip(f[j], range[0], range[1]);
      }
    }
  }

  // add DC motor mechanical forces (not subject to current limits)
  for (int i=0; i < nactuator; i++) {
    if (m->actuator_biastype[i] != mjBIAS_DCMOTOR) {
      continue;
    }
    if (sleep_filter && mj_sleepState(m, d, mjOBJ_ACTUATOR, i) == mjS_ASLEEP) {
      continue;
    }
    if (mj_actuatorDisabled(m, i) || m->actuator_plugin[i] >= 0) {
      continue;
    }

    const mjtNum* biasprm = m->actuator_biasprm + mjNBIAS*i;
    const mjtNum* dynprm = m->actuator_dynprm + mjNDYN*i;
    int oadr = m->actuator_outadr[i];

    // cogging torque
    mjtNum A = biasprm[0];
    if (A != 0) {
      mjtNum Np = biasprm[1];
      mjtNum phi = biasprm[2];
      force[oadr] += A * mju_sin(Np*d->actuator_length[oadr] + phi);
    }

    // LuGre friction
    mjtNum sigma0 = dynprm[5];
    if (sigma0 > 0) {
      mjtNum sigma1 = dynprm[6];
      mjDCMotorSlots slots = mj_dcmotorSlots(dynprm, m->actuator_gainprm + mjNGAIN*i);
      int adr = m->actuator_actadr[i] + slots.bristle;
      mjtNum z = d->act[adr];
      mjtNum z_dot = d->act_dot[adr];
      force[oadr] -= sigma0 * z + sigma1 * z_dot;
    }
  }

  // qfrc_actuator = moment' * force
  mju_mulMatTVecSparse(d->qfrc_actuator, d->actuator_moment, force, nout, nv,
                       d->moment_rownnz, d->moment_rowadr, d->moment_colind);

  // actuator-level gravity compensation
  if (m->flg_gravcomp && !mjDISABLED(mjDSBL_GRAVITY) && mju_norm3(m->opt.gravity)) {
    // number of dofs for each joint type: {mjJNT_FREE, mjJNT_BALL, mjJNT_SLIDE, mjJNT_HINGE}
    static const int jnt_dofnum[4] = {6, 3, 1, 1};
    int njnt = m->njnt;
    for (int i=0; i < njnt; i++) {
      // skip if gravcomp added as passive force
      if (!m->jnt_actgravcomp[i]) {
        continue;
      }

      // add gravcomp force
      int dofnum = jnt_dofnum[m->jnt_type[i]];
      int dofadr = m->jnt_dofadr[i];
      mju_addTo(d->qfrc_actuator + dofadr, d->qfrc_gravcomp + dofadr, dofnum);
    }
  }

  // clamp qfrc_actuator to joint-level actuator force limits
  clampVec(d->qfrc_actuator, m->jnt_actfrcrange, m->jnt_actfrclimited, m->njnt, m->jnt_dofadr);

  mj_freeStack(d);
  TM_END(mjTIMER_ACTUATION);
}
