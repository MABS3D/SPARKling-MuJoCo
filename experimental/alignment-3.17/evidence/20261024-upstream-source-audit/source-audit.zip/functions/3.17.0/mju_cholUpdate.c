int mju_cholUpdate(mjtNum* restrict mat, mjtNum* restrict x, int n, int flg_plus) {
  int rank = n;
  mjtNum r, c, cinv, s, Lkk, tmp;

  for (int k=0; k < n; k++) {
    if (x[k]) {
      // prepare constants
      Lkk = mat[k*(n+1)];
      tmp = Lkk*Lkk + (flg_plus ? x[k]*x[k] : -x[k]*x[k]);
      if (tmp < mjMINVAL) {
        tmp = mjMINVAL;
        rank--;
      }
      r = mju_sqrt(tmp);
      c = r / Lkk;
      cinv = 1 / c;
      s = x[k] / Lkk;

      // update diagonal
      mat[k*(n+1)] = r;

      // update mat and x
      mjtNum s_signed = flg_plus ? s : -s;
      for (int i=k+1; i < n; i++) {
        mjtNum m = (mat[i*n+k] + s_signed*x[i])*cinv;
        mat[i*n+k] = m;
        x[i] = c*x[i] - s*m;
      }
    }
  }

  return rank;
}
