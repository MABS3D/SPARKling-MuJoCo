static mjtNum inertiaScale(const mjModel* m, const mjData* d, int island) {
  int nv = island < 0 ? m->nv : d->island_nv[island];
  const int* dofs = island < 0 ? NULL : d->map_idof2dof + d->island_idofadr[island];
  mjtNum trace = 0;
  for (int i=0; i < nv; i++) {
    int dof = dofs ? dofs[i] : i;
    trace += d->M[m->M_rowadr[dof] + m->M_rownnz[dof] - 1];
  }
  return 1 / mju_max(mjMINVAL, trace);
}
