from pathlib import Path
import hashlib,json,sys,traceback
import mujoco
out=Path(sys.argv[1]);expected=sys.argv[2]
report={'expected_version':expected,'actual_version':mujoco.__version__,'python':sys.executable,'module':mujoco.__file__,'stages':[]}
assert mujoco.__version__==expected
xml=(out.parent/'model.xml').read_text();report['xml_sha256']=hashlib.sha256(xml.encode()).hexdigest()
for p in Path(mujoco.__file__).parent.glob('libmujoco.so*'):
 report.setdefault('libraries',[]).append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
def meta(m):
 return {'nv':int(m.nv),'ntendon':int(m.ntendon),'nJten':int(m.nJten),'ten_J_rownnz':m.ten_J_rownnz.tolist(),'ten_J_rowadr':m.ten_J_rowadr.tolist(),'ten_J_colind':m.ten_J_colind.tolist()}
stage='compile'
try:
 m=mujoco.MjModel.from_xml_string(xml);report['stages'].append({'stage':stage,'passed':True,'model':meta(m)})
 stage='save';path=out/'model.mjb';mujoco.mj_saveModel(m,str(path),None);report['stages'].append({'stage':stage,'passed':True,'path':str(path),'size':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 stage='reload';loaded=mujoco.MjModel.from_binary_path(str(path));report['stages'].append({'stage':stage,'passed':True,'model':meta(loaded)})
 stage='forward';data=mujoco.MjData(loaded);mujoco.mj_forward(loaded,data);report['stages'].append({'stage':stage,'passed':True,'ten_J':data.ten_J.tolist(),'ten_length':data.ten_length.tolist()})
except Exception as exc:
 report['stages'].append({'stage':stage,'passed':False,'exception':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
report['all_stages_passed']=all(x['passed'] for x in report['stages']) and len(report['stages'])==4
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
