"""Regression proposal: run against a MuJoCo wheel; red on unpatched C3.17."""
from pathlib import Path
import tempfile
import unittest
import mujoco

XML = '''<mujoco><option jacobian="sparse"/><worldbody><body><joint name="j"/><geom type="sphere" size="0.1" mass="1"/></body>{extra}</worldbody><tendon><fixed><joint joint="j" coef="1"/><joint joint="j" coef="2"/></fixed></tendon></mujoco>'''

class DuplicateFixedTendon(unittest.TestCase):
    def roundtrip(self, extra, nv):
        original = mujoco.MjModel.from_xml_string(XML.format(extra=extra))
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/"model.mjb"
            mujoco.mj_saveModel(original, str(path), None)
            loaded = mujoco.MjModel.from_binary_path(str(path))
        self.assertEqual(loaded.nv, nv)
        self.assertEqual(loaded.ten_J_rownnz.tolist(), [2])
        self.assertEqual(loaded.ten_J_colind.tolist(), [0, 0])
        data = mujoco.MjData(loaded)
        mujoco.mj_forward(loaded, data)
        self.assertEqual(data.ten_J.tolist(), [3.0, 0.0])

    def test_duplicate_terms_one_dof(self):
        self.roundtrip("", 1)

    def test_same_duplicate_terms_two_dof(self):
        self.roundtrip('<body><joint/><geom type="sphere" size="0.1" mass="1"/></body>', 2)

if __name__ == "__main__":
    unittest.main(verbosity=2)
