#include <stdint.h>
#include <mujoco/mjtype.h>
static int validateSparse(int nrows, int ncols, mjtSize nnz,
                          const int* rownnz, const int* rowadr, const int* colind,
                          int strict) {
  for (int r=0; r < nrows; r++) {
    int nnz_r = rownnz[r];
    if (nnz_r < 0 || nnz_r > ncols) {
      return 1;
    }
    int adr_r = rowadr[r];
    if (adr_r < 0 || (mjtSize)adr_r + nnz_r > nnz) {
      return 2;
    }
    for (int k=0; k < nnz_r; k++) {
      int col = colind[adr_r+k];
      if (col < 0 || col >= ncols) {
        return 3;
      }
      if (k > 0) {
        int prev = colind[adr_r+k-1];
        if (strict ? (col <= prev) : (col < prev)) {
          return 3;
        }
      }
    }
  }
  return 0;
}
int probe_validate(int nr, int nc, int64_t nnz, const int* w, const int* a, const int* c, int strict) {
  return validateSparse(nr, nc, (mjtSize)nnz, w, a, c, strict);
}
