from pathlib import Path
import subprocess,json
root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');runs=[]
for scope in ['Row_Entry','Ordered_Positions','Reject_Column','Find_Column','Subset_Model','Sorted_Subset','Rows_Equal']:
 out=Path('/var/tmp/sparkling-structures-'+scope.lower()+'-r148-20261024')
 cmd=['python3',str(root/'experimental/alignment-3.17/tests/check_structures.py'),'--foundation','/var/tmp/sparkling-alignment-317-foundation-r5-20261024','--out',str(out),'--subprogram',scope]
 r=subprocess.run(cmd,cwd=root);runs.append(dict(scope=scope,command=cmd,exit=r.returncode))
 Path('/var/tmp/sparkling-structures-search-minima-r148-20261024.json').write_text(json.dumps(runs,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
