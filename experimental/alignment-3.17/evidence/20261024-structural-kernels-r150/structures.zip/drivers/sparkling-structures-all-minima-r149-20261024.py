from pathlib import Path
import subprocess,json
root=Path('/mnt/c/Users/Chello/Desktop/Sparkling Mujoco');runs=[]
scopes=['Span','Width_OK','Column_OK','Columns_OK','Row_Valid','Check_Row','Matrix_Shape','Matrix_Valid','Check_CSR','Row_Entry','Ordered_Positions','Reject_Column','Find_Column','Subset_Model','Sorted_Subset','Rows_Equal','Body_Links','Body_Count_Model','Unfold_Body_Count','Ancestor_Count','Dof_Links','Dof_Count_Model','Unfold_Dof_Count','Dof_Count','Row_Length','Mass_Links','Mass_Ancestor_Equal','Diagonal_Valid']
for scope in scopes:
 out=Path('/var/tmp/sparkling-structures-'+scope.lower()+'-r149-20261024')
 cmd=['python3',str(root/'experimental/alignment-3.17/tests/check_structures.py'),'--foundation','/var/tmp/sparkling-alignment-317-foundation-r5-20261024','--out',str(out),'--subprogram',scope]
 r=subprocess.run(cmd,cwd=root);runs.append(dict(scope=scope,command=cmd,exit=r.returncode))
 Path('/var/tmp/sparkling-structures-all-minima-r149-20261024.json').write_text(json.dumps(runs,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
