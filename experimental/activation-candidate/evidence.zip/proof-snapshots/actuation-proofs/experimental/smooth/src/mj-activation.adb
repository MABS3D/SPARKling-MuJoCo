with Ada.Numerics.Long_Elementary_Functions;
package body MJ.Activation with SPARK_Mode is
   function Exact_Factor (H : Nonneg_Tier0; Tau : Time_Constant) return Decay_Factor is
      X : constant Real := H / Tau;
      E : Real;
   begin
      if H = 0.0 then return 0.0; end if;
      --  exp(-40) is below half an ulp at one: the C factor rounds to 1.
      --  This also keeps the elementary-function argument in a small domain.
      if X > 40.0 then return 1.0; end if;
      declare
         subtype Small_Exponent is Real range -40.0 .. 0.0;
         Argument : constant Small_Exponent := -X;
      begin
         E := Ada.Numerics.Long_Elementary_Functions.Exp (Argument);
      end;
      if E <= 0.0 then return 1.0; end if;
      if E >= 1.0 then return 0.0; end if;
      return 1.0 - Decay_Factor (E);
   end Exact_Factor;
   function Next_Value (Kind : Dynamics; Act : Tier0_Real; Dot : Rate;
      H : Nonneg_Tier0; Tau : Time_Constant; Factor : Decay_Factor;
      Has_Limit : Boolean; Lower, Upper : Tier0_Real) return Update_Value is
      Value : constant Update_Value := Raw_Next (Kind, Act, Dot, H, Tau, Factor);
   begin
      if Has_Limit then return Real'Max (Lower, Real'Min (Upper, Value)); end if;
      return Value;
   end Next_Value;
end MJ.Activation;
