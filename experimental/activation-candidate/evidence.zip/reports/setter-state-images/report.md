# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-kxh7eei0/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Equal_State_Images` | `mj-data.adb:42` | [completed_no_unproved](logs/mj-data__equal_state_images__adb_42.log) | 3 | 0 | 0 | 26.7 |
| `Set_Activation` | `mj-data.adb:1195` | [unproved_checks](logs/mj-data__set_activation__adb_1195.log) | 40 | 1 | 0 | 126.5 |

## Diagnostics

### mj-data__set_activation__adb_1195

- `mj-data.ads:158` (medium): postcondition might fail, cannot prove Activation_Values (D) = As_Reals (Values) [provers reached time limit before completing the proof]

