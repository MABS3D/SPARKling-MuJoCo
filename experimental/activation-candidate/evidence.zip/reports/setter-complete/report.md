# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-i7uo5zej/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Equal_Activation_Images` | `mj-data.adb:42` | [completed_no_unproved](logs/mj-data__equal_activation_images__adb_42.log) | 13 | 0 | 0 | 25.3 |
| `Set_Activation` | `mj-data.adb:1204` | [completed_no_unproved](logs/mj-data__set_activation__adb_1204.log) | 43 | 0 | 0 | 134.1 |

## Diagnostics

