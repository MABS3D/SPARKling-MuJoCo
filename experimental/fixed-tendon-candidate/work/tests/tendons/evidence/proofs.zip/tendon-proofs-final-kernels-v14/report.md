# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-mgilnct8/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Polynomial_First` | `mj-tendon_kernels.adb:2` | [completed_no_unproved](logs/mj-tendon_kernels__polynomial_first__adb_2.log) | 5 | 0 | 0 | 3.3 |
| `Polynomial_Second` | `mj-tendon_kernels.adb:7` | [completed_no_unproved](logs/mj-tendon_kernels__polynomial_second__adb_7.log) | 7 | 0 | 0 | 4.3 |
| `Poly_Value` | `mj-tendon_kernels.adb:13` | [completed_no_unproved](logs/mj-tendon_kernels__poly_value__adb_13.log) | 6 | 0 | 0 | 4.3 |
| `Spring_Damper` | `mj-tendon_kernels.adb:20` | [completed_no_unproved](logs/mj-tendon_kernels__spring_damper__adb_20.log) | 7 | 0 | 0 | 24.8 |
| `Sum_Step` | `mj-tendon_kernels.adb:42` | [unproved_checks](logs/mj-tendon_kernels__sum_step__adb_42.log) | 11 | 1 | 0 | 50.9 |
| `Reduced_Bound` | `mj-tendon_kernels.adb:48` | [completed_no_unproved](logs/mj-tendon_kernels__reduced_bound__adb_48.log) | 8 | 0 | 0 | 3.1 |
| `Dot` | `mj-tendon_kernels.adb:54` | [completed_no_unproved](logs/mj-tendon_kernels__dot__adb_54.log) | 25 | 0 | 0 | 8.4 |
| `Combine` | `mj-tendon_kernels.adb:66` | [completed_no_unproved](logs/mj-tendon_kernels__combine__adb_66.log) | 20 | 0 | 0 | 9.2 |
| `Tail_Add` | `mj-tendon_kernels.adb:75` | [completed_no_unproved](logs/mj-tendon_kernels__tail_add__adb_75.log) | 13 | 0 | 0 | 5.9 |
| `Unfold_Lane` | `mj-tendon_kernels.adb:80` | [completed_no_unproved](logs/mj-tendon_kernels__unfold_lane__adb_80.log) | 17 | 0 | 0 | 4.1 |
| `Unfold_Sparse` | `mj-tendon_kernels.adb:84` | [completed_no_unproved](logs/mj-tendon_kernels__unfold_sparse__adb_84.log) | 35 | 0 | 0 | 5.1 |
| `Advance_Lane` | `mj-tendon_kernels.adb:88` | [unproved_checks](logs/mj-tendon_kernels__advance_lane__adb_88.log) | 29 | 1 | 0 | 30.1 |
| `Advance_Tail` | `mj-tendon_kernels.adb:97` | [unproved_checks](logs/mj-tendon_kernels__advance_tail__adb_97.log) | 33 | 1 | 0 | 31.4 |
| `Tail_Bound` | `mj-tendon_kernels.adb:106` | [completed_no_unproved](logs/mj-tendon_kernels__tail_bound__adb_106.log) | 10 | 0 | 0 | 3.3 |
| `Sparse_Dot` | `mj-tendon_kernels.adb:111` | [unproved_checks](logs/mj-tendon_kernels__sparse_dot__adb_111.log) | 56 | 1 | 0 | 37.4 |
| `Fixed_Kinematics` | `mj-tendon_kernels.adb:139` | [completed_no_unproved](logs/mj-tendon_kernels__fixed_kinematics__adb_139.log) | 10 | 0 | 0 | 3.3 |
| `Project` | `mj-tendon_kernels.adb:147` | [completed_no_unproved](logs/mj-tendon_kernels__project__adb_147.log) | 5 | 0 | 0 | 3.3 |
| `Mass_Entry` | `mj-tendon_kernels.adb:153` | [completed_no_unproved](logs/mj-tendon_kernels__mass_entry__adb_153.log) | 7 | 0 | 0 | 4.8 |
| `Accumulate_Mass` | `mj-tendon_kernels.adb:158` | [completed_no_unproved](logs/mj-tendon_kernels__accumulate_mass__adb_158.log) | 4 | 0 | 0 | 2.8 |
| `Project_Small` | `mj-tendon_kernels.adb:163` | [completed_no_unproved](logs/mj-tendon_kernels__project_small__adb_163.log) | 6 | 0 | 0 | 2.8 |
| `Displacement` | `mj-tendon_kernels.ads:23` | [completed_no_unproved](logs/mj-tendon_kernels__displacement__ads_23.log) | 4 | 0 | 0 | 2.3 |
| `Spring_Model` | `mj-tendon_kernels.ads:45` | [completed_no_unproved](logs/mj-tendon_kernels__spring_model__ads_45.log) | 4 | 0 | 0 | 2.8 |
| `Damper_Model` | `mj-tendon_kernels.ads:56` | [completed_no_unproved](logs/mj-tendon_kernels__damper_model__ads_56.log) | 2 | 0 | 0 | 2.6 |
| `Valid_Row` | `mj-tendon_kernels.ads:71` | [completed_no_proof_checks](logs/mj-tendon_kernels__valid_row__ads_71.log) | 0 | 0 | 0 | 2.5 |
| `Reduction` | `mj-tendon_kernels.ads:82` | [completed_no_unproved](logs/mj-tendon_kernels__reduction__ads_82.log) | 15 | 0 | 0 | 3.3 |
| `Lane_Value` | `mj-tendon_kernels.ads:99` | [completed_no_unproved](logs/mj-tendon_kernels__lane_value__ads_99.log) | 20 | 0 | 0 | 3.8 |
| `Sparse_Model` | `mj-tendon_kernels.ads:122` | [completed_no_unproved](logs/mj-tendon_kernels__sparse_model__ads_122.log) | 38 | 0 | 0 | 5.3 |

## Diagnostics

### mj-tendon_kernels__sum_step__adb_42

- `mj-tendon_kernels.ads:81` (medium): postcondition might fail, cannot prove abs Sum_Step'Result <= Real (Count + 1) * Step_Bound [provers reached time limit before completing the proof]

### mj-tendon_kernels__advance_lane__adb_88

- `mj-tendon_kernels.adb:93` (medium): assertion might fail [provers reached time limit before completing the proof]

### mj-tendon_kernels__advance_tail__adb_97

- `mj-tendon_kernels.adb:102` (medium): assertion might fail [provers reached time limit before completing the proof]

### mj-tendon_kernels__sparse_dot__adb_111

- `mj-tendon_kernels.adb:128` (medium): assertion might fail [provers reached time limit before completing the proof]

