# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-1ka86gqy/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Inertia` | `mj-data-tendon_phase.adb:38` | [unproved_checks](logs/mj-data-tendon_phase__inertia__adb_38.log) | 5 | 4 | 0 | 46.9 |
| `Passive` | `mj-data-tendon_phase.adb:8` | [proof_timeout](logs/mj-data-tendon_phase__passive__adb_8.log) | 0 | 0 | 0 | 60.1 |

## Diagnostics

### mj-data-tendon_phase__inertia__adb_38

- `mj-data-tendon_phase.adb:43` (medium): precondition might fail, cannot prove A (MJ.Smooth_Kernels.Matrix_Offset (N, I, J)) = A (MJ.Smooth_Kernels.Matrix_Offset (N, J, I)) [provers reached time limit before completing the proof]
- `mj-data-tendon_phase.adb:43` (medium): in inlined expression function body at mj-smooth_dynamics.ads:116
- `mj-data-tendon_phase.ads:12` (medium): postcondition might fail, cannot prove Stable_Ready (D) [provers reached time limit before completing the proof]
- `mj-data-tendon_phase.ads:12` (medium): in inlined expression function body at mj-data.ads:661

