# Smooth dynamics: fragmented GNATprove results

Each row is one bounded subprogram, line or whole-unit invocation on unchanged sources.
A completed row is limited to the emitted obligations and their contracts;
it is not a proof of physical correctness or of the complete simulator.
An unproved check is not, by itself, a demonstrated runtime failure.
Timeouts and jobs not yet run must not be counted as passes.

Source snapshot: `/tmp/sparkling-smooth-fragments-kookg82e/source`

| Subprogram | Location | Result | Proof checks | Unproved/flow | Errors | Seconds |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| `Load` | `mj-fixed_tendons.adb:3` | [proof_timeout](logs/mj-fixed_tendons__load__adb_3.log) | 0 | 0 | 0 | 60.2 |
| `Kinematics` | `mj-fixed_tendons.adb:131` | [completed_no_unproved](logs/mj-fixed_tendons__kinematics__adb_131.log) | 23 | 0 | 0 | 14.0 |
| `Project_Pair` | `mj-fixed_tendons.adb:142` | [completed_no_unproved](logs/mj-fixed_tendons__project_pair__adb_142.log) | 19 | 0 | 0 | 10.1 |
| `Project_Small_Pair` | `mj-fixed_tendons.adb:156` | [completed_no_unproved](logs/mj-fixed_tendons__project_small_pair__adb_156.log) | 15 | 0 | 0 | 5.9 |
| `Add_Passive` | `mj-fixed_tendons.adb:165` | [proof_timeout](logs/mj-fixed_tendons__add_passive__adb_165.log) | 0 | 0 | 0 | 60.0 |
| `Mass_Model` | `mj-fixed_tendons.ads:121` | [completed_no_unproved](logs/mj-fixed_tendons__mass_model__ads_121.log) | 14 | 0 | 0 | 4.8 |
| `Unfold_Mass` | `mj-fixed_tendons.adb:207` | [completed_no_unproved](logs/mj-fixed_tendons__unfold_mass__adb_207.log) | 13 | 0 | 0 | 5.8 |
| `Store_Mass_Pair` | `mj-fixed_tendons.adb:212` | [completed_no_unproved](logs/mj-fixed_tendons__store_mass_pair__adb_212.log) | 35 | 0 | 0 | 7.1 |
| `Add_Mass` | `mj-fixed_tendons.adb:227` | [completed_no_unproved](logs/mj-fixed_tendons__add_mass__adb_227.log) | 22 | 0 | 0 | 11.9 |

## Diagnostics

